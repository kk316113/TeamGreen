// src/app/pages/ForgotPassword.js
import { useState } from "react";
import { useNavigate, Link } from "react-router";
import { BarChart3, Mail, Lock, CheckCircle, ArrowLeft, Key } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import forgotPasswordApi from "../api/teacher/forgotPassword"; // 引入封装好的 API

export function ForgotPassword() {
    const navigate = useNavigate();
    const [step, setStep] = useState("email"); // email / verify / reset / success
    const [email, setEmail] = useState("");
    const [verificationCode, setVerificationCode] = useState("");
    const [newPassword, setNewPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [countdown, setCountdown] = useState(0);

    // 发送验证码
    const handleSendCode = async (e) => {
        e.preventDefault();
        if (!email) {
            alert("请输入邮箱地址");
            return;
        }
        try {
            const res = await forgotPasswordApi.sendForgotPasswordCode(email);
            alert(res.message || "验证码已发送到邮箱");
            setStep("verify");
            setCountdown(60);
            const timer = setInterval(() => {
                setCountdown((prev) => {
                    if (prev <= 1) {
                        clearInterval(timer);
                        return 0;
                    }
                    return prev - 1;
                });
            }, 1000);
        } catch (err) {
            alert(err.message);
        }
    };

    // 重新发送验证码
    const handleResendCode = async () => {
        if (countdown > 0) return;
        await handleSendCode({ preventDefault: () => {} });
    };

    // 验证码前端校验
    const handleVerifyCode = (e) => {
        e.preventDefault();
        if (!verificationCode) {
            alert("请输入验证码");
            return;
        }
        setStep("reset");
    };

    // 重置密码
    const handleResetPassword = async (e) => {
        e.preventDefault();
        if (!newPassword || !confirmPassword) {
            alert("请输入新密码");
            return;
        }
        if (newPassword !== confirmPassword) {
            alert("两次输入的密码不一致");
            return;
        }
        if (newPassword.length < 6) {
            alert("密码长度至少6位");
            return;
        }
        try {
            const res = await forgotPasswordApi.resetPassword(email, verificationCode, newPassword);
            alert(res.message || "密码重置成功");
            setStep("success");
        } catch (err) {
            alert(err.message);
        }
    };

    const handleBackToLogin = () => {
        navigate("/login");
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
            <div className="w-full max-w-md">
                <div className="bg-white rounded-2xl shadow-xl p-8">
                    <div className="text-center mb-8">
                        <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl mb-4 shadow-sm">
                            <BarChart3 className="w-8 h-8 text-white" />
                        </div>
                        <h1 className="text-2xl font-semibold text-gray-900 mb-2">找回密码</h1>
                        <p className="text-gray-500">教师端 - 密码重置</p>
                    </div>

                    {/* 邮箱输入 */}
                    {step === "email" && (
                        <form onSubmit={handleSendCode} className="space-y-5">
                            <div className="space-y-2">
                                <Label htmlFor="email">邮箱地址</Label>
                                <div className="relative">
                                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                                    <Input
                                        id="email"
                                        type="email"
                                        placeholder="请输入注册邮箱"
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                        className="h-11 pl-10 border-gray-200"
                                    />
                                </div>
                                <p className="text-xs text-gray-500">我们将向此邮箱发送验证码</p>
                            </div>
                            <Button type="submit" className="w-full h-11 bg-blue-600 hover:bg-blue-700 shadow-sm">
                                <Mail className="w-4 h-4 mr-2" />
                                发送验证码
                            </Button>
                            <div className="text-center">
                                <Link to="/login" className="text-sm text-gray-600 hover:text-gray-900 inline-flex items-center gap-1">
                                    <ArrowLeft className="w-4 h-4" />
                                    返回登录
                                </Link>
                            </div>
                        </form>
                    )}

                    {/* 验证码输入 */}
                    {step === "verify" && (
                        <form onSubmit={handleVerifyCode} className="space-y-5">
                            <div className="p-4 bg-blue-50 rounded-xl border border-blue-100">
                                <p className="text-sm text-blue-700">
                                    验证码已发送到 <span className="font-medium">{email}</span>
                                </p>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="code">验证码</Label>
                                <div className="relative">
                                    <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                                    <Input
                                        id="code"
                                        type="text"
                                        placeholder="请输入6位验证码"
                                        value={verificationCode}
                                        onChange={(e) => setVerificationCode(e.target.value)}
                                        maxLength={6}
                                        className="h-11 pl-10 border-gray-200"
                                    />
                                </div>
                                <div className="flex items-center justify-between text-xs">
                                    <span className="text-gray-500">请查收邮件中的验证码</span>
                                    {countdown > 0 ? (
                                        <span className="text-gray-400">{countdown}秒后可重发</span>
                                    ) : (
                                        <button type="button" onClick={handleResendCode} className="text-blue-600 hover:text-blue-700">
                                            重新发送
                                        </button>
                                    )}
                                </div>
                            </div>
                            <Button type="submit" className="w-full h-11 bg-blue-600 hover:bg-blue-700 shadow-sm">
                                验证并继续
                            </Button>
                            <div className="text-center">
                                <button type="button" onClick={() => setStep("email")} className="text-sm text-gray-600 hover:text-gray-900 inline-flex items-center gap-1">
                                    <ArrowLeft className="w-4 h-4" />
                                    返回上一步
                                </button>
                            </div>
                        </form>
                    )}

                    {/* 重置密码 */}
                    {step === "reset" && (
                        <form onSubmit={handleResetPassword} className="space-y-5">
                            <div className="space-y-2">
                                <Label htmlFor="newPassword">新密码</Label>
                                <div className="relative">
                                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                                    <Input
                                        id="newPassword"
                                        type="password"
                                        placeholder="请输入新密码（至少6位）"
                                        value={newPassword}
                                        onChange={(e) => setNewPassword(e.target.value)}
                                        className="h-11 pl-10 border-gray-200"
                                    />
                                </div>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="confirmPassword">确认密码</Label>
                                <div className="relative">
                                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                                    <Input
                                        id="confirmPassword"
                                        type="password"
                                        placeholder="请再次输入新密码"
                                        value={confirmPassword}
                                        onChange={(e) => setConfirmPassword(e.target.value)}
                                        className="h-11 pl-10 border-gray-200"
                                    />
                                </div>
                            </div>
                            {newPassword && confirmPassword && newPassword !== confirmPassword && (
                                <p className="text-sm text-red-600">两次输入的密码不一致</p>
                            )}
                            <Button type="submit" className="w-full h-11 bg-blue-600 hover:bg-blue-700 shadow-sm">
                                <Lock className="w-4 h-4 mr-2" />
                                确认重置密码
                            </Button>
                        </form>
                    )}

                    {/* 重置成功 */}
                    {step === "success" && (
                        <div className="text-center space-y-6">
                            <div className="inline-flex items-center justify-center w-20 h-20 bg-green-50 rounded-full">
                                <CheckCircle className="w-12 h-12 text-green-600" />
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold text-gray-900 mb-2">密码重置成功！</h3>
                                <p className="text-gray-500">您的密码已成功重置，请使用新密码登录</p>
                            </div>
                            <Button onClick={handleBackToLogin} className="w-full h-11 bg-blue-600 hover:bg-blue-700 shadow-sm">
                                返回登录
                            </Button>
                        </div>
                    )}

                    <div className="mt-8 pt-6 border-t border-gray-100 text-center text-sm text-gray-500">
                        © 2024 AutoGrader. 教师端管理系统
                    </div>
                </div>
            </div>
        </div>
    );
}