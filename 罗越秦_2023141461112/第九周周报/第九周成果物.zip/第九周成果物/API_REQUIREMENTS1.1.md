# AutoGrader 前端 API 需求文档

## 一、概述

### 1.1 基础配置

| 配置项 | 值 |
|--------|-----|
| 教师端 Base URL | `/api/v1/teacher` |
| 学生端 Base URL | `http://localhost:8000/api/v1` |
| 认证方式 | Bearer Token |
| 教师端 Token Key | `token` |
| 学生端 Token Key | `student_token` |
| 响应格式 | `{ code: 0, message: "success", data: {...} }` |

### 1.2 通用响应格式

```json
{
  "code": 0,
  "message": "success",
  "data": {}
}
```

---

## 二、教师端 API

### 2.1 认证相关

#### 教师登录

- **POST** `/api/v1/auth/login`
- **Request:**

```json
{
  "username": "teacher_id",
  "password": "password"
}
```

- **Response:**

```json
{
  "code": 0,
  "message": "success",
  "data": {
    "token": "string"
  }
}
```

#### 教师忘记密码

- **POST** `/api/v1/auth/forgot-password`
- **Request:**

```json
{
  "email": "teacher@school.edu.cn"
}
```

- **Response:**

```json
{
  "code": 0,
  "message": "验证码已发送到邮箱"
}
```

#### 重置密码

- **POST** `/api/v1/auth/reset-password`
- **Request:**

```json
{
  "email": "teacher@school.edu.cn",
  "code": "123456",
  "newPassword": "newPassword123"
}
```

---

### 2.2 教师端首页 `Dashboard`

#### 获取首页统计

- **GET** `/api/v1/teacher/dashboard/stats`
- **Response:**

```json
{
  "code": 0,
  "data": [
    { "title": "授课课程", "value": 5, "color": "blue" },
    { "title": "管理班级", "value": 8, "color": "green" },
    { "title": "课程任务", "value": 12, "color": "purple" },
    { "title": "待截止任务", "value": 3, "color": "orange" }
  ]
}
```

#### 获取最近导入记录

- **GET** `/api/v1/teacher/dashboard/recent-imports`
- **Response:**

```json
{
  "code": 0,
  "data": [
    {
      "id": 1,
      "fileName": "2024春季-计算机科学-学生名单.xlsx",
      "date": "2024-03-28 14:30",
      "count": 45
    }
  ]
}
```

#### 获取最近成绩摘要

- **GET** `/api/v1/teacher/dashboard/recent-grades`
- **Response:**

```json
{
  "code": 0,
  "data": [
    {
      "course": "Python程序设计",
      "assignment": "实验3：二叉树遍历",
      "avgScore": 88.5,
      "submitted": 48,
      "total": 52
    }
  ]
}
```

---

### 2.3 题库管理 `QuestionBank`

#### 获取课程列表（用于下拉框）

- **GET** `/api/v1/teacher/courses`
- **Response:**

```json
{
  "code": 0,
  "data": [
    {
      "courseId": "string",
      "courseName": "string",
      "courseCode": "string",
      "className": "string",
      "semester": "string"
    }
  ]
}
```

#### 获取题库列表

- **GET** `/api/v1/teacher/questions`
- **Query:** `courseId?`, `keyword?`, `difficulty?`
- **Response:**

```json
{
  "code": 0,
  "data": [
    {
      "questionId": "string",
      "title": "string",
      "difficulty": "easy|medium|hard",
      "description": "string",
      "languages": ["python", "java"],
      "maxScore": 100,
      "tags": ["数组", "动态规划"]
    }
  ]
}
```

#### 获取题目详情

- **GET** `/api/v1/teacher/questions/{questionId}`
- **Response:**

```json
{
  "code": 0,
  "data": {
    "questionId": "string",
    "title": "string",
    "difficulty": "easy|medium|hard",
    "description": "string",
    "languages": ["python", "java"],
    "maxScore": 100,
    "tags": ["数组"],
    "inputDescription": "string",
    "outputDescription": "string",
    "sampleInput": "string",
    "sampleOutput": "string",
    "requirements": "string",
    "constraints": "string",
    "timeLimit": 1000,
    "memoryLimit": 128
  }
}
```

#### 解析文件预览题目

- **POST** `/api/v1/teacher/questions/parse`
- **Body:** `FormData { file, type: pdf|doc|docx }`
- **Response:**

```json
{
  "code": 0,
  "data": {
    "questions": [
      {
        "title": "string",
        "difficulty": "easy|medium|hard",
        "description": "string",
        "inputDescription": "string",
        "outputDescription": "string",
        "sampleInput": "string",
        "sampleOutput": "string",
        "requirements": "string",
        "constraints": "string",
        "images": ["url1", "url2"],
        "maxScore": 100,
        "tags": ["数组"],
        "languages": ["python"],
        "timeLimit": 1000,
        "memoryLimit": 128
      }
    ]
  }
}
```

#### 导入题目

- **POST** `/api/v1/teacher/questions/import`
- **Body:** `FormData { file, courseId }`

---

### 2.4 学生管理 `StudentManagement`

#### 获取学生列表

- **GET** `/api/v1/teacher/students`
- **Query:** `name?`, `student_no?`, `major?`, `class_name?`, `course_code?`
- **Response:**

```json
{
  "code": 0,
  "data": [
    {
      "id": 1,
      "student_no": "20210001",
      "name": "张三",
      "major": "计算机科学与技术",
      "class_name": "计科2101",
      "course_code": "CS101",
      "course_seq": "01"
    }
  ]
}
```

#### 添加学生

- **POST** `/api/v1/teacher/students`
- **Request:**

```json
{
  "student_no": "20210002",
  "name": "李四",
  "major": "软件工程",
  "class_name": "软工2101",
  "course_code": "SE101",
  "course_seq": "01"
}
```

#### 更新学生

- **PUT** `/api/v1/teacher/students/{id}`
- **Request:** 同添加

#### 删除学生

- **DELETE** `/api/v1/teacher/students/{studentNo}`

#### 导出学生

- **GET** `/api/v1/teacher/students/export`
- **Query:** `courseCode?`, `className?`

---

### 2.5 学生导入 `StudentImport`

#### 导入学生

- **POST** `/api/v1/teacher/students/import`
- **Request:**

```json
{
  "class_id": 1,
  "students": [
    {
      "student_no": "2024001",
      "name": "张三",
      "courseCode": "123456789",
      "courseSeq": "01",
      "className": "计算机1班"
    }
  ]
}
```

- **Response:**

```json
{
  "code": 0,
  "data": {
    "success_count": 1,
    "failed_count": 0
  }
}
```

#### 获取导入历史

- **GET** `/api/v1/teacher/students/import/history`
- **Query:** `page?`, `page_size?`, `classId?`, `startDate?`, `endDate?`
- **Response:**

```json
{
  "code": 0,
  "data": {
    "total": 100,
    "page": 1,
    "page_size": 10,
    "records": [
      {
        "id": 1,
        "class_id": 1,
        "class_name": "计算机1班",
        "import_time": "2024-01-15 10:30:00",
        "total_count": 50,
        "success_count": 48,
        "failed_count": 2
      }
    ]
  }
}
```

#### 重新导入

- **POST** `/api/v1/teacher/students/import/history/{recordId}/reimport`

#### 删除导入记录

- **DELETE** `/api/v1/teacher/students/import/history/{recordId}`

---

### 2.6 班级管理 `ClassManagement`

#### 获取班级列表

- **GET** `/api/v1/teacher/classes`
- **Query:** `search?`
- **Response:**

```json
{
  "code": 0,
  "data": [
    {
      "id": 1,
      "class_name": "计科2101",
      "major": "计算机科学与技术",
      "grade": "2021",
      "student_count": 45,
      "course_code": "CS101",
      "course_name": "计算机基础"
    }
  ]
}
```

#### 获取课程分组班级列表

- **GET** `/api/v1/teacher/classes/grouped`
- **Query:** `courseCode?`
- **Response:**

```json
{
  "code": 0,
  "data": {
    "CS101": {
      "course_name": "计算机基础",
      "classes": [
        {
          "id": 1,
          "class_name": "计科2101",
          "student_count": 45
        },
        {
          "id": 2,
          "class_name": "计科2102",
          "student_count": 42
        }
      ]
    }
  }
}
```

#### 获取指定课程的班级

- **GET** `/api/v1/teacher/classes/course`
- **Query:** `courseCode`, `courseName`
- **Response:**

```json
{
  "code": 0,
  "data": [
    {
      "id": 1,
      "class_name": "计科2101",
      "major": "计算机科学与技术",
      "grade": "2021",
      "student_count": 45
    }
  ]
}
```

#### 获取班级学生列表

- **GET** `/api/v1/teacher/classes/{classId}/students`
- **Query:** `page?`, `pageSize?`
- **Response:**

```json
{
  "code": 0,
  "data": {
    "total": 45,
    "page": 1,
    "students": [
      {
        "id": 1,
        "student_no": "20210001",
        "name": "张三",
        "major": "计算机科学与技术",
        "class_name": "计科2101"
      }
    ]
  }
}
```

#### 获取课程学生列表

- **GET** `/api/v1/teacher/classes/students`
- **Query:** `courseCode`, `courseName`, `page?`, `pageSize?`
- **Response:**

```json
{
  "code": 0,
  "data": [
    {
      "id": 1,
      "student_no": "20210001",
      "name": "张三",
      "major": "计算机科学与技术",
      "class_name": "计科2101",
      "course_code": "CS101"
    }
  ]
}
```

#### 调整学生班级

- **POST** `/api/v1/teacher/classes/adjust`
- **Request:**

```json
{
  "studentIds": [1, 2, 3],
  "targetClass": "计科2102",
  "courseCode": "CS101",
  "courseName": "计算机基础"
}
```

- **Response:**

```json
{
  "code": 0,
  "message": "调整成功",
  "data": {
    "success_count": 3,
    "failed_count": 0,
    "failed_students": []
  }
}
```

#### 批量调整学生班级

- **POST** `/api/v1/teacher/classes/batch-adjust`
- **Request:**

```json
{
  "adjustments": [
    {
      "studentIds": [1, 2, 3],
      "targetClass": "计科2102",
      "courseCode": "CS101",
      "courseName": "计算机基础"
    },
    {
      "studentIds": [4, 5],
      "targetClass": "计科2103",
      "courseCode": "CS101",
      "courseName": "计算机基础"
    }
  ]
}
```

- **Response:**

```json
{
  "code": 0,
  "message": "批量调整成功",
  "data": {
    "total_adjustments": 2,
    "success_count": 2,
    "failed_count": 0,
    "failed_adjustments": []
  }
}
```

#### 获取班级统计

- **GET** `/api/v1/teacher/classes/statistics`
- **Response:**

```json
{
  "code": 0,
  "data": {
    "total_classes": 15,
    "total_students": 680,
    "average_students_per_class": 45,
    "class_distribution": {
      "计算机科学与技术": 5,
      "软件工程": 4,
      "网络工程": 3,
      "信息安全": 3
    }
  }
}
```

#### 获取课程统计

- **GET** `/api/v1/teacher/classes/course-statistics`
- **Response:**

```json
{
  "code": 0,
  "data": {
    "total_courses": 8,
    "total_classes": 15,
    "courses": [
      {
        "course_code": "CS101",
        "course_name": "计算机基础",
        "class_count": 3,
        "student_count": 135
      }
    ]
  }
}
```

#### 创建班级

- **POST** `/api/v1/teacher/classes`
- **Request:**

```json
{
  "class_name": "计科2104",
  "major": "计算机科学与技术",
  "grade": "2021",
  "course_code": "CS101",
  "course_name": "计算机基础"
}
```

#### 更新班级

- **PUT** `/api/v1/teacher/classes/{classId}`

#### 删除班级

- **DELETE** `/api/v1/teacher/classes/{classId}`

#### 导出班级数据

- **GET** `/api/v1/teacher/classes/export`
- **Query:** `courseCode?`, `format?` (excel)
- **Response:** 返回 Excel 文件流

---

### 2.7 任务管理 `TaskManagement`

#### 获取任务列表

- **GET** `/api/v1/teacher/tasks`
- **Query:** `keyword?`, `courseId?`, `status?` (ongoing|completed|graded)
- **Response:**

```json
{
  "code": 0,
  "data": {
    "summary": {
      "totalCount": 12,
      "ongoingCount": 5,
      "completedCount": 4,
      "gradedCount": 3
    },
    "tasks": [
      {
        "taskId": "string",
        "taskName": "string",
        "courseId": "string",
        "courseName": "string",
        "deadline": "2024-04-20 23:59:59",
        "status": "ongoing",
        "questionCount": 3,
        "submittedCount": 48,
        "totalStudents": 52,
        "averageScore": 88.5
      }
    ]
  }
}
```

---

### 2.8 成绩总览 `GradeOverview`

#### 获取成绩总览

- **GET** `/api/v1/teacher/grades/overview`
- **Query:** `keyword?`, `semester?`, `courseId?`
- **Response:**

```json
{
  "code": 0,
  "data": {
    "summary": {
      "courseCount": 8,
      "assignmentCount": 24,
      "studentCount": 320,
      "averageScore": 85.6,
      "passRate": 0.92,
      "excellentRate": 0.45
    },
    "courses": [
      {
        "courseId": "course_001",
        "courseName": "Python程序设计",
        "courseCode": "CS101",
        "className": "软件工程1班",
        "studentCount": 45,
        "assignmentCount": 5,
        "averageScore": 88.5,
        "highestScore": 98,
        "lowestScore": 62,
        "passRate": 0.95,
        "excellentRate": 0.48,
        "assignments": [
          {
            "assignmentId": "assignment_001",
            "assignmentName": "实验1：变量与输入输出",
            "deadline": "2024-04-15 23:59:59",
            "submittedCount": 43,
            "unsubmittedCount": 2,
            "averageScore": 90.2,
            "status": "ended"
          }
        ]
      }
    ]
  }
}
```

#### 获取课程成绩详情

- **GET** `/api/v1/teacher/grades/courses/{courseId}`
- **Response:**

```json
{
  "code": 0,
  "data": {
    "courseId": "string",
    "courseName": "string",
    "studentCount": 45,
    "students": [
      {
        "studentId": "string",
        "studentNo": "20210001",
        "studentName": "张三",
        "totalScore": 450,
        "averageScore": 90,
        "submittedCount": 5,
        "missingCount": 0,
        "rank": 1,
        "assignmentScores": [
          {
            "assignmentId": "assignment_001",
            "assignmentName": "实验1",
            "score": 95
          }
        ]
      }
    ]
  }
}
```

#### 获取作业成绩明细

- **GET** `/api/v1/teacher/grades/assignments/{assignmentId}`
- **Response:**

```json
{
  "code": 0,
  "data": {
    "assignmentId": "string",
    "assignmentName": "string",
    "totalStudents": 45,
    "submittedCount": 43,
    "unsubmittedCount": 2,
    "averageScore": 88.5,
    "students": [
      {
        "studentId": "string",
        "studentNo": "20210001",
        "studentName": "张三",
        "submitStatus": "submitted|unsubmitted",
        "judgeStatus": "pending|judging|finished|failed",
        "score": 95,
        "submitTime": "2024-04-14 14:30:00",
        "rank": 1
      }
    ]
  }
}
```
### 2.9 教师端个人中心 `Profile`

#### 获取教师个人信息

- **GET** `/api/v1/teacher/profile`
- **Headers:**`Authorization: Bearer {token}`
- **Response:**

```json
{
  "code": 0,
  "message": "成功",
  "data": {
    "id": 123,
    "name": "张老师",
    "email": "zhang@school.edu.cn",
    "phone": "138****5678",
    "department": "计算机科学系",
    "title": "副教授",
    "office": "信息楼 A305",
    "bio": "主要研究方向：Python程序设计...",
    "stats": {
      "courses": 8,
      "students": 328
    }
  }
}
```
#### 修改教师个人信息

- **PUT** `/api/v1/teacher/profile`
- **Headers:**`Authorization: Bearer {token}`
- **Request:**

```json
{
  "name": "张老师",                  // 必传：姓名
  "email": "zhang@school.edu.cn",    // 必传：邮箱
  "phone": "138****5678",             // 可选：手机号
  "department": "计算机科学系",        // 可选：院系
  "title": "副教授",                 // 可选：职称
  "office": "信息楼 A305",            // 可选：办公室
  "bio": "主要研究方向：Python程序设计..." // 可选：个人简介
}
```
- **Response:**

```json
{
  "code": 0,
  "message": "保存成功"
}
```
#### 修改密码

- **PUT** `/api/v1/teacher/change-password`
- **Headers:**`Authorization: Bearer {token}`
- **Request:**

```json
{
  "oldPassword": "OldPwd123!",  // 必传：旧密码
  "newPassword": "NewPwd456@"   // 必传：新密码
}
```
- **Response(成功):**

```json
{
  "code": 0,
  "message": "密码修改成功"
}
```
- **Response(失败):**

```json
{
  "code": 400,
  "message": "旧密码错误"
}
```
---

## 三、学生端 API

### 3.1 认证相关

#### 学生登录

- **POST** `http://localhost:8000/api/v1/auth/login`
- **Request:**

```json
{
  "username": "2024001",
  "password": "password"
}
```

- **Response:**

```json
{
  "code": 0,
  "message": "success",
  "data": {
    "token": "string"
  }
}
```

#### 获取当前用户

- **GET** `http://localhost:8000/api/v1/auth/me`
- **Headers:** `Authorization: Bearer {token}`
- **Response:**

```json
{
  "code": 0,
  "data": {
    "user_id": 1,
    "role": "student"
  }
}
```

---

### 3.2 学生首页 `StudentDashboard`

#### 获取首页数据

- **GET** `/api/v1/student/dashboard`
- **Headers:** `Authorization: Bearer {student_token}`
- **Response:**

```json
{
  "code": 0,
  "data": {
    "totalTasks": 12,
    "pendingTasks": 3,
    "completedTasks": 9,
    "recentSubmissions": [
      {
        "assignment": "实验3：二叉树遍历",
        "submit_time": "2024-03-28 14:30",
        "status": "completed",
        "status_text": "已完成"
      }
    ]
  }
}
```

---

### 3.3 作业列表 `MyTasks`

#### 获取作业列表

- **GET** `http://localhost:8000/api/v1/assignments`
- **Headers:** `Authorization: Bearer {student_token}`
- **Response:**

```json
{
  "code": 0,
  "data": {
    "items": [
      {
        "assignment_id": 1,
        "course_name": "Python程序设计",
        "assignment_name": "实验1：变量与输入输出",
        "deadline": "2024-04-15 23:59:59",
        "status": "pending",
        "problem_ids": [1, 2]
      }
    ]
  }
}
```

---

### 3.4 题目详情 `TaskDetail`

#### 获取题目详情

- **GET** `http://localhost:8000/api/v1/problems/{problemId}`
- **Headers:** `Authorization: Bearer {student_token}`
- **Response:**

```json
{
  "code": 0,
  "data": {
    "problem_id": 1,
    "title": "两数之和",
    "description": "给定一个整数数组 nums...",
    "inputDescription": "第一行输入整数n，第二行输入n个整数",
    "outputDescription": "输出两数之和",
    "sampleInput": "5\n2 7 11 15",
    "sampleOutput": "9",
    "requirements": "1. 使用哈希表\n2. 时间复杂度O(n)",
    "constraints": "2 <= nums.length <= 10^4",
    "timeLimit": 1000,
    "memoryLimit": 128,
    "language": "python"
  }
}
```

---

### 3.5 代码提交 `AssignmentSubmit`

#### 提交代码

- **POST** `http://localhost:8000/api/v1/submissions`
- **Headers:** `Authorization: Bearer {student_token}`
- **Request:**

```json
{
  "assignment_id": 1,
  "problem_id": 1,
  "language": "python",
  "code": "print('Hello World')"
}
```

- **Response:**

```json
{
  "code": 0,
  "data": {
    "submission_id": 123
  }
}
```

#### 获取提交状态

- **GET** `http://localhost:8000/api/v1/submissions/{submissionId}/status`
- **Response:**

```json
{
  "code": 0,
  "data": {
    "status": "pending|judging|finished|failed",
    "score": null
  }
}
```

#### 获取提交详情

- **GET** `http://localhost:8000/api/v1/submissions/{submissionId}`
- **Response:**

```json
{
  "code": 0,
  "data": {
    "submission_id": 123,
    "status": "finished",
    "score": 95,
    "testCases": [
      {
        "id": 1,
        "name": "测试点1",
        "status": "passed",
        "time": "0.012s",
        "memory": "2.1MB"
      }
    ],
    "submitTime": "2024-03-28 14:30:00"
  }
}
```

---

### 3.6 提交历史 `SubmissionHistory`

#### 获取提交历史

- **GET** `http://localhost:8000/api/v1/submissions`
- **Headers:** `Authorization: Bearer {student_token}`
- **Response:**

```json
{
  "code": 0,
  "data": [
    {
      "submission_id": 123,
      "assignment": "实验3：二叉树遍历",
      "course": "Python程序设计",
      "submitTime": "2024-03-28 14:30:00",
      "status": "finished",
      "score": 95
    }
  ]
}
```

---

### 3.7 成绩查询 `MyGrades`

#### 获取我的成绩

- **GET** `http://localhost:8000/api/v1/scores/me`
- **Headers:** `Authorization: Bearer {student_token}`
- **Response:**

```json
{
  "code": 0,
  "data": [
    {
      "course": "Python程序设计",
      "courseCode": "CS101",
      "assignments": [
        {
          "assignmentId": 1,
          "assignmentName": "实验1：变量与输入输出",
          "score": 95,
          "maxScore": 100,
          "submitTime": "2024-04-14 14:30:00"
        }
      ],
      "averageScore": 92
    }
  ]
}
```

#### 获取成绩详情

- **GET** `http://localhost:8000/api/v1/submissions/{gradeId}`
- **Response:**

```json
{
  "code": 0,
  "data": {
    "submission_id": 123,
    "assignment": "实验3：二叉树遍历",
    "course": "Python程序设计",
    "score": 95,
    "maxScore": 100,
    "submitTime": "2024-03-28 14:30:00",
    "gradeTime": "2024-03-29 10:20:00",
    "testCases": [
      {
        "name": "测试点1",
        "status": "passed",
        "score": 20,
        "time": "0.012s"
      }
    ]
  }
}
```

---

### 3.8 学生个人中心 `StudentProfile`

#### 获取个人信息

- **GET** `/api/v1/student/profile`
- **Headers:** `Authorization: Bearer {student_token}`
- **Response:**

```json
{
  "code": 0,
  "data": {
    "studentId": "2023141460000",
    "name": "张三",
    "email": "zhangsan@example.com",
    "phone": "13800000000",
    "major": "计算机科学与技术",
    "className": "计科2401",
    "enrollYear": "2024",
    "selectedCourses": 5,
    "completedAssignments": 12,
    "avgScore": 88.5,
    "excellentRate": "75%",
    "enrolledCourses": [
      {
        "name": "Python程序设计",
        "code": "PY101",
        "teacher": "李老师"
      },
      {
        "name": "Bash Shell程序设计",
        "code": "SH201",
        "teacher": "王老师"
      }
    ]
  }
}
```

#### 更新个人信息

- **PUT** `/api/v1/student/profile`
- **Headers:** `Authorization: Bearer {student_token}`
- **Request:**

```json
{
  "email": "newemail@example.com",
  "phone": "13900000000"
}
```
#### 修改密码
- **PUT** `/api/v1/student/change-password`
- **Headers:** `Authorization: Bearer {student_token}`
- **Request:**

```json
{
  "oldPassword": "旧密码123",
  "newPassword": "新密码456"
}
```
- **Response:**
{
  "code": 0,
  "message": "密码修改成功"
}
---

### 3.9 忘记密码 `ForgotPassword`

#### 验证学生身份

- **GET** `http://localhost:8000/api/v1/students/{studentId}`

#### 验证验证码

- **POST** `http://localhost:8000/api/v1/auth/verify-code`
- **Request:**

```json
{
  "studentId": "2024001",
  "code": "123456"
}
```

#### 重置密码

- **POST** `http://localhost:8000/api/v1/auth/reset-password`
- **Request:**

```json
{
  "studentId": "2024001",
  "code": "123456",
  "newPassword": "newPassword123"
}
```

---

## 四、数据字典

### 4.1 状态枚举

| 状态名 | 枚举值 | 说明 |
|--------|--------|------|
| 题目难度 | `easy` | 简单 |
| 题目难度 | `medium` | 中等 |
| 题目难度 | `hard` | 困难 |
| 提交状态 | `submitted` | 已提交 |
| 提交状态 | `unsubmitted` | 未提交 |
| 提交状态 | `late` | 迟交 |
| 判题状态 | `pending` | 待判题 |
| 判题状态 | `judging` | 判题中 |
| 判题状态 | `finished` | 已完成 |
| 判题状态 | `failed` | 失败 |
| 任务状态 | `not_started` | 未开始 |
| 任务状态 | `ongoing` | 进行中 |
| 任务状态 | `ended` | 已结束 |
| 任务状态 | `graded` | 已评分 |

### 4.2 字段类型

| 字段 | 类型 | 说明 |
|------|------|------|
| id | integer | 主键ID |
| student_no | string | 学号（13位数字） |
| course_code | string | 课程编号（9位数字） |
| course_seq | string | 课序号 |
| class_name | string | 班级名称 |
| deadline | string | 截止时间（YYYY-MM-DD HH:mm:ss） |
| score | number | 分数 |
| timeLimit | integer | 时间限制（毫秒） |
| memoryLimit | integer | 内存限制（MB） |

---

## 五、接口汇总表

### 5.1 教师端接口

| 方法 | 接口路径 | 说明 |
|------|---------|------|
| POST | `/api/v1/auth/login` | 教师登录 |
| POST | `/api/v1/auth/forgot-password` | 教师忘记密码 |
| POST | `/api/v1/auth/reset-password` | 重置密码 |
| GET | `/api/v1/teacher/dashboard/stats` | 获取首页统计 |
| GET | `/api/v1/teacher/dashboard/recent-imports` | 获取最近导入 |
| GET | `/api/v1/teacher/dashboard/recent-grades` | 获取最近成绩 |
| GET | `/api/v1/teacher/courses` | 获取课程列表 |
| GET | `/api/v1/teacher/questions` | 获取题库列表 |
| GET | `/api/v1/teacher/questions/{questionId}` | 获取题目详情 |
| POST | `/api/v1/teacher/questions/parse` | 解析文件预览 |
| POST | `/api/v1/teacher/questions/import` | 导入题目 |
| GET | `/api/v1/teacher/students` | 获取学生列表 |
| POST | `/api/v1/teacher/students` | 添加学生 |
| PUT | `/api/v1/teacher/students/{id}` | 更新学生 |
| DELETE | `/api/v1/teacher/students/{studentNo}` | 删除学生 |
| GET | `/api/v1/teacher/students/export` | 导出学生 |
| POST | `/api/v1/teacher/students/import` | 导入学生 |
| GET | `/api/v1/teacher/students/import/history` | 导入历史 |
| POST | `/api/v1/teacher/students/import/history/{recordId}/reimport` | 重新导入 |
| DELETE | `/api/v1/teacher/students/import/history/{recordId}` | 删除记录 |
| GET | `/api/v1/teacher/classes` | 获取班级列表 |
| GET | `/api/v1/teacher/classes/grouped` | 获取课程分组班级 |
| GET | `/api/v1/teacher/classes/course` | 获取指定课程的班级 |
| GET | `/api/v1/teacher/classes/{classId}/students` | 班级学生列表 |
| GET | `/api/v1/teacher/classes/students` | 课程学生列表 |
| POST | `/api/v1/teacher/classes/adjust` | 调整学生班级 |
| POST | `/api/v1/teacher/classes/batch-adjust` | 批量调整班级 |
| GET | `/api/v1/teacher/classes/statistics` | 班级统计 |
| GET | `/api/v1/teacher/classes/course-statistics` | 课程统计 |
| POST | `/api/v1/teacher/classes` | 创建班级 |
| PUT | `/api/v1/teacher/classes/{classId}` | 更新班级 |
| DELETE | `/api/v1/teacher/classes/{classId}` | 删除班级 |
| GET | `/api/v1/teacher/classes/export` | 导出班级 |
| GET | `/api/v1/teacher/tasks` | 获取任务列表 |
| GET | `/api/v1/teacher/grades/overview` | 成绩总览 |
| GET | `/api/v1/teacher/grades/courses/{courseId}` | 课程成绩 |
| GET | `/api/v1/teacher/grades/assignments/{assignmentId}` | 作业成绩 |
| GET | `/api/v1/teacher/profile` | 获取个人信息 |
| PUT | `/api/v1/teacher/profile` | 更新个人信息 |

### 5.2 学生端接口

| 方法 | 接口路径 | 说明 |
|------|---------|------|
| POST | `/api/v1/auth/login` | 学生登录 |
| GET | `/api/v1/auth/me` | 获取当前用户 |
| GET | `/api/v1/student/dashboard` | 首页数据 |
| GET | `/api/v1/student/profile` | 获取个人信息 |
| PUT | `/api/v1/student/profile` | 更新个人信息 |
| GET | `/api/v1/assignments` | 获取作业列表 |
| GET | `/api/v1/problems/{problemId}` | 题目详情 |
| POST | `/api/v1/submissions` | 提交代码 |
| GET | `/api/v1/submissions` | 提交历史 |
| GET | `/api/v1/submissions/{submissionId}` | 提交详情 |
| GET | `/api/v1/submissions/{submissionId}/status` | 判题状态 |
| GET | `/api/v1/scores/me` | 我的成绩 |
| GET | `/api/v1/students/{studentId}` | 验证身份 |
| POST | `/api/v1/auth/verify-code` | 验证验证码 |
| POST | `/api/v1/auth/reset-password` | 重置密码 |
