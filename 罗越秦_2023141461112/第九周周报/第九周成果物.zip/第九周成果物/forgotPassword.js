// src/app/api/teacher/forgotPassword.js
import { post } from "../request";

/**
 * 教师端发送忘记密码验证码
 * POST /api/v1/auth/forgot-password
 * @param {string} email - 教师注册邮箱
 * @returns {Promise<{code:number,message:string}>}
 */
export const sendForgotPasswordCode = (email) => {
    return post("/auth/forgot-password", { email });
};

/**
 * 教师端重置密码
 * POST /api/v1/auth/reset-password
 * @param {string} email - 教师注册邮箱
 * @param {string} code - 邮件验证码
 * @param {string} newPassword - 新密码
 * @returns {Promise<{code:number,message:string}>}
 */
export const resetPassword = (email, code, newPassword) => {
    return post("/auth/reset-password", { email, code, newPassword });
};

export default {
    sendForgotPasswordCode,
    resetPassword,
};