// src/app/pages/student/StudentProfile.jsx
import { useState, useEffect } from "react";
import { User, BookOpen, Save } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";

// ======================== StudentProfile 页面 ========================
export function StudentProfile() {
  // -------------------- 学生基本信息 --------------------
  const [profile, setProfile] = useState({
    name: "",
    studentId: "",
    email: "",
    phone: "",
    major: "",
    class: "",
    enrollmentYear: "",
  });

  // -------------------- 密码修改状态 --------------------
  const [oldPwd, setOldPwd] = useState("");
  const [newPwd, setNewPwd] = useState("");
  const [confirmPwd, setConfirmPwd] = useState("");
  const [pwdLoading, setPwdLoading] = useState(false);
  const [strength, setStrength] = useState("");

  const [loading, setLoading] = useState(false);

  // -------------------- 获取学生信息接口 --------------------
  useEffect(() => {
    const fetchProfile = async () => {
      try {
        setLoading(true);
        const token = localStorage.getItem("student_token");
        if (!token) return;

        const res = await fetch("/api/v1/student/profile", {
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        });
        const data = await res.json();

        if (data.code === 0) {
          setProfile({
            name: data.data.name || "",
            studentId: data.data.studentId || "",
            email: data.data.email || "",
            phone: data.data.phone || "",
            major: data.data.major || "",
            class: data.data.className || "",
            enrollmentYear: data.data.enrollYear || "",
          });
        }
      } catch (err) {
        console.error("获取个人信息失败", err);
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, []);

  // -------------------- 保存学生基本信息 --------------------
  const handleSave = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem("student_token");
      const res = await fetch("/api/v1/student/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ email: profile.email, phone: profile.phone }),
      });
      const data = await res.json();
      if (data.code === 0) alert("个人信息已保存");
      else alert(data.message || "保存失败");
    } catch (err) {
      console.error(err);
      alert("保存失败，请检查网络");
    } finally {
      setLoading(false);
    }
  };

  // -------------------- 修改密码 --------------------
  const handleChangePassword = async () => {
    if (!oldPwd || !newPwd || !confirmPwd) return alert("请完整填写旧密码、新密码和确认密码");
    if (newPwd !== confirmPwd) return alert("新密码和确认密码不一致");
    if (strength === "弱") return alert("密码强度不足，请至少8位，包含大小写字母、数字和特殊字符");

    try {
      setPwdLoading(true);
      const token = localStorage.getItem("student_token");
      const res = await fetch("/api/v1/student/change-password", {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ oldPassword: oldPwd, newPassword: newPwd }),
      });
      const data = await res.json();
      if (data.code === 0) {
        alert("密码修改成功");
        setOldPwd(""); setNewPwd(""); setConfirmPwd(""); setStrength("");
      } else {
        alert(data.message || "修改失败");
      }
    } catch (err) {
      console.error(err);
      alert("修改失败，请检查网络");
    } finally {
      setPwdLoading(false);
    }
  };

  // -------------------- 实时密码强度 --------------------
  useEffect(() => {
    if (!newPwd) { setStrength(""); return; }
    let score = 0;
    if (newPwd.length >= 8) score++;
    if (/[A-Z]/.test(newPwd)) score++;
    if (/[a-z]/.test(newPwd)) score++;
    if (/\d/.test(newPwd)) score++;
    if (/[\W_]/.test(newPwd)) score++;
    if (score <= 2) setStrength("弱");
    else if (score <= 4) setStrength("中");
    else setStrength("强");
  }, [newPwd]);

  const strengthColor = { 弱:"bg-red-500", 中:"bg-yellow-400", 强:"bg-green-500" }[strength] || "bg-gray-200";

  if (loading) return <div className="p-10 text-center">加载中...</div>;

  const stats = [
    { label: "已选课程", value: profile?.selectedCourses ?? 0 },
    { label: "完成作业", value: profile?.completedAssignments ?? 0 },
    { label: "平均分", value: profile?.avgScore ?? 0 },
    { label: "优秀率", value: profile?.excellentRate ?? "0%" },
  ];

  const enrolledCourses = profile?.enrolledCourses || [];

  return (
    <div className="space-y-6">
      {/* 学生信息卡片 */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-6 flex items-start gap-6">
          <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
            <User className="w-12 h-12 text-white"/>
          </div>
          <div className="flex-1">
            <h2 className="text-2xl text-gray-900 mb-2">{profile?.name}</h2>
            <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-4">
              <div className="flex items-center gap-2">{profile?.studentId}</div>
              <div className="flex items-center gap-2">{profile?.major}</div>
              <div className="flex items-center gap-2">{profile?.class}</div>
            </div>
            <div className="grid grid-cols-4 gap-4 pt-4 border-t border-gray-100">
              {stats.map((stat,index)=>(
                <div key={index} className="text-center">
                  <p className="text-2xl text-blue-600 mb-1">{stat.value}</p>
                  <p className="text-xs text-gray-600">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 基本信息编辑卡片 */}
      <Card className="border-0 shadow-sm">
        <CardHeader><CardTitle>基本信息</CardTitle></CardHeader>
        <CardContent className="pt-4 px-6 pb-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2"><Label>姓名</Label>
              <Input value={profile?.name ?? ""} onChange={(e)=>setProfile({...profile,name:e.target.value})}/></div>
            <div className="space-y-2"><Label>邮箱</Label>
              <Input type="email" value={profile?.email ?? ""} onChange={(e)=>setProfile({...profile,email:e.target.value})}/></div>
            <div className="space-y-2"><Label>手机</Label>
              <Input value={profile?.phone ?? ""} onChange={(e)=>setProfile({...profile,phone:e.target.value})}/></div>
          </div>
          <div className="flex justify-end pt-4">
            <Button onClick={handleSave} className="gap-2 bg-blue-600 hover:bg-blue-700"><Save className="w-4 h-4"/>保存修改</Button>
          </div>
        </CardContent>
      </Card>

      {/* 已选课程卡片 */}
      <Card className="border-0 shadow-sm">
        <CardHeader><CardTitle>已选课程</CardTitle></CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {enrolledCourses.map((course,index)=>(
            <div key={index} className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 hover:shadow-sm transition-all">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1"><h3 className="text-sm text-gray-900">{course.name}</h3></div>
                  <p className="text-xs text-gray-600 mb-2">{course.code}</p>
                  <p className="text-xs text-gray-500">授课教师：{course.teacher}</p>
                </div>
                <BookOpen className="w-5 h-5 text-blue-600"/>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* 密码修改卡片 */}
      <Card className="border-0 shadow-sm">
        <CardHeader><CardTitle>修改密码</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>旧密码</Label>
            <Input type="password" value={oldPwd} onChange={e=>setOldPwd(e.target.value)}/>
          </div>
          <div className="space-y-2">
            <Label>新密码</Label>
            <Input type="password" value={newPwd} onChange={e=>setNewPwd(e.target.value)}/>
            {newPwd && <>
              <div className="mt-1 h-2 w-full bg-gray-200 rounded">
                <div className={`${{弱:"bg-red-500",中:"bg-yellow-400",强:"bg-green-500"}[strength]} h-2 rounded`} style={{width:"100%"}}></div>
              </div>
              <p className="text-xs text-gray-600 mt-1">密码强度：{strength}</p>
            </>}
          </div>
          <div className="space-y-2">
            <Label>确认新密码</Label>
            <Input type="password" value={confirmPwd} onChange={e=>setConfirmPwd(e.target.value)}/>
          </div>
          <div className="flex justify-end pt-4">
            <Button onClick={handleChangePassword} disabled={pwdLoading} className="gap-2 bg-blue-600 hover:bg-blue-700">修改密码</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default StudentProfile;