// src/app/pages/Profile.jsx
import { useState, useEffect } from "react";
import { User, Mail, Phone, Building, Save } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";

import { getTeacherProfile, updateTeacherProfile, changePassword } from "../api/teacher/teacherProfileApi";

export function Profile() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  const [oldPwd, setOldPwd] = useState("");
  const [newPwd, setNewPwd] = useState("");
  const [confirmPwd, setConfirmPwd] = useState("");
  const [pwdLoading, setPwdLoading] = useState(false);

  const [strength, setStrength] = useState(""); // 密码强度

  useEffect(() => {
    getTeacherProfile()
      .then((data) => {
        setProfile(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
        alert("获取教师信息失败");
      });
  }, []);

  // 处理个人信息保存
  const handleSave = async () => {
    try {
      await updateTeacherProfile(profile);
      alert("个人信息已保存");
    } catch (err) {
      alert(err.message || "保存失败");
    }
  };

  // 处理密码修改
  const handleChangePassword = async () => {
    if (!oldPwd || !newPwd || !confirmPwd) {
      alert("请完整填写旧密码、新密码和确认密码");
      return;
    }
    if (newPwd !== confirmPwd) {
      alert("新密码和确认密码不一致");
      return;
    }
    if (strength === "弱") {
      alert("密码强度不足，请至少8位，包含大小写字母、数字和特殊字符");
      return;
    }

    try {
      setPwdLoading(true);
      await changePassword({ oldPassword: oldPwd, newPassword: newPwd });
      alert("密码修改成功");
      setOldPwd("");
      setNewPwd("");
      setConfirmPwd("");
      setStrength("");
    } catch (err) {
      alert(err.message || "修改失败");
    } finally {
      setPwdLoading(false);
    }
  };

  // 实时计算密码强度
  useEffect(() => {
    if (!newPwd) {
      setStrength("");
      return;
    }
    let score = 0;
    if (newPwd.length >= 8) score++;
    if (/[A-Z]/.test(newPwd)) score++;
    if (/[a-z]/.test(newPwd)) score++;
    if (/\d/.test(newPwd)) score++;
    if (/[\W_]/.test(newPwd)) score++;

    if (score <= 2) setStrength("弱");
    else if (score === 3 || score === 4) setStrength("中");
    else setStrength("强");
  }, [newPwd]);

  if (loading) return <p>加载中...</p>;

  // 可选链访问 stats，防止 null 报错
  const stats = [
    { label: "授课课程", value: profile?.stats?.courses ?? 0 },
    { label: "在读学生", value: profile?.stats?.students ?? 0 },
  ];

  const strengthColor = {
    弱: "bg-red-500",
    中: "bg-yellow-400",
    强: "bg-green-500",
  }[strength] || "bg-gray-200";

  return (
    <div className="space-y-6">
      {/* 教师信息卡片 */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-6 flex items-start gap-6">
          <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
            <User className="w-12 h-12 text-white" />
          </div>
          <div className="flex-1">
            <h2 className="text-2xl text-gray-900 mb-2">{profile?.name}</h2>
            <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-4">
              <div className="flex items-center gap-2">
                <Building className="w-4 h-4" />
                {profile?.department}
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                {profile?.email}
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4" />
                {profile?.phone}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-100">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <p className="text-2xl text-blue-600 mb-1">{stat.value}</p>
                  <p className="text-xs text-gray-600">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-0 shadow-sm">
  <CardHeader>
    <CardTitle>基本信息</CardTitle>
  </CardHeader>
  <CardContent className="pt-4 px-6 pb-6 space-y-4">
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="space-y-2">
        <Label htmlFor="name">姓名</Label>
        <Input
          id="name"
          value={profile?.name ?? ""}
          onChange={(e) => setProfile({ ...profile, name: e.target.value })}
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="title">职称</Label>
        <Input
          id="title"
          value={profile?.title ?? ""}
          onChange={(e) => setProfile({ ...profile, title: e.target.value })}
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="email">邮箱</Label>
        <Input
          id="email"
          value={profile?.email ?? ""}
          onChange={(e) => setProfile({ ...profile, email: e.target.value })}
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="phone">手机</Label>
        <Input
          id="phone"
          value={profile?.phone ?? ""}
          onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="department">所属院系</Label>
        <Input
          id="department"
          value={profile?.department ?? ""}
          onChange={(e) => setProfile({ ...profile, department: e.target.value })}
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="office">办公室</Label>
        <Input
          id="office"
          value={profile?.office ?? ""}
          onChange={(e) => setProfile({ ...profile, office: e.target.value })}
        />
      </div>
    </div>
    <div className="space-y-2">
      <Label htmlFor="bio">个人简介</Label>
      <Textarea
        id="bio"
        value={profile?.bio ?? ""}
        onChange={(e) => setProfile({ ...profile, bio: e.target.value })}
        rows={4}
      />
    </div>
    <div className="flex justify-end pt-4">
      <Button onClick={handleSave} className="gap-2 bg-blue-600 hover:bg-blue-700">
        <Save className="w-4 h-4" />
        保存修改
      </Button>
    </div>
  </CardContent>
</Card>

      {/* 密码修改 */}
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>修改密码</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="oldPwd">旧密码</Label>
            <Input
              id="oldPwd"
              type="password"
              value={oldPwd}
              onChange={(e) => setOldPwd(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="newPwd">新密码</Label>
            <Input
              id="newPwd"
              type="password"
              value={newPwd}
              onChange={(e) => setNewPwd(e.target.value)}
            />
            {newPwd && (
              <>
                <div className="mt-1 h-2 w-full bg-gray-200 rounded">
                  <div
                    className={`${{
                      弱: "bg-red-500",
                      中: "bg-yellow-400",
                      强: "bg-green-500",
                    }[strength]} h-2 rounded`}
                    style={{ width: "100%" }}
                  ></div>
                </div>
                <p className="text-xs text-gray-600 mt-1">密码强度：{strength}</p>
              </>
            )}
          </div>
          <div className="space-y-2">
            <Label htmlFor="confirmPwd">确认新密码</Label>
            <Input
              id="confirmPwd"
              type="password"
              value={confirmPwd}
              onChange={(e) => setConfirmPwd(e.target.value)}
            />
          </div>
          <div className="flex justify-end pt-4">
            <Button
              onClick={handleChangePassword}
              disabled={pwdLoading}
              className="gap-2 bg-blue-600 hover:bg-blue-700"
            >
              修改密码
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default Profile;