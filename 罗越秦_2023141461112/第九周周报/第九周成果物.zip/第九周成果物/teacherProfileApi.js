// src/app/api/teacher/teacherProfileApi.js
import { get, put } from "../request"; // 注意路径

/**
 * 获取教师个人信息
 * 前端调用：Profile 页面初始化表单和统计数据
 * 方法：GET /teacher/profile
 *
 * 返回示例：
 * {
 *   code: 0,
 *   message: "成功",
 *   data: {
 *     id: 123,                  // 教师唯一ID
 *     name: "张老师",           // 姓名
 *     email: "zhang@school.edu.cn", // 邮箱
 *     phone: "138****5678",     // 手机
 *     department: "计算机科学系", // 院系
 *     title: "副教授",          // 职称
 *     office: "信息楼 A305",     // 办公室
 *     bio: "主要研究方向：Python程序设计...", // 个人简介
 *     stats: {
 *       courses: 8,             // 授课课程数量
 *       students: 328           // 在读学生数量
 *     }
 *   }
 * }
 */
export const getTeacherProfile = async () => {
  return get("/teacher/profile");
};

/**
 * 修改教师个人信息
 * 前端调用：Profile 页面点击“保存修改”
 * 方法：PUT /teacher/profile
 *
 * 请求体示例：
 * {
 *   name: "张老师",                  // 必传：姓名
 *   email: "zhang@school.edu.cn",    // 必传：邮箱
 *   phone: "138****5678",             // 可选：手机号
 *   department: "计算机科学系",        // 可选：院系
 *   title: "副教授",                 // 可选：职称
 *   office: "信息楼 A305",            // 可选：办公室
 *   bio: "主要研究方向：Python程序设计..." // 可选：个人简介
 * }
 *
 * 返回示例：
 * {
 *   code: 0,
 *   message: "保存成功"
 * }
 */
export const updateTeacherProfile = async (profile) => {
  return put("/teacher/profile", profile);
};

/**
 * 修改密码
 * 前端调用：Profile 页面点击“修改密码”
 * 方法：PUT /teacher/change-password
 *
 * 请求体示例：
 * {
 *   oldPassword: "OldPwd123!",  // 必传：旧密码
 *   newPassword: "NewPwd456@"   // 必传：新密码
 * }
 *
 * 返回示例：
 * 成功：
 * {
 *   code: 0,
 *   message: "密码修改成功"
 * }
 *
 * 失败示例：
 * {
 *   code: 400,
 *   message: "旧密码错误"
 * }
 *
 * 前端逻辑：
 * - 前端会校验新密码强度和确认密码是否一致
 * - 后端再次校验旧密码是否正确以及新密码是否符合策略
 */
export const changePassword = async ({ oldPassword, newPassword }) => {
  return put("/teacher/change-password", { oldPassword, newPassword });
};

// 默认导出
export default {
  getTeacherProfile,
  updateTeacherProfile,
  changePassword,
};