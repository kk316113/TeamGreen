import { BASE_URL, getHeaders, handleResponse } from "./request";

/**
 * 运行代码
 * POST /api/v1/student/submissions/run
 *
 * 用途：
 * - 对当前编辑器中的代码进行一次临时运行
 * - 用于页面“运行结果”区域展示
 *
 * request body:
 * {
 *   assignmentId: string,   // 作业/任务 ID，例如 "lab3"
 *   problemId: number,      // 题目 ID，例如 5
 *   language: string,       // 代码语言，例如 "python" / "shell"
 *   code: string            // 代码正文
 * }
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: {
 *     status: "success" | "failed", // 运行状态
 *     output: string,               // 标准输出内容
 *     error: string,                // 错误信息，运行成功时可为空字符串
 *     executionTime: string,        // 执行时间，例如 "0.023s"
 *     memory: string                // 内存占用，例如 "2.4MB"
 *   }
 * }
 */
export async function runCode(data) {
  if (!data || !data.assignmentId || !data.problemId || !data.language || !data.code) {
    throw new Error("运行代码参数不完整");
  }

  const response = await fetch(`${BASE_URL}/submissions/run`, {
    method: "POST",
    headers: getHeaders(),
    body: JSON.stringify(data),
  });

  return handleResponse(response, "运行代码失败");
}

/**
 * 提交代码
 * POST /api/v1/student/submissions
 *
 * 用途：
 * - 正式提交代码进入判题流程
 * - 用于页面“提交”按钮
 *
 * request body:
 * {
 *   assignmentId: string,   // 作业/任务 ID，例如 "lab3"
 *   problemId: number,      // 题目 ID，例如 5
 *   language: string,       // 代码语言，例如 "python"
 *   code: string            // 提交的代码内容
 * }
 *
 * response:
 * {
 *   code: 0,
 *   message: "submit success",
 *   data: {
 *     submissionId: string, // 提交记录 ID，例如 "sub_10086"
 *     status: "pending" | "judging" | "finished" | "failed",
 *     submittedAt: string   // 提交时间，例如 "2026-04-14 13:48:31"
 *   }
 * }
 */
export async function submitCode(data) {
  if (!data || !data.assignmentId || !data.problemId || !data.language || !data.code) {
    throw new Error("提交代码参数不完整");
  }

  const response = await fetch(`${BASE_URL}/submissions`, {
    method: "POST",
    headers: getHeaders(),
    body: JSON.stringify(data),
  });

  return handleResponse(response, "提交代码失败");
}

/**
 * 获取提交状态
 * GET /api/v1/student/submissions/{submissionId}/status
 *
 * 用途：
 * - 提交后轮询判题状态
 * - 一般用于判断是否继续轮询，或是否去拉取详情
 *
 * path params:
 * - submissionId: string    // 提交记录 ID
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: {
 *     submissionId: string, // 提交记录 ID
 *     status: "pending" | "judging" | "finished" | "failed"
 *   }
 * }
 */
export async function getSubmissionStatus(submissionId) {
  if (!submissionId) {
    throw new Error("submissionId 不能为空");
  }

  const response = await fetch(
    `${BASE_URL}/submissions/${encodeURIComponent(submissionId)}/status`,
    {
      method: "GET",
      headers: getHeaders(),
    }
  );

  return handleResponse(response, "获取提交状态失败");
}

/**
 * 获取提交详情
 * GET /api/v1/student/submissions/{submissionId}
 *
 * 用途：
 * - 获取完整提交结果
 * - 用于页面“提交结果”区域展示
 *
 * path params:
 * - submissionId: string    // 提交记录 ID
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: {
 *     submissionId: string,              // 提交记录 ID
 *     assignmentId: string,              // 作业/任务 ID
 *     problemId: number,                 // 题目 ID
 *     status: "accepted" | "rejected" | "failed",
 *     score: number,                     // 实得分，例如 95
 *     totalScore: number,                // 总分，例如 100
 *     submitTime: string,                // 提交时间，例如 "2026/4/14 13:48:31"
 *     testCases: [
 *       {
 *         id: number,                    // 测试点编号
 *         name: string,                  // 测试点名称，例如 "测试点1"
 *         status: "passed" | "failed",   // 测试点状态
 *         time: string,                  // 该测试点执行时间，例如 "0.012s"
 *         memory: string,                // 该测试点内存占用，例如 "2.1MB"
 *         error: string                  // 错误信息，成功时可为空字符串
 *       }
 *     ]
 *   }
 * }
 */
export async function getSubmissionDetail(submissionId) {
  if (!submissionId) {
    throw new Error("submissionId 不能为空");
  }

  const response = await fetch(
    `${BASE_URL}/submissions/${encodeURIComponent(submissionId)}`,
    {
      method: "GET",
      headers: getHeaders(),
    }
  );

  return handleResponse(response, "获取提交详情失败");
}

/**
 * 保存草稿
 * POST /api/v1/student/assignments/{assignmentId}/draft
 *
 * 用途：
 * - 保存当前任务下的代码草稿
 * - 用于页面“保存草稿”按钮
 *
 * path params:
 * - assignmentId: string    // 作业/任务 ID
 *
 * request body:
 * {
 *   language: string,       // 代码语言，例如 "python"
 *   code: string            // 草稿代码内容
 * }
 *
 * response:
 * {
 *   code: 0,
 *   message: "draft saved",
 *   data: {
 *     draftId: string,      // 草稿 ID，例如 "draft_20001"
 *     savedAt: string       // 保存时间，例如 "2026-04-14 14:25:00"
 *   }
 * }
 */
export async function saveDraft(assignmentId, data) {
  if (!assignmentId) {
    throw new Error("assignmentId 不能为空");
  }

  if (!data || !data.language || typeof data.code !== "string") {
    throw new Error("保存草稿参数不完整");
  }

  const response = await fetch(
    `${BASE_URL}/assignments/${encodeURIComponent(assignmentId)}/draft`,
    {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify(data),
    }
  );

  return handleResponse(response, "保存草稿失败");
}

/**
 * 获取草稿
 * GET /api/v1/student/assignments/{assignmentId}/draft
 *
 * 用途：
 * - 进入页面或切换任务时，获取当前任务的历史草稿
 * - 用于页面初始化恢复编辑器内容
 *
 * path params:
 * - assignmentId: string    // 作业/任务 ID
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: {
 *     draftId: string,      // 草稿 ID
 *     language: string,     // 草稿语言，例如 "python"
 *     code: string,         // 草稿代码正文
 *     savedAt: string       // 最近保存时间
 *   }
 * }
 */
export async function getDraft(assignmentId) {
  if (!assignmentId) {
    throw new Error("assignmentId 不能为空");
  }

  const response = await fetch(
    `${BASE_URL}/assignments/${encodeURIComponent(assignmentId)}/draft`,
    {
      method: "GET",
      headers: getHeaders(),
    }
  );

  return handleResponse(response, "获取草稿失败");
}