import { BASE_URL, getHeaders, handleResponse } from "./request";

/**
 * 获取当前学生可见的课程列表
 * GET /api/v1/student/courses
 */
export async function getCourseList() {
  const response = await fetch(`${BASE_URL}/courses`, {
    method: "GET",
    headers: getHeaders(),
  });

  return handleResponse(response, "获取课程列表失败");
}

/**
 * 获取某门课程下的任务列表
 * GET /api/v1/student/courses/{courseId}/assignments
 */
export async function getAssignmentList(courseId) {
  if (!courseId) {
    throw new Error("courseId 不能为空");
  }

  const response = await fetch(
    `${BASE_URL}/courses/${encodeURIComponent(courseId)}/assignments`,
    {
      method: "GET",
      headers: getHeaders(),
    }
  );

  return handleResponse(response, "获取任务列表失败");
}

/**
 * 获取任务详情
 * GET /api/v1/student/assignments/{assignmentId}
 */
export async function getAssignmentDetail(assignmentId) {
  if (!assignmentId) {
    throw new Error("assignmentId 不能为空");
  }

  const response = await fetch(
    `${BASE_URL}/assignments/${encodeURIComponent(assignmentId)}`,
    {
      method: "GET",
      headers: getHeaders(),
    }
  );

  return handleResponse(response, "获取任务详情失败");
}

/**
 * 获取邮件提交配置
 * GET /api/v1/student/assignments/{assignmentId}/email-config
 */
export async function getSubmissionEmailConfig(assignmentId) {
  if (!assignmentId) {
    throw new Error("assignmentId 不能为空");
  }

  const response = await fetch(
    `${BASE_URL}/assignments/${encodeURIComponent(assignmentId)}/email-config`,
    {
      method: "GET",
      headers: getHeaders(),
    }
  );

  return handleResponse(response, "获取邮件提交配置失败");
}