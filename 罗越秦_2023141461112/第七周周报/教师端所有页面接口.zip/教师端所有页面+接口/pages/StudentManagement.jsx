import { useState, useEffect, useCallback } from "react";
import { Search, Edit, Trash2, Plus, Filter, Download, RefreshCw } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../components/ui/dialog";
import { Label } from "../components/ui/label";
import { 
  getStudentList, 
  addStudent, 
  updateStudent, 
  deleteStudent,
  exportStudents 
} from "../api/teacher/StudentManagement";

/**
 * 学生信息管理组件
 * 用于学生信息的查询、添加、编辑、删除和导出功能
 */
export function StudentManagement() {
  // 状态管理
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [editingStudent, setEditingStudent] = useState(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);
  const [exporting, setExporting] = useState(false);

  // 获取学生列表
  const fetchStudents = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await getStudentList();
      if (result.code === 0) {
        setStudents(result.data || []);
      } else {
        setError(result.message || "获取学生列表失败");
      }
    } catch (err) {
      console.error("获取学生列表失败", err);
      setError(err.message || "网络错误，请稍后重试");
    } finally {
      setLoading(false);
    }
  }, []);

  // 初始加载
  useEffect(() => {
    fetchStudents();
  }, [fetchStudents]);

  /**
   * 处理编辑学生信息的函数
   * @param {Object} student - 包含学生信息的对象
   */
  const handleEdit = (student) => {
    // 使用展开运算符复制学生对象，设置为正在编辑的学生状态
    setEditingStudent({ ...student });
    // 打开编辑对话框
    setIsDialogOpen(true);
    // 清除任何可能存在的错误信息
    setError(null);
    // 清除任何可能存在的成功信息
    setSuccessMessage(null);
  };

/**
 * 处理学生删除操作的异步函数
 * @param {Object} student - 要删除的学生对象，包含学生姓名和学号等信息
 */
  const handleDelete = async (student) => {
  // 显示确认对话框，提示用户确认删除操作
    if (!confirm(`确定要删除学生 "${student.name}" (学号: ${student.student_no}) 的信息吗？`)) {
      return; // 如果用户取消，则直接返回，不执行后续操作
    }

    try {
    // 调用删除学生的API接口，传入学生学号
      const result = await deleteStudent(student.student_no);
    // 检查API返回结果
      if (result.code === 0) {
      // 删除成功，设置成功提示消息
        setSuccessMessage("删除成功");
        fetchStudents(); // 刷新列表
        // 3秒后自动清除成功消息
        setTimeout(() => setSuccessMessage(null), 3000);
      } else {
        setError(result.message || "删除失败");
      }
    } catch (err) {
      console.error("删除失败", err);
      setError(err.message || "网络错误，请稍后重试");
    }
  };

  /**
   * 处理学生信息保存的异步函数
   * 根据当前是编辑模式还是添加模式调用不同的API
   * 包含表单校验、错误处理和成功提示等功能
   */
  const handleSave = async () => {
    // 如果没有正在编辑的学生信息，则直接返回
    if (!editingStudent) return;

    // 基础校验：检查学号和姓名是否为空
    if (!editingStudent.student_no || !editingStudent.name) {
      setError("学号和姓名不能为空");
      return;
    }

    // 设置提交状态为true，表示正在提交
    setSubmitting(true);
    // 清空错误信息
    setError(null);

    try {
      // 判断是编辑模式还是添加模式
      const isEdit = !!editingStudent.id;
      let result;
      
      // 如果是编辑模式，调用更新接口
      if (isEdit) {
        result = await updateStudent(editingStudent.id, editingStudent);
      } else {
        // 如果是添加模式，调用添加接口
        result = await addStudent(editingStudent);
      }

      // 检查操作是否成功
      if (result.code === 0) {
        // 设置成功消息
        setSuccessMessage(isEdit ? "更新成功" : "添加成功");
        // 关闭对话框
        setIsDialogOpen(false);
        // 清空编辑的学生信息
        setEditingStudent(null);
        fetchStudents(); // 刷新列表
        // 3秒后自动清除成功消息
        setTimeout(() => setSuccessMessage(null), 3000);
      } else {
        setError(result.message || "操作失败");
      }
    } catch (err) {
      console.error("保存失败", err);
      setError(err.message || "网络错误，请稍后重试");
    } finally {
      setSubmitting(false);
    }
  };

  /**
   * 处理添加学生信息的函数
   * 该函数会初始化一个新的学生对象，并打开编辑对话框
   */
  const handleAdd = () => {
    // 设置编辑中的学生对象为空值，用于创建新学生
    setEditingStudent({
      student_no: "",
      name: "",
      major: "",
      class_name: "",
      course_code: "",
      course_seq: "",
      email: "",
      phone: "",
    });
    setError(null);
    setSuccessMessage(null);
    setIsDialogOpen(true);
  };
  /**
   * 处理学生数据导出的函数
   * 该函数异步执行导出操作，包括创建Excel文件、下载文件并处理相关状态
   */
  const handleExport = async () => {
    // 设置导出状态为true，表示正在导出
    setExporting(true);
    try {
      // 调用导出函数，传入搜索条件，获取Blob对象
      const blob = await exportStudents({ search: searchTerm });
      
      // 创建下载链接
      const url = window.URL.createObjectURL(blob);  // 将Blob对象转换为URL
      const link = document.createElement('a');       // 创建一个a元素用于下载
      link.href = url;                              // 设置下载链接
      // 设置下载文件名，包含当前时间戳
      link.download = `students_${new Date().toISOString().slice(0, 19)}.xlsx`;
      document.body.appendChild(link);    // 将链接添加到文档中
      link.click();                      // 模拟点击触发下载
      document.body.removeChild(link);    // 下载完成后移除链接
      window.URL.revokeObjectURL(url);   // 释放URL对象
      
      // 设置成功消息，3秒后自动清除
      setSuccessMessage("导出成功");
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err) {
      // 错误处理：打印错误信息并设置错误提示
      console.error("导出失败", err);
      setError(err.message || "导出失败，请稍后重试");
    } finally {
      // 无论成功失败，最终都将导出状态设为false
      setExporting(false);
    }
  };

  // 过滤学生列表
  const filteredStudents = students.filter((student) => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      student.student_no?.toLowerCase().includes(term) ||
      student.name?.toLowerCase().includes(term) ||
      student.major?.toLowerCase().includes(term) ||
      student.class_name?.toLowerCase().includes(term)
    );
  });

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div>
        <h1 className="text-2xl text-gray-900 mb-1">学生信息维护</h1>
        <p className="text-gray-600">查询、编辑和删除学生信息</p>
      </div>

      {/* 操作栏 */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="搜索学号、姓名、专业或班级..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                className="gap-2"
                onClick={handleExport}
                disabled={exporting}
              >
                <Download className="w-4 h-4" />
                {exporting ? "导出中..." : "导出"}
              </Button>
              <Button 
                variant="outline" 
                className="gap-2"
                onClick={fetchStudents}
                disabled={loading}
              >
                <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
                刷新
              </Button>
              <Button 
                className="gap-2 bg-blue-600 hover:bg-blue-700"
                onClick={handleAdd}
              >
                <Plus className="w-4 h-4" />添加学生
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 提示消息 */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
          {error}
        </div>
      )}
      {successMessage && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-green-700">
          {successMessage}
        </div>
      )}

      {/* 学生列表 */}
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>学生列表 ({filteredStudents.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-12">
              <RefreshCw className="w-8 h-8 text-gray-400 mx-auto mb-2 animate-spin" />
              <p className="text-gray-500">加载中...</p>
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left py-3 px-4 text-sm text-gray-600">学号</th>
                      <th className="text-left py-3 px-4 text-sm text-gray-600">姓名</th>
                      <th className="text-left py-3 px-4 text-sm text-gray-600">专业</th>
                      <th className="text-left py-3 px-4 text-sm text-gray-600">班级</th>
                      <th className="text-left py-3 px-4 text-sm text-gray-600">课程编号</th>
                      <th className="text-left py-3 px-4 text-sm text-gray-600">课序号</th>
                      <th className="text-left py-3 px-4 text-sm text-gray-600">邮箱</th>
                      <th className="text-left py-3 px-4 text-sm text-gray-600">手机</th>
                      <th className="text-center py-3 px-4 text-sm text-gray-600">操作</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {filteredStudents.map((student) => (
                      <tr key={student.id} className="hover:bg-gray-50">
                        <td className="py-3 px-4 text-sm text-gray-900">{student.student_no}</td>
                        <td className="py-3 px-4 text-sm text-gray-900">{student.name}</td>
                        <td className="py-3 px-4 text-sm text-gray-600">{student.major || "-"}</td>
                        <td className="py-3 px-4 text-sm text-gray-600">{student.class_name || "-"}</td>
                        <td className="py-3 px-4 text-sm text-gray-600">{student.course_code || "-"}</td>
                        <td className="py-3 px-4 text-sm text-gray-600">{student.course_seq || "-"}</td>
                        <td className="py-3 px-4 text-sm text-gray-600">{student.email || "-"}</td>
                        <td className="py-3 px-4 text-sm text-gray-600">{student.phone || "-"}</td>
                        <td className="py-3 px-4">
                          <div className="flex items-center justify-center gap-2">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => handleEdit(student)}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => handleDelete(student)}
                            >
                              <Trash2 className="w-4 h-4 text-red-600" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {filteredStudents.length === 0 && !loading && (
                <div className="text-center py-12">
                  <p className="text-gray-500">没有找到匹配的学生信息</p>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* 编辑/添加对话框 */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingStudent?.id ? "编辑学生信息" : "添加学生"}</DialogTitle>
          </DialogHeader>
          {editingStudent && (
            <div className="grid grid-cols-2 gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="student_no">学号 *</Label>
                <Input
                  id="student_no"
                  value={editingStudent.student_no}
                  onChange={(e) => setEditingStudent({
                    ...editingStudent,
                    student_no: e.target.value,
                  })}
                  disabled={!!editingStudent.id} // 编辑时学号不可修改
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="name">姓名 *</Label>
                <Input
                  id="name"
                  value={editingStudent.name}
                  onChange={(e) => setEditingStudent({
                    ...editingStudent,
                    name: e.target.value,
                  })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="major">专业</Label>
                <Input
                  id="major"
                  value={editingStudent.major || ""}
                  onChange={(e) => setEditingStudent({
                    ...editingStudent,
                    major: e.target.value,
                  })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="class_name">班级</Label>
                <Input
                  id="class_name"
                  value={editingStudent.class_name || ""}
                  onChange={(e) => setEditingStudent({
                    ...editingStudent,
                    class_name: e.target.value,
                  })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="course_code">课程编号</Label>
                <Input
                  id="course_code"
                  value={editingStudent.course_code || ""}
                  onChange={(e) => setEditingStudent({
                    ...editingStudent,
                    course_code: e.target.value,
                  })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="course_seq">课序号</Label>
                <Input
                  id="course_seq"
                  value={editingStudent.course_seq || ""}
                  onChange={(e) => setEditingStudent({
                    ...editingStudent,
                    course_seq: e.target.value,
                  })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">邮箱</Label>
                <Input
                  id="email"
                  type="email"
                  value={editingStudent.email || ""}
                  onChange={(e) => setEditingStudent({
                    ...editingStudent,
                    email: e.target.value,
                  })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">手机</Label>
                <Input
                  id="phone"
                  value={editingStudent.phone || ""}
                  onChange={(e) => setEditingStudent({
                    ...editingStudent,
                    phone: e.target.value,
                  })}
                />
              </div>
            </div>
          )}
          {error && (
            <div className="text-sm text-red-600 mb-4">{error}</div>
          )}
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => {
                setIsDialogOpen(false);
                setEditingStudent(null);
                setError(null);
              }}
            >
              取消
            </Button>
            <Button 
              onClick={handleSave} 
              disabled={submitting}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {submitting ? "保存中..." : "保存"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}