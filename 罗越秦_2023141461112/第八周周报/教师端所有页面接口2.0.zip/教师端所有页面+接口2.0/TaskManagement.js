import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router";
import { Search, Plus, Eye, Edit } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import {
  getTaskManagementCourses,
  getTaskManagementList,
} from "../api/teacher/taskManagement";

export function TaskManagement() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCourse, setFilterCourse] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");

  const [courses, setCourses] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [summary, setSummary] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    loadCourses();
  }, []);

  useEffect(() => {
    loadTasks();
  }, [searchTerm, filterCourse, filterStatus]);

  async function loadCourses() {
    try {
      const res = await getTaskManagementCourses();
      const courseList = res?.data || [];

      setCourses([
        {
          courseId: "all",
          courseName: "全部课程",
        },
        ...courseList,
      ]);
    } catch (error) {
      alert(error.message || "获取课程列表失败");
    }
  }

  async function loadTasks() {
    try {
      setIsLoading(true);

      const res = await getTaskManagementList({
        keyword: searchTerm,
        courseId: filterCourse !== "all" ? filterCourse : "",
        status: filterStatus !== "all" ? filterStatus : "",
      });

      const data = res?.data || {};
      const taskList = Array.isArray(data)
        ? data
        : data.tasks || data.list || [];

      setSummary(data.summary || null);

      setTasks(
        taskList.map((item) => ({
          id: item.taskId || item.id,
          taskName: item.taskName || item.assignmentName || "未命名任务",
          courseId: item.courseId,
          courseName: item.courseName || "-",
          deadline: item.deadline || item.endTime || "-",
          status: normalizeStatus(item.status),
          statusText: getStatusText(normalizeStatus(item.status)),
          questionCount: item.questionCount || item.problemCount || 0,
          submittedCount: item.submittedCount || item.submitCount || 0,
          gradedCount: item.gradedCount || item.markedCount || 0,
          totalStudents: item.totalStudents || item.studentCount || 0,
          avgScore:
            item.averageScore ??
            item.avgScore ??
            item.meanScore ??
            "-",
          createdAt: item.createdAt || item.createTime || "-",
        }))
      );
    } catch (error) {
      alert(error.message || "获取课程任务列表失败");
    } finally {
      setIsLoading(false);
    }
  }

  function normalizeStatus(status) {
    const statusMap = {
      ongoing: "ongoing",
      completed: "completed",
      graded: "graded",
      published: "ongoing",
      ended: "completed",
      finished: "graded",
      进行中: "ongoing",
      已截止: "completed",
      评分完成: "graded",
    };

    return statusMap[status] || status || "ongoing";
  }

  function getStatusText(status) {
    const textMap = {
      ongoing: "进行中",
      completed: "已截止",
      graded: "评分完成",
    };

    return textMap[status] || "进行中";
  }

  function formatDeadlineDate(deadline) {
    if (!deadline || deadline === "-") {
      return "-";
    }

    return String(deadline).split(" ")[0] || "-";
  }

  function formatDeadlineTime(deadline) {
    if (!deadline || deadline === "-") {
      return "";
    }

    return String(deadline).split(" ")[1] || "";
  }

  const filteredTasks = tasks;

  const getStatusBadge = (status, text) => {
    const colorClasses = {
      ongoing: "bg-blue-50 text-blue-700 border-blue-200",
      completed: "bg-orange-50 text-orange-700 border-orange-200",
      graded: "bg-green-50 text-green-700 border-green-200",
    };

    return _jsx(Badge, {
      variant: "outline",
      className:
        colorClasses[status] || "bg-gray-50 text-gray-700 border-gray-200",
      children: text,
    });
  };

  const stats = useMemo(() => {
    return [
      {
        label: "总任务数",
        value: summary?.totalCount ?? tasks.length,
        color: "blue",
      },
      {
        label: "进行中",
        value:
          summary?.ongoingCount ??
          tasks.filter((task) => task.status === "ongoing").length,
        color: "purple",
      },
      {
        label: "已截止",
        value:
          summary?.completedCount ??
          tasks.filter((task) => task.status === "completed").length,
        color: "orange",
      },
      {
        label: "评分完成",
        value:
          summary?.gradedCount ??
          tasks.filter((task) => task.status === "graded").length,
        color: "green",
      },
    ];
  }, [summary, tasks]);

  return _jsxs("div", {
    className: "space-y-6",
    children: [
      _jsxs("div", {
        className: "flex items-center justify-between",
        children: [
          _jsxs("div", {
            children: [
              _jsx("h1", {
                className: "text-2xl text-gray-900 mb-1",
                children: "课程任务管理",
              }),
              _jsx("p", {
                className: "text-gray-600",
                children: "管理课程任务，查看任务完成情况和成绩",
              }),
            ],
          }),
          _jsx(Link, {
            to: "/teacher/task-form",
            children: _jsxs(Button, {
              className: "gap-2 bg-blue-600 hover:bg-blue-700",
              children: [
                _jsx(Plus, {
                  className: "w-4 h-4",
                }),
                "新建任务",
              ],
            }),
          }),
        ],
      }),

      _jsx("div", {
        className: "grid grid-cols-1 md:grid-cols-4 gap-6",
        children: stats.map((stat, index) => {
          const colorClasses = {
            blue: "bg-blue-50 text-blue-600",
            green: "bg-green-50 text-green-600",
            orange: "bg-orange-50 text-orange-600",
            purple: "bg-purple-50 text-purple-600",
          };

          return _jsx(
            Card,
            {
              className: "border-0 shadow-sm",
              children: _jsx(CardContent, {
                className: "p-6",
                children: _jsxs("div", {
                  className: "text-center",
                  children: [
                    _jsx("p", {
                      className: `text-3xl mb-1 ${colorClasses[stat.color]}`,
                      children: stat.value,
                    }),
                    _jsx("p", {
                      className: "text-sm text-gray-600",
                      children: stat.label,
                    }),
                  ],
                }),
              }),
            },
            index
          );
        }),
      }),

      _jsx(Card, {
        className: "border-0 shadow-sm",
        children: _jsx(CardContent, {
          className: "p-6",
          children: _jsxs("div", {
            className: "flex flex-col lg:flex-row gap-4",
            children: [
              _jsxs("div", {
                className: "flex-1 relative",
                children: [
                  _jsx(Search, {
                    className:
                      "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400",
                  }),
                  _jsx(Input, {
                    placeholder: "搜索任务名称或课程...",
                    value: searchTerm,
                    onChange: (e) => setSearchTerm(e.target.value),
                    className: "pl-10",
                  }),
                ],
              }),

              _jsx("div", {
                className: "w-full lg:w-48",
                children: _jsxs(Select, {
                  value: filterCourse,
                  onValueChange: setFilterCourse,
                  children: [
                    _jsx(SelectTrigger, {
                      children: _jsx(SelectValue, {}),
                    }),
                    _jsx(SelectContent, {
                      children: courses.map((course) =>
                        _jsx(
                          SelectItem,
                          {
                            value: course.courseId,
                            children: course.courseName,
                          },
                          course.courseId
                        )
                      ),
                    }),
                  ],
                }),
              }),

              _jsx("div", {
                className: "w-full lg:w-48",
                children: _jsxs(Select, {
                  value: filterStatus,
                  onValueChange: setFilterStatus,
                  children: [
                    _jsx(SelectTrigger, {
                      children: _jsx(SelectValue, {}),
                    }),
                    _jsxs(SelectContent, {
                      children: [
                        _jsx(SelectItem, {
                          value: "all",
                          children: "全部状态",
                        }),
                        _jsx(SelectItem, {
                          value: "ongoing",
                          children: "进行中",
                        }),
                        _jsx(SelectItem, {
                          value: "completed",
                          children: "已截止",
                        }),
                        _jsx(SelectItem, {
                          value: "graded",
                          children: "评分完成",
                        }),
                      ],
                    }),
                  ],
                }),
              }),
            ],
          }),
        }),
      }),

      _jsxs(Card, {
        className: "border-0 shadow-sm",
        children: [
          _jsx(CardHeader, {
            children: _jsxs(CardTitle, {
              children: [
                "任务列表 (",
                isLoading ? "加载中" : filteredTasks.length,
                ")",
              ],
            }),
          }),
          _jsxs(CardContent, {
            children: [
              _jsx("div", {
                className: "overflow-x-auto",
                children: _jsxs("table", {
                  className: "w-full",
                  children: [
                    _jsx("thead", {
                      children: _jsxs("tr", {
                        className: "border-b border-gray-200",
                        children: [
                          _jsx("th", {
                            className:
                              "text-left py-3 px-4 text-sm text-gray-600",
                            children: "任务名称",
                          }),
                          _jsx("th", {
                            className:
                              "text-left py-3 px-4 text-sm text-gray-600",
                            children: "课程",
                          }),
                          _jsx("th", {
                            className:
                              "text-center py-3 px-4 text-sm text-gray-600",
                            children: "截止时间",
                          }),
                          _jsx("th", {
                            className:
                              "text-center py-3 px-4 text-sm text-gray-600",
                            children: "题目数",
                          }),
                          _jsx("th", {
                            className:
                              "text-center py-3 px-4 text-sm text-gray-600",
                            children: "提交/总数",
                          }),
                          _jsx("th", {
                            className:
                              "text-center py-3 px-4 text-sm text-gray-600",
                            children: "已评分",
                          }),
                          _jsx("th", {
                            className:
                              "text-center py-3 px-4 text-sm text-gray-600",
                            children: "平均分",
                          }),
                          _jsx("th", {
                            className:
                              "text-center py-3 px-4 text-sm text-gray-600",
                            children: "状态",
                          }),
                          _jsx("th", {
                            className:
                              "text-center py-3 px-4 text-sm text-gray-600",
                            children: "操作",
                          }),
                        ],
                      }),
                    }),

                    _jsx("tbody", {
                      className: "divide-y divide-gray-200",
                      children:
                        !isLoading &&
                        filteredTasks.map((task) =>
                          _jsxs(
                            "tr",
                            {
                              className: "hover:bg-gray-50",
                              children: [
                                _jsx("td", {
                                  className:
                                    "py-3 px-4 text-sm text-gray-900",
                                  children: task.taskName,
                                }),
                                _jsx("td", {
                                  className:
                                    "py-3 px-4 text-sm text-gray-600",
                                  children: task.courseName,
                                }),
                                _jsx("td", {
                                  className:
                                    "py-3 px-4 text-center text-sm text-gray-600",
                                  children: _jsxs("div", {
                                    className: "flex flex-col items-center",
                                    children: [
                                      _jsx("span", {
                                        children: formatDeadlineDate(
                                          task.deadline
                                        ),
                                      }),
                                      _jsx("span", {
                                        className: "text-xs text-gray-500",
                                        children: formatDeadlineTime(
                                          task.deadline
                                        ),
                                      }),
                                    ],
                                  }),
                                }),
                                _jsx("td", {
                                  className:
                                    "py-3 px-4 text-center text-sm text-gray-900",
                                  children: task.questionCount,
                                }),
                                _jsxs("td", {
                                  className: "py-3 px-4 text-center text-sm",
                                  children: [
                                    _jsx("span", {
                                      className: "text-gray-900",
                                      children: task.submittedCount,
                                    }),
                                    _jsxs("span", {
                                      className: "text-gray-500",
                                      children: ["/", task.totalStudents],
                                    }),
                                  ],
                                }),
                                _jsx("td", {
                                  className:
                                    "py-3 px-4 text-center text-sm text-gray-900",
                                  children: task.gradedCount,
                                }),
                                _jsx("td", {
                                  className: "py-3 px-4 text-center",
                                  children: _jsx("span", {
                                    className: `text-lg ${
                                      task.avgScore === "-"
                                        ? "text-gray-500"
                                        : task.avgScore >= 90
                                        ? "text-green-600"
                                        : task.avgScore >= 80
                                        ? "text-blue-600"
                                        : "text-amber-600"
                                    }`,
                                    children: task.avgScore,
                                  }),
                                }),
                                _jsx("td", {
                                  className: "py-3 px-4 text-center",
                                  children: getStatusBadge(
                                    task.status,
                                    task.statusText
                                  ),
                                }),
                                _jsx("td", {
                                  className: "py-3 px-4",
                                  children: _jsxs("div", {
                                    className:
                                      "flex items-center justify-center gap-2",
                                    children: [
                                      _jsx(Link, {
                                        to: `/teacher/task-detail/${task.id}`,
                                        children: _jsxs(Button, {
                                          variant: "ghost",
                                          size: "sm",
                                          className: "gap-1",
                                          children: [
                                            _jsx(Eye, {
                                              className: "w-4 h-4",
                                            }),
                                            "详情",
                                          ],
                                        }),
                                      }),
                                      _jsx(Link, {
                                        to: `/teacher/task-form/${task.id}`,
                                        children: _jsx(Button, {
                                          variant: "ghost",
                                          size: "sm",
                                          className: "gap-1",
                                          children: _jsx(Edit, {
                                            className: "w-4 h-4",
                                          }),
                                        }),
                                      }),
                                    ],
                                  }),
                                }),
                              ],
                            },
                            task.id
                          )
                        ),
                    }),
                  ],
                }),
              }),

              isLoading &&
                _jsx("div", {
                  className: "text-center py-12",
                  children: _jsx("p", {
                    className: "text-gray-500",
                    children: "正在加载任务数据...",
                  }),
                }),

              !isLoading &&
                filteredTasks.length === 0 &&
                _jsx("div", {
                  className: "text-center py-12",
                  children: _jsx("p", {
                    className: "text-gray-500",
                    children: "没有找到匹配的任务",
                  }),
                }),
            ],
          }),
        ],
      }),
    ],
  });
}