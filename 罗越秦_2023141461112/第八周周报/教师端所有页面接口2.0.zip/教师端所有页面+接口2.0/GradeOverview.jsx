import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import {
  TrendingUp,
  Award,
  Users,
  FileText,
  Download,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";

import {
  getGradeOverview,
  getCourseGradeDetail,
  getCourseAssignmentGrades,
  getAssignmentGradeDetail,
} from "../api/teacher/gradeOverview";

const LEVEL_COLORS = {
  excellent: "#10b981",
  good: "#3b82f6",
  medium: "#f59e0b",
  pass: "#ef4444",
  fail: "#6b7280",
};

function formatScore(value) {
  if (value === null || value === undefined || value === "") {
    return "-";
  }

  const numberValue = Number(value);
  if (Number.isNaN(numberValue)) {
    return value;
  }

  return Number.isInteger(numberValue) ? String(numberValue) : numberValue.toFixed(1);
}

function formatPercent(value) {
  if (value === null || value === undefined || value === "") {
    return "-";
  }

  const numberValue = Number(value);
  if (Number.isNaN(numberValue)) {
    return value;
  }

  const percentValue = numberValue <= 1 ? numberValue * 100 : numberValue;
  return `${percentValue.toFixed(1)}%`;
}

function buildScoreDistribution(scores) {
  const distribution = [
    { range: "0-59", count: 0 },
    { range: "60-69", count: 0 },
    { range: "70-79", count: 0 },
    { range: "80-89", count: 0 },
    { range: "90-100", count: 0 },
  ];

  scores.forEach((score) => {
    const value = Number(score);

    if (Number.isNaN(value)) {
      return;
    }

    if (value < 60) {
      distribution[0].count += 1;
    } else if (value < 70) {
      distribution[1].count += 1;
    } else if (value < 80) {
      distribution[2].count += 1;
    } else if (value < 90) {
      distribution[3].count += 1;
    } else {
      distribution[4].count += 1;
    }
  });

  return distribution;
}

function buildGradeLevelData(distribution) {
  const fail = distribution.find((item) => item.range === "0-59")?.count || 0;
  const pass = distribution.find((item) => item.range === "60-69")?.count || 0;
  const medium = distribution.find((item) => item.range === "70-79")?.count || 0;
  const good = distribution.find((item) => item.range === "80-89")?.count || 0;
  const excellent = distribution.find((item) => item.range === "90-100")?.count || 0;

  return [
    { name: "优秀 (90-100)", value: excellent, color: LEVEL_COLORS.excellent },
    { name: "良好 (80-89)", value: good, color: LEVEL_COLORS.good },
    { name: "中等 (70-79)", value: medium, color: LEVEL_COLORS.medium },
    { name: "及格 (60-69)", value: pass, color: LEVEL_COLORS.pass },
    { name: "不及格 (<60)", value: fail, color: LEVEL_COLORS.fail },
  ];
}

function getStudentAssignmentScore(student, assignmentId) {
  const assignmentScores =
    student.assignmentScores ||
    student.assignmentGrades ||
    student.assignments ||
    [];

  const matched = assignmentScores.find(
    (item) => item.assignmentId === assignmentId
  );

  return matched?.score ?? matched?.totalScore ?? "-";
}

function getStudentKey(student) {
  return student.studentId || student.studentNo || student.id;
}

function getStudentNo(student) {
  return student.studentNo || student.studentId || "-";
}

function getStudentName(student) {
  return student.studentName || student.name || "-";
}

function getJudgeStatusText(status) {
  const map = {
    pending: "待评测",
    judging: "评测中",
    finished: "已批改",
    failed: "评测失败",
    submitted: "已提交",
    unsubmitted: "未提交",
    late: "迟交",
  };

  return map[status] || status || "-";
}

export function GradeOverview() {
  const [selectedCourse, setSelectedCourse] = useState("");
  const [selectedTask, setSelectedTask] = useState("");

  const [courses, setCourses] = useState([]);
  const [courseAssignments, setCourseAssignments] = useState([]);
  const [courseDetail, setCourseDetail] = useState(null);
  const [assignmentDetail, setAssignmentDetail] = useState(null);

  const [isLoadingOverview, setIsLoadingOverview] = useState(false);
  const [isLoadingCourse, setIsLoadingCourse] = useState(false);
  const [isLoadingAssignment, setIsLoadingAssignment] = useState(false);

  useEffect(() => {
    loadOverview();
  }, []);

  useEffect(() => {
    if (selectedCourse) {
      loadCourseData(selectedCourse);
    }
  }, [selectedCourse]);

  useEffect(() => {
    if (selectedTask) {
      loadAssignmentData(selectedTask);
    }
  }, [selectedTask]);

  async function loadOverview() {
    try {
      setIsLoadingOverview(true);

      const res = await getGradeOverview();
      const courseList = res?.data?.courses || [];

      setCourses(courseList);

      if (courseList.length > 0) {
        const firstCourse = courseList[0];
        const firstAssignment = firstCourse.assignments?.[0];

        setSelectedCourse(firstCourse.courseId || "");
        setSelectedTask(firstAssignment?.assignmentId || "");
      }
    } catch (error) {
      alert(error.message || "获取成绩总览失败");
    } finally {
      setIsLoadingOverview(false);
    }
  }

  async function loadCourseData(courseId) {
    try {
      setIsLoadingCourse(true);
      setAssignmentDetail(null);

      const [courseRes, assignmentsRes] = await Promise.all([
        getCourseGradeDetail(courseId),
        getCourseAssignmentGrades(courseId),
      ]);

      const detail = courseRes?.data || null;
      const assignments =
        assignmentsRes?.data?.assignments ||
        detail?.assignments ||
        courses.find((course) => course.courseId === courseId)?.assignments ||
        [];

      setCourseDetail(detail);
      setCourseAssignments(assignments);

      if (assignments.length > 0) {
        const hasCurrentTask = assignments.some(
          (assignment) => assignment.assignmentId === selectedTask
        );

        if (!hasCurrentTask) {
          setSelectedTask(assignments[0].assignmentId);
        }
      } else {
        setSelectedTask("");
      }
    } catch (error) {
      alert(error.message || "获取课程成绩详情失败");
    } finally {
      setIsLoadingCourse(false);
    }
  }

  async function loadAssignmentData(assignmentId) {
    try {
      setIsLoadingAssignment(true);

      const res = await getAssignmentGradeDetail(assignmentId);
      setAssignmentDetail(res?.data || null);
    } catch (error) {
      alert(error.message || "获取作业成绩明细失败");
    } finally {
      setIsLoadingAssignment(false);
    }
  }

  function handleCourseChange(courseId) {
    setSelectedCourse(courseId);

    const selected = courses.find((course) => course.courseId === courseId);
    const firstAssignment = selected?.assignments?.[0];

    setSelectedTask(firstAssignment?.assignmentId || "");
  }

  const currentCourse = useMemo(() => {
    return (
      courseDetail ||
      courses.find((course) => course.courseId === selectedCourse) ||
      null
    );
  }, [courseDetail, courses, selectedCourse]);

  const currentTask = useMemo(() => {
    return (
      courseAssignments.find(
        (assignment) => assignment.assignmentId === selectedTask
      ) || null
    );
  }, [courseAssignments, selectedTask]);

  const courseStudents = courseDetail?.students || [];
  const assignmentStudents = assignmentDetail?.students || [];

  const courseScores = courseStudents
    .map((student) => student.totalScore ?? student.averageScore)
    .filter((score) => score !== null && score !== undefined);

  const assignmentScores = assignmentStudents
    .map((student) => student.score)
    .filter((score) => score !== null && score !== undefined);

  const courseGradeDistribution = buildScoreDistribution(courseScores);
  const courseGradeLevelData = buildGradeLevelData(courseGradeDistribution);

  const gradeDistribution = buildScoreDistribution(assignmentScores);
  const gradeLevelData = buildGradeLevelData(gradeDistribution);

  const completedAssignmentCount = courseAssignments.filter(
    (assignment) => assignment.status === "ended" || assignment.status === "finished"
  ).length;

  const courseStats = [
    {
      title: "课程平均分",
      value: formatScore(currentCourse?.averageScore),
      icon: Award,
    },
    {
      title: "最高总成绩",
      value: formatScore(currentCourse?.highestScore),
      icon: TrendingUp,
    },
    {
      title: "课程及格率",
      value: formatPercent(currentCourse?.passRate),
      icon: Users,
    },
    {
      title: "已完成任务",
      value: `${completedAssignmentCount}/${currentCourse?.assignmentCount || courseAssignments.length || 0}`,
      icon: FileText,
    },
  ];

  const submittedCount = assignmentDetail?.submittedCount || 0;
  const totalStudents =
    assignmentDetail?.totalStudents ||
    submittedCount + (assignmentDetail?.unsubmittedCount || 0);

  const submitRate =
    totalStudents > 0 ? (submittedCount / totalStudents) * 100 : null;

  const stats = [
    {
      title: "作业平均分",
      value: formatScore(assignmentDetail?.averageScore),
      icon: Award,
    },
    {
      title: "作业最高分",
      value: formatScore(assignmentDetail?.highestScore),
      icon: TrendingUp,
    },
    {
      title: "作业及格率",
      value: formatPercent(assignmentDetail?.passRate),
      icon: Users,
    },
    {
      title: "作业提交率",
      value: submitRate === null ? "-" : `${submitRate.toFixed(1)}%`,
      icon: FileText,
    },
  ];

  const getScoreClassName = (score) => {
    if (score >= 90) {
      return "bg-green-50 text-green-700";
    }
    if (score >= 80) {
      return "bg-blue-50 text-blue-700";
    }
    if (score >= 70) {
      return "bg-amber-50 text-amber-700";
    }
    if (score >= 60) {
      return "bg-orange-50 text-orange-700";
    }
    return "bg-red-50 text-red-700";
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl text-gray-900 mb-1">成绩总览</h1>
          <p className="text-gray-600">查看课程总成绩统计和单次作业成绩明细</p>
        </div>

        <Button variant="outline" className="gap-2">
          <Download className="w-4 h-4" />
          导出报告
        </Button>
      </div>

      <Card className="border-0 shadow-sm">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <label className="text-sm text-gray-600 mb-2 block">选择课程</label>
              <Select
                value={selectedCourse}
                onValueChange={handleCourseChange}
                disabled={isLoadingOverview || courses.length === 0}
              >
                <SelectTrigger>
                  <SelectValue
                    placeholder={isLoadingOverview ? "课程加载中..." : "请选择课程"}
                  />
                </SelectTrigger>
                <SelectContent>
                  {courses.map((course) => (
                    <SelectItem key={course.courseId} value={course.courseId}>
                      {course.courseCode} - {course.courseName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex-1">
              <label className="text-sm text-gray-600 mb-2 block">选择课程任务</label>
              <Select
                value={selectedTask}
                onValueChange={setSelectedTask}
                disabled={!selectedCourse || isLoadingCourse || courseAssignments.length === 0}
              >
                <SelectTrigger>
                  <SelectValue
                    placeholder={
                      !selectedCourse
                        ? "请先选择课程"
                        : isLoadingCourse
                        ? "任务加载中..."
                        : "请选择课程任务"
                    }
                  />
                </SelectTrigger>
                <SelectContent>
                  {courseAssignments.map((task) => (
                    <SelectItem key={task.assignmentId} value={task.assignmentId}>
                      {task.assignmentName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        <div>
          <h2 className="text-xl text-gray-900 mb-1">课程总成绩统计</h2>
          <p className="text-sm text-gray-600">
            汇总展示{currentCourse?.courseName || "当前课程"}下所有作业的整体成绩情况
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {courseStats.map((stat, index) => {
            const Icon = stat.icon;

            return (
              <Card key={index} className="border-0 shadow-sm">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm text-gray-600 mb-1">{stat.title}</p>
                      <h3 className="text-3xl text-gray-900">{stat.value}</h3>
                    </div>
                    <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center">
                      <Icon className="w-6 h-6 text-blue-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle>课程总成绩分布</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={courseGradeDistribution}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="range" tick={{ fill: "#6b7280", fontSize: 12 }} />
                <YAxis tick={{ fill: "#6b7280", fontSize: 12 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#fff",
                    border: "1px solid #e5e7eb",
                    borderRadius: "8px",
                  }}
                />
                <Bar dataKey="count" fill="#3b82f6" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle>课程等级分布</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={courseGradeLevelData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) =>
                    `${name.split(" ")[0]} ${(percent * 100).toFixed(0)}%`
                  }
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {courseGradeLevelData.map((entry, index) => (
                    <Cell key={`course-cell-${entry.name}-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#fff",
                    border: "1px solid #e5e7eb",
                    borderRadius: "8px",
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card className="border-0 shadow-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>课程总成绩表</CardTitle>
            <Button variant="outline" size="sm" className="gap-2">
              <Download className="w-4 h-4" />
              导出Excel
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[1100px]">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 text-sm text-gray-600">学号</th>
                  <th className="text-left py-3 px-4 text-sm text-gray-600">姓名</th>
                  {courseAssignments.map((assignment) => (
                    <th
                      key={assignment.assignmentId}
                      className="text-center py-3 px-4 text-sm text-gray-600"
                    >
                      {assignment.assignmentName}
                    </th>
                  ))}
                  <th className="text-center py-3 px-4 text-sm text-gray-600">
                    课程总成绩
                  </th>
                  <th className="text-center py-3 px-4 text-sm text-gray-600">排名</th>
                  <th className="text-center py-3 px-4 text-sm text-gray-600">操作</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {courseStudents.map((student) => (
                  <tr key={getStudentKey(student)} className="hover:bg-gray-50">
                    <td className="py-3 px-4 text-sm text-gray-900">
                      {getStudentNo(student)}
                    </td>
                    <td className="py-3 px-4 text-sm text-gray-900">
                      {getStudentName(student)}
                    </td>
                    {courseAssignments.map((assignment) => (
                      <td
                        key={assignment.assignmentId}
                        className="py-3 px-4 text-center text-sm text-gray-700"
                      >
                        {formatScore(
                          getStudentAssignmentScore(student, assignment.assignmentId)
                        )}
                      </td>
                    ))}
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`inline-flex items-center px-2.5 py-1 rounded-full text-sm ${getScoreClassName(
                          student.totalScore ?? student.averageScore
                        )}`}
                      >
                        {formatScore(student.totalScore ?? student.averageScore)}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center text-sm text-gray-700">
                      {student.rank ?? "-"}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <Link
                        to={`/teacher/student-grade-detail/${
                          student.studentId || student.studentNo
                        }`}
                      >
                        <Button variant="ghost" size="sm">
                          查看详情
                        </Button>
                      </Link>
                    </td>
                  </tr>
                ))}

                {!isLoadingCourse && courseStudents.length === 0 && (
                  <tr>
                    <td
                      colSpan={courseAssignments.length + 5}
                      className="py-8 text-center text-sm text-gray-500"
                    >
                      暂无课程成绩数据
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3 pt-2">
        <div>
          <h2 className="text-xl text-gray-900 mb-1">作业成绩明细</h2>
          <p className="text-sm text-gray-600">
            按课程任务查看{currentTask?.assignmentName || "当前作业"}的成绩统计与学生提交情况
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => {
            const Icon = stat.icon;

            return (
              <Card key={index} className="border-0 shadow-sm">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm text-gray-600 mb-1">{stat.title}</p>
                      <h3 className="text-3xl text-gray-900">{stat.value}</h3>
                    </div>
                    <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center">
                      <Icon className="w-6 h-6 text-blue-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle>单次作业成绩分布</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={gradeDistribution}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="range" tick={{ fill: "#6b7280", fontSize: 12 }} />
                <YAxis tick={{ fill: "#6b7280", fontSize: 12 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#fff",
                    border: "1px solid #e5e7eb",
                    borderRadius: "8px",
                  }}
                />
                <Bar dataKey="count" fill="#3b82f6" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle>单次作业等级分布</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={gradeLevelData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) =>
                    `${name.split(" ")[0]} ${(percent * 100).toFixed(0)}%`
                  }
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {gradeLevelData.map((entry, index) => (
                    <Cell key={`cell-${entry.name}-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#fff",
                    border: "1px solid #e5e7eb",
                    borderRadius: "8px",
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card className="border-0 shadow-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>学生作业成绩表</CardTitle>
            <Button variant="outline" size="sm" className="gap-2">
              <Download className="w-4 h-4" />
              导出Excel
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[1000px]">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 text-sm text-gray-600">学号</th>
                  <th className="text-left py-3 px-4 text-sm text-gray-600">姓名</th>
                  <th className="text-left py-3 px-4 text-sm text-gray-600">作业名称</th>
                  <th className="text-center py-3 px-4 text-sm text-gray-600">分数</th>
                  <th className="text-left py-3 px-4 text-sm text-gray-600">提交时间</th>
                  <th className="text-center py-3 px-4 text-sm text-gray-600">状态</th>
                  <th className="text-center py-3 px-4 text-sm text-gray-600">操作</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {assignmentStudents.map((grade) => (
                  <tr key={getStudentKey(grade)} className="hover:bg-gray-50">
                    <td className="py-3 px-4 text-sm text-gray-900">
                      {getStudentNo(grade)}
                    </td>
                    <td className="py-3 px-4 text-sm text-gray-900">
                      {getStudentName(grade)}
                    </td>
                    <td className="py-3 px-4 text-sm text-gray-600">
                      {assignmentDetail?.assignmentName || currentTask?.assignmentName || "-"}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`inline-flex items-center px-2.5 py-1 rounded-full text-sm ${getScoreClassName(
                          grade.score
                        )}`}
                      >
                        {formatScore(grade.score)}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-sm text-gray-600">
                      {grade.submitTime || "-"}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className="inline-flex items-center px-2.5 py-1 bg-green-50 text-green-700 rounded-full text-xs">
                        {getJudgeStatusText(grade.judgeStatus || grade.submitStatus)}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <Link
                        to={`/teacher/student-grade-detail/${
                          grade.studentId || grade.studentNo
                        }`}
                      >
                        <Button variant="ghost" size="sm">
                          查看详情
                        </Button>
                      </Link>
                    </td>
                  </tr>
                ))}

                {!isLoadingAssignment && assignmentStudents.length === 0 && (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-sm text-gray-500">
                      暂无作业成绩数据
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}