import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Link } from "react-router";
import { Users, Upload, BarChart3, Clock, BookOpen, ArrowRight, CheckCircle, Library, ClipboardList, Edit, } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
export function Dashboard() {
    const stats = [
        {
            title: "授课课程",
            value: "5",
            change: "+1",
            trend: "up",
            icon: BookOpen,
            color: "blue",
        },
        {
            title: "管理班级",
            value: "8",
            change: "+2",
            trend: "up",
            icon: Users,
            color: "green",
        },
        {
            title: "课程任务",
            value: "12",
            change: "+3",
            trend: "up",
            icon: ClipboardList,
            color: "purple",
        },
        {
            title: "待截止任务",
            value: "3",
            change: "-2",
            trend: "down",
            icon: Clock,
            color: "orange",
        },
    ];
    const quickActions = [
        {
            title: "学生信息导入",
            description: "批量导入学生信息",
            icon: Upload,
            link: "/teacher/student-import",
            color: "blue",
        },
        {
            title: "学生信息维护",
            description: "编辑和维护学生信息",
            icon: Edit,
            link: "/teacher/student-management",
            color: "purple",
        },
        {
            title: "分班管理",
            description: "管理课程班级信息",
            icon: BookOpen,
            link: "/teacher/class-management",
            color: "green",
        },
        {
            title: "题库选题",
            description: "从题库中选择题目",
            icon: Library,
            link: "/teacher/question-bank",
            color: "indigo",
        },
        {
            title: "课程任务管理",
            description: "创建和管理课程任务",
            icon: ClipboardList,
            link: "/teacher/task-management",
            color: "cyan",
        },
        {
            title: "成绩总览",
            description: "查看任务成绩分析",
            icon: BarChart3,
            link: "/teacher/grade-overview",
            color: "emerald",
        },
    ];
    const recentImports = [
        {
            id: 1,
            fileName: "2024春季-计算机科学-学生名单.xlsx",
            date: "2024-03-28 14:30",
            count: 45,
            status: "success",
        },
        {
            id: 2,
            fileName: "2024春季-软件工程-学生名单.pdf",
            date: "2024-03-27 09:15",
            count: 38,
            status: "success",
        },
        {
            id: 3,
            fileName: "2024春季-数据结构-学生名单.xlsx",
            date: "2024-03-26 16:45",
            count: 52,
            status: "success",
        },
    ];
    const recentGrades = [
        {
            course: "Python程序设计",
            assignment: "实验3：二叉树遍历",
            avgScore: 88.5,
            submitted: 48,
            total: 52,
        },
        {
            course: "Bash Shell程序设计",
            assignment: "实验2：进程调度",
            avgScore: 82.3,
            submitted: 35,
            total: 38,
        },
        {
            course: "Python程序设计",
            assignment: "实验4：TCP协议实现",
            avgScore: 90.2,
            submitted: 42,
            total: 45,
        },
    ];
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { children: [_jsx("h1", { className: "text-2xl text-gray-900 mb-1", children: "\u6B22\u8FCE\u56DE\u6765\uFF0C\u5F20\u8001\u5E08" }), _jsx("p", { className: "text-gray-600", children: "\u8FD9\u662F\u60A8\u7684\u5DE5\u4F5C\u53F0\u6982\u89C8" })] }), _jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6", children: stats.map((stat, index) => {
                    const Icon = stat.icon;
                    const colorClasses = {
                        blue: "bg-blue-50 text-blue-600",
                        green: "bg-green-50 text-green-600",
                        orange: "bg-orange-50 text-orange-600",
                        purple: "bg-purple-50 text-purple-600",
                    };
                    return (_jsx(Card, { className: "border-0 shadow-sm", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "flex items-start justify-between", children: [_jsxs("div", { children: [_jsx("p", { className: "text-sm text-gray-600 mb-1", children: stat.title }), _jsxs("div", { className: "flex items-end gap-2", children: [_jsx("h3", { className: "text-3xl text-gray-900", children: stat.value }), _jsx("span", { className: `text-sm mb-1 ${stat.trend === "up"
                                                            ? "text-green-600"
                                                            : "text-red-600"}`, children: stat.change })] })] }), _jsx("div", { className: `w-12 h-12 rounded-xl flex items-center justify-center ${colorClasses[stat.color]}`, children: _jsx(Icon, { className: "w-6 h-6" }) })] }) }) }, index));
                }) }), _jsxs("div", { children: [_jsx("h2", { className: "text-lg text-gray-900 mb-4", children: "\u5FEB\u6377\u529F\u80FD" }), _jsx("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: quickActions.map((action, index) => {
                            const Icon = action.icon;
                            const colorClasses = {
                                blue: "bg-blue-600 hover:bg-blue-700",
                                green: "bg-green-600 hover:bg-green-700",
                                purple: "bg-purple-600 hover:bg-purple-700",
                                indigo: "bg-indigo-600 hover:bg-indigo-700",
                                cyan: "bg-cyan-600 hover:bg-cyan-700",
                                emerald: "bg-emerald-600 hover:bg-emerald-700",
                            };
                            return (_jsx(Link, { to: action.link, children: _jsx(Card, { className: "border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "flex items-start gap-4", children: [_jsx("div", { className: `w-12 h-12 rounded-xl flex items-center justify-center ${colorClasses[action.color]}`, children: _jsx(Icon, { className: "w-6 h-6 text-white" }) }), _jsxs("div", { className: "flex-1", children: [_jsx("h3", { className: "text-gray-900 mb-1", children: action.title }), _jsx("p", { className: "text-sm text-gray-600", children: action.description })] }), _jsx(ArrowRight, { className: "w-5 h-5 text-gray-400" })] }) }) }) }, index));
                        }) })] }), _jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6", children: [_jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { className: "pb-3", children: _jsx(CardTitle, { className: "text-lg", children: "\u6700\u8FD1\u5BFC\u5165\u8BB0\u5F55" }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "space-y-4", children: recentImports.map((item) => (_jsxs("div", { className: "flex items-start gap-3 pb-4 border-b border-gray-100 last:border-0 last:pb-0", children: [_jsx("div", { className: "w-10 h-10 bg-green-50 rounded-lg flex items-center justify-center flex-shrink-0", children: _jsx(CheckCircle, { className: "w-5 h-5 text-green-600" }) }), _jsxs("div", { className: "flex-1 min-w-0", children: [_jsx("p", { className: "text-sm text-gray-900 truncate", children: item.fileName }), _jsxs("div", { className: "flex items-center gap-3 mt-1", children: [_jsxs("span", { className: "text-xs text-gray-500 flex items-center gap-1", children: [_jsx(Clock, { className: "w-3 h-3" }), item.date] }), _jsxs("span", { className: "text-xs text-blue-600", children: [item.count, " \u540D\u5B66\u751F"] })] })] })] }, item.id))) }), _jsx(Link, { to: "/teacher/student-import", children: _jsxs(Button, { variant: "ghost", className: "w-full mt-4", children: ["\u67E5\u770B\u5168\u90E8", _jsx(ArrowRight, { className: "w-4 h-4 ml-2" })] }) })] })] }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { className: "pb-3", children: _jsx(CardTitle, { className: "text-lg", children: "\u6700\u8FD1\u6210\u7EE9\u6458\u8981" }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "space-y-4", children: recentGrades.map((item, index) => (_jsxs("div", { className: "pb-4 border-b border-gray-100 last:border-0 last:pb-0", children: [_jsxs("div", { className: "flex items-start justify-between mb-2", children: [_jsxs("div", { className: "flex-1 min-w-0", children: [_jsx("p", { className: "text-sm text-gray-900", children: item.course }), _jsx("p", { className: "text-xs text-gray-600 mt-1", children: item.assignment })] }), _jsxs("div", { className: "text-right ml-4", children: [_jsxs("p", { className: "text-sm text-gray-900", children: [item.avgScore, "\u5206"] }), _jsx("p", { className: "text-xs text-gray-600 mt-1", children: "\u5E73\u5747\u5206" })] })] }), _jsxs("div", { className: "flex items-center gap-2 mt-2", children: [_jsx("div", { className: "flex-1 bg-gray-100 rounded-full h-2", children: _jsx("div", { className: "bg-blue-600 h-2 rounded-full", style: {
                                                                    width: `${(item.submitted / item.total) * 100}%`,
                                                                } }) }), _jsxs("span", { className: "text-xs text-gray-600", children: [item.submitted, "/", item.total] })] })] }, index))) }), _jsx(Link, { to: "/teacher/grade-overview", children: _jsxs(Button, { variant: "ghost", className: "w-full mt-4", children: ["\u67E5\u770B\u5168\u90E8", _jsx(ArrowRight, { className: "w-4 h-4 ml-2" })] }) })] })] })] })] }));
}
