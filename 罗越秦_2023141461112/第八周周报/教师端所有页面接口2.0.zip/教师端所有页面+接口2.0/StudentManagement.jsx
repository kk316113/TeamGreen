// src/app/pages/teacher/StudentManagement.jsx
import { useState, useEffect, useCallback } from "react";
import { Search, Edit, Trash2, Plus, Download, RefreshCw } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../components/ui/dialog";
import { Label } from "../components/ui/label";
import {
  getStudentList,
  addStudent,
  updateStudent,
  deleteStudent,
  exportStudents
} from "../api/teacher/StudentManagement";

/**
 * 学生信息管理组件
 */
export function StudentManagement() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [editingStudent, setEditingStudent] = useState(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);
  const [exporting, setExporting] = useState(false);

  const fetchStudents = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await getStudentList();
      if (result.code === 0) {
        setStudents(result.data || []);
      } else {
        setError(result.message || "获取学生列表失败");
      }
    } catch (err) {
      console.error("获取学生列表失败", err);
      setError(err.message || "网络错误，请稍后重试");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchStudents();
  }, [fetchStudents]);

  const handleEdit = (student) => {
    setEditingStudent({ ...student });
    setIsDialogOpen(true);
    setError(null);
    setSuccessMessage(null);
  };

  const handleDelete = async (student) => {
    if (!confirm(`确定要删除学生 "${student.name}" (学号: ${student.student_no}) 的信息吗？`)) return;
    try {
      const result = await deleteStudent(student.student_no);
      if (result.code === 0) {
        setSuccessMessage("删除成功");
        fetchStudents();
        setTimeout(() => setSuccessMessage(null), 3000);
      } else {
        setError(result.message || "删除失败");
      }
    } catch (err) {
      console.error("删除失败", err);
      setError(err.message || "网络错误，请稍后重试");
    }
  };

  const handleSave = async () => {
    if (!editingStudent) return;
    if (!editingStudent.student_no || !editingStudent.name) {
      setError("学号和姓名不能为空");
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const isEdit = !!editingStudent.id;
      const result = isEdit
        ? await updateStudent(editingStudent.id, editingStudent)
        : await addStudent(editingStudent);

      if (result.code === 0) {
        setSuccessMessage(isEdit ? "更新成功" : "添加成功");
        setIsDialogOpen(false);
        setEditingStudent(null);
        fetchStudents();
        setTimeout(() => setSuccessMessage(null), 3000);
      } else {
        setError(result.message || "操作失败");
      }
    } catch (err) {
      console.error("保存失败", err);
      setError(err.message || "网络错误，请稍后重试");
    } finally {
      setSubmitting(false);
    }
  };

  const handleAdd = () => {
    setEditingStudent({
      student_no: "",
      name: "",
      major: "",
      class_name: "",
      course_code: "",
      course_seq: "",
    });
    setError(null);
    setSuccessMessage(null);
    setIsDialogOpen(true);
  };

  const handleExport = async () => {
    setExporting(true);
    try {
      const blob = await exportStudents({ search: searchTerm });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `students_${new Date().toISOString().slice(0, 19)}.xlsx`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      setSuccessMessage("导出成功");
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err) {
      console.error("导出失败", err);
      setError(err.message || "导出失败，请稍后重试");
    } finally {
      setExporting(false);
    }
  };

  const filteredStudents = students.filter((student) => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      student.student_no?.toLowerCase().includes(term) ||
      student.name?.toLowerCase().includes(term) ||
      student.major?.toLowerCase().includes(term) ||
      student.class_name?.toLowerCase().includes(term)
    );
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl text-gray-900 mb-1">学生信息维护</h1>
        <p className="text-gray-600">查询、编辑和删除学生信息</p>
      </div>

      <Card className="border-0 shadow-sm">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="搜索学号、姓名、专业或班级..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                className="gap-2"
                onClick={handleExport}
                disabled={exporting}
              >
                <Download className="w-4 h-4" />
                {exporting ? "导出中..." : "导出"}
              </Button>
              <Button 
                variant="outline" 
                className="gap-2"
                onClick={fetchStudents}
                disabled={loading}
              >
                <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
                刷新
              </Button>
              <Button 
                className="gap-2 bg-blue-600 hover:bg-blue-700"
                onClick={handleAdd}
              >
                <Plus className="w-4 h-4" />添加学生
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
          {error}
        </div>
      )}
      {successMessage && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-green-700">
          {successMessage}
        </div>
      )}

      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle>学生列表 ({filteredStudents.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-12">
              <RefreshCw className="w-8 h-8 text-gray-400 mx-auto mb-2 animate-spin" />
              <p className="text-gray-500">加载中...</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 text-sm text-gray-600">学号</th>
                    <th className="text-left py-3 px-4 text-sm text-gray-600">姓名</th>
                    <th className="text-left py-3 px-4 text-sm text-gray-600">专业</th>
                    <th className="text-left py-3 px-4 text-sm text-gray-600">班级</th>
                    <th className="text-left py-3 px-4 text-sm text-gray-600">课程编号</th>
                    <th className="text-left py-3 px-4 text-sm text-gray-600">课序号</th>
                    <th className="text-center py-3 px-4 text-sm text-gray-600">操作</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filteredStudents.map((student) => (
                    <tr key={student.id} className="hover:bg-gray-50">
                      <td className="py-3 px-4 text-sm text-gray-900">{student.student_no}</td>
                      <td className="py-3 px-4 text-sm text-gray-900">{student.name}</td>
                      <td className="py-3 px-4 text-sm text-gray-600">{student.major || "-"}</td>
                      <td className="py-3 px-4 text-sm text-gray-600">{student.class_name || "-"}</td>
                      <td className="py-3 px-4 text-sm text-gray-600">{student.course_code || "-"}</td>
                      <td className="py-3 px-4 text-sm text-gray-600">{student.course_seq || "-"}</td>
                      <td className="py-3 px-4">
                        <div className="flex items-center justify-center gap-2">
                          <Button variant="ghost" size="sm" onClick={() => handleEdit(student)}>
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => handleDelete(student)}>
                            <Trash2 className="w-4 h-4 text-red-600" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 编辑/添加对话框 */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingStudent?.id ? "编辑学生信息" : "添加学生"}</DialogTitle>
          </DialogHeader>
          {editingStudent && (
            <div className="grid grid-cols-2 gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="student_no">学号 *</Label>
                <Input
                  id="student_no"
                  value={editingStudent.student_no || ""}
                  onChange={(e) => setEditingStudent({ ...editingStudent, student_no: e.target.value })}
                  disabled={!!editingStudent.id}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="name">姓名 *</Label>
                <Input
                  id="name"
                  value={editingStudent.name || ""}
                  onChange={(e) => setEditingStudent({ ...editingStudent, name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="major">专业</Label>
                <Input
                  id="major"
                  value={editingStudent.major || ""}
                  onChange={(e) => setEditingStudent({ ...editingStudent, major: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="class_name">班级</Label>
                <Input
                  id="class_name"
                  value={editingStudent.class_name || ""}
                  onChange={(e) => setEditingStudent({ ...editingStudent, class_name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="course_code">课程编号</Label>
                <Input
                  id="course_code"
                  value={editingStudent.course_code || ""}
                  onChange={(e) => setEditingStudent({ ...editingStudent, course_code: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="course_seq">课序号</Label>
                <Input
                  id="course_seq"
                  value={editingStudent.course_seq || ""}
                  onChange={(e) => setEditingStudent({ ...editingStudent, course_seq: e.target.value })}
                />
              </div>
            </div>
          )}
          {error && <div className="text-sm text-red-600 mb-4">{error}</div>}
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsDialogOpen(false);
                setEditingStudent(null);
                setError(null);
              }}
            >
              取消
            </Button>
            <Button onClick={handleSave} disabled={submitting} className="bg-blue-600 hover:bg-blue-700">
              {submitting ? "保存中..." : "保存"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}