import { get } from "../request";

/**
 * 获取教师课程列表
 * GET /api/v1/teacher/courses
 *
 * 用途：
 * - 获取当前教师可管理的课程
 * - 用于课程任务管理页面的“全部课程”筛选框
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: [
 *     {
 *       courseId: string,
 *       courseName: string,
 *       courseCode: string,
 *       className: string,
 *       semester: string
 *     }
 *   ]
 * }
 */
export function getTaskManagementCourses() {
  return get("/teacher/courses");
}

/**
 * 获取课程任务列表
 * GET /api/v1/teacher/tasks
 *
 * 用途：
 * - 获取课程任务管理页面的任务列表
 * - 支持按课程、状态、关键词筛选
 *
 * query params:
 * {
 *   keyword?: string,      // 搜索任务名称或课程名称
 *   courseId?: string,     // 课程 ID
 *   status?: string        // ongoing | completed | graded
 * }
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: {
 *     summary: {
 *       totalCount: number,
 *       ongoingCount: number,
 *       completedCount: number,
 *       gradedCount: number
 *     },
 *     tasks: [
 *       {
 *         taskId: string,
 *         taskName: string,
 *         courseId: string,
 *         courseName: string,
 *         deadline: string,
 *         status: "ongoing" | "completed" | "graded",
 *         questionCount: number,
 *         submittedCount: number,
 *         gradedCount: number,
 *         totalStudents: number,
 *         averageScore: number,
 *         createdAt: string
 *       }
 *     ]
 *   }
 * }
 */
export function getTaskManagementList(params = {}) {
  return get("/teacher/tasks", params);
}