// src/app/api/teacher/ClassManagement.js
import { get, post, put, del, download } from "../request";

// 班级管理相关接口
const BASE_PATH = "/teacher/classes";

/**
 * 获取所有班级列表
 * 接口地址: GET /api/v1/teacher/classes
 * 请求示例:
 * GET /api/v1/teacher/classes?search=计科
 * 响应示例:
 * {
 *   "code": 0,
 *   "message": "success",
 *   "data": [
 *     {
 *       "id": 1,
 *       "class_name": "计科2101",
 *       "major": "计算机科学与技术",
 *       "grade": "2021",
 *       "student_count": 45,
 *       "course_code": "CS101",
 *       "course_name": "计算机基础"
 *     },
 *     // 更多班级数据...
 *   ]
 * }
 * 
 * @param {Object} params - 查询参数
 * @param {string} params.search - 搜索关键词
 * @returns {Promise}
 */
export const getClassList = async (params = {}) => {
  return get(BASE_PATH, params);
};

/**
 * 获取课程分组班级列表
 * * 接口地址: GET /api/v1/teacher/classes/grouped
 * 请求示例:
 * GET /api/v1/teacher/classes/grouped?courseCode=CS101
 * 响应示例:
 * {
 *   "code": 0,
 *   "message": "success",
 *   "data": {
 *     "CS101": {
 *       "course_name": "计算机基础",
 *       "classes": [
 *         {
 *           "id": 1,
 *           "class_name": "计科2101",
 *           "student_count": 45
 *         },
 *         {
 *           "id": 2,
 *           "class_name": "计科2102",
 *           "student_count": 42
 *         }
 *       ]
 *     }
 *   }
 * }
 * 
 * @param {Object} params - 查询参数
 * @returns {Promise}
 */
export const getGroupedClasses = async (params = {}) => {
  return get(`${BASE_PATH}/grouped`, params);
};

/**
 * 获取指定课程的所有班级
 * 接口地址: GET /api/v1/teacher/classes/course
 *  请求示例:
 * GET /api/v1/teacher/classes/course?courseCode=CS101&courseName=计算机基础
 * 响应示例:
 * {
 *   "code": 0,
 *   "message": "success",
 *   "data": [
 *     {
 *       "id": 1,
 *       "class_name": "计科2101",
 *       "major": "计算机科学与技术",
 *       "grade": "2021",
 *       "student_count": 45
 *     },
 *     {
 *       "id": 2,
 *       "class_name": "计科2102",
 *       "major": "计算机科学与技术",
 *       "grade": "2021",
 *       "student_count": 42
 *     }
 *   ]
 * }
 * @param {string} courseCode - 课程编号
 * @param {string} courseName - 课程名称
 * @returns {Promise}
 */
export const getCourseClasses = async (courseCode, courseName) => {
  return get(`${BASE_PATH}/course`, { courseCode, courseName });
};

/**
 * 获取班级学生列表
 * * 接口地址: GET /api/v1/teacher/classes/{classId}/students
 *  请求示例:
 * GET /api/v1/teacher/classes/1/students?page=1&pageSize=20
 * 响应示例:
 * {
 *   "code": 0,
 *   "message": "success",
 *   "data": {
 *     "total": 45,
 *     "page": 1,
 *     "pageSize": 20,
 *     "students": [
 *       {
 *         "id": 1,
 *         "student_no": "20210001",
 *         "name": "张三",
 *         "major": "计算机科学与技术",
 *         "class_name": "计科2101",
 *         "email": "zhangsan@example.com"
 *       },
 *       // 更多学生数据...
 *     ]
 *   }
 * }
 * @param {string} classId - 班级ID
 * @param {Object} params - 查询参数
 * @returns {Promise}
 */
export const getClassStudents = async (classId, params = {}) => {
  return get(`${BASE_PATH}/${classId}/students`, params);
};

/**
 * 获取课程的学生列表
 * * 接口地址: GET /api/v1/teacher/classes/students
 * 请求示例:
 * GET /api/v1/teacher/classes/students?courseCode=CS101&courseName=计算机基础
 *  响应示例:
 * {
 *   "code": 0,
 *   "message": "success",
 *   "data": [
 *     {
 *       "id": 1,
 *       "student_no": "20210001",
 *       "name": "张三",
 *       "major": "计算机科学与技术",
 *       "class_name": "计科2101",
 *       "course_code": "CS101",
 *       "email": "zhangsan@example.com"
 *     },
 *     // 更多学生数据...
 *   ]
 * }
 * @param {string} courseCode - 课程编号
 * @param {string} courseName - 课程名称
 * @param {Object} params - 查询参数
 * @returns {Promise}
 */
export const getCourseStudents = async (courseCode, courseName, params = {}) => {
  return get(`${BASE_PATH}/students`, { courseCode, courseName, ...params });
};

/**
 * 调整学生班级
 * 接口地址: POST /api/v1/teacher/classes/adjust
 * 请求示例:
 * {
 *   "studentIds": [1, 2, 3],
 *   "targetClass": "计科2102",
 *   "courseCode": "CS101",
 *   "courseName": "计算机基础"
 * }
 *  响应示例:
 * {
 *   "code": 0,
 *   "message": "调整成功",
 *   "data": {
 *     "success_count": 3,
 *     "failed_count": 0,
 *     "failed_students": []
 *   }
 * }
 * @param {Object} data - 调整数据
 * @param {Array<number>} data.studentIds - 学生ID列表
 * @param {string} data.targetClass - 目标班级名称
 * @param {string} data.courseCode - 课程编号
 * @param {string} data.courseName - 课程名称
 * @returns {Promise}
 */
export const adjustStudentClass = async (data) => {
  return post(`${BASE_PATH}/adjust`, data);
};

/**
 * 批量调整学生班级
 * * 接口地址: POST /api/v1/teacher/classes/batch-adjust
 * 请求示例:
 * {
 *   "adjustments": [
 *     {
 *       "studentIds": [1, 2, 3],
 *       "targetClass": "计科2102",
 *       "courseCode": "CS101",
 *       "courseName": "计算机基础"
 *     },
 *     {
 *       "studentIds": [4, 5],
 *       "targetClass": "计科2103",
 *       "courseCode": "CS101",
 *       "courseName": "计算机基础"
 *     }
 *   ]
 * }
 * 响应示例:
 * {
 *   "code": 0,
 *   "message": "批量调整成功",
 *   "data": {
 *     "total_adjustments": 2,
 *     "success_count": 2,
 *     "failed_count": 0,
 *     "failed_adjustments": []
 *   }
 * }
 * @param {Object} data - 批量调整数据
 * @returns {Promise}
 */
export const batchAdjustStudentClass = async (data) => {
  return post(`${BASE_PATH}/batch-adjust`, data);
};

/**
 * 获取班级统计信息
 * 接口地址: GET /api/v1/teacher/classes/statistics
 * 接口地址: GET /api/v1/teacher/classes/statistics
 *  响应示例:
 * {
 *   "code": 0,
 *   "message": "success",
 *   "data": {
 *     "total_classes": 15,
 *     "total_students": 680,
 *     "average_students_per_class": 45,
 *     "class_distribution": {
 *       "计算机科学与技术": 5,
 *       "软件工程": 4,
 *       "网络工程": 3,
 *       "信息安全": 3
 *     }
 *   }
 * }
 * @returns {Promise}
 */
export const getClassStatistics = async () => {
  return get(`${BASE_PATH}/statistics`);
};

/**
 * 获取课程统计信息
 * 接口地址: GET /api/v1/teacher/classes/course-statistics
 * 
 * 请求示例:
 * GET /api/v1/teacher/classes/course-statistics
 * 
 * 响应示例:
 * {
 *   "code": 0,
 *   "message": "success",
 *   "data": {
 *     "total_courses": 8,
 *     "total_classes": 15,
 *     "courses": [
 *       {
 *         "course_code": "CS101",
 *         "course_name": "计算机基础",
 *         "class_count": 3,
 *         "student_count": 135
 *       },
 *       {
 *         "course_code": "SE201",
 *         "course_name": "软件工程导论",
 *         "class_count": 2,
 *         "student_count": 90
 *       }
 *     ]
 *   }
 * }
 * @returns {Promise}
 */
export const getCourseStatistics = async () => {
  return get(`${BASE_PATH}/course-statistics`);
};

/**
 * 创建新班级
 * 接口地址: POST /api/v1/teacher/classes
 * 
 * 请求示例:
 * {
 *   "class_name": "计科2104",
 *   "major": "计算机科学与技术",
 *   "grade": "2021",
 *   "course_code": "CS101",
 *   "course_name": "计算机基础"
 * }
 * 
 * 响应示例:
 * {
 *   "code": 0,
 *   "message": "创建成功",
 *   "data": {
 *     "id": 16,
 *     "class_name": "计科2104",
 *     "major": "计算机科学与技术",
 *     "grade": "2021",
 *     "course_code": "CS101",
 *     "course_name": "计算机基础",
 *     "student_count": 0,
 *     "created_at": "2024-01-15T10:30:00Z"
 *   }
 * }
 * @param {Object} classData - 班级信息
 * @returns {Promise}
 */
export const createClass = async (classData) => {
  return post(BASE_PATH, classData);
};

/**
 * 更新班级信息
 * 接口地址: PUT /api/v1/teacher/classes/{classId}
 * 
 * 请求示例:
 * PUT /api/v1/teacher/classes/16
 * {
 *   "class_name": "计科2104-更新",
 *   "major": "计算机科学与技术"
 * }
 * 
 * 响应示例:
 * {
 *   "code": 0,
 *   "message": "更新成功",
 *   "data": {
 *     "id": 16,
 *     "class_name": "计科2104-更新",
 *     "major": "计算机科学与技术",
 *     "grade": "2021",
 *     "course_code": "CS101",
 *     "course_name": "计算机基础",
 *     "student_count": 0,
 *     "updated_at": "2024-01-15T11:30:00Z"
 *   }
 * }
 * @param {string} classId - 班级ID
 * @param {Object} classData - 班级信息
 * @returns {Promise}
 */
export const updateClass = async (classId, classData) => {
  return put(`${BASE_PATH}/${classId}`, classData);
};

/**
 * 删除班级
 * 接口地址: DELETE /api/v1/teacher/classes/{classId}
 * 
 * 请求示例:
 * DELETE /api/v1/teacher/classes/16
 * 
 * 响应示例:
 * {
 *   "code": 0,
 *   "message": "删除成功",
 *   "data": null
 * }
 * @param {string} classId - 班级ID
 * @returns {Promise}
 */
export const deleteClass = async (classId) => {
  return del(`${BASE_PATH}/${classId}`);
};

/**
 * 导出班级数据
 * 接口地址: GET /api/v1/teacher/classes/export
 * 
 * 请求示例:
 * GET /api/v1/teacher/classes/export?courseCode=CS101&format=excel
 * 
 * 响应示例:
 * 返回Excel文件流
 * @param {Object} params - 导出参数
 * @returns {Promise<Blob>}
 */
export const exportClasses = async (params = {}) => {
  return download(`${BASE_PATH}/export`, params);
};

export default {
  getClassList,
  getGroupedClasses,
  getCourseClasses,
  getClassStudents,
  getCourseStudents,
  adjustStudentClass,
  batchAdjustStudentClass,
  getClassStatistics,
  getCourseStatistics,
  createClass,
  updateClass,
  deleteClass,
  exportClasses,
};