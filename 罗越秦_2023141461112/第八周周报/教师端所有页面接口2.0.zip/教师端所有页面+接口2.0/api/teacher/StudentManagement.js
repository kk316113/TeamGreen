// src/app/api/teacher/studentManagement.js
import { get, post, put, del, download } from "../request";

// 学生管理相关接口
const BASE_PATH = "/teacher/students";

/**
 * 获取学生列表
 * @returns {Promise}
 * 接口地址: GET /api/v1/teacher/students
 * 请求参数: 无
 * 响应示例：
 * {
 *   "code": 0,
 *   "message": "success",
 *   "data": [
 *     {
 *       "id": 1,
 *       "student_no": "20210001",
 *       "name": "张三",
 *       "major": "计算机科学与技术",
 *       "class_name": "计科2101",
 *       "course_code": "CS101",
 *       "course_seq": "01"
 *     }
 *   ]
 * }
 */
export const getStudentList = async () => {
  return get(BASE_PATH);
};

/**
 * 添加学生
 * 接口地址: POST /api/v1/teacher/students
 * 请求示例:
 * {
 *   "student_no": "20210002",
 *   "name": "李四",
 *   "major": "软件工程",
 *   "class_name": "软工2101",
 *   "course_code": "SE101",
 *   "course_seq": "01"
 * }
 * 注意：已删除 email 和 phone 字段
 * 响应示例:
 * {
 *   "code": 0,
 *   "message": "添加成功",
 *   "data": {
 *     "id": 2,
 *     "student_no": "20210002",
 *     "name": "李四",
 *     "major": "软件工程",
 *     "class_name": "软工2101",
 *     "course_code": "SE101",
 *     "course_seq": "01"
 *   }
 * }
 * @param {Object} studentData - 学生信息（不包含邮箱和手机）
 * @returns {Promise}
 */
export const addStudent = async (studentData) => {
  // 创建一个新对象，移除 email 和 phone
  const dataToSend = { ...studentData };
  delete dataToSend.email;
  delete dataToSend.phone;

  return post(BASE_PATH, dataToSend);
};

/**
 * 更新学生信息
 * 接口地址: PUT /api/v1/teacher/students/{id}
 * 请求示例:
 * PUT /api/v1/teacher/students/2
 * {
 *   "name": "李四"
 * }
 * 注意：已删除 email 和 phone 字段
 * 响应示例:
 * {
 *   "code": 0,
 *   "message": "更新成功",
 *   "data": {
 *     "id": 2,
 *     "student_no": "20210002",
 *     "name": "李四",
 *     "major": "软件工程",
 *     "class_name": "软工2101",
 *     "course_code": "SE101",
 *     "course_seq": "01"
 *   }
 * }
 * @param {number|string} id - 学生ID
 * @param {Object} studentData - 学生信息（不包含邮箱和手机）
 * @returns {Promise}
 */
export const updateStudent = async (id, studentData) => {
  const dataToSend = { ...studentData };
  delete dataToSend.email;
  delete dataToSend.phone;

  return put(`${BASE_PATH}/${encodeURIComponent(id)}`, dataToSend);
};

/**
 * 删除学生
 * 接口地址: DELETE /api/v1/teacher/students/{studentNo}
 * 请求示例:
 * DELETE /api/v1/teacher/students/20210002
 * 响应示例:
 * {
 *   "code": 0,
 *   "message": "删除成功",
 *   "data": null
 * }
 * @param {number|string} studentNo - 学号
 * @returns {Promise}
 */
export const deleteStudent = async (studentNo) => {
  return del(`${BASE_PATH}/${encodeURIComponent(studentNo)}`);
};

/**
 * 导出学生列表
 * 接口地址: GET /api/v1/teacher/students/export
 * 请求示例:
 * GET /api/v1/teacher/students/export?courseCode=CS101&className=计科2101
 * 响应示例:
 * 返回Excel文件流
 *
 * @param {Object} params - 导出参数
 * @returns {Promise<Blob>}
 */
export const exportStudents = async (params = {}) => {
  return download(`${BASE_PATH}/export`, params);
};

/**
 * 根据条件搜索学生
 * 接口地址: GET /api/v1/teacher/students
 * 请求示例:
 * GET /api/v1/teacher/students?name=张&major=计算机
 * 响应示例:
 * {
 *   "code": 0,
 *   "message": "success",
 *   "data": [
 *     {
 *       "id": 1,
 *       "student_no": "20210001",
 *       "name": "张三",
 *       "major": "计算机科学与技术",
 *       "class_name": "计科2101",
 *       "course_code": "CS101",
 *       "course_seq": "01"
 *     }
 *   ]
 * }
 * @param {Object} searchParams - 搜索参数
 * @param {string} searchParams.name - 学生姓名，可选
 * @param {string} searchParams.student_no - 学号，可选
 * @param {string} searchParams.major - 专业，可选
 * @param {string} searchParams.class_name - 班级，可选
 * @param {string} searchParams.course_code - 课程编号，可选
 * @returns {Promise}
 */
export const searchStudents = async (searchParams = {}) => {
  return get(BASE_PATH, searchParams);
};

export default {
  getStudentList,
  addStudent,
  updateStudent,
  deleteStudent,
  exportStudents,
  searchStudents,
};