// src/app/api/teacher/studentImport.js
import * as XLSX from 'xlsx';
import * as pdfParse from 'pdf-parse';
import { get, post, del, download } from '../request';

const STUDENT_IMPORT_PATH = '/teacher/students/import';
const CLASS_PATH = '/teacher/classes';

/**
 * 解析 Excel 文件（.xlsx, .xls）
 */
export const parseExcelFile = async (file, onProgress) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });

        const firstSheetName = workbook.SheetNames[0];
        const firstSheet = workbook.Sheets[firstSheetName];
        const jsonData = XLSX.utils.sheet_to_json(firstSheet);

        if (jsonData.length === 0) {
          reject(new Error('Excel 文件中没有数据'));
          return;
        }

        const students = jsonData.map((row, index) => {
          if (onProgress) {
            onProgress(Math.floor(((index + 1) / jsonData.length) * 100));
          }

          const student_no =
            row['学号'] ||
            row['student_no'] ||
            row['学号/Student ID'] ||
            row['学生编号'] ||
            '';
          const name = row['姓名'] || row['name'] || row['学生姓名'] || '';
          const courseCode =
            row['课程编号'] || row['courseCode'] || row['course_code'] || '';
          const courseSeq =
            row['课序号'] || row['courseSeq'] || row['course_seq'] || '';
          const className =
            row['班级'] || row['className'] || row['class_name'] || '';

          return {
            student_no: String(student_no).trim(),
            name: String(name).trim(),
            courseCode: String(courseCode).trim(),
            courseSeq: String(courseSeq).trim(),
            className: String(className).trim(),
            rowIndex: index + 2,
          };
        }).filter((student) => student.student_no || student.name);

        resolve(students);
      } catch (error) {
        reject(new Error(`Excel解析失败: ${error.message}`));
      }
    };

    reader.onerror = () => {
      reject(new Error('文件读取失败'));
    };

    reader.readAsArrayBuffer(file);
  });
};

/**
 * 解析 PDF 文件
 */
export const parsePdfFile = async (file, onProgress) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = async (e) => {
      try {
        if (onProgress) onProgress(30);

        const dataBuffer = e.target.result;
        const pdfData = await pdfParse(dataBuffer);

        if (onProgress) onProgress(60);

        const text = pdfData.text;
        const students = parsePdfText(text);

        if (onProgress) onProgress(100);

        if (students.length === 0) {
          reject(new Error('PDF 文件中未识别到学生数据'));
          return;
        }

        resolve(students);
      } catch (error) {
        reject(new Error(`PDF解析失败: ${error.message}`));
      }
    };

    reader.onerror = () => {
      reject(new Error('文件读取失败'));
    };

    reader.readAsArrayBuffer(file);
  });
};

/**
 * 解析 PDF 文本内容
 */
const parsePdfText = (text) => {
  const lines = text.split('\n').filter((line) => line.trim());
  const students = [];

  const tablePattern =
    /(\d{13})\s+([^\s]+)\s+([A-Z0-9]+)\s+(\d+)\s+(.+)/;  // 邮箱字段已删除
  const simplePattern =
    /(\d{13})\s+([^\s]+)\s+([A-Z0-9]+)\s+(\d+)\s+(.+)/;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    let match = null;
    let student = null;

    if ((match = line.match(tablePattern))) {
      student = {
        student_no: match[1],
        name: match[2],
        courseCode: match[3],
        courseSeq: match[4],
        className: match[5],
      };
    } else if ((match = line.match(simplePattern))) {
      student = {
        student_no: match[1],
        name: match[2],
        courseCode: match[3],
        courseSeq: match[4],
        className: match[5],
      };
    }

    if (student) {
      students.push({
        ...student,
        rowIndex: i + 1,
      });
    }
  }

  return students;
};

/**
 * 解析 CSV 文件
 */

export const parseCsvFile = async (file, onProgress) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const text = e.target.result;
        const lines = text.split('\n').filter((line) => line.trim());

        if (lines.length < 2) {
          reject(new Error('CSV 文件至少需要包含表头和数据行'));
          return;
        }

        const headers = parseCsvLine(lines[0]);
        const students = [];

        for (let i = 1; i < lines.length; i++) {
          if (onProgress) {
            onProgress(Math.floor(((i + 1) / lines.length) * 100));
          }

          const values = parseCsvLine(lines[i]);
          const student = {};

          headers.forEach((header, idx) => {
            const fieldName = mapHeaderToField(header);
            // 只解析去掉邮箱后的字段
            if (fieldName !== 'email') {
              student[fieldName] = values[idx] || '';
            }
          });

          if (student.student_no || student.name) {
            student.rowIndex = i + 1;
            students.push(student);
          }
        }

        resolve(students);
      } catch (error) {
        reject(new Error(`CSV解析失败: ${error.message}`));
      }
    };

    reader.onerror = () => {
      reject(new Error('文件读取失败'));
    };

    reader.readAsText(file, 'UTF-8');
  });
};

/**
 * 解析 CSV 行
 */
const parseCsvLine = (line) => {
  const result = [];
  let inQuotes = false;
  let currentValue = '';

  for (let i = 0; i < line.length; i++) {
    const char = line[i];

    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      result.push(currentValue.trim());
      currentValue = '';
    } else {
      currentValue += char;
    }
  }

  result.push(currentValue.trim());
  return result;
};

/**
 * 映射 CSV 表头到字段名
 * 去除邮箱字段
 */
const mapHeaderToField = (header) => {
  const mapping = {
    学号: 'student_no',
    student_no: 'student_no',
    学生编号: 'student_no',
    studentId: 'student_no',
    姓名: 'name',
    name: 'name',
    学生姓名: 'name',
    // 删除邮箱相关映射
    课程编号: 'courseCode',
    courseCode: 'courseCode',
    course_code: 'courseCode',
    课序号: 'courseSeq',
    courseSeq: 'courseSeq',
    course_seq: 'courseSeq',
    班级: 'className',
    className: 'className',
    class_name: 'className',
  };

  return mapping[header] || header;
};

/**
 * 智能解析文件（自动识别文件类型）
 */
export const parseFile = async (file, onProgress) => {
  const fileExtension = file.name.split('.').pop()?.toLowerCase();

  try {
    let students = [];

    switch (fileExtension) {
      case 'xlsx':
      case 'xls':
        students = await parseExcelFile(file, onProgress);
        break;
      case 'pdf':
        students = await parsePdfFile(file, onProgress);
        break;
      case 'csv':
        students = await parseCsvFile(file, onProgress);
        break;
      default:
        throw new Error(
          `不支持的文件格式: ${fileExtension}，请上传 Excel(.xlsx/.xls)、PDF 或 CSV 文件`
        );
    }

    if (students.length === 0) {
      return {
        code: -1,
        data: [],
        message: '文件中未找到有效的学生数据，请检查文件格式',
      };
    }

    return {
      code: 0,
      data: students,
      message: `解析成功，共 ${students.length} 条记录`,
    };
  } catch (error) {
    console.error('文件解析错误:', error);
    return {
      code: -1,
      data: [],
      message: error.message,
    };
  }
};

/**
 * 导入学生数据到后端
 ** 接口地址: POST /api/v1/teacher/students/import
 * 请求示例：
 * importStudents(1, [
 * {
 *    student_no: "2024001",
 *    name: "张三",
 *    email: "zhangsan@example.com",
 *    courseCode: "PYTHON101",
 *    courseSeq: "01",
 *    className: "计算机1班",
 *    rowIndex: 2
 *  }
 * ])
 * 响应示例：
 * {
 *  "code": 0,
 *  "message": "导入成功",
 *  "data": {
 *    "success_count": 1,
 *    "failed_count": 0
 *  }
 * }
 */
export const importStudents = async (classId, students) => {
  return post(STUDENT_IMPORT_PATH, {
    class_id: parseInt(classId),
    students: students,
  });
};

/**
 * 获取导入历史记录列表
 *
 * 接口地址: GET /api/v1/teacher/students/import/history
 * 请求示例：
 * getImportHistory({ page: 1, pageSize: 10, classId: 1, startDate: '2023-01-01', endDate: '2023-12-31' })
 * 响应示例：
 * {
 *  "code": 0,
 *  "data": {
 *    "total": 100,
 *    "page": 1,
 *    "page_size": 10,
 *    "records": [
 *      {
 *        "id": 1,
 *        "class_id": 1,
 *        "class_name": "计算机1班",
 *        "import_time": "2024-01-15 10:30:00",
 *        "total_count": 50,
 *        "success_count": 48,
 *        "failed_count": 2
 *      }
 *    ]
 *  }
 * }
 */
export const getImportHistory = async (params = {}) => {
  const { page = 1, pageSize = 10, classId, startDate, endDate } = params;
  const queryParams = {
    page,
    page_size: pageSize,
    ...(classId && { class_id: classId }),
    ...(startDate && { start_date: startDate }),
    ...(endDate && { end_date: endDate }),
  };

  return get(`${STUDENT_IMPORT_PATH}/history`, queryParams);
};

/**
 * 获取导入记录详情
 * 接口地址: GET /api/v1/teacher/students/import/history/{recordId}
 * 请求示例：
 * getImportRecordDetail(1)
 */
export const getImportRecordDetail = async (recordId) => {
  return get(`${STUDENT_IMPORT_PATH}/history/${encodeURIComponent(recordId)}`);
};

/**
 * 删除导入记录
 * 接口地址: DELETE /api/v1/teacher/students/import/history/{recordId}
 * 请求示例：
 * deleteImportRecord(1)
 */
export const deleteImportRecord = async (recordId) => {
  return del(`${STUDENT_IMPORT_PATH}/history/${encodeURIComponent(recordId)}`);
};

/**
 * 重新导入（基于历史记录）
 * 接口地址: POST /api/v1/teacher/students/import/history/{recordId}/reimport
 * 请求示例：
 * reimportStudents(1)
 */
export const reimportStudents = async (recordId) => {
  return post(
    `${STUDENT_IMPORT_PATH}/history/${encodeURIComponent(recordId)}/reimport`
  );
};

/**
 * 导出失败记录
 * 接口地址: GET /api/v1/teacher/students/import/history/{recordId}/export-failed
 * 请求示例：
 * exportFailedRecords(1)
 * 响应示例：
 * 返回 Excel 文件流，包含所有导入失败的记录
 */
export const exportFailedRecords = async (recordId) => {
  return download(
    `${STUDENT_IMPORT_PATH}/history/${encodeURIComponent(recordId)}/export-failed`
  );
};

/**
 * 获取班级列表
 * 接口地址: GET /api/v1/teacher/classes
 * 请求示例：
 * getClassList()
 */
export const getClassList = async () => {
  return get(CLASS_PATH, { page_size: 1000 });
};

/**
 * 前端校验学生数据
 */
export const validateStudentData = (
  students,
  validCourseCodes = []  // 这里可以去除原来默认的课程编号列表
) => {
  const errors = [];
  const studentIds = new Set();

  students.forEach((student, index) => {
    const studentNo = student.student_no;
    const rowNum = student.rowIndex || index + 1;

    console.log("校验数据:", student);  // 打印每条数据，确保校验执行

    // 校验学号不能为空
    if (!studentNo || studentNo.trim() === '') {
      errors.push({
        row: rowNum,
        field: '学号',
        message: '学号不能为空',
        severity: 'error',
      });
    }

    // 校验姓名不能为空
    if (!student.name || student.name.trim() === '') {
      errors.push({
        row: rowNum,
        field: '姓名',
        message: '姓名不能为空',
        severity: 'error',
      });
    }

    // 校验学号是否重复
    if (studentNo) {
      if (studentIds.has(studentNo)) {
        errors.push({
          row: rowNum,
          field: '学号',
          message: `学号 ${studentNo} 重复`,
          severity: 'error',
        });
      } else {
        studentIds.add(studentNo);
      }
    }

    // 校验学号格式：13位数字
    if (studentNo && !/^\d{13}$/.test(studentNo)) {
      errors.push({
        row: rowNum,
        field: '学号',
        message: '学号格式错误（应为13位数字）',
        severity: 'warning',
      });
    }

    // 校验课程编号格式：9位数字
    if (student.courseCode && !/^\d{9}$/.test(student.courseCode)) {
      errors.push({
        row: rowNum,
        field: '课程编号',
        message: '课程编号格式错误（应为9位数字）',
        severity: 'warning',
      });
    }
  });

  return {
    errors,
    errorCount: errors.filter((e) => e.severity === 'error').length,
    warningCount: errors.filter((e) => e.severity === 'warning').length,
    validCount: students.length - errors.filter((e) => e.severity === 'error').length,
    totalCount: students.length,
  };
};
/**
 * 下载导入模板
 */
export const downloadTemplate = () => {
  const templateData = [
    ['学号', '姓名', '课程编号', '课序号', '班级'],  // 删除邮箱列
    ['2023141460000', '张三', '123456789', '01', '计算机1班'],
    ['2023141460001', '李四', '123456789', '01', '计算机1班'],
    ['2023141460002', '王五', '012345678', '02', '计算机2班'],
  ];

  const ws = XLSX.utils.aoa_to_sheet(templateData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, '学生导入模板');

  ws['!cols'] = [
    { wch: 12 },
    { wch: 10 },
    { wch: 15 },
    { wch: 8 },
    { wch: 20 },
  ];

  const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });

  return new Blob([excelBuffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
};