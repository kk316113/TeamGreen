// src/app/api/teacher/DashboardAPI.js
import { get } from "../request";

/**
 * 获取教师端首页统计信息
 * 接口地址: GET /api/v1/teacher/dashboard/stats
 * 请求参数: 无
 * 响应示例：
 * {
 *   "code": 0,
 *   "message": "success",
 *   "data": [
 *     { "title": "授课课程", "value": 5, "color": "blue" },
 *     { "title": "管理班级", "value": 8, "color": "green" },
 *     { "title": "课程任务", "value": 12, "color": "purple" },
 *     { "title": "待截止任务", "value": 3, "color": "orange" }
 *   ]
 * }
 * @returns {Promise<Array<{title:string, value:number, color:string}>>}
 */
export const getDashboardStats = async () => {
  const res = await get("/teacher/dashboard/stats");
  return res.data || [];
};

/**
 * 获取教师端首页最近导入的学生记录
 * 接口地址: GET /api/v1/teacher/dashboard/recent-imports
 * 请求参数: 无
 * 响应示例：
 * {
 *   "code": 0,
 *   "message": "success",
 *   "data": [
 *     { 
 *       "id": 1,
 *       "fileName": "2024春季-计算机科学-学生名单.xlsx",
 *       "date": "2024-03-28 14:30",
 *       "count": 45
 *     },
 *     {
 *       "id": 2,
 *       "fileName": "2024春季-软件工程-学生名单.pdf",
 *       "date": "2024-03-27 09:15",
 *       "count": 38
 *     }
 *   ]
 * }
 * @returns {Promise<Array<{id:number, fileName:string, date:string, count:number}>>}
 */
export const getRecentImports = async () => {
  const res = await get("/teacher/dashboard/recent-imports");
  return res.data || [];
};

/**
 * 获取教师端首页最近成绩摘要
 * 接口地址: GET /api/v1/teacher/dashboard/recent-grades
 * 请求参数: 无
 * 响应示例：
 * {
 *   "code": 0,
 *   "message": "success",
 *   "data": [
 *     {
 *       "course": "Python程序设计",
 *       "assignment": "实验3：二叉树遍历",
 *       "avgScore": 88.5,
 *       "submitted": 48,
 *       "total": 52
 *     },
 *     {
 *       "course": "Bash Shell程序设计",
 *       "assignment": "实验2：进程调度",
 *       "avgScore": 82.3,
 *       "submitted": 35,
 *       "total": 38
 *     }
 *   ]
 * }
 * @returns {Promise<Array<{course:string, assignment:string, avgScore:number, submitted:number, total:number}>>}
 */
export const getRecentGrades = async () => {
  const res = await get("/teacher/dashboard/recent-grades");
  return res.data || [];
};

export default {
  getDashboardStats,
  getRecentImports,
  getRecentGrades,
};