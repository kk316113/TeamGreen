import { get } from "../request";

/**
 * 获取教师课程列表
 * GET /api/v1/teacher/courses
 *
 * 用途：
 * - 获取当前教师可管理的课程
 * - 用于题库选题页面的“目标课程”下拉框
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: [
 *     {
 *       courseId: string,
 *       courseName: string,
 *       courseCode: string,
 *       className: string,
 *       semester: string
 *     }
 *   ]
 * }
 */
export function getQuestionBankCourses() {
  return get("/teacher/courses");
}

/**
 * 获取题库编程题列表
 * GET /api/v1/teacher/questions
 *
 * 用途：
 * - 获取题库选题页面的编程题列表
 * - 支持按课程、关键词、难度筛选
 * - 题型已固定为编程题，因此不再传 type
 *
 * query params:
 * {
 *   courseId?: string,
 *   keyword?: string,
 *   difficulty?: string
 * }
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: [
 *     {
 *       questionId: string,
 *       title: string,
 *       difficulty: string,
 *       description: string,
 *       languages: string[],
 *       maxScore: number,
 *       tags: string[]
 *     }
 *   ]
 * }
 */
export function getQuestionBankList(params = {}) {
  return get("/teacher/questions", params);
}

/**
 * 获取题目详情
 * GET /api/v1/teacher/questions/{questionId}
 *
 * 用途：
 * - 点击“查看详情”后获取题目完整信息
 *
 * path params:
 * - questionId: string
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: {
 *     questionId: string,
 *     title: string,
 *     difficulty: string,
 *     description: string,
 *     languages: string[],
 *     maxScore: number,
 *     tags: string[],
 *     inputDescription: string,
 *     outputDescription: string,
 *     sampleInput: string,
 *     sampleOutput: string,
 *     timeLimit: number,
 *     memoryLimit: number
 *   }
 * }
 */
export function getQuestionDetail(questionId) {
  if (!questionId) {
    throw new Error("questionId 不能为空");
  }

  return get(`/teacher/questions/${encodeURIComponent(questionId)}`);
}