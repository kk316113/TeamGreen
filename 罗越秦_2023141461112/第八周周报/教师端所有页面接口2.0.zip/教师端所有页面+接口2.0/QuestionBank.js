import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useState } from "react";
import { Link } from "react-router";
import {
  Search,
  Eye,
  Plus,
  Code,
  FileText,
  Target,
  BookOpen,
  X,
} from "lucide-react";
import { Card, CardContent } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import {
  getQuestionBankCourses,
  getQuestionBankList,
  getQuestionDetail,
} from "../api/teacher/questionBank";

export function QuestionBank() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterDifficulty, setFilterDifficulty] = useState("all");
  const [selectedCourse, setSelectedCourse] = useState("none");

  const [courses, setCourses] = useState([]);
  const [questions, setQuestions] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const [detailVisible, setDetailVisible] = useState(false);
  const [detailLoading, setDetailLoading] = useState(false);
  const [questionDetail, setQuestionDetail] = useState(null);

  useEffect(() => {
    loadCourses();
  }, []);

  useEffect(() => {
    loadQuestions();
  }, [selectedCourse, searchTerm, filterDifficulty]);

  async function loadCourses() {
    try {
      const res = await getQuestionBankCourses();
      const courseList = res?.data || [];

      setCourses([
        {
          courseId: "none",
          courseName: "请选择课程",
        },
        ...courseList,
      ]);
    } catch (error) {
      alert(error.message || "获取课程列表失败");
    }
  }

  async function loadQuestions() {
    try {
      setIsLoading(true);

      const res = await getQuestionBankList({
        courseId: selectedCourse !== "none" ? selectedCourse : "",
        keyword: searchTerm,
        difficulty: filterDifficulty !== "all" ? filterDifficulty : "",
      });

      const questionList = Array.isArray(res?.data)
        ? res.data
        : res?.data?.questions || res?.data?.list || [];

      setQuestions(
        questionList.map((item) => ({
          id: item.questionId || item.id,
          title: item.title || item.questionTitle || "未命名题目",
          difficulty: normalizeDifficulty(item.difficulty),
          languages: normalizeArray(item.languages || item.supportLanguages),
          description: item.description || item.content || "",
          tags: normalizeArray(item.tags),
          maxScore: item.maxScore || item.score || item.totalScore || 100,
        }))
      );
    } catch (error) {
      alert(error.message || "获取题库题目失败");
    } finally {
      setIsLoading(false);
    }
  }

  function normalizeArray(value) {
    if (Array.isArray(value)) {
      return value;
    }

    if (typeof value === "string" && value.trim()) {
      return value.split(",").map((item) => item.trim());
    }

    return [];
  }

  function normalizeDifficulty(difficulty) {
    const difficultyMap = {
      easy: "简单",
      medium: "中等",
      hard: "困难",
      EASY: "简单",
      MEDIUM: "中等",
      HARD: "困难",
    };

    return difficultyMap[difficulty] || difficulty || "中等";
  }

  async function handleViewDetail(questionId) {
    if (!questionId) {
      alert("题目 ID 不能为空");
      return;
    }

    try {
      setDetailVisible(true);
      setDetailLoading(true);
      setQuestionDetail(null);

      const res = await getQuestionDetail(questionId);
      const detail = res?.data || {};

      setQuestionDetail({
        id: detail.questionId || detail.id || questionId,
        title: detail.title || detail.questionTitle || "未命名题目",
        difficulty: normalizeDifficulty(detail.difficulty),
        languages: normalizeArray(detail.languages || detail.supportLanguages),
        description: detail.description || detail.content || "",
        tags: normalizeArray(detail.tags),
        maxScore: detail.maxScore || detail.score || detail.totalScore || 100,
        inputDescription: detail.inputDescription || detail.input || "",
        outputDescription: detail.outputDescription || detail.output || "",
        sampleInput: detail.sampleInput || "",
        sampleOutput: detail.sampleOutput || "",
        timeLimit: detail.timeLimit || "",
        memoryLimit: detail.memoryLimit || "",
      });
    } catch (error) {
      setDetailVisible(false);
      alert(error.message || "获取题目详情失败");
    } finally {
      setDetailLoading(false);
    }
  }

  function handleAddQuestion(question) {
    if (selectedCourse === "none") {
      alert("请先选择目标课程");
      return;
    }

    const savedQuestions = JSON.parse(
      localStorage.getItem("selectedTaskQuestions") || "[]"
    );

    const exists = savedQuestions.some(
      (item) => String(item.id) === String(question.id)
    );

    if (exists) {
      alert("该题目已加入任务");
      return;
    }

    const nextQuestions = [
      ...savedQuestions,
      {
        id: question.id,
        title: question.title,
        difficulty: question.difficulty,
        maxScore: question.maxScore,
      },
    ];

    localStorage.setItem("selectedTaskCourseId", selectedCourse);
    localStorage.setItem("selectedTaskQuestions", JSON.stringify(nextQuestions));

    alert("题目已加入待创建任务");
  }

  const getDifficultyBadge = (difficulty) => {
    const colorClasses = {
      简单: "bg-green-50 text-green-700 border-green-200",
      中等: "bg-amber-50 text-amber-700 border-amber-200",
      困难: "bg-red-50 text-red-700 border-red-200",
    };

    return _jsx(Badge, {
      variant: "outline",
      className:
        colorClasses[difficulty] ||
        "bg-gray-50 text-gray-700 border-gray-200",
      children: difficulty,
    });
  };

  const currentCourseName =
    courses.find((course) => course.courseId === selectedCourse)?.courseName ||
    "";

  const filteredQuestions = questions;

  return _jsxs("div", {
    className: "space-y-6",
    children: [
      _jsxs("div", {
        children: [
          _jsx("h1", {
            className: "text-2xl text-gray-900 mb-1",
            children: "题库选题",
          }),
          _jsx("p", {
            className: "text-gray-600",
            children: "从题库中选择题目，用于创建课程任务",
          }),
        ],
      }),

      selectedCourse === "none" &&
        _jsx(Card, {
          className: "border-0 shadow-sm bg-blue-50 border-blue-200",
          children: _jsx(CardContent, {
            className: "p-4",
            children: _jsxs("div", {
              className: "flex items-start gap-3",
              children: [
                _jsx(BookOpen, {
                  className: "w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5",
                }),
                _jsxs("div", {
                  children: [
                    _jsx("p", {
                      className: "text-sm text-blue-900 mb-1",
                      children: "请先选择要创建任务的课程",
                    }),
                    _jsx("p", {
                      className: "text-xs text-blue-700",
                      children:
                        "选择课程后，可以从题库中选择题目并加入到该课程的任务中",
                    }),
                  ],
                }),
              ],
            }),
          }),
        }),

      _jsx(Card, {
        className: "border-0 shadow-sm",
        children: _jsx(CardContent, {
          className: "p-6",
          children: _jsxs("div", {
            className: "flex flex-col lg:flex-row gap-4",
            children: [
              _jsxs("div", {
                className: "w-full lg:w-64",
                children: [
                  _jsx("label", {
                    className: "text-sm text-gray-700 mb-2 block",
                    children: "目标课程",
                  }),
                  _jsxs(Select, {
                    value: selectedCourse,
                    onValueChange: setSelectedCourse,
                    children: [
                      _jsx(SelectTrigger, {
                        children: _jsx(SelectValue, {}),
                      }),
                      _jsx(SelectContent, {
                        children: courses.map((course) =>
                          _jsx(
                            SelectItem,
                            {
                              value: course.courseId,
                              children: course.courseName,
                            },
                            course.courseId
                          )
                        ),
                      }),
                    ],
                  }),
                ],
              }),

              _jsxs("div", {
                className: "flex-1 relative",
                children: [
                  _jsx("label", {
                    className: "text-sm text-gray-700 mb-2 block",
                    children: "搜索",
                  }),
                  _jsx(Search, {
                    className: "absolute left-3 bottom-3 w-4 h-4 text-gray-400",
                  }),
                  _jsx(Input, {
                    placeholder: "搜索题目名称、描述或标签...",
                    value: searchTerm,
                    onChange: (e) => setSearchTerm(e.target.value),
                    className: "pl-10",
                  }),
                ],
              }),

              _jsxs("div", {
                className: "w-full lg:w-40",
                children: [
                  _jsx("label", {
                    className: "text-sm text-gray-700 mb-2 block",
                    children: "难度",
                  }),
                  _jsxs(Select, {
                    value: filterDifficulty,
                    onValueChange: setFilterDifficulty,
                    children: [
                      _jsx(SelectTrigger, {
                        children: _jsx(SelectValue, {}),
                      }),
                      _jsxs(SelectContent, {
                        children: [
                          _jsx(SelectItem, {
                            value: "all",
                            children: "全部难度",
                          }),
                          _jsx(SelectItem, {
                            value: "简单",
                            children: "简单",
                          }),
                          _jsx(SelectItem, {
                            value: "中等",
                            children: "中等",
                          }),
                          _jsx(SelectItem, {
                            value: "困难",
                            children: "困难",
                          }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
        }),
      }),

      _jsxs("div", {
        className: "space-y-4",
        children: [
          _jsx("div", {
            className: "flex items-center justify-between",
            children: _jsx("p", {
              className: "text-sm text-gray-600",
              children: isLoading
                ? "正在加载题目..."
                : `找到 ${filteredQuestions.length} 道题目`,
            }),
          }),

          !isLoading &&
            filteredQuestions.map((question) =>
              _jsx(
                Card,
                {
                  className:
                    "border-0 shadow-sm hover:shadow-md transition-shadow",
                  children: _jsx(CardContent, {
                    className: "p-6",
                    children: _jsxs("div", {
                      className: "flex flex-col lg:flex-row gap-4",
                      children: [
                        _jsxs("div", {
                          className: "flex-1 space-y-3",
                          children: [
                            _jsx("div", {
                              className: "flex items-start gap-3",
                              children: _jsxs("div", {
                                className: "flex-1",
                                children: [
                                  _jsxs("div", {
                                    className: "flex items-center gap-3 mb-2",
                                    children: [
                                      _jsx("h3", {
                                        className: "text-lg text-gray-900",
                                        children: question.title,
                                      }),
                                      getDifficultyBadge(question.difficulty),
                                    ],
                                  }),
                                  _jsx("p", {
                                    className:
                                      "text-sm text-gray-600 line-clamp-2",
                                    children: question.description,
                                  }),
                                ],
                              }),
                            }),

                            _jsxs("div", {
                              className:
                                "flex flex-wrap items-center gap-4 text-sm",
                              children: [
                                _jsxs("div", {
                                  className:
                                    "flex items-center gap-2 text-gray-600",
                                  children: [
                                    _jsx(Code, {
                                      className: "w-4 h-4",
                                    }),
                                    _jsx("span", {
                                      children:
                                        question.languages.length > 0
                                          ? question.languages.join(", ")
                                          : "未设置语言",
                                    }),
                                  ],
                                }),

                                _jsxs("div", {
                                  className:
                                    "flex items-center gap-2 text-gray-600",
                                  children: [
                                    _jsx(Target, {
                                      className: "w-4 h-4",
                                    }),
                                    _jsxs("span", {
                                      children: [
                                        "满分：",
                                        question.maxScore,
                                        "分",
                                      ],
                                    }),
                                  ],
                                }),

                                _jsx("div", {
                                  className: "flex flex-wrap gap-2",
                                  children: question.tags.map((tag, index) =>
                                    _jsx(
                                      Badge,
                                      {
                                        variant: "secondary",
                                        className: "bg-gray-100 text-gray-700",
                                        children: tag,
                                      },
                                      index
                                    )
                                  ),
                                }),
                              ],
                            }),
                          ],
                        }),

                        _jsxs("div", {
                          className:
                            "flex lg:flex-col gap-2 lg:justify-center lg:min-w-[140px]",
                          children: [
                            _jsxs(Button, {
                              variant: "outline",
                              size: "sm",
                              className: "flex-1 gap-2",
                              onClick: () => handleViewDetail(question.id),
                              children: [
                                _jsx(Eye, {
                                  className: "w-4 h-4",
                                }),
                                "查看详情",
                              ],
                            }),

                            _jsxs(Button, {
                              size: "sm",
                              className:
                                "flex-1 gap-2 bg-blue-600 hover:bg-blue-700",
                              disabled: selectedCourse === "none",
                              onClick: () => handleAddQuestion(question),
                              children: [
                                _jsx(Plus, {
                                  className: "w-4 h-4",
                                }),
                                "加入任务",
                              ],
                            }),
                          ],
                        }),
                      ],
                    }),
                  }),
                },
                question.id
              )
            ),

          !isLoading &&
            filteredQuestions.length === 0 &&
            _jsx(Card, {
              className: "border-0 shadow-sm",
              children: _jsx(CardContent, {
                className: "py-12",
                children: _jsx("div", {
                  className: "text-center",
                  children: _jsx("p", {
                    className: "text-gray-500",
                    children: "没有找到匹配的题目",
                  }),
                }),
              }),
            }),
        ],
      }),

      selectedCourse !== "none" &&
        _jsx(Card, {
          className: "border-0 shadow-sm bg-gray-50",
          children: _jsx(CardContent, {
            className: "p-4",
            children: _jsxs("div", {
              className: "flex items-center justify-between",
              children: [
                _jsxs("p", {
                  className: "text-sm text-gray-700",
                  children: [
                    "当前目标课程：",
                    _jsx("span", {
                      className: "text-gray-900 ml-2",
                      children: currentCourseName,
                    }),
                  ],
                }),
                _jsx(Link, {
                  to: "/teacher/task-management",
                  children: _jsxs(Button, {
                    className: "gap-2",
                    children: [
                      _jsx(FileText, {
                        className: "w-4 h-4",
                      }),
                      "前往任务管理",
                    ],
                  }),
                }),
              ],
            }),
          }),
        }),

      detailVisible &&
        _jsx("div", {
          className:
            "fixed inset-0 z-50 flex items-center justify-center bg-black/30 px-4",
          children: _jsx(Card, {
            className: "w-full max-w-3xl border-0 shadow-lg",
            children: _jsx(CardContent, {
              className: "p-6",
              children: detailLoading
                ? _jsx("div", {
                    className: "py-16 text-center text-gray-500",
                    children: "正在加载题目详情...",
                  })
                : questionDetail &&
                  _jsxs("div", {
                    className: "space-y-5",
                    children: [
                      _jsxs("div", {
                        className: "flex items-start justify-between gap-4",
                        children: [
                          _jsxs("div", {
                            children: [
                              _jsxs("div", {
                                className: "flex items-center gap-3 mb-2",
                                children: [
                                  _jsx("h2", {
                                    className: "text-xl text-gray-900",
                                    children: questionDetail.title,
                                  }),
                                  getDifficultyBadge(questionDetail.difficulty),
                                ],
                              }),
                              _jsxs("p", {
                                className: "text-sm text-gray-600",
                                children: [
                                  "满分：",
                                  questionDetail.maxScore,
                                  "分",
                                ],
                              }),
                            ],
                          }),
                          _jsx(Button, {
                            variant: "ghost",
                            size: "icon",
                            onClick: () => setDetailVisible(false),
                            children: _jsx(X, {
                              className: "w-5 h-5",
                            }),
                          }),
                        ],
                      }),

                      _jsxs("div", {
                        className: "space-y-2",
                        children: [
                          _jsx("h3", {
                            className: "text-sm text-gray-900",
                            children: "题目描述",
                          }),
                          _jsx("p", {
                            className: "text-sm text-gray-600 leading-6",
                            children:
                              questionDetail.description || "暂无题目描述",
                          }),
                        ],
                      }),

                      _jsxs("div", {
                        className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                        children: [
                          _jsxs("div", {
                            className: "space-y-2",
                            children: [
                              _jsx("h3", {
                                className: "text-sm text-gray-900",
                                children: "输入说明",
                              }),
                              _jsx("p", {
                                className: "text-sm text-gray-600 leading-6",
                                children:
                                  questionDetail.inputDescription || "暂无",
                              }),
                            ],
                          }),
                          _jsxs("div", {
                            className: "space-y-2",
                            children: [
                              _jsx("h3", {
                                className: "text-sm text-gray-900",
                                children: "输出说明",
                              }),
                              _jsx("p", {
                                className: "text-sm text-gray-600 leading-6",
                                children:
                                  questionDetail.outputDescription || "暂无",
                              }),
                            ],
                          }),
                        ],
                      }),

                      _jsxs("div", {
                        className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                        children: [
                          _jsxs("div", {
                            className: "space-y-2",
                            children: [
                              _jsx("h3", {
                                className: "text-sm text-gray-900",
                                children: "样例输入",
                              }),
                              _jsx("pre", {
                                className:
                                  "rounded-lg bg-gray-50 p-3 text-sm text-gray-700 overflow-auto",
                                children: questionDetail.sampleInput || "暂无",
                              }),
                            ],
                          }),
                          _jsxs("div", {
                            className: "space-y-2",
                            children: [
                              _jsx("h3", {
                                className: "text-sm text-gray-900",
                                children: "样例输出",
                              }),
                              _jsx("pre", {
                                className:
                                  "rounded-lg bg-gray-50 p-3 text-sm text-gray-700 overflow-auto",
                                children:
                                  questionDetail.sampleOutput || "暂无",
                              }),
                            ],
                          }),
                        ],
                      }),

                      _jsxs("div", {
                        className: "flex flex-wrap items-center gap-4 text-sm",
                        children: [
                          _jsxs("div", {
                            className: "flex items-center gap-2 text-gray-600",
                            children: [
                              _jsx(Code, {
                                className: "w-4 h-4",
                              }),
                              _jsx("span", {
                                children:
                                  questionDetail.languages.length > 0
                                    ? questionDetail.languages.join(", ")
                                    : "未设置语言",
                              }),
                            ],
                          }),
                          questionDetail.timeLimit &&
                            _jsxs("span", {
                              className: "text-gray-600",
                              children: [
                                "时间限制：",
                                questionDetail.timeLimit,
                                " ms",
                              ],
                            }),
                          questionDetail.memoryLimit &&
                            _jsxs("span", {
                              className: "text-gray-600",
                              children: [
                                "内存限制：",
                                questionDetail.memoryLimit,
                                " MB",
                              ],
                            }),
                        ],
                      }),

                      questionDetail.tags.length > 0 &&
                        _jsx("div", {
                          className: "flex flex-wrap gap-2",
                          children: questionDetail.tags.map((tag, index) =>
                            _jsx(
                              Badge,
                              {
                                variant: "secondary",
                                className: "bg-gray-100 text-gray-700",
                                children: tag,
                              },
                              index
                            )
                          ),
                        }),
                    ],
                  }),
            }),
          }),
        }),
    ],
  });
}