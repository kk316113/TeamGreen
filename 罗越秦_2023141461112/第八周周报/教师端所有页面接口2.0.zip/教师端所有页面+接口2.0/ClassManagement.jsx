import { useState, useEffect, useCallback } from "react";
import { BookOpen, Users, Search, UserCog, ArrowRight, Check, RefreshCw } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "../components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import {
  getGroupedClasses,
  getCourseStudents,
  adjustStudentClass,
  getClassStatistics,
} from "../api/teacher/ClassManagement";

/**
 * 分班管理组件
 * 用于查看课程班级信息，调整学生分班
 */
export function ClassManagement() {
  // 搜索相关状态
  const [searchTerm, setSearchTerm] = useState("");
  // 调整学生班级对话框状态
  const [isAdjustDialogOpen, setIsAdjustDialogOpen] = useState(false);
  // 当前选中的课程
  const [selectedCourse, setSelectedCourse] = useState(null);
  // 学生搜索关键词
  const [studentSearchTerm, setStudentSearchTerm] = useState("");
  // 选中的学生ID列表
  const [selectedStudents, setSelectedStudents] = useState([]);
  // 目标班级
  const [targetClass, setTargetClass] = useState("");
  
  // 数据状态
  const [groupedCourses, setGroupedCourses] = useState({});
  const [classes, setClasses] = useState([]);
  const [courseStudents, setCourseStudents] = useState([]);
  const [statistics, setStatistics] = useState({
    courseCount: 0,
    classCount: 0,
    studentCount: 0,
  });
  
  // UI 状态
  const [loading, setLoading] = useState(false);
  const [loadingStudents, setLoadingStudents] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);

  // 获取班级分组数据
  const fetchGroupedClasses = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await getGroupedClasses({ search: searchTerm });
      if (result.code === 0) {
        const data = result.data || {};
        setGroupedCourses(data.groupedCourses || {});
        setClasses(data.classes || []);
      } else {
        setError(result.message || "获取班级列表失败");
      }
    } catch (err) {
      console.error("获取班级列表失败", err);
      setError(err.message || "网络错误，请稍后重试");
    } finally {
      setLoading(false);
    }
  }, [searchTerm]);

  // 获取统计数据
  const fetchStatistics = useCallback(async () => {
    try {
      const result = await getClassStatistics();
      if (result.code === 0) {
        setStatistics(result.data || {
          courseCount: 0,
          classCount: 0,
          studentCount: 0,
        });
      }
    } catch (err) {
      console.error("获取统计数据失败", err);
    }
  }, []);

  // 初始加载
  useEffect(() => {
    fetchGroupedClasses();
    fetchStatistics();
  }, [fetchGroupedClasses, fetchStatistics]);

  // 搜索时重新加载
  useEffect(() => {
    const debounceTimer = setTimeout(() => {
      if (searchTerm !== undefined) {
        fetchGroupedClasses();
      }
    }, 300);
    
    return () => clearTimeout(debounceTimer);
  }, [searchTerm, fetchGroupedClasses]);

  // 获取课程学生列表
  const fetchCourseStudents = useCallback(async (course) => {
    if (!course) return [];
    
    setLoadingStudents(true);
    try {
      const result = await getCourseStudents(course.courseCode, course.courseName);
      if (result.code === 0) {
        setCourseStudents(result.data || []);
        return result.data || [];
      } else {
        setError(result.message || "获取学生列表失败");
        return [];
      }
    } catch (err) {
      console.error("获取学生列表失败", err);
      setError(err.message || "网络错误，请稍后重试");
      return [];
    } finally {
      setLoadingStudents(false);
    }
  }, []);

/**
 * 处理打开调整对话框的函数
 * @param {Object} course - 课程对象，包含课程相关信息
 */
  const handleOpenAdjustDialog = async (course) => {
  // 设置当前选中的课程
    setSelectedCourse(course);
  // 打开调整对话框
    setIsAdjustDialogOpen(true);
  // 清空已选学生列表
    setSelectedStudents([]);
  // 清空目标班级
    setTargetClass("");
  // 清空学生搜索关键词
    setStudentSearchTerm("");
  // 清空错误信息
    setError(null);
    
    // 加载该课程的学生列表
    await fetchCourseStudents(course);
  };

  /**
   * 关闭对话框并重置所有相关状态
   * 该函数用于处理对话框关闭时的状态清理工作
   */
  const handleCloseDialog = () => {
    setIsAdjustDialogOpen(false); // 关闭调整对话框
    setSelectedCourse(null); // 清空选中的课程
    setSelectedStudents([]); // 清空选中的学生列表
    setTargetClass(""); // 清空目标班级
    setStudentSearchTerm(""); // 清空学生搜索关键词
    setError(null); // 清空错误信息
  };

/**
 * 切换学生选择状态的函数
 * @param {number|string} studentId - 要切换选择状态的学生ID
 */
  const toggleStudentSelection = (studentId) => {
  // 检查当前学生ID是否已在已选学生列表中
    if (selectedStudents.includes(studentId)) {
    // 如果已存在，则从已选学生列表中移除该学生
      setSelectedStudents(selectedStudents.filter((id) => id !== studentId));
    } else {
    // 如果不存在，则将该学生添加到已选学生列表中
      setSelectedStudents([...selectedStudents, studentId]);
    }
  };

/**
 * 全选/取消全选学生的切换函数
 * 当已选学生数量等于筛选后的学生数量时，清空已选学生列表
 * 否则，将所有筛选后的学生ID添加到已选学生列表中
 */
  const toggleSelectAll = () => {
  // 判断是否已全选
    if (selectedStudents.length === filteredStudents.length) {
    // 如果已全选，则清空已选学生列表
      setSelectedStudents([]);
    } else {
    // 如果未全选，则将所有筛选后的学生ID添加到已选学生列表
      setSelectedStudents(filteredStudents.map(s => s.id));
    }
  };


  /**
   * 处理调整学生班级的异步函数
   * 该函数负责验证输入参数、调用API调整学生班级、处理响应结果和错误情况
   */
  /**
   * 处理调整学生班级的异步函数
   * 该函数会验证输入参数，调用API进行班级调整，并根据结果更新UI状态
   */
  const handleAdjustClass = async () => {
    // 验证是否选择了学生和目标班级
    if (selectedStudents.length === 0 || !targetClass) {
      setError("请选择学生和目标班级");
      return;
    }

    // 验证课程信息是否完整
    if (!selectedCourse) {
      setError("课程信息缺失");
      return;
    }

    // 设置提交状态为true，清空错误信息
    setSubmitting(true);
    setError(null);

    try {
      // 调用调整学生班级的API
      const result = await adjustStudentClass({
        studentIds: selectedStudents,  // 选中的学生ID数组
        targetClass: targetClass,      // 目标班级
        courseCode: selectedCourse.courseCode,  // 课程代码
        courseName: selectedCourse.courseName,  // 课程名称
      });

      // 如果API返回成功
      if (result.code === 0) {
        // 设置成功消息，关闭对话框，刷新数据
        setSuccessMessage(`成功将 ${selectedStudents.length} 名学生调整到 ${targetClass}`);
        handleCloseDialog();
        // 刷新数据
        fetchGroupedClasses();
        fetchStatistics();
        // 3秒后自动清除成功消息
        setTimeout(() => setSuccessMessage(null), 3000);
      } else {
        setError(result.message || "调整失败");
      }
    } catch (err) {
      console.error("调整失败", err);
      setError(err.message || "网络错误，请稍后重试");
    } finally {
      // 无论成功或失败，都将提交状态重置为false
      setSubmitting(false);
    }
  };

  // 搜索过滤学生
  const filteredStudents = courseStudents.filter((student) => {
    if (!studentSearchTerm) return true;
    const term = studentSearchTerm.toLowerCase();
    return (
      student.name?.toLowerCase().includes(term) ||
      student.student_no?.toLowerCase().includes(term) ||
      student.current_class?.toLowerCase().includes(term)
    );
  });

/**
 * 获取目标班级名称列表
 * 该函数从选中的课程中提取班级名称
 * @returns {Array} 返回班级名称数组，如果没有选中课程或课程没有班级信息则返回空数组
 */
  const getTargetClasses = () => {
  // 检查是否有选中的课程以及课程是否包含班级信息
    if (!selectedCourse || !selectedCourse.classes) return [];
  // 将课程中的班级对象映射为班级名称数组
  // 支持两种可能的属性名：class_name 和 className
    return selectedCourse.classes.map((cls) => cls.class_name || cls.className);
  };

  // 计算总学生数
  const totalStudents = classes.reduce((sum, cls) => sum + (cls.student_count || cls.studentCount || 0), 0);

  // 渲染加载状态
  if (loading && Object.keys(groupedCourses).length === 0) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 text-gray-400 mx-auto mb-2 animate-spin" />
          <p className="text-gray-500">加载中...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* 页面标题 */}
      <div>
        <h1 className="text-3xl font-semibold text-gray-900 mb-2">分班管理</h1>
        <p className="text-gray-500">按课程/课序号查看班级，调整学生分班</p>
      </div>

      {/* 错误提示 */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
          {error}
        </div>
      )}
      
      {/* 成功提示 */}
      {successMessage && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-green-700">
          {successMessage}
        </div>
      )}

      {/* 搜索栏 */}
      <Card className="border border-gray-100 shadow-sm">
        <CardContent className="p-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="搜索课程编号、课程名称、课序号或班级..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 border-gray-200"
            />
          </div>
        </CardContent>
      </Card>

      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-500 mb-3">课程总数</p>
                <h3 className="text-4xl font-semibold text-gray-900">
                  {statistics.courseCount || Object.keys(groupedCourses).length}
                </h3>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-sm">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-500 mb-3">班级总数</p>
                <h3 className="text-4xl font-semibold text-gray-900">
                  {statistics.classCount || classes.length}
                </h3>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-sm">
                <Users className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-500 mb-3">学生总数</p>
                <h3 className="text-4xl font-semibold text-gray-900">
                  {statistics.studentCount || totalStudents}
                </h3>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center shadow-sm">
                <Users className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 课程列表 */}
      <div className="space-y-6">
        {Object.values(groupedCourses).map((course, index) => (
          <Card key={index} className="border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
            <CardHeader className="bg-gray-50 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg font-semibold text-gray-900">
                    {course.course_code || course.courseCode} - {course.course_name || course.courseName}
                  </CardTitle>
                  <p className="text-sm text-gray-500 mt-1">
                    {course.classes?.length || 0} 个班级 •{" "}
                    {course.classes?.reduce((sum, cls) => sum + (cls.student_count || cls.studentCount || 0), 0)} 名学生
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant="outline" className="text-blue-600 border-blue-200 bg-blue-50">
                    {course.classes?.[0]?.semester || "2024春季"}
                  </Badge>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleOpenAdjustDialog(course)}
                    className="gap-2 border-gray-200 hover:bg-blue-50 hover:text-blue-600 hover:border-blue-200"
                  >
                    <UserCog className="w-4 h-4" />
                    调整学生班级
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {course.classes?.map((cls) => (
                  <div
                    key={cls.id || cls.class_id}
                    className="border border-gray-200 rounded-xl p-4 hover:border-blue-300 hover:shadow-sm transition-all"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-medium text-gray-900">
                            {cls.class_name || cls.className}
                          </h3>
                          <Badge variant="secondary" className="text-xs bg-blue-50 text-blue-700 font-normal">
                            课序号 {cls.course_seq || cls.courseSeq}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-500">{cls.teacher || "未分配教师"}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 pt-3 border-t border-gray-100">
                      <Users className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-600">
                        {cls.student_count || cls.studentCount || 0} 名学生
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* 空状态 */}
      {Object.keys(groupedCourses).length === 0 && !loading && (
        <Card className="border border-gray-100 shadow-sm">
          <CardContent className="p-16">
            <div className="text-center">
              <p className="text-gray-500">没有找到匹配的班级信息</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* 调整学生班级对话框 */}
      <Dialog open={isAdjustDialogOpen} onOpenChange={handleCloseDialog}>
        <DialogContent className="sm:max-w-[700px]">
          <DialogHeader>
            <DialogTitle className="text-xl">调整学生班级</DialogTitle>
            <DialogDescription className="text-gray-500">
              {selectedCourse && (
                <span>
                  {selectedCourse.course_code || selectedCourse.courseCode} -{" "}
                  {selectedCourse.course_name || selectedCourse.courseName}
                </span>
              )}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            {/* 搜索学生 */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="搜索学生姓名、学号或班级..."
                value={studentSearchTerm}
                onChange={(e) => setStudentSearchTerm(e.target.value)}
                className="pl-10 border-gray-200"
              />
            </div>

            {/* 学生列表 */}
            <div className="border border-gray-200 rounded-lg p-4 max-h-[300px] overflow-y-auto">
              {loadingStudents ? (
                <div className="text-center py-8">
                  <RefreshCw className="w-6 h-6 text-gray-400 mx-auto mb-2 animate-spin" />
                  <p className="text-gray-500">加载学生列表中...</p>
                </div>
              ) : filteredStudents.length > 0 ? (
                <div className="space-y-3">
                  {/* 全选按钮 */}
                  <div className="flex justify-end mb-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={toggleSelectAll}
                      className="text-xs"
                    >
                      {selectedStudents.length === filteredStudents.length ? "取消全选" : "全选"}
                    </Button>
                  </div>
                  
                  {filteredStudents.map((student) => (
                    <label
                      key={student.id}
                      className={`flex items-center justify-between p-3 rounded-lg cursor-pointer transition-all ${
                        selectedStudents.includes(student.id)
                          ? "bg-blue-50 border border-blue-200"
                          : "bg-gray-50 border border-transparent hover:border-gray-200"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <input
                          type="checkbox"
                          checked={selectedStudents.includes(student.id)}
                          onChange={() => toggleStudentSelection(student.id)}
                          className="w-4 h-4 text-blue-600 bg-white border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                        />
                        <div>
                          <div className="text-sm font-medium text-gray-900">
                            {student.name}
                          </div>
                          <div className="text-xs text-gray-500">
                            学号: {student.student_no || student.studentId}
                          </div>
                        </div>
                      </div>
                      <div className="text-sm">
                        <Badge variant="secondary" className="bg-gray-100 text-gray-700">
                          {student.current_class || student.currentClass}
                        </Badge>
                      </div>
                    </label>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  没有找到匹配的学生
                </div>
              )}
            </div>

            {/* 已选择提示 */}
            {selectedStudents.length > 0 && (
              <div className="flex items-center gap-2 p-3 bg-blue-50 rounded-lg border border-blue-100">
                <Check className="w-4 h-4 text-blue-600" />
                <span className="text-sm text-blue-700">
                  已选择 {selectedStudents.length} 名学生
                </span>
              </div>
            )}

            {/* 目标班级选择 */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">目标班级</label>
              <Select value={targetClass} onValueChange={setTargetClass}>
                <SelectTrigger className="w-full border-gray-200">
                  <SelectValue placeholder="选择目标班级" />
                </SelectTrigger>
                <SelectContent>
                  {getTargetClasses().map((className) => (
                    <SelectItem key={className} value={className}>
                      {className}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* 调整预览 */}
            {selectedStudents.length > 0 && targetClass && (
              <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                <div className="flex items-center gap-3 text-sm">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-gray-500" />
                    <span className="text-gray-700">{selectedStudents.length} 名学生</span>
                  </div>
                  <ArrowRight className="w-4 h-4 text-gray-400" />
                  <Badge className="bg-blue-600 text-white">{targetClass}</Badge>
                </div>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={handleCloseDialog}
              className="border-gray-200"
            >
              取消
            </Button>
            <Button
              type="button"
              onClick={handleAdjustClass}
              className="bg-blue-600 hover:bg-blue-700"
              disabled={selectedStudents.length === 0 || !targetClass || submitting}
            >
              <UserCog className="w-4 h-4 mr-2" />
              {submitting ? "调整中..." : "确认调整"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}