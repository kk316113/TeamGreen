// src/app/pages/StudentImport.jsx
import { useState, useEffect, useCallback } from "react";
import { 
  Upload, FileText, CheckCircle, XCircle, AlertCircle, 
  RefreshCw, Send, Eye, Download, Filter, Trash2
} from "lucide-react";


// 导入 API 函数
import {
  parseFile,
  importStudents,
  getImportHistory,
  getImportRecordDetail,
  deleteImportRecord,
  reimportStudents,
  exportFailedRecords,
  getClassList,
  validateStudentData,
  downloadTemplate
} from "../api/teacher/StudentImport";

/**
 * 学生信息导入组件
 * 用于批量导入学生信息，支持Excel、PDF和CSV格式文件
 */
export function StudentImport() {
  // 状态管理
  const [file, setFile] = useState(null); // 选中的文件
  const [parsing, setParsing] = useState(false); // 是否正在解析文件
  const [parsingProgress, setParsingProgress] = useState(0); // 解析进度
  const [parsedData, setParsedData] = useState([]); // 解析后的数据
  const [validationErrors, setValidationErrors] = useState([]); // 数据验证错误
  const [classId, setClassId] = useState(""); // 选中的班级ID
  const [classList, setClassList] = useState([]); // 班级列表
  const [submitting, setSubmitting] = useState(false); // 是否正在提交
  const [submitResult, setSubmitResult] = useState(null); // 提交结果
  
  // 历史记录相关状态
  const [historyRecords, setHistoryRecords] = useState([]); // 历史记录列表
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyPage, setHistoryPage] = useState(1);
  const [historyTotal, setHistoryTotal] = useState(0);
  const [historyFilters, setHistoryFilters] = useState({
    classId: "",
    startDate: "",
    endDate: "",
  });
  const [showFilters, setShowFilters] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [recordDetail, setRecordDetail] = useState(null);

  // 加载班级列表
  const loadClassList = async () => {
    try {
      const result = await getClassList();
      setClassList(result.data.items || result.data || []);
    } catch (error) {
      console.error("加载班级列表失败", error);
    }
  };
  
  // 加载历史记录
  const loadHistoryRecords = useCallback(async () => {
    setHistoryLoading(true);
    try {
      const params = {
        page: historyPage,
        pageSize: 10,
        ...(historyFilters.classId && { classId: historyFilters.classId }),
        ...(historyFilters.startDate && { startDate: historyFilters.startDate }),
        ...(historyFilters.endDate && { endDate: historyFilters.endDate }),
      };
      const result = await getImportHistory(params);
      setHistoryRecords(result.data.items);
      setHistoryTotal(result.data.total);
    } catch (error) {
      console.error("加载历史记录失败", error);
    } finally {
      setHistoryLoading(false);
    }
  }, [historyPage, historyFilters]);
  
  // 查看记录详情
  const handleViewDetail = async (recordId) => {
    try {
      const result = await getImportRecordDetail(recordId);
      setRecordDetail(result.data);
      setShowDetailModal(true);
    } catch (error) {
      alert("获取记录详情失败: " + error.message);
    }
  };
  
  // 删除记录
  const handleDeleteRecord = async (recordId) => {
    if (!window.confirm("确认删除这条导入记录吗？")) return;
    try {
      await deleteImportRecord(recordId);
      await loadHistoryRecords();
    } catch (error) {
      alert("删除失败: " + error.message);
    }
  };
  
  // 重新导入
  const handleReimport = async (recordId) => {
    if (!window.confirm("确认基于历史记录重新导入吗？")) return;
    try {
      const result = await reimportStudents(recordId);
      alert(result.message || "重新导入成功");
      await loadHistoryRecords();
    } catch (error) {
      alert("重新导入失败: " + error.message);
    }
  };
  
  // 导出失败记录
  const handleExportFailed = async (recordId, fileName) => {
    try {
      const blob = await exportFailedRecords(recordId);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${fileName}_failed_records.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      alert("导出失败: " + error.message);
    }
  };
  
  // 下载模板
  const handleDownloadTemplate = () => {
    const blob = downloadTemplate();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = '学生导入模板.xlsx';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  };
  
  // 处理文件选择
  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      setParsedData([]);
      setValidationErrors([]);
      setSubmitResult(null);
      setParsingProgress(0);
    }
  };
  
// 解析文件
const handleParse = async () => {
  if (!file) return;

  setParsing(true);
  setParsingProgress(0);

  try {
    const result = await parseFile(file, (progress) => {
      setParsingProgress(progress);
    });

    if (result.code === 0 && result.data.length > 0) {
      // 去除解析后的数据中的 email 字段
      const filteredData = result.data.map((record) => {
        const { email, ...rest } = record;  // 解构，去除 email 字段
        return rest;  // 返回没有 email 的数据
      });

      setParsedData(filteredData);  // 使用过滤后的数据
      const validation = validateStudentData(filteredData);  // 校验数据
      setValidationErrors(validation.errors);  // 校验错误
    } else if (result.code === 0 && result.data.length === 0) {
      alert("文件中未找到有效的学生数据，请检查文件格式");
    } else {
      alert(result.message || "文件解析失败");
    }
  } catch (error) {
    console.error("解析错误:", error);
    alert("文件解析失败: " + error.message);
  } finally {
    setParsing(false);
  }
};
  
 // 提交导入
const handleImport = async () => {
  const validRecords = parsedData.filter((_, index) => {
    const hasError = validationErrors.some((err) => err.row === index + 1 && err.severity === "error");
    return !hasError;
  });

  const studentData = validRecords.map((record) => ({
    student_no: record.student_no,
    name: record.name,
    // 不包括邮箱字段
    course_code: record.courseCode,
    course_seq: record.courseSeq,
    class_name: record.className,
  }));

  if (!classId) {
    setSubmitResult({
      success: false,
      message: "请选择班级",
      total: parsedData.length,
      successCount: 0,
      failedCount: parsedData.length,
      submitTime: new Date().toLocaleString(),
    });
    return;
  }

  if (validRecords.length === 0) {
    setSubmitResult({
      success: false,
      message: "没有有效的数据可以导入",
      total: parsedData.length,
      successCount: 0,
      failedCount: parsedData.length,
      submitTime: new Date().toLocaleString(),
    });
    return;
  }

  setSubmitting(true);

  try {
    const result = await importStudents(classId, studentData);
    setSubmitResult({
      success: true,
      message: result.message || "导入成功",
      total: parsedData.length,
      successCount: result.data.success_count || studentData.length,
      failedCount: result.data.fail_count || 0,
      submitTime: new Date().toLocaleString(),
    });

    // 刷新历史记录
    await loadHistoryRecords();
  } catch (error) {
    setSubmitResult({
      success: false,
      message: error.message || "导入失败",
      total: parsedData.length,
      successCount: 0,
      failedCount: parsedData.length,
      submitTime: new Date().toLocaleString(),
    });
  } finally {
    setSubmitting(false);
  }
};
  // 重新上传
  const handleReupload = () => {
    setFile(null);
    setParsedData([]);
    setValidationErrors([]);
    setSubmitResult(null);
    setClassId("");
    setParsingProgress(0);
  };
  
  // 重置筛选
  const resetFilters = () => {
    setHistoryFilters({
      classId: "",
      startDate: "",
      endDate: "",
    });
    setHistoryPage(1);
  };
  
  const errorCount = validationErrors.filter((e) => e.severity === "error").length;
  const warningCount = validationErrors.filter((e) => e.severity === "warning").length;
  const validCount = parsedData.length - parsedData.filter((_, index) => 
    validationErrors.some((err) => err.row === index + 1 && err.severity === "error")
  ).length;
  
  useEffect(() => {
    loadClassList();
    loadHistoryRecords();
  }, [loadHistoryRecords]);
  
  return (
    <div className="space-y-6 p-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-1">学生信息导入</h1>
          <p className="text-gray-600">上传 Excel、PDF 或 CSV 文件批量导入学生信息</p>
        </div>
        <button
          onClick={handleDownloadTemplate}
          className="flex items-center gap-2 px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Download className="w-4 h-4" />
          下载导入模板
        </button>
      </div>
      
      {/* 班级信息 */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200 px-6 py-4">
          <h2 className="text-lg font-semibold text-gray-900">班级信息</h2>
        </div>
        <div className="p-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">
              选择班级 <span className="text-red-500">*</span>
            </label>
            <select
              className="w-full max-w-md px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={classId}
              onChange={(e) => setClassId(e.target.value)}
            >
              <option value="">请选择班级</option>
              {classList.map((cls) => (
                <option key={cls.id} value={cls.id}>
                  {cls.class_name}（{cls.grade || "-"} / {cls.term || "-"}）
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
      
      {/* 步骤1：上传文件 */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">步骤1：上传文件</h2>
          {file && parsedData.length === 0 && (
            <button
              onClick={handleParse}
              disabled={parsing}
              className="flex items-center gap-2 px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${parsing ? "animate-spin" : ""}`} />
              {parsing ? "解析中..." : "开始解析"}
            </button>
          )}
        </div>
        <div className="p-6 space-y-6">
          {/* 解析进度条 */}
          {parsing && parsingProgress > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">正在解析文件...</span>
                <span className="text-gray-600">{parsingProgress}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                <div 
                  className="bg-blue-600 h-2 transition-all duration-300 rounded-full"
                  style={{ width: `${parsingProgress}%` }}
                />
              </div>
            </div>
          )}
          
          {!file ? (
            <>
              <div className="border-2 border-dashed border-gray-300 rounded-xl p-12 text-center hover:border-blue-400 transition-colors">
                <input
                  type="file"
                  accept=".pdf,.xlsx,.xls,.csv"
                  onChange={handleFileChange}
                  className="hidden"
                  id="file-upload"
                />
                <label htmlFor="file-upload" className="cursor-pointer flex flex-col items-center">
                  <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mb-4">
                    <Upload className="w-8 h-8 text-blue-600" />
                  </div>
                  <p className="text-gray-900 mb-1">点击上传或拖拽文件到此区域</p>
                  <p className="text-sm text-gray-500">支持 Excel (.xlsx, .xls)、PDF格式，单个文件不超过 10MB</p>
                </label>
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex gap-3">
                  <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0" />
                  <div className="text-sm text-gray-700">
                    <p className="font-medium mb-2">文件格式要求：</p>
                    <ul className="list-disc list-inside space-y-1 text-gray-600">
                      <li>第一行为列名：学号、姓名、课程编号、课序号、班级</li>
                      <li>学号格式：13位数字（如 2023141460000）</li>
                      <li>课程编号：9位数字（如123456789）</li>
                    </ul>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center gap-3">
                <FileText className="w-10 h-10 text-blue-600" />
                <div className="flex-1">
                  <p className="text-sm text-gray-900 truncate">{file.name}</p>
                  <p className="text-xs text-gray-600">{(file.size / 1024).toFixed(2)} KB</p>
                </div>
                {parsedData.length > 0 && (
                  <button
                    onClick={handleReupload}
                    className="flex items-center gap-2 px-3 py-1 text-sm border border-gray-300 rounded-lg hover:bg-gray-50"
                  >
                    <Upload className="w-4 h-4" />重新上传
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* 步骤2-4：数据预览和校验 */}
      {parsedData.length > 0 && (
        <>
          {/* 解析结果预览 */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="border-b border-gray-200 px-6 py-4 flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">步骤2-3：解析结果预览</h2>
              <div className="flex items-center gap-2">
                <span className="px-2 py-1 text-xs bg-blue-50 text-blue-700 rounded">共 {parsedData.length} 条</span>
                <span className="px-2 py-1 text-xs bg-green-50 text-green-700 rounded">有效 {validCount} 条</span>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200 bg-gray-50">
                    <th className="text-left py-3 px-4 text-sm text-gray-600">行号</th>
                    <th className="text-left py-3 px-4 text-sm text-gray-600">学号</th>
                    <th className="text-left py-3 px-4 text-sm text-gray-600">姓名</th>
                    <th className="text-left py-3 px-4 text-sm text-gray-600">课程编号</th>
                    <th className="text-left py-3 px-4 text-sm text-gray-600">课序号</th>
                    <th className="text-left py-3 px-4 text-sm text-gray-600">班级</th>
                    <th className="text-center py-3 px-4 text-sm text-gray-600">状态</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {parsedData.slice(0, 10).map((record, index) => {
                    const rowErrors = validationErrors.filter((e) => e.row === index + 1);
                    const hasError = rowErrors.some((e) => e.severity === "error");
                    const hasWarning = rowErrors.some((e) => e.severity === "warning");
                    return (
                      <tr key={index} className={`hover:bg-gray-50 ${hasError ? "bg-red-50" : hasWarning ? "bg-amber-50" : ""}`}>
                        <td className="py-3 px-4 text-sm text-gray-900">{index + 1}</td>
                        <td className="py-3 px-4 text-sm text-gray-900">
                          {record.student_no || <span className="text-red-500">缺失</span>}
                        </td>
                        <td className="py-3 px-4 text-sm text-gray-900">
                          {record.name || <span className="text-red-500">缺失</span>}
                        </td> 
                        <td className="py-3 px-4 text-sm text-gray-900">{record.courseCode}</td>
                        <td className="py-3 px-4 text-sm text-gray-900">{record.courseSeq}</td>
                        <td className="py-3 px-4 text-sm text-gray-900">{record.className}</td>
                        <td className="py-3 px-4 text-center">
                          {hasError ? (
                            <span className="inline-flex items-center gap-1 px-2 py-1 text-xs bg-red-100 text-red-700 rounded">
                              <XCircle className="w-3 h-3" />错误
                            </span>
                          ) : hasWarning ? (
                            <span className="inline-flex items-center gap-1 px-2 py-1 text-xs bg-amber-100 text-amber-700 rounded">
                              <AlertCircle className="w-3 h-3" />警告
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2 py-1 text-xs bg-green-100 text-green-700 rounded">
                              <CheckCircle className="w-3 h-3" />正常
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {parsedData.length > 10 && (
                <div className="px-4 py-2 text-sm text-gray-500 text-center border-t">
                  仅显示前10条，共 {parsedData.length} 条记录
                </div>
              )}
            </div>
          </div>
          
          {/* 校验结果汇总 */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="border-b border-gray-200 px-6 py-4">
              <h2 className="text-lg font-semibold text-gray-900">步骤4：数据校验结果</h2>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-gray-50 rounded-lg p-4 text-center">
                  <p className="text-3xl font-bold text-gray-900 mb-1">{parsedData.length}</p>
                  <p className="text-sm text-gray-600">解析总数</p>
                </div>
                <div className="bg-green-50 rounded-lg p-4 text-center border border-green-200">
                  <p className="text-3xl font-bold text-green-600 mb-1">{validCount}</p>
                  <p className="text-sm text-gray-600">可提交数</p>
                </div>
                <div className="bg-red-50 rounded-lg p-4 text-center border border-red-200">
                  <p className="text-3xl font-bold text-red-600 mb-1">{parsedData.length - validCount}</p>
                  <p className="text-sm text-gray-600">错误条数</p>
                </div>
              </div>
              
              {errorCount > 0 && (
                <div className="space-y-2">
                  <h3 className="font-medium text-red-700">错误详情</h3>
                  {validationErrors.filter(e => e.severity === "error").map((error, idx) => (
                    <div key={idx} className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
                      <XCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
                      <div>
                        <p className="text-sm text-red-900">第 {error.row} 行 - {error.field}</p>
                        <p className="text-xs text-red-700">{error.message}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
          
          {/* 确认提交 */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="border-b border-gray-200 px-6 py-4">
              <h2 className="text-lg font-semibold text-gray-900">步骤5：确认提交</h2>
            </div>
            <div className="p-6">
              <div className="flex items-center gap-4">
                <button
                  onClick={handleReupload}
                  className="flex items-center gap-2 px-4 py-2 text-sm border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  <Upload className="w-4 h-4" />重新上传
                </button>
                <button
                  onClick={handleParse}
                  disabled={parsing}
                  className="flex items-center gap-2 px-4 py-2 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50"
                >
                  <RefreshCw className={`w-4 h-4 ${parsing ? "animate-spin" : ""}`} />重新解析
                </button>
                <button
                  onClick={handleImport}
                  disabled={submitting || validCount === 0 || !classId}
                  className="flex items-center gap-2 px-4 py-2 text-sm bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 ml-auto"
                >
                  <Send className="w-4 h-4" />
                  {submitting ? "提交中..." : `确认提交 (${validCount}条)`}
                </button>
              </div>
              
              {validCount < parsedData.length && (
                <div className="mt-4 bg-amber-50 border border-amber-200 rounded-lg p-4">
                  <div className="flex gap-3">
                    <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0" />
                    <p className="text-sm text-amber-900">
                      检测到 {parsedData.length - validCount} 条记录存在错误，提交时将自动跳过这些记录
                    </p>
                  </div>
                </div>
              )}
              
              {submitResult && (
                <div className={`mt-4 rounded-lg p-4 ${submitResult.success ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
                  <div className="flex items-start gap-3">
                    {submitResult.success ? 
                      <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0" /> : 
                      <XCircle className="w-6 h-6 text-red-600 flex-shrink-0" />
                    }
                    <div className="flex-1">
                      <h3 className={`font-semibold ${submitResult.success ? 'text-green-900' : 'text-red-900'}`}>
                        {submitResult.success ? "提交成功！" : "提交失败"}
                      </h3>
                      <p className={`text-sm ${submitResult.success ? 'text-green-700' : 'text-red-700'}`}>
                        {submitResult.message}
                      </p>
                      <div className="mt-2 grid grid-cols-2 gap-2 text-sm">
                        <div className="text-gray-600">总记录数：{submitResult.total}</div>
                        <div className="text-green-600">成功：{submitResult.successCount}</div>
                        <div className="text-red-600">失败：{submitResult.failedCount}</div>
                      </div>
                      <p className="text-xs text-gray-500 mt-2">提交时间：{submitResult.submitTime}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </>
      )}
      
      {/* 历史导入记录 */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">历史导入记录</h2>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-2 px-3 py-1 text-sm border border-gray-300 rounded-lg hover:bg-gray-50"
          >
            <Filter className="w-4 h-4" />
            筛选
          </button>
        </div>
        
        {/* 筛选栏 */}
        {showFilters && (
          <div className="p-4 border-b border-gray-200 bg-gray-50">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="text-sm text-gray-600 block mb-1">班级</label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                  value={historyFilters.classId}
                  onChange={(e) => setHistoryFilters({...historyFilters, classId: e.target.value})}
                >
                  <option value="">全部班级</option>
                  {classList.map((cls) => (
                    <option key={cls.id} value={cls.id}>{cls.class_name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm text-gray-600 block mb-1">开始日期</label>
                <input
                  type="date"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                  value={historyFilters.startDate}
                  onChange={(e) => setHistoryFilters({...historyFilters, startDate: e.target.value})}
                />
              </div>
              <div>
                <label className="text-sm text-gray-600 block mb-1">结束日期</label>
                <input
                  type="date"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                  value={historyFilters.endDate}
                  onChange={(e) => setHistoryFilters({...historyFilters, endDate: e.target.value})}
                />
              </div>
              <div className="flex items-end gap-2">
                <button onClick={loadHistoryRecords} className="px-3 py-2 text-sm bg-blue-600 text-white rounded-lg">查询</button>
                <button onClick={resetFilters} className="px-3 py-2 text-sm border border-gray-300 rounded-lg">重置</button>
              </div>
            </div>
          </div>
        )}
        
        <div className="overflow-x-auto">
          {historyLoading ? (
            <div className="text-center py-12">
              <RefreshCw className="w-8 h-8 text-gray-400 animate-spin mx-auto mb-2" />
              <p className="text-gray-500">加载中...</p>
            </div>
          ) : historyRecords.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="w-12 h-12 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-500">暂无导入记录</p>
            </div>
          ) : (
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200 bg-gray-50">
                  <th className="text-left py-3 px-4 text-sm text-gray-600">文件名</th>
                  <th className="text-left py-3 px-4 text-sm text-gray-600">班级</th>
                  <th className="text-left py-3 px-4 text-sm text-gray-600">导入时间</th>
                  <th className="text-center py-3 px-4 text-sm text-gray-600">总数</th>
                  <th className="text-center py-3 px-4 text-sm text-gray-600">成功</th>
                  <th className="text-center py-3 px-4 text-sm text-gray-600">失败</th>
                  <th className="text-center py-3 px-4 text-sm text-gray-600">状态</th>
                  <th className="text-center py-3 px-4 text-sm text-gray-600">操作</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {historyRecords.map((record) => (
                  <tr key={record.id} className="hover:bg-gray-50">
                    <td className="py-3 px-4 text-sm text-gray-900">{record.file_name}</td>
                    <td className="py-3 px-4 text-sm text-gray-600">{record.class_name || "-"}</td>
                    <td className="py-3 px-4 text-sm text-gray-600">{record.import_time}</td>
                    <td className="py-3 px-4 text-sm text-gray-900 text-center">{record.total_count}</td>
                    <td className="py-3 px-4 text-sm text-green-600 text-center">{record.success_count}</td>
                    <td className="py-3 px-4 text-sm text-red-600 text-center">{record.fail_count}</td>
                    <td className="py-3 px-4 text-center">
                      {record.status === "completed" ? (
                        <span className="inline-flex items-center gap-1 px-2 py-1 text-xs bg-green-100 text-green-700 rounded">
                          <CheckCircle className="w-3 h-3" />完成
                        </span>
                      ) : record.status === "partial" ? (
                        <span className="inline-flex items-center gap-1 px-2 py-1 text-xs bg-amber-100 text-amber-700 rounded">
                          <AlertCircle className="w-3 h-3" />部分成功
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-1 text-xs bg-red-100 text-red-700 rounded">
                          <XCircle className="w-3 h-3" />失败
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => handleViewDetail(record.id)}
                          className="text-blue-600 hover:text-blue-800 text-sm"
                        >
                          详情
                        </button>
                        {record.fail_count > 0 && (
                          <button
                            onClick={() => handleExportFailed(record.id, record.file_name)}
                            className="text-green-600 hover:text-green-800 text-sm"
                          >
                            <Download className="w-3 h-3 inline" /> 导出失败
                          </button>
                        )}
                        <button
                          onClick={() => handleReimport(record.id)}
                          className="text-amber-600 hover:text-amber-800 text-sm"
                        >
                          <RefreshCw className="w-3 h-3 inline" /> 重导
                        </button>
                        <button
                          onClick={() => handleDeleteRecord(record.id)}
                          className="text-red-600 hover:text-red-800 text-sm"
                        >
                          <Trash2 className="w-3 h-3 inline" /> 删除
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
        
        {/* 分页 */}
        {historyTotal > 10 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-200">
            <div className="text-sm text-gray-600">共 {historyTotal} 条记录</div>
            <div className="flex gap-2">
              <button
                disabled={historyPage === 1}
                onClick={() => setHistoryPage(p => p - 1)}
                className="px-3 py-1 text-sm border border-gray-300 rounded-lg disabled:opacity-50"
              >
                上一页
              </button>
              <span className="px-3 py-1 text-sm">
                第 {historyPage} 页 / 共 {Math.ceil(historyTotal / 10)} 页
              </span>
              <button
                disabled={historyPage >= Math.ceil(historyTotal / 10)}
                onClick={() => setHistoryPage(p => p + 1)}
                className="px-3 py-1 text-sm border border-gray-300 rounded-lg disabled:opacity-50"
              >
                下一页
              </button>
            </div>
          </div>
        )}
      </div>
      
      {/* 详情弹窗 */}
      {showDetailModal && recordDetail && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" onClick={() => setShowDetailModal(false)}>
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-[80vh] overflow-auto" onClick={(e) => e.stopPropagation()}>
            <div className="sticky top-0 bg-white border-b border-gray-200 p-4 flex items-center justify-between">
              <h3 className="text-lg font-semibold">导入记录详情</h3>
              <button onClick={() => setShowDetailModal(false)} className="text-gray-500 hover:text-gray-700 text-xl">✕</button>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-gray-500">文件名</label>
                  <p className="text-gray-900">{recordDetail.file_name}</p>
                </div>
                <div>
                  <label className="text-sm text-gray-500">导入时间</label>
                  <p className="text-gray-900">{recordDetail.import_time}</p>
                </div>
                <div>
                  <label className="text-sm text-gray-500">操作人</label>
                  <p className="text-gray-900">{recordDetail.operator_name}</p>
                </div>
                <div>
                  <label className="text-sm text-gray-500">班级</label>
                  <p className="text-gray-900">{recordDetail.class_name}</p>
                </div>
              </div>
              
              <div className="border-t pt-4">
                <h4 className="font-medium mb-2">导入统计</h4>
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center p-3 bg-gray-50 rounded">
                    <p className="text-2xl font-bold text-gray-900">{recordDetail.total_count}</p>
                    <p className="text-sm text-gray-500">总数</p>
                  </div>
                  <div className="text-center p-3 bg-green-50 rounded">
                    <p className="text-2xl font-bold text-green-600">{recordDetail.success_count}</p>
                    <p className="text-sm text-gray-500">成功</p>
                  </div>
                  <div className="text-center p-3 bg-red-50 rounded">
                    <p className="text-2xl font-bold text-red-600">{recordDetail.fail_count}</p>
                    <p className="text-sm text-gray-500">失败</p>
                  </div>
                </div>
              </div>
              
              {recordDetail.error_details && recordDetail.error_details.length > 0 && (
                <div className="border-t pt-4">
                  <h4 className="font-medium mb-2">错误详情</h4>
                  <div className="space-y-2 max-h-60 overflow-auto">
                    {recordDetail.error_details.map((err, idx) => (
                      <div key={idx} className="p-2 bg-red-50 rounded text-sm">
                        <span className="text-red-600">第 {err.row_number} 行</span> - {err.error_message}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default StudentImport;