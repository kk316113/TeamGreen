/**
 * 学生端作业提交页面
 *
 * 当前已接入接口：
 * 1. getCourseList()                  // 获取课程列表
 * 2. getAssignmentList(courseId)      // 获取课程下任务列表
 * 3. getAssignmentDetail(assignmentId)// 获取任务详情
 * 4. runCode(data)                    // 运行代码
 * 5. submitCode(data)                 // 提交代码
 * 6. getSubmissionStatus(submissionId)// 查询提交状态
 * 7. getSubmissionDetail(submissionId)// 查询提交详情
 *
 * 当前暂未接入接口：
 * 1. saveDraft(assignmentId, data)    // 保存草稿
 * 2. getDraft(assignmentId)           // 获取草稿
 * 3. getSubmissionEmailConfig(id)     // 邮件提交配置
 *
 * 说明：
 * - 当前“邮件提交”页仍使用本地静态说明数据
 * - 当前“保存草稿”按钮仍为前端占位提示
 */

import { useEffect, useMemo, useRef, useState } from "react";
import Editor from "@monaco-editor/react";
import {
  Upload,
  Play,
  Send,
  Save,
  RotateCcw,
  CheckCircle,
  XCircle,
  Clock,
  FileCode,
  ChevronDown,
  ChevronUp,
  Mail,
  AlertCircle,
  Info,
} from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../../components/ui/select";
import { Badge } from "../../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/ui/tabs";

import {
  getCourseList,
  getAssignmentList,
  getAssignmentDetail,
  runCode,
  submitCode,
  getSubmissionStatus,
  getSubmissionDetail,
} from "../../api/student/studentSubmit";

const DEFAULT_EMAIL_INFO = {
  email: "autograder@school.edu.cn",
  subjectFormat: "[课程编号]-[学号]-[作业名称]",
  examples: [
    { course: "PY101", student: "2024001", task: "实验2", subject: "PY101-2024001-实验2" },
    { course: "SH201", student: "2024002", task: "实验3", subject: "SH201-2024002-实验3" },
  ],
  attachmentFormat: "学号_姓名_作业名称",
  attachmentExamples: [
    "2024001_张三_实验2.py",
    "2024002_李四_实验3.sh",
    "2024003_王五_实验1.zip",
  ],
  supportedFormats: [".py", ".sh", ".zip"],
  maxSize: "10MB",
  syncTime: "5-10分钟",
};

export function AssignmentSubmit() {
  const [selectedCourse, setSelectedCourse] = useState("");
  const [selectedAssignment, setSelectedAssignment] = useState("");
  const [code, setCode] = useState("");

  const [courses, setCourses] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [selectedAssignmentInfo, setSelectedAssignmentInfo] = useState(null);

  const [isLoadingCourses, setIsLoadingCourses] = useState(false);
  const [isLoadingAssignments, setIsLoadingAssignments] = useState(false);
  const [isLoadingDetail, setIsLoadingDetail] = useState(false);

  const [isRunning, setIsRunning] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [runResult, setRunResult] = useState(null);
  const [submitResult, setSubmitResult] = useState(null);
  const [showResult, setShowResult] = useState(true);

  const fileInputRef = useRef(null);
  const pollingTimerRef = useRef(null);

  useEffect(() => {
    loadCourses();

    return () => {
      if (pollingTimerRef.current) {
        clearTimeout(pollingTimerRef.current);
      }
    };
  }, []);

  const selectedCourseInfo = useMemo(
    () => courses.find((course) => course.courseId === selectedCourse),
    [courses, selectedCourse]
  );

  const currentProblem = selectedAssignmentInfo?.problems?.[0] || null;

  const editorLanguage =
    selectedAssignmentInfo?.allowedLanguages?.[0] ||
    (selectedCourseInfo?.language === "python" ? "python" : "shell");

  async function loadCourses() {
    try {
      setIsLoadingCourses(true);
      const res = await getCourseList();
      setCourses(res.data || []);
    } catch (error) {
      alert(error.message || "获取课程列表失败");
    } finally {
      setIsLoadingCourses(false);
    }
  }

  async function handleCourseChange(value) {
    setSelectedCourse(value);
    setSelectedAssignment("");
    setAssignments([]);
    setSelectedAssignmentInfo(null);
    setCode("");
    setRunResult(null);
    setSubmitResult(null);

    if (pollingTimerRef.current) {
      clearTimeout(pollingTimerRef.current);
    }

    try {
      setIsLoadingAssignments(true);
      const res = await getAssignmentList(value);
      setAssignments(res.data || []);
    } catch (error) {
      alert(error.message || "获取任务列表失败");
    } finally {
      setIsLoadingAssignments(false);
    }
  }

  async function handleAssignmentChange(value) {
    setSelectedAssignment(value);
    setSelectedAssignmentInfo(null);
    setCode("");
    setRunResult(null);
    setSubmitResult(null);

    if (pollingTimerRef.current) {
      clearTimeout(pollingTimerRef.current);
    }

    try {
      setIsLoadingDetail(true);
      const res = await getAssignmentDetail(value);
      setSelectedAssignmentInfo(res.data || null);
    } catch (error) {
      alert(error.message || "获取任务详情失败");
    } finally {
      setIsLoadingDetail(false);
    }
  }

  const handleFileUpload = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();

      reader.onload = (event) => {
        if (event.target?.result) {
          setCode(String(event.target.result));
        }
      };

      reader.readAsText(file);
    }
  };

  async function handleRun() {
    if (!selectedCourse || !selectedAssignment || !selectedAssignmentInfo) {
      alert("请先选择课程和任务");
      return;
    }

    if (!code.trim()) {
      alert("请先编写代码");
      return;
    }

    try {
      setIsRunning(true);
      setShowResult(true);
      setSubmitResult(null);

      const res = await runCode({
        assignmentId: selectedAssignment,
        problemId: currentProblem?.problemId,
        language: selectedAssignmentInfo?.allowedLanguages?.[0] || editorLanguage,
        code,
      });

      setRunResult(res.data || null);
    } catch (error) {
      alert(error.message || "运行代码失败");
    } finally {
      setIsRunning(false);
    }
  }

  async function handleSubmit() {
    if (!selectedCourse || !selectedAssignment || !selectedAssignmentInfo) {
      alert("请选择课程和任务");
      return;
    }

    if (!code.trim()) {
      alert("请先编写代码");
      return;
    }

    try {
      setIsSubmitting(true);
      setShowResult(true);
      setRunResult(null);

      const submitRes = await submitCode({
        assignmentId: selectedAssignment,
        problemId: currentProblem?.problemId,
        language: selectedAssignmentInfo?.allowedLanguages?.[0] || editorLanguage,
        code,
      });

      const submissionId = submitRes?.data?.submissionId;
      if (!submissionId) {
        throw new Error("提交成功但未返回 submissionId");
      }

      await pollSubmissionResult(submissionId);
    } catch (error) {
      alert(error.message || "提交代码失败");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function pollSubmissionResult(submissionId) {
    const maxRetry = 20;
    let retryCount = 0;

    const poll = async () => {
      const statusRes = await getSubmissionStatus(submissionId);
      const currentStatus = statusRes?.data?.status;

      if (currentStatus === "finished" || currentStatus === "failed") {
        const detailRes = await getSubmissionDetail(submissionId);
        if (detailRes?.data) {
          setSubmitResult(detailRes.data);
        }
        return;
      }

      retryCount += 1;
      if (retryCount >= maxRetry) {
        throw new Error("提交状态查询超时，请稍后到提交记录页面查看");
      }

      await new Promise((resolve) => {
        pollingTimerRef.current = setTimeout(resolve, 2000);
      });

      return poll();
    };

    return poll();
  }

  function handleSaveDraft() {
    alert("保存草稿接口暂未接入");
  }

  function handleReset() {
    if (window.confirm("确定要重置代码吗？")) {
      setCode("");
      setRunResult(null);
      setSubmitResult(null);
    }
  }

  const emailInfo = DEFAULT_EMAIL_INFO;

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl text-gray-900 mb-1">提交代码</h1>
        <p className="text-gray-600">在线编写提交代码，或通过邮件方式提交作业</p>
      </div>

      <Tabs defaultValue="online" className="space-y-4">
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="online" className="gap-2">
            <FileCode className="w-4 h-4" />
            在线提交
          </TabsTrigger>
          <TabsTrigger value="email" className="gap-2">
            <Mail className="w-4 h-4" />
            邮件提交
          </TabsTrigger>
        </TabsList>

        <TabsContent value="online" className="space-y-4">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm text-gray-700">课程</label>
                  <Select
                    value={selectedCourse}
                    onValueChange={handleCourseChange}
                    disabled={isLoadingCourses}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={isLoadingCourses ? "课程加载中..." : "请选择课程"} />
                    </SelectTrigger>
                    <SelectContent>
                      {courses.map((course) => (
                        <SelectItem key={course.courseId} value={course.courseId}>
                          {course.courseCode} - {course.courseName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-gray-700">任务</label>
                  <Select
                    value={selectedAssignment}
                    onValueChange={handleAssignmentChange}
                    disabled={!selectedCourse || isLoadingAssignments}
                  >
                    <SelectTrigger>
                      <SelectValue
                        placeholder={
                          !selectedCourse
                            ? "请先选择课程"
                            : isLoadingAssignments
                            ? "任务加载中..."
                            : "请选择任务"
                        }
                      />
                    </SelectTrigger>
                    <SelectContent>
                      {assignments.map((assignment) => (
                        <SelectItem key={assignment.assignmentId} value={assignment.assignmentId}>
                          {assignment.assignmentName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {selectedAssignmentInfo ? (
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
              <div className="lg:col-span-2">
                <Card className="border-0 shadow-sm h-full">
                  <CardHeader className="border-b border-gray-100">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-lg mb-2">
                          {selectedAssignmentInfo.assignmentName}
                        </CardTitle>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Clock className="w-4 h-4" />
                          <span>截止时间：{selectedAssignmentInfo.deadline}</span>
                        </div>
                      </div>
                      <Badge className="bg-green-50 text-green-700 border-green-200">
                        {selectedCourseInfo?.courseName}
                      </Badge>
                    </div>
                  </CardHeader>

                  <CardContent
                    className="p-6 space-y-6 overflow-y-auto"
                    style={{ maxHeight: "calc(100vh - 320px)" }}
                  >
                    {isLoadingDetail ? (
                      <p className="text-sm text-gray-500">任务详情加载中...</p>
                    ) : (
                      <>
                        <div>
                          <h3 className="text-sm font-semibold text-gray-900 mb-2">题目描述</h3>
                          <p className="text-sm text-gray-700 leading-relaxed">
                            {currentProblem?.description || selectedAssignmentInfo.description}
                          </p>
                        </div>

                        <div>
                          <h3 className="text-sm font-semibold text-gray-900 mb-2">输入说明</h3>
                          <div className="bg-gray-50 rounded-lg p-3">
                            <pre className="text-sm text-gray-700 whitespace-pre-wrap">
                              {currentProblem?.inputDescription}
                            </pre>
                          </div>
                        </div>

                        <div>
                          <h3 className="text-sm font-semibold text-gray-900 mb-2">输出说明</h3>
                          <div className="bg-gray-50 rounded-lg p-3">
                            <pre className="text-sm text-gray-700 whitespace-pre-wrap">
                              {currentProblem?.outputDescription}
                            </pre>
                          </div>
                        </div>

                        <div className="space-y-3">
                          <div>
                            <h3 className="text-sm font-semibold text-gray-900 mb-2">样例输入</h3>
                            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                              <pre className="text-sm text-blue-900 font-mono">
                                {currentProblem?.sampleInput}
                              </pre>
                            </div>
                          </div>

                          <div>
                            <h3 className="text-sm font-semibold text-gray-900 mb-2">样例输出</h3>
                            <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                              <pre className="text-sm text-green-900 font-mono">
                                {currentProblem?.sampleOutput}
                              </pre>
                            </div>
                          </div>
                        </div>

                        <div>
                          <h3 className="text-sm font-semibold text-gray-900 mb-2">题目要求</h3>
                          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                            <pre className="text-sm text-amber-900 whitespace-pre-wrap">
                              {selectedAssignmentInfo.description}
                            </pre>
                          </div>
                        </div>

                        <div>
                          <h3 className="text-sm font-semibold text-gray-900 mb-2">限制条件</h3>
                          <div className="bg-gray-50 rounded-lg p-3">
                            <pre className="text-sm text-gray-700 whitespace-pre-wrap">
                              {`支持语言：${selectedAssignmentInfo.allowedLanguages?.join(", ") || ""}
最大文件大小：${selectedAssignmentInfo.maxFileSize || ""} MB
作业总分：${selectedAssignmentInfo.totalScore || ""} 分
题目分值：${currentProblem?.score || ""} 分`}
                            </pre>
                          </div>
                        </div>
                      </>
                    )}
                  </CardContent>
                </Card>
              </div>

              <div className="lg:col-span-3 space-y-4">
                <Card className="border-0 shadow-sm">
                  <CardHeader className="border-b border-gray-100">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">代码编辑器</CardTitle>
                      <div className="flex items-center gap-2">
                        <input
                          type="file"
                          ref={fileInputRef}
                          onChange={handleFileUpload}
                          accept={editorLanguage === "python" ? ".py" : ".sh"}
                          className="hidden"
                        />
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => fileInputRef.current?.click()}
                          className="gap-2"
                        >
                          <Upload className="w-4 h-4" />
                          上传文件
                        </Button>
                        <Badge variant="secondary" className="bg-gray-100">
                          {editorLanguage === "python" ? "Python" : "Bash Shell"}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="p-0">
                    <div className="border-b border-gray-100">
                      <Editor
                        height="400px"
                        language={editorLanguage}
                        value={code}
                        onChange={(value) => setCode(value || "")}
                        theme="vs-light"
                        options={{
                          fontSize: 14,
                          minimap: { enabled: false },
                          scrollBeyondLastLine: false,
                          lineNumbers: "on",
                          tabSize: 4,
                        }}
                      />
                    </div>

                    <div className="p-4 bg-gray-50 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Button
                          onClick={handleRun}
                          disabled={isRunning || !code.trim()}
                          className="gap-2 bg-green-600 hover:bg-green-700"
                        >
                          <Play className="w-4 h-4" />
                          {isRunning ? "运行中..." : "运行"}
                        </Button>

                        <Button
                          onClick={handleSubmit}
                          disabled={isSubmitting || !code.trim()}
                          className="gap-2 bg-blue-600 hover:bg-blue-700"
                        >
                          <Send className="w-4 h-4" />
                          {isSubmitting ? "提交中..." : "提交"}
                        </Button>

                        <Button
                          variant="outline"
                          onClick={handleSaveDraft}
                          disabled={!code.trim()}
                          className="gap-2"
                        >
                          <Save className="w-4 h-4" />
                          保存草稿
                        </Button>

                        <Button
                          variant="outline"
                          onClick={handleReset}
                          disabled={!code.trim()}
                          className="gap-2"
                        >
                          <RotateCcw className="w-4 h-4" />
                          重置
                        </Button>
                      </div>

                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowResult(!showResult)}
                        className="gap-2"
                      >
                        {showResult ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                        {showResult ? "隐藏结果" : "显示结果"}
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {showResult && (runResult || submitResult) && (
                  <Card className="border-0 shadow-sm">
                    <CardHeader className="border-b border-gray-100">
                      <CardTitle className="text-lg">运行结果</CardTitle>
                    </CardHeader>

                    <CardContent className="p-6">
                      <Tabs defaultValue={submitResult ? "submit" : "run"}>
                        <TabsList className="grid w-full grid-cols-2">
                          <TabsTrigger value="run" disabled={!runResult}>
                            运行输出
                          </TabsTrigger>
                          <TabsTrigger value="submit" disabled={!submitResult}>
                            提交结果
                          </TabsTrigger>
                        </TabsList>

                        {runResult && (
                          <TabsContent value="run" className="space-y-4 mt-4">
                            <div className="flex items-center gap-2">
                              {runResult.status === "success" ? (
                                <CheckCircle className="w-5 h-5 text-green-600" />
                              ) : (
                                <XCircle className="w-5 h-5 text-red-600" />
                              )}

                              <span
                                className={`font-medium ${
                                  runResult.status === "success" ? "text-green-600" : "text-red-600"
                                }`}
                              >
                                {runResult.status === "success" ? "运行成功" : "运行失败"}
                              </span>

                              <div className="ml-auto flex items-center gap-4 text-sm text-gray-600">
                                <span>执行时间: {runResult.executionTime}</span>
                                <span>内存: {runResult.memory}</span>
                              </div>
                            </div>

                            {runResult.output && (
                              <div>
                                <h4 className="text-sm font-semibold text-gray-900 mb-2">输出</h4>
                                <div className="bg-gray-900 rounded-lg p-4">
                                  <pre className="text-sm text-green-400 font-mono whitespace-pre-wrap">
                                    {runResult.output}
                                  </pre>
                                </div>
                              </div>
                            )}

                            {runResult.error && (
                              <div>
                                <h4 className="text-sm font-semibold text-gray-900 mb-2">错误信息</h4>
                                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                                  <pre className="text-sm text-red-900 font-mono whitespace-pre-wrap">
                                    {runResult.error}
                                  </pre>
                                </div>
                              </div>
                            )}
                          </TabsContent>
                        )}

                        {submitResult && (
                          <TabsContent value="submit" className="space-y-4 mt-4">
                            <div className="flex items-center justify-between p-4 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg border border-green-200">
                              <div className="flex items-center gap-3">
                                {submitResult.status === "accepted" ? (
                                  <CheckCircle className="w-6 h-6 text-green-600" />
                                ) : (
                                  <XCircle className="w-6 h-6 text-red-600" />
                                )}

                                <div>
                                  <p className="font-semibold text-gray-900">
                                    {submitResult.status === "accepted" ? "通过" : "未通过"}
                                  </p>
                                  <p className="text-sm text-gray-600">
                                    提交时间：{submitResult.submitTime}
                                  </p>
                                </div>
                              </div>

                              <div className="text-right">
                                <p className="text-3xl font-bold text-green-600">{submitResult.score}</p>
                                <p className="text-sm text-gray-600">/ {submitResult.totalScore}</p>
                              </div>
                            </div>

                            <div>
                              <h4 className="text-sm font-semibold text-gray-900 mb-3">测试点详情</h4>
                              <div className="space-y-2">
                                {submitResult.testCases?.map((testCase) => (
                                  <div
                                    key={testCase.id}
                                    className={`p-3 rounded-lg border ${
                                      testCase.status === "passed"
                                        ? "bg-green-50 border-green-200"
                                        : "bg-red-50 border-red-200"
                                    }`}
                                  >
                                    <div className="flex items-center justify-between">
                                      <div className="flex items-center gap-2">
                                        {testCase.status === "passed" ? (
                                          <CheckCircle className="w-4 h-4 text-green-600" />
                                        ) : (
                                          <XCircle className="w-4 h-4 text-red-600" />
                                        )}
                                        <span className="text-sm font-medium text-gray-900">
                                          {testCase.name}
                                        </span>
                                      </div>

                                      <div className="flex items-center gap-4 text-xs text-gray-600">
                                        <span>{testCase.time}</span>
                                        <span>{testCase.memory}</span>
                                      </div>
                                    </div>

                                    {testCase.error && (
                                      <p className="text-xs text-red-700 mt-2 ml-6">{testCase.error}</p>
                                    )}
                                  </div>
                                ))}
                              </div>
                            </div>
                          </TabsContent>
                        )}
                      </Tabs>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          ) : (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-12 text-center">
                <FileCode className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">
                  {selectedCourse ? "请选择任务后开始编程" : "请选择课程和任务后开始编程"}
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="email" className="space-y-6">
          <Card className="border-0 shadow-sm bg-blue-50 border-blue-200">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <Info className="w-6 h-6 text-blue-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-blue-900 mb-1">邮件提交说明</h3>
                  <p className="text-sm text-blue-700">
                    如果在线提交遇到问题，您可以通过发送邮件的方式提交作业。请严格按照以下格式要求发送邮件，系统将自动识别并导入您的作业记录。
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardHeader className="border-b border-gray-100">
              <CardTitle className="flex items-center gap-2">
                <Mail className="w-5 h-5" />
                提交邮箱地址
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="bg-gray-50 rounded-lg p-4 text-center">
                <p className="text-xs text-gray-600 mb-2">请将作业发送至以下邮箱</p>
                <div className="text-2xl font-mono text-blue-600 mb-2">{emailInfo.email}</div>
                <p className="text-xs text-gray-500">请使用您的学校邮箱发送</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardHeader className="border-b border-gray-100">
              <CardTitle>邮件主题格式</CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                <p className="text-sm text-amber-900 mb-3">
                  <span className="font-semibold">格式要求：</span>
                  <code className="ml-2 px-2 py-1 bg-white rounded text-amber-700">
                    {emailInfo.subjectFormat}
                  </code>
                </p>

                <div className="space-y-2">
                  <p className="text-xs text-amber-800">示例：</p>
                  {emailInfo.examples.map((example, index) => (
                    <div key={index} className="bg-white rounded px-3 py-2">
                      <code className="text-sm text-gray-800">{example.subject}</code>
                      <span className="text-xs text-gray-500 ml-3">
                        ({example.course} 课程，学号 {example.student}，{example.task})
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardHeader className="border-b border-gray-100">
              <CardTitle>附件命名与格式</CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <div>
                <h4 className="text-sm font-semibold text-gray-900 mb-2">附件命名建议</h4>
                <p className="text-sm text-gray-600 mb-3">
                  格式：
                  <code className="px-2 py-1 bg-gray-100 rounded text-gray-800">
                    {emailInfo.attachmentFormat}
                  </code>
                </p>
                <div className="space-y-2">
                  {emailInfo.attachmentExamples.map((example, index) => (
                    <div key={index} className="bg-gray-50 rounded px-3 py-2">
                      <code className="text-sm text-gray-700">{example}</code>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-sm font-semibold text-gray-900 mb-2">支持的文件格式</h4>
                <div className="flex gap-2">
                  {emailInfo.supportedFormats.map((format, index) => (
                    <Badge
                      key={index}
                      variant="secondary"
                      className="bg-green-50 text-green-700 border-green-200"
                    >
                      {format}
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-sm font-semibold text-gray-900 mb-2">文件大小限制</h4>
                <p className="text-sm text-gray-600">
                  单个附件不超过 <span className="font-semibold text-gray-900">{emailInfo.maxSize}</span>
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardHeader className="border-b border-gray-100">
              <CardTitle>注意事项</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-3 text-sm text-gray-700">
                <div className="flex gap-3">
                  <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="space-y-2">
                    <p>• <span className="font-semibold">必须使用学校邮箱</span>发送，否则系统无法识别您的身份</p>
                    <p>• 邮件主题格式必须<span className="font-semibold">严格一致</span>，否则可能导入失败</p>
                    <p>• 附件文件名建议包含学号和作业名称，方便后续查询</p>
                    <p>• 如需提交多个文件，请打包为 <code className="px-1 bg-gray-100 rounded">.zip</code> 格式</p>
                    <p>• 确保代码文件编码为 <span className="font-semibold">UTF-8</span></p>
                    <p>• 邮件发送后约 <span className="font-semibold text-green-600">{emailInfo.syncTime}</span> 内会同步到系统，您可以在“提交记录”页面查看</p>
                    <p>• 邮件提交后系统将自动回复确认邮件，请注意查收</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
            <CardHeader className="border-b border-gray-100">
              <CardTitle>邮件提交流程示例</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-sm font-semibold text-green-600">1</div>
                  <p className="text-sm text-gray-700">使用学校邮箱登录邮件客户端</p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-sm font-semibold text-green-600">2</div>
                  <p className="text-sm text-gray-700">收件人填写：<code className="px-2 py-1 bg-white rounded text-blue-600">{emailInfo.email}</code></p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-sm font-semibold text-green-600">3</div>
                  <p className="text-sm text-gray-700">主题填写：<code className="px-2 py-1 bg-white rounded text-gray-700">PY101-2024001-实验2</code></p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-sm font-semibold text-green-600">4</div>
                  <p className="text-sm text-gray-700">添加附件：<code className="px-2 py-1 bg-white rounded text-gray-700">2024001_张三_实验2.py</code></p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-sm font-semibold text-green-600">5</div>
                  <p className="text-sm text-gray-700">点击发送，等待系统自动同步（5-10分钟）</p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-sm font-semibold text-green-600">6</div>
                  <p className="text-sm text-gray-700">在“提交记录”页面查看提交状态和评测结果</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}