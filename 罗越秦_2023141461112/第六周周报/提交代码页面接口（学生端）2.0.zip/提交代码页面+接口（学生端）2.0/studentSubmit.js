import { BASE_URL, getHeaders, handleResponse } from "./request";

/**
 * 获取当前学生可见的课程列表
 * GET /api/v1/student/courses
 *
 * 用途：
 * - 获取当前登录学生可选择的课程
 * - 用于学生端代码提交页面的“课程选择”下拉框
 *
 * request:
 * - 无请求体
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: [
 *     {
 *       courseId: string,      // 课程 ID，例如 "course_001"
 *       courseName: string,    // 课程名称，例如 "Java 程序设计"
 *       courseCode: string,    // 课程编号，例如 "CS101"
 *       className: string,     // 班级/课序号，例如 "软件工程1班"
 *       teacherName: string,   // 任课教师姓名，例如 "张老师"
 *       semester: string       // 学期，例如 "2025-2026-2"
 *     }
 *   ]
 * }
 */
export async function getCourseList() {
  const response = await fetch(`${BASE_URL}/courses`, {
    method: "GET",
    headers: getHeaders(),
  });

  return handleResponse(response, "获取课程列表失败");
}

/**
 * 获取某门课程下的任务列表
 * GET /api/v1/student/courses/{courseId}/assignments
 *
 * 用途：
 * - 根据学生选择的课程，获取该课程下可提交的作业/实验任务
 * - 用于学生端代码提交页面的“任务选择”下拉框或任务列表
 *
 * path params:
 * - courseId: string    // 课程 ID，例如 "course_001"
 *
 * request:
 * - 无请求体
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: [
 *     {
 *       assignmentId: string,      // 作业/任务 ID，例如 "lab3"
 *       assignmentName: string,    // 作业/任务名称，例如 "实验三：循环结构程序设计"
 *       courseId: string,          // 所属课程 ID，例如 "course_001"
 *       courseName: string,        // 所属课程名称，例如 "Java 程序设计"
 *       startTime: string,         // 开始时间，例如 "2026-04-01 00:00:00"
 *       deadline: string,          // 截止时间，例如 "2026-04-20 23:59:59"
 *       status: "not_started" | "ongoing" | "ended",      // 任务状态：未开始/进行中/已结束
 *       submitStatus: "unsubmitted" | "submitted" | "late", // 学生提交状态：未提交/已提交/迟交
 *       score: number | null,      // 当前学生该任务得分，未评分或未提交时为 null
 *       totalScore: number         // 任务总分，例如 100
 *     }
 *   ]
 * }
 */
export async function getAssignmentList(courseId) {
  if (!courseId) {
    throw new Error("courseId 不能为空");
  }

  const response = await fetch(
    `${BASE_URL}/courses/${encodeURIComponent(courseId)}/assignments`,
    {
      method: "GET",
      headers: getHeaders(),
    }
  );

  return handleResponse(response, "获取任务列表失败");
}

/**
 * 获取任务详情
 * GET /api/v1/student/assignments/{assignmentId}
 *
 * 用途：
 * - 获取某个作业/实验任务的详细信息
 * - 用于学生选择任务后展示任务要求、题目列表、支持语言、提交限制等
 *
 * path params:
 * - assignmentId: string    // 作业/任务 ID，例如 "lab3"
 *
 * request:
 * - 无请求体
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: {
 *     assignmentId: string,       // 作业/任务 ID，例如 "lab3"
 *     assignmentName: string,     // 作业/任务名称，例如 "实验三：循环结构程序设计"
 *     courseId: string,           // 所属课程 ID，例如 "course_001"
 *     courseName: string,         // 所属课程名称，例如 "Java 程序设计"
 *     description: string,        // 作业说明/任务要求
 *     startTime: string,          // 开始时间，例如 "2026-04-01 00:00:00"
 *     deadline: string,           // 截止时间，例如 "2026-04-20 23:59:59"
 *     status: "not_started" | "ongoing" | "ended",
 *     submitStatus: "unsubmitted" | "submitted" | "late",
 *     allowedLanguages: string[], // 支持语言，例如 ["python", "bash shell"]
 *     maxFileSize: number,        // 最大文件大小，单位 MB，例如 10
 *     totalScore: number,         // 作业总分，例如 100
 *     problems: [
 *       {
 *         problemId: number,      // 题目 ID，例如 1
 *         title: string,          // 题目标题，例如 "计算两个数之和"
 *         description: string,    // 题目描述
 *         inputDescription: string,  // 输入说明
 *         outputDescription: string, // 输出说明
 *         sampleInput: string,    // 样例输入
 *         sampleOutput: string,   // 样例输出
 *         score: number           // 该题分值，例如 20
 *       }
 *     ]
 *   }
 * }
 */
export async function getAssignmentDetail(assignmentId) {
  if (!assignmentId) {
    throw new Error("assignmentId 不能为空");
  }

  const response = await fetch(
    `${BASE_URL}/assignments/${encodeURIComponent(assignmentId)}`,
    {
      method: "GET",
      headers: getHeaders(),
    }
  );

  return handleResponse(response, "获取任务详情失败");
}

/**
 * 获取邮件提交配置
 * GET /api/v1/student/assignments/{assignmentId}/email-config
 *
 * 用途：
 * - 获取某个作业/任务的邮件提交配置信息
 * - 用于页面展示邮件提交地址、邮件主题格式、附件要求等
 *
 * path params:
 * - assignmentId: string    // 作业/任务 ID，例如 "lab3"
 *
 * request:
 * - 无请求体
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: {
 *     assignmentId: string,       // 作业/任务 ID，例如 "lab3"
 *     enableEmailSubmit: boolean, // 是否允许邮件提交
 *     emailAddress: string,       // 提交邮箱，例如 "submit@autograder.com"
 *     subjectFormat: string,      // 邮件主题格式，例如 "学号-姓名-任务ID"
 *     attachmentFormat: string[], // 允许的附件格式，例如 [".py", ".java", ".cpp", ".zip"]
 *     maxAttachmentSize: number,  // 最大附件大小，单位 MB，例如 10
 *     description: string         // 邮件提交说明
 *   }
 * }
 */
export async function getSubmissionEmailConfig(assignmentId) {
  if (!assignmentId) {
    throw new Error("assignmentId 不能为空");
  }

  const response = await fetch(
    `${BASE_URL}/assignments/${encodeURIComponent(assignmentId)}/email-config`,
    {
      method: "GET",
      headers: getHeaders(),
    }
  );

  return handleResponse(response, "获取邮件提交配置失败");
}

/**
 * 运行代码
 * POST /api/v1/student/submissions/run
 *
 * 用途：
 * - 对当前编辑器中的代码进行一次临时运行
 * - 不作为正式提交记录
 * - 用于页面“运行结果”区域展示
 *
 * request body:
 * {
 *   assignmentId: string,   // 作业/任务 ID，例如 "lab3"
 *   problemId: number,      // 题目 ID，例如 5
 *   language: string,       // 代码语言，例如 "python" / "java" / "cpp" / "shell"
 *   code: string            // 代码正文
 * }
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: {
 *     status: "success" | "failed", // 运行状态
 *     output: string,                // 标准输出内容
 *     error: string,                 // 错误信息，运行成功时可为空字符串
 *     executionTime: string,         // 执行时间，例如 "0.023s"
 *     memory: string                 // 内存占用，例如 "2.4MB"
 *   }
 * }
 */
export async function runCode(data) {
  if (
    !data ||
    !data.assignmentId ||
    !data.problemId ||
    !data.language ||
    !data.code
  ) {
    throw new Error("运行代码参数不完整");
  }

  const response = await fetch(`${BASE_URL}/submissions/run`, {
    method: "POST",
    headers: getHeaders(),
    body: JSON.stringify(data),
  });

  return handleResponse(response, "运行代码失败");
}

/**
 * 提交代码
 * POST /api/v1/student/submissions
 *
 * 用途：
 * - 正式提交代码进入判题流程
 * - 用于页面“提交”按钮
 * - 提交成功后，前端可根据 submissionId 继续轮询判题状态
 *
 * request body:
 * {
 *   assignmentId: string,   // 作业/任务 ID，例如 "lab3"
 *   problemId: number,      // 题目 ID，例如 5
 *   language: string,       // 代码语言，例如 "python" / "java" / "cpp"
 *   code: string            // 提交的代码内容
 * }
 *
 * response:
 * {
 *   code: 0,
 *   message: "submit success",
 *   data: {
 *     submissionId: string, // 提交记录 ID，例如 "sub_10086"
 *     assignmentId: string, // 作业/任务 ID，例如 "lab3"
 *     problemId: number,    // 题目 ID，例如 5
 *     status: "pending" | "judging" | "finished" | "failed", // 判题状态
 *     submittedAt: string   // 提交时间，例如 "2026-04-14 13:48:31"
 *   }
 * }
 */
export async function submitCode(data) {
  if (
    !data ||
    !data.assignmentId ||
    !data.problemId ||
    !data.language ||
    !data.code
  ) {
    throw new Error("提交代码参数不完整");
  }

  const response = await fetch(`${BASE_URL}/submissions`, {
    method: "POST",
    headers: getHeaders(),
    body: JSON.stringify(data),
  });

  return handleResponse(response, "提交代码失败");
}

/**
 * 获取提交状态
 * GET /api/v1/student/submissions/{submissionId}/status
 *
 * 用途：
 * - 提交后轮询判题状态
 * - 判断是否继续轮询，或是否拉取提交详情
 *
 * path params:
 * - submissionId: string    // 提交记录 ID，例如 "sub_10086"
 *
 * request:
 * - 无请求体
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: {
 *     submissionId: string, // 提交记录 ID，例如 "sub_10086"
 *     status: "pending" | "judging" | "finished" | "failed", // 当前判题状态
 *     progress: number,     // 判题进度，0-100，例如 80
 *     message: string       // 状态说明，例如 "正在运行测试点 3/5"
 *   }
 * }
 */
export async function getSubmissionStatus(submissionId) {
  if (!submissionId) {
    throw new Error("submissionId 不能为空");
  }

  const response = await fetch(
    `${BASE_URL}/submissions/${encodeURIComponent(submissionId)}/status`,
    {
      method: "GET",
      headers: getHeaders(),
    }
  );

  return handleResponse(response, "获取提交状态失败");
}

/**
 * 获取提交详情
 * GET /api/v1/student/submissions/{submissionId}
 *
 * 用途：
 * - 获取完整提交结果
 * - 用于页面“提交结果”区域展示
 * - 一般在判题完成后调用
 *
 * path params:
 * - submissionId: string    // 提交记录 ID，例如 "sub_10086"
 *
 * request:
 * - 无请求体
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: {
 *     submissionId: string,              // 提交记录 ID，例如 "sub_10086"
 *     assignmentId: string,              // 作业/任务 ID，例如 "lab3"
 *     assignmentName: string,            // 作业/任务名称，例如 "实验三：循环结构程序设计"
 *     problemId: number,                 // 题目 ID，例如 5
 *     problemTitle: string,              // 题目标题，例如 "计算两个数之和"
 *     language: string,                  // 提交语言，例如 "python"
 *     code: string,                      // 提交的代码内容
 *     status: "accepted" | "rejected" | "failed" | "pending" | "judging",
 *     score: number,                     // 实得分，例如 95
 *     totalScore: number,                // 总分，例如 100
 *     submitTime: string,                // 提交时间，例如 "2026-04-14 13:48:31"
 *     executionTime: string,             // 总执行时间，例如 "0.123s"
 *     memory: string,                    // 最大内存占用，例如 "12.5MB"
 *     compileError: string,              // 编译错误信息，没有则为空字符串
 *     runtimeError: string,              // 运行错误信息，没有则为空字符串
 *     testCases: [
 *       {
 *         id: number,                    // 测试点编号，例如 1
 *         name: string,                  // 测试点名称，例如 "测试点1"
 *         status: "passed" | "failed",  // 测试点状态
 *         score: number,                 // 该测试点得分，例如 20
 *         totalScore: number,            // 该测试点总分，例如 20
 *         input: string,                 // 测试输入，可选
 *         expectedOutput: string,        // 期望输出，可选
 *         actualOutput: string,          // 实际输出，可选
 *         time: string,                  // 该测试点执行时间，例如 "0.012s"
 *         memory: string,                // 该测试点内存占用，例如 "2.1MB"
 *         error: string                  // 错误信息，成功时可为空字符串
 *       }
 *     ]
 *   }
 * }
 */
export async function getSubmissionDetail(submissionId) {
  if (!submissionId) {
    throw new Error("submissionId 不能为空");
  }

  const response = await fetch(
    `${BASE_URL}/submissions/${encodeURIComponent(submissionId)}`,
    {
      method: "GET",
      headers: getHeaders(),
    }
  );

  return handleResponse(response, "获取提交详情失败");
}

/**
 * 保存草稿
 * POST /api/v1/student/assignments/{assignmentId}/draft
 *
 * 用途：
 * - 保存当前任务下的代码草稿
 * - 用于页面“保存草稿”按钮
 * - 不进入正式判题流程
 *
 * path params:
 * - assignmentId: string    // 作业/任务 ID，例如 "lab3"
 *
 * request body:
 * {
 *   language: string,       // 代码语言，例如 "python" / "java" / "cpp"
 *   code: string            // 草稿代码内容，可以为空字符串
 * }
 *
 * response:
 * {
 *   code: 0,
 *   message: "draft saved",
 *   data: {
 *     draftId: string,      // 草稿 ID，例如 "draft_20001"
 *     assignmentId: string, // 作业/任务 ID，例如 "lab3"
 *     language: string,     // 草稿语言，例如 "python"
 *     savedAt: string       // 保存时间，例如 "2026-04-14 14:25:00"
 *   }
 * }
 */
export async function saveDraft(assignmentId, data) {
  if (!assignmentId) {
    throw new Error("assignmentId 不能为空");
  }

  if (!data || !data.language || typeof data.code !== "string") {
    throw new Error("保存草稿参数不完整");
  }

  const response = await fetch(
    `${BASE_URL}/assignments/${encodeURIComponent(assignmentId)}/draft`,
    {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify(data),
    }
  );

  return handleResponse(response, "保存草稿失败");
}

/**
 * 获取草稿
 * GET /api/v1/student/assignments/{assignmentId}/draft
 *
 * 用途：
 * - 进入页面或切换任务时，获取当前任务的历史草稿
 * - 用于页面初始化恢复编辑器内容
 *
 * path params:
 * - assignmentId: string    // 作业/任务 ID，例如 "lab3"
 *
 * request:
 * - 无请求体
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: {
 *     draftId: string | null,  // 草稿 ID，没有草稿时为 null
 *     assignmentId: string,    // 作业/任务 ID，例如 "lab3"
 *     language: string,        // 草稿语言，例如 "python"
 *     code: string,            // 草稿代码正文，没有草稿时可为空字符串
 *     savedAt: string | null   // 最近保存时间，没有草稿时为 null
 *   }
 * }
 */
export async function getDraft(assignmentId) {
  if (!assignmentId) {
    throw new Error("assignmentId 不能为空");
  }

  const response = await fetch(
    `${BASE_URL}/assignments/${encodeURIComponent(assignmentId)}/draft`,
    {
      method: "GET",
      headers: getHeaders(),
    }
  );

  return handleResponse(response, "获取草稿失败");
}