import { BASE_URL, getHeaders, handleResponse } from "./request";

/**
 * 获取教师端成绩总览数据
 * GET /api/v1/teacher/grades/overview
 *
 * 用途：
 * - 获取教师端“成绩总览”页面的整体数据
 * - 用于页面初始化加载
 * - 包含课程总成绩统计和每门课程下的作业成绩明细
 *
 * query params:
 * {
 *   keyword?: string,       // 搜索关键词，可用于搜索课程名、课程编号、班级名
 *   semester?: string,      // 学期，例如 "2025-2026-2"
 *   courseId?: string       // 课程 ID，可选
 * }
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: {
 *     summary: {
 *       courseCount: number,      // 课程数量
 *       assignmentCount: number,  // 作业总数
 *       studentCount: number,     // 学生总数
 *       averageScore: number,     // 总平均分
 *       passRate: number,         // 总及格率，例如 0.86
 *       excellentRate: number     // 总优秀率，例如 0.32
 *     },
 *     courses: [
 *       {
 *         courseId: string,       // 课程 ID，例如 "course_001"
 *         courseName: string,     // 课程名称，例如 "python 程序设计"
 *         courseCode: string,     // 课程编号，例如 "CS101"
 *         className: string,      // 班级/课序号，例如 "软件工程1班"
 *         studentCount: number,   // 该课程学生人数
 *         assignmentCount: number,// 该课程作业数量
 *         averageScore: number,   // 课程平均分
 *         highestScore: number,   // 课程最高分
 *         lowestScore: number,    // 课程最低分
 *         passRate: number,       // 课程及格率
 *         excellentRate: number,  // 课程优秀率
 *         assignments: [
 *           {
 *             assignmentId: string,     // 作业 ID，例如 "assignment_001"
 *             assignmentName: string,   // 作业名称，例如 "第一次作业"
 *             deadline: string,         // 截止时间，例如 "2026-04-20 23:59:59"
 *             submittedCount: number,   // 已提交人数
 *             unsubmittedCount: number, // 未提交人数
 *             averageScore: number,     // 作业平均分
 *             highestScore: number,     // 作业最高分
 *             lowestScore: number,      // 作业最低分
 *             passRate: number,         // 作业及格率
 *             status: "not_started" | "ongoing" | "ended"
 *           }
 *         ]
 *       }
 *     ]
 *   }
 * }
 */
export async function getGradeOverview(params = {}) {
  const query = new URLSearchParams();

  if (params.keyword) {
    query.append("keyword", params.keyword);
  }

  if (params.semester) {
    query.append("semester", params.semester);
  }

  if (params.courseId) {
    query.append("courseId", params.courseId);
  }

  const queryString = query.toString();
  const url = queryString
    ? `${BASE_URL}/grades/overview?${queryString}`
    : `${BASE_URL}/grades/overview`;

  const response = await fetch(url, {
    method: "GET",
    headers: getHeaders(),
  });

  return handleResponse(response, "获取成绩总览失败");
}

/**
 * 获取某门课程的成绩详情
 * GET /api/v1/teacher/grades/courses/{courseId}
 *
 * 用途：
 * - 获取单门课程的完整成绩统计
 * - 用于点击课程卡片、展开课程详情、进入课程成绩详情页
 *
 * path params:
 * - courseId: string   // 课程 ID
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: {
 *     courseId: string,
 *     courseName: string,
 *     courseCode: string,
 *     className: string,
 *     studentCount: number,
 *     assignmentCount: number,
 *     averageScore: number,
 *     highestScore: number,
 *     lowestScore: number,
 *     passRate: number,
 *     excellentRate: number,
 *     assignments: [
 *       {
 *         assignmentId: string,
 *         assignmentName: string,
 *         submittedCount: number,
 *         unsubmittedCount: number,
 *         averageScore: number,
 *         highestScore: number,
 *         lowestScore: number,
 *         passRate: number,
 *         status: "not_started" | "ongoing" | "ended"
 *       }
 *     ],
 *     students: [
 *       {
 *         studentId: string,      // 学生 ID
 *         studentNo: string,      // 学号
 *         studentName: string,    // 姓名
 *         totalScore: number,     // 课程总成绩
 *         averageScore: number,   // 平均成绩
 *         submittedCount: number, // 已提交作业数
 *         missingCount: number,   // 未提交作业数
 *         rank: number            // 排名
 *          assignmentScores: [
 *       {
 *          assignmentId: string,    // 作业 ID，例如 "assignment_001"
 *          assignmentName: string,  // 作业名称，例如 "实验1：变量与输入输出"
 *          score: number | null     // 该学生该次作业得分，未提交或未评分时为 null
 *    }
 *    ]
 *       }
 *     ]
 *   }
 * }
 */
export async function getCourseGradeDetail(courseId) {
  if (!courseId) {
    throw new Error("courseId 不能为空");
  }

  const response = await fetch(
    `${BASE_URL}/grades/courses/${encodeURIComponent(courseId)}`,
    {
      method: "GET",
      headers: getHeaders(),
    }
  );

  return handleResponse(response, "获取课程成绩详情失败");
}

/**
 * 获取某门课程下的作业成绩统计
 * GET /api/v1/teacher/grades/courses/{courseId}/assignments
 *
 * 用途：
 * - 获取某门课程下每次作业的成绩统计
 * - 用于课程展开区域或作业成绩列表
 *
 * path params:
 * - courseId: string   // 课程 ID
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: {
 *     courseId: string,
 *     courseName: string,
 *     assignments: [
 *       {
 *         assignmentId: string,
 *         assignmentName: string,
 *         deadline: string,
 *         totalStudents: number,
 *         submittedCount: number,
 *         unsubmittedCount: number,
 *         averageScore: number,
 *         highestScore: number,
 *         lowestScore: number,
 *         passRate: number,
 *         excellentRate: number,
 *         status: "not_started" | "ongoing" | "ended"
 *       }
 *     ]
 *   }
 * }
 */
export async function getCourseAssignmentGrades(courseId) {
  if (!courseId) {
    throw new Error("courseId 不能为空");
  }

  const response = await fetch(
    `${BASE_URL}/grades/courses/${encodeURIComponent(courseId)}/assignments`,
    {
      method: "GET",
      headers: getHeaders(),
    }
  );

  return handleResponse(response, "获取课程作业成绩统计失败");
}

/**
 * 获取某次作业的学生成绩明细
 * GET /api/v1/teacher/grades/assignments/{assignmentId}
 *
 * 用途：
 * - 获取某次作业下所有学生的成绩明细
 * - 用于点击某次作业后查看学生提交情况和得分情况
 *
 * path params:
 * - assignmentId: string   // 作业 ID
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: {
 *     assignmentId: string,
 *     assignmentName: string,
 *     courseId: string,
 *     courseName: string,
 *     totalStudents: number,
 *     submittedCount: number,
 *     unsubmittedCount: number,
 *     averageScore: number,
 *     highestScore: number,
 *     lowestScore: number,
 *     passRate: number,
 *     students: [
 *       {
 *         studentId: string,      // 学生 ID
 *         studentNo: string,      // 学号
 *         studentName: string,    // 姓名
 *         submitStatus: "submitted" | "unsubmitted" | "late",
 *         judgeStatus: "pending" | "judging" | "finished" | "failed",
 *         score: number | null,   // 分数，未提交时可为 null
 *         submitTime: string | null,
 *         rank: number | null
 *       }
 *     ]
 *   }
 * }
 */
export async function getAssignmentGradeDetail(assignmentId) {
  if (!assignmentId) {
    throw new Error("assignmentId 不能为空");
  }

  const response = await fetch(
    `${BASE_URL}/grades/assignments/${encodeURIComponent(assignmentId)}`,
    {
      method: "GET",
      headers: getHeaders(),
    }
  );

  return handleResponse(response, "获取作业成绩明细失败");
}

/**
 * 获取某个学生在某门课程下的成绩详情
 * GET /api/v1/teacher/grades/courses/{courseId}/students/{studentId}
 *
 * 用途：
 * - 查看单个学生在某门课程下的总成绩和每次作业成绩
 * - 用于学生成绩详情弹窗或详情页
 *
 * path params:
 * - courseId: string    // 课程 ID
 * - studentId: string   // 学生 ID
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: {
 *     studentId: string,
 *     studentNo: string,
 *     studentName: string,
 *     courseId: string,
 *     courseName: string,
 *     totalScore: number,
 *     averageScore: number,
 *     rank: number,
 *     submittedCount: number,
 *     missingCount: number,
 *     assignments: [
 *       {
 *         assignmentId: string,
 *         assignmentName: string,
 *         submitStatus: "submitted" | "unsubmitted" | "late",
 *         judgeStatus: "pending" | "judging" | "finished" | "failed",
 *         score: number | null,
 *         submitTime: string | null
 *       }
 *     ]
 *   }
 * }
 */
export async function getStudentCourseGradeDetail(courseId, studentId) {
  if (!courseId) {
    throw new Error("courseId 不能为空");
  }

  if (!studentId) {
    throw new Error("studentId 不能为空");
  }

  const response = await fetch(
    `${BASE_URL}/grades/courses/${encodeURIComponent(courseId)}/students/${encodeURIComponent(studentId)}`,
    {
      method: "GET",
      headers: getHeaders(),
    }
  );

  return handleResponse(response, "获取学生课程成绩详情失败");
}