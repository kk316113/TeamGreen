const BASE_URL = "/api/v1/teacher";

function getToken() {
  return localStorage.getItem("token") || "";
}

function getHeaders() {
  const token = getToken();

  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

async function handleResponse(response, defaultMessage = "请求失败") {
  const result = await response.json();

  if (!response.ok || result.code !== 0) {
    throw new Error(result.message || defaultMessage);
  }

  return result;
}

export { BASE_URL, getToken, getHeaders, handleResponse };