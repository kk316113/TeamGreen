"""
动态测试器单元测试
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
import json

from app.analyzers.dynamic_tester import (
    DynamicTester, 
    TestResult, 
    TestStatus, 
    DynamicEvaluation
)
from app.analyzers.sandbox import DockerSandbox, ExecutionResult, validate_code_safety
from app.analyzers.test_loader import TestCaseLoader, TestCase, TestType
from app.analyzers.output_comparator import OutputComparator, ComparisonResult


class TestDynamicTester:
    """DynamicTester测试类"""
    
    def setup_method(self):
        self.config = {
            'timeout_seconds': 5,
            'memory_limit': '128m',
            'ignore_whitespace': True
        }
    
    @patch('app.analyzers.dynamic_tester.DockerSandbox')
    @patch('app.analyzers.dynamic_tester.TestCaseLoader')
    def test_init(self, mock_loader, mock_sandbox):
        """测试初始化"""
        tester = DynamicTester(self.config)
        
        assert tester.config == self.config
        assert tester.sandbox is not None
        assert tester.test_loader is not None
    
    @patch('app.analyzers.dynamic_tester.DockerSandbox')
    @patch('app.analyzers.dynamic_tester.TestCaseLoader')
    def test_test_with_mocked_sandbox(self, mock_loader_class, mock_sandbox_class):
        """测试完整流程（Mock沙箱）"""
        # Mock测试用例加载器
        mock_loader = Mock()
        mock_loader.load_test_cases.return_value = [
            TestCase(
                id="test_001",
                name="测试1",
                description="测试描述",
                test_type=TestType.STDIN,
                input_data="1 2",
                expected_output="3",
                points=50.0
            )
        ]
        mock_loader_class.return_value = mock_loader
        
        # Mock沙箱
        mock_sandbox = Mock()
        mock_sandbox.execute.return_value = ExecutionResult(
            stdout="3",
            stderr="",
            exit_code=0,
            execution_time_ms=45,
            status="success"
        )
        mock_sandbox_class.return_value = mock_sandbox
        
        # 创建测试器
        tester = DynamicTester(self.config)
        tester.test_loader = mock_loader
        tester.sandbox = mock_sandbox
        
        # 执行测试
        result = tester.test(
            submission_id="test_sub_001",
            code_content="print(sum(map(int, input().split())))",
            language="python",
            assignment_id="TEST_HW01"
        )
        
        assert isinstance(result, DynamicEvaluation)
        assert result.total_tests == 1
        assert result.passed_tests == 1
        assert result.overall_score == 100.0
        assert result.passed is True
    
    def test_calculate_score(self):
        """测试评分计算"""
        evaluation = DynamicEvaluation(
            submission_id="test",
            overall_score=0,
            passed=False,
            total_tests=4,
            passed_tests=3,
            failed_tests=1,
            error_tests=0,
            total_execution_time_ms=100,
            test_results=[],
            summary=""
        )
        
        assert evaluation.overall_score == 0  # 初始值
        # 手动计算评分
        score = (3 / 4) * 100
        assert score == 75.0


class TestDockerSandbox:
    """DockerSandbox测试类"""
    
    def test_sandbox_config(self):
        from app.analyzers.sandbox import SandboxConfig
        
        config = SandboxConfig(
            timeout_seconds=5,
            memory_limit="128m",
            network_disabled=True
        )
        
        assert config.timeout_seconds == 5
        assert config.memory_limit == "128m"
        assert config.network_disabled is True
    
    @patch('docker.from_env')
    def test_sandbox_init(self, mock_docker):
        """测试沙箱初始化"""
        mock_client = Mock()
        mock_docker.return_value = mock_client
        
        sandbox = DockerSandbox()
        
        assert sandbox.client is not None
    
    def test_validate_code_safety_python(self):
        """测试Python代码安全性验证"""
        safe_code = "print('hello world')"
        is_safe, error = validate_code_safety(safe_code, 'python')
        
        assert is_safe is True
        assert error is None
        
        unsafe_code = "import os; os.system('rm -rf /')"
        is_safe, error = validate_code_safety(unsafe_code, 'python')
        
        assert is_safe is False
        assert 'os.system' in error
    
    def test_validate_code_safety_bash(self):
        """测试Bash代码安全性验证"""
        safe_code = "echo 'hello world'"
        is_safe, error = validate_code_safety(safe_code, 'bash')
        
        assert is_safe is True
        assert error is None
        
        unsafe_code = "rm -rf /"
        is_safe, error = validate_code_safety(unsafe_code, 'bash')
        
        assert is_safe is False
        assert 'rm -rf' in error
    
    def test_language_config(self):
        """测试语言配置"""
        from app.analyzers.sandbox import DockerSandbox
        
        assert 'python' in DockerSandbox.LANGUAGE_CONFIG
        assert 'bash' in DockerSandbox.LANGUAGE_CONFIG
        assert DockerSandbox.LANGUAGE_CONFIG['python']['filename'] == 'code.py'


class TestOutputComparator:
    """OutputComparator测试类"""
    
    def test_exact_match(self):
        """测试完全匹配"""
        comparator = OutputComparator(ignore_whitespace=False)
        
        result = comparator.compare("hello", "hello")
        
        assert result.match is True
        assert result.similarity == 1.0
    
    def test_whitespace_ignore(self):
        """测试忽略空白"""
        comparator = OutputComparator(ignore_whitespace=True)
        
        result = comparator.compare("hello world", "hello   world")
        
        assert result.match is True
    
    def test_case_ignore(self):
        """测试忽略大小写"""
        comparator = OutputComparator(ignore_case=True)
        
        result = comparator.compare("Hello World", "hello world")
        
        assert result.match is True
    
    def test_float_comparison(self):
        """测试浮点数比较"""
        comparator = OutputComparator(tolerance=1e-6)
        
        result = comparator.compare("3.14159", "3.14159265")
        
        assert result.match is True
    
    def test_mismatch(self):
        """测试不匹配"""
        comparator = OutputComparator()
        
        result = comparator.compare("expected", "actual")
        
        assert result.match is False
        assert result.similarity < 1.0
        assert result.error_message is not None


class TestTestCaseLoader:
    """TestCaseLoader测试类"""
    
    def test_test_case_model(self):
        """测试TestCase模型"""
        test_case = TestCase(
            id="test_001",
            name="测试用例1",
            description="描述",
            test_type=TestType.STDIN,
            input_data="test input",
            expected_output="test output"
        )
        
        assert test_case.id == "test_001"
        assert test_case.test_type == TestType.STDIN
    
    def test_test_type_enum(self):
        """测试TestType枚举"""
        assert TestType.STDIN.value == "stdin"
        assert TestType.FILE.value == "file"
        assert TestType.MODULE.value == "module"


class TestDynamicTesterIntegration:
    """动态测试器集成测试（需要Docker环境）"""
    
    @pytest.mark.integration
    def test_python_code_execution(self):
        """测试Python代码执行（集成测试）"""
        python_code = '''
a, b = map(int, input().split())
print(a + b)
'''
        
        tester = DynamicTester({
            'timeout_seconds': 5,
            'memory_limit': '64m'
        })
        
        # 创建测试用例
        test_case = TestCase(
            id="add_test",
            name="加法测试",
            description="测试加法",
            test_type=TestType.STDIN,
            input_data="10 20",
            expected_output="30"
        )
        
        # 注意：需要先有测试用例文件才能完整测试
        # 这里仅测试沙箱执行部分
        result = tester.sandbox.execute(
            code=python_code,
            language='python',
            stdin_data="10 20"
        )
        
        assert result.status == 'success'
        assert result.stdout.strip() == "30"
        
        tester.cleanup()
    
    @pytest.mark.integration
    def test_bash_code_execution(self):
        """测试Bash代码执行（集成测试）"""
        bash_code = '''
read a b
echo $((a + b))
'''
        
        tester = DynamicTester()
        
        result = tester.sandbox.execute(
            code=bash_code,
            language='bash',
            stdin_data="10 20"
        )
        
        assert result.status == 'success'
        assert result.stdout.strip() == "30"
        
        tester.cleanup()
    
    @pytest.mark.integration
    def test_timeout_handling(self):
        """测试超时处理"""
        infinite_loop = '''
while True:
    pass
'''
        
        tester = DynamicTester({'timeout_seconds': 2})
        
        result = tester.sandbox.execute(
            code=infinite_loop,
            language='python'
        )
        
        assert result.status == 'timeout'
        
        tester.cleanup()


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])