"""
动态评价数据模型
符合RQ-B-2-50：记录评价结果，包含总体评价与细节评价
"""

from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum


class TestStatusEnum(str, Enum):
    """测试状态枚举"""
    PASSED = "passed"
    FAILED = "failed"
    ERROR = "error"
    TIMEOUT = "timeout"
    SKIPPED = "skipped"


class TestResultSchema(BaseModel):
    """单个测试结果模型"""
    test_id: str = Field(..., description="测试用例ID")
    test_name: str = Field(..., description="测试名称")
    status: TestStatusEnum = Field(..., description="测试状态")
    expected_output: str = Field(..., description="预期输出")
    actual_output: str = Field(default="", description="实际输出")
    execution_time_ms: int = Field(..., description="执行耗时(毫秒)")
    memory_used_kb: Optional[int] = Field(None, description="内存使用(KB)")
    error_message: Optional[str] = Field(None, description="错误信息")
    diff_details: Optional[str] = Field(None, description="差异详情")
    points_earned: float = Field(default=0.0, description="获得分数")
    
    class Config:
        json_schema_extra = {
            "example": {
                "test_id": "test_001",
                "test_name": "基本功能测试",
                "status": "passed",
                "expected_output": "3",
                "actual_output": "3",
                "execution_time_ms": 45,
                "memory_used_kb": 1024,
                "error_message": None,
                "diff_details": None,
                "points_earned": 50.0
            }
        }


class DynamicEvaluationSchema(BaseModel):
    """动态测试评价结果模型 - 符合RQ-B-2-50"""
    submission_id: str = Field(..., description="提交ID")
    overall_score: float = Field(..., ge=0, le=100, description="总体评分 0-100")
    passed: bool = Field(..., description="是否通过所有测试")
    total_tests: int = Field(..., description="测试用例总数")
    passed_tests: int = Field(..., description="通过的测试数")
    failed_tests: int = Field(..., description="失败的测试数")
    error_tests: int = Field(..., description="执行错误的测试数")
    total_execution_time_ms: int = Field(..., description="总执行时间(毫秒)")
    test_results: List[TestResultSchema] = Field(default_factory=list, description="详细测试结果")
    summary: str = Field(..., description="总体评价文字描述")
    evaluated_at: datetime = Field(default_factory=datetime.now, description="评价时间")
    sandbox_config: Optional[Dict[str, Any]] = Field(None, description="沙箱配置")
    
    class Config:
        json_schema_extra = {
            "example": {
                "submission_id": "sub_20240415_001001_HW01_abc123",
                "overall_score": 100.0,
                "passed": True,
                "total_tests": 2,
                "passed_tests": 2,
                "failed_tests": 0,
                "error_tests": 0,
                "total_execution_time_ms": 120,
                "test_results": [],
                "summary": "动态测试全部通过！共 2 个测试用例均正确执行。",
                "evaluated_at": "2024-04-15T10:30:00",
                "sandbox_config": {
                    "timeout_seconds": 10,
                    "memory_limit": "256m"
                }
            }
        }


class EvaluationResultResponseSchema(BaseModel):
    """评价结果响应模型"""
    success: bool = Field(..., description="请求是否成功")
    data: Optional[DynamicEvaluationSchema] = Field(None, description="评价数据")
    error: Optional[str] = Field(None, description="错误信息")