-- B-2模块 动态测试结果存储表
-- 符合需求：RQ-B-2-50（记录评价结果）
-- 符合需求：RQ-B-2-60（评价结果记录到数据库）

-- 动态测试评价主表
CREATE TABLE IF NOT EXISTS dynamic_evaluations (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    submission_id VARCHAR(64) NOT NULL COMMENT '关联的提交ID',
    
    -- 总体评价
    overall_score DECIMAL(5,2) NOT NULL COMMENT '总体评分 0-100',
    passed BOOLEAN NOT NULL DEFAULT FALSE COMMENT '是否通过所有测试',
    total_tests INT NOT NULL DEFAULT 0 COMMENT '测试用例总数',
    passed_tests INT NOT NULL DEFAULT 0 COMMENT '通过的测试数',
    failed_tests INT NOT NULL DEFAULT 0 COMMENT '失败的测试数',
    error_tests INT NOT NULL DEFAULT 0 COMMENT '执行错误的测试数',
    total_execution_time_ms INT DEFAULT 0 COMMENT '总执行时间(毫秒)',
    summary TEXT COMMENT '总体评价文字描述',
    
    -- 沙箱配置
    sandbox_timeout INT COMMENT '超时设置(秒)',
    sandbox_memory_limit VARCHAR(20) COMMENT '内存限制',
    
    -- 评价元数据
    evaluator_version VARCHAR(20) COMMENT '测评器版本',
    evaluated_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '评价时间',
    
    FOREIGN KEY (submission_id) REFERENCES submissions(id) ON DELETE CASCADE,
    INDEX idx_submission (submission_id),
    INDEX idx_passed (passed),
    INDEX idx_score (overall_score),
    INDEX idx_evaluated (evaluated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='动态测试评价结果表';

-- 动态测试细节表
CREATE TABLE IF NOT EXISTS dynamic_test_results (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    evaluation_id BIGINT NOT NULL COMMENT '关联的评价ID',
    submission_id VARCHAR(64) NOT NULL COMMENT '关联的提交ID',
    
    -- 测试用例信息
    test_id VARCHAR(50) NOT NULL COMMENT '测试用例ID',
    test_name VARCHAR(200) COMMENT '测试名称',
    test_type ENUM('stdin', 'file', 'module') COMMENT '测试类型',
    
    -- 执行结果
    status ENUM('passed', 'failed', 'error', 'timeout', 'skipped') NOT NULL COMMENT '测试状态',
    expected_output TEXT COMMENT '预期输出',
    actual_output TEXT COMMENT '实际输出',
    execution_time_ms INT COMMENT '执行耗时(毫秒)',
    memory_used_kb INT COMMENT '内存使用(KB)',
    
    -- 错误和差异
    error_message TEXT COMMENT '错误信息',
    diff_details MEDIUMTEXT COMMENT '差异详情',
    
    -- 评分
    max_points DECIMAL(5,2) COMMENT '满分',
    points_earned DECIMAL(5,2) COMMENT '获得分数',
    
    executed_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '执行时间',
    
    FOREIGN KEY (evaluation_id) REFERENCES dynamic_evaluations(id) ON DELETE CASCADE,
    INDEX idx_evaluation (evaluation_id),
    INDEX idx_submission (submission_id),
    INDEX idx_test_id (test_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='动态测试详细结果表';

-- 创建视图：提交的完整测评结果（静态+动态）
CREATE OR REPLACE VIEW v_complete_evaluation AS
SELECT 
    s.id AS submission_id,
    s.student_id,
    s.student_name,
    s.course_id,
    s.assignment_id,
    s.language,
    s.status,
    s.submitted_at,
    
    -- 静态检查结果
    se.overall_score AS static_score,
    se.passed AS static_passed,
    se.error_count AS static_errors,
    se.warning_count AS static_warnings,
    
    -- 动态测试结果
    de.overall_score AS dynamic_score,
    de.passed AS dynamic_passed,
    de.passed_tests,
    de.total_tests,
    
    -- 综合评分（静态40% + 动态60%）
    ROUND(COALESCE(se.overall_score, 0) * 0.4 + COALESCE(de.overall_score, 0) * 0.6, 2) AS total_score,
    
    -- 是否完全通过
    COALESCE(se.passed, TRUE) AND COALESCE(de.passed, TRUE) AS fully_passed
    
FROM submissions s
LEFT JOIN static_evaluations se ON s.id = se.submission_id
LEFT JOIN dynamic_evaluations de ON s.id = de.submission_id;

-- 创建存储过程：记录动态测试结果
DELIMITER //

CREATE PROCEDURE save_dynamic_evaluation(
    IN p_submission_id VARCHAR(64),
    IN p_overall_score DECIMAL(5,2),
    IN p_passed BOOLEAN,
    IN p_total_tests INT,
    IN p_passed_tests INT,
    IN p_failed_tests INT,
    IN p_error_tests INT,
    IN p_total_time_ms INT,
    IN p_summary TEXT,
    OUT p_evaluation_id BIGINT
)
BEGIN
    INSERT INTO dynamic_evaluations (
        submission_id, overall_score, passed, total_tests,
        passed_tests, failed_tests, error_tests,
        total_execution_time_ms, summary
    ) VALUES (
        p_submission_id, p_overall_score, p_passed, p_total_tests,
        p_passed_tests, p_failed_tests, p_error_tests,
        p_total_time_ms, p_summary
    );
    
    SET p_evaluation_id = LAST_INSERT_ID();
    
    -- 更新提交记录状态
    UPDATE submissions 
    SET status = 'completed', 
        processed_at = NOW()
    WHERE id = p_submission_id;
END //

DELIMITER ;