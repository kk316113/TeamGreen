"""
B-2模块 - 静态代码检查器
功能：检测Python/Bash代码的语法错误与规范违规
符合需求：RQ-B-2-40
"""

import subprocess
import json
import tempfile
import os
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum


class IssueSeverity(Enum):
    """问题严重程度"""
    ERROR = "error"      # 语法错误，代码无法运行
    WARNING = "warning"  # 规范问题，建议修改
    INFO = "info"        # 提示信息
    CONVENTION = "convention"  # 编码风格


@dataclass
class StaticIssue:
    """静态检查发现的问题"""
    line: int
    column: int
    severity: str
    message: str
    rule_id: str
    symbol: str = ""


@dataclass
class StaticEvaluation:
    """静态检查评价结果 - 符合RQ-B-2-40"""
    overall_score: float  # 总体评分 0-100
    passed: bool          # 是否通过静态检查
    issue_count: int      # 问题总数
    error_count: int      # 错误数量
    warning_count: int    # 警告数量
    details: List[Dict]   # 详细问题列表
    summary: str          # 总体评价文字描述
    
    def to_dict(self) -> Dict:
        return asdict(self)
    
    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)


class StaticCodeChecker:
    """静态代码检查器主类"""
    
    SUPPORTED_LANGUAGES = ['python', 'bash', 'shell']
    
    def __init__(self, config: Optional[Dict] = None):
        """
        初始化静态检查器
        
        Args:
            config: 配置字典，可包含 pylint_rcfile, shellcheck_options 等
        """
        self.config = config or {}
        self.pylint_rcfile = self.config.get('pylint_rcfile', None)
        self.shellcheck_options = self.config.get('shellcheck_options', ['-f', 'json'])
        
    def check(self, code_content: str, language: str) -> StaticEvaluation:
        """
        执行静态代码检查
        
        Args:
            code_content: 待检查的代码内容
            language: 编程语言 (python/bash/shell)
            
        Returns:
            StaticEvaluation: 评价结果对象
        """
        language = language.lower()
        
        if language not in self.SUPPORTED_LANGUAGES:
            raise ValueError(f"不支持的语言: {language}，支持: {self.SUPPORTED_LANGUAGES}")
        
        if language == 'python':
            return self._check_python(code_content)
        elif language in ['bash', 'shell']:
            return self._check_bash(code_content)
    
    def _check_python(self, code: str) -> StaticEvaluation:
        """使用pylint检查Python代码"""
        issues = []
        
        # 1. 语法检查（编译检查）
        syntax_issues = self._check_python_syntax(code)
        issues.extend(syntax_issues)
        
        # 2. 如果有语法错误，直接返回，不再进行pylint检查
        if syntax_issues:
            return self._build_evaluation(issues, "语法错误，请修复后重新提交")
        
        # 3. Pylint规范检查
        pylint_issues = self._run_pylint(code)
        issues.extend(pylint_issues)
        
        return self._build_evaluation(issues, self._generate_summary(issues))
    
    def _check_python_syntax(self, code: str) -> List[StaticIssue]:
        """检查Python语法错误"""
        try:
            compile(code, '<submission>', 'exec')
            return []
        except SyntaxError as e:
            return [StaticIssue(
                line=e.lineno or 1,
                column=e.offset or 0,
                severity=IssueSeverity.ERROR.value,
                message=f"语法错误: {e.msg}",
                rule_id="E0001",
                symbol="syntax-error"
            )]
    
    def _run_pylint(self, code: str) -> List[StaticIssue]:
        """运行pylint检查"""
        issues = []
        
        with tempfile.NamedTemporaryFile(
            mode='w', 
            suffix='.py', 
            delete=False,
            encoding='utf-8'
        ) as f:
            f.write(code)
            temp_path = f.name
        
        try:
            cmd = ['pylint', '--output-format=json']
            if self.pylint_rcfile:
                cmd.extend(['--rcfile', self.pylint_rcfile])
            cmd.append(temp_path)
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.stdout:
                pylint_output = json.loads(result.stdout)
                for item in pylint_output:
                    severity = self._map_pylint_severity(item.get('type', 'warning'))
                    issues.append(StaticIssue(
                        line=item.get('line', 1),
                        column=item.get('column', 0),
                        severity=severity,
                        message=item.get('message', ''),
                        rule_id=item.get('message-id', ''),
                        symbol=item.get('symbol', '')
                    ))
                    
        except subprocess.TimeoutExpired:
            issues.append(StaticIssue(
                line=1, column=0,
                severity=IssueSeverity.ERROR.value,
                message="Pylint检查超时",
                rule_id="E9999",
                symbol="timeout"
            ))
        except json.JSONDecodeError:
            # Pylint可能输出非JSON格式的错误
            pass
        finally:
            os.unlink(temp_path)
        
        return issues
    
    def _check_bash(self, code: str) -> StaticEvaluation:
        """使用shellcheck检查Bash/Shell代码"""
        issues = []
        
        # 基础语法检查
        syntax_issues = self._check_bash_syntax(code)
        issues.extend(syntax_issues)
        
        if syntax_issues:
            return self._build_evaluation(issues, "脚本语法错误，请修复后重新提交")
        
        # ShellCheck详细检查
        shellcheck_issues = self._run_shellcheck(code)
        issues.extend(shellcheck_issues)
        
        return self._build_evaluation(issues, self._generate_summary(issues))
    
    def _check_bash_syntax(self, code: str) -> List[StaticIssue]:
        """检查Bash语法错误"""
        with tempfile.NamedTemporaryFile(
            mode='w',
            suffix='.sh',
            delete=False,
            encoding='utf-8'
        ) as f:
            f.write(code)
            temp_path = f.name
        
        try:
            # 使用 bash -n 检查语法
            result = subprocess.run(
                ['bash', '-n', temp_path],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if result.returncode != 0:
                # 解析错误信息
                error_line = self._parse_bash_error_line(result.stderr)
                return [StaticIssue(
                    line=error_line,
                    column=0,
                    severity=IssueSeverity.ERROR.value,
                    message=result.stderr.strip(),
                    rule_id="SC0001",
                    symbol="syntax-error"
                )]
            return []
        finally:
            os.unlink(temp_path)
    
    def _run_shellcheck(self, code: str) -> List[StaticIssue]:
        """运行shellcheck检查"""
        issues = []
        
        result = subprocess.run(
            ['shellcheck', '-f', 'json', '-'],
            input=code,
            capture_output=True,
            text=True,
            timeout=30
        )
        
        if result.stdout:
            try:
                shellcheck_output = json.loads(result.stdout)
                for item in shellcheck_output:
                    severity = self._map_shellcheck_severity(item.get('level', 'warning'))
                    issues.append(StaticIssue(
                        line=item.get('line', 1),
                        column=item.get('column', 1),
                        severity=severity,
                        message=item.get('message', ''),
                        rule_id=f"SC{item.get('code', 0)}",
                        symbol=''
                    ))
            except json.JSONDecodeError:
                pass
        
        return issues
    
    def _parse_bash_error_line(self, stderr: str) -> int:
        """从bash错误输出中提取行号"""
        import re
        match = re.search(r'line (\d+):', stderr)
        if match:
            return int(match.group(1))
        return 1
    
    def _map_pylint_severity(self, pylint_type: str) -> str:
        """映射pylint类型到统一严重程度"""
        mapping = {
            'error': IssueSeverity.ERROR.value,
            'fatal': IssueSeverity.ERROR.value,
            'warning': IssueSeverity.WARNING.value,
            'convention': IssueSeverity.CONVENTION.value,
            'refactor': IssueSeverity.INFO.value,
            'info': IssueSeverity.INFO.value,
        }
        return mapping.get(pylint_type, IssueSeverity.WARNING.value)
    
    def _map_shellcheck_severity(self, level: str) -> str:
        """映射shellcheck级别到统一严重程度"""
        mapping = {
            'error': IssueSeverity.ERROR.value,
            'warning': IssueSeverity.WARNING.value,
            'info': IssueSeverity.INFO.value,
            'style': IssueSeverity.CONVENTION.value,
        }
        return mapping.get(level, IssueSeverity.WARNING.value)
    
    def _build_evaluation(self, issues: List[StaticIssue], summary: str) -> StaticEvaluation:
        """构建评价结果对象"""
        error_count = sum(1 for i in issues if i.severity == IssueSeverity.ERROR.value)
        warning_count = sum(1 for i in issues if i.severity == IssueSeverity.WARNING.value)
        issue_count = len(issues)
        
        # 计算分数：每个错误扣20分，每个警告扣5分，最低0分
        score = max(0, 100 - error_count * 20 - warning_count * 5)
        
        # 有语法错误则直接不通过
        passed = error_count == 0
        
        return StaticEvaluation(
            overall_score=score,
            passed=passed,
            issue_count=issue_count,
            error_count=error_count,
            warning_count=warning_count,
            details=[asdict(i) for i in issues],
            summary=summary
        )
    
    def _generate_summary(self, issues: List[StaticIssue]) -> str:
        """生成总体评价文字描述"""
        if not issues:
            return "代码静态检查通过，未发现问题。"
        
        error_count = sum(1 for i in issues if i.severity == IssueSeverity.ERROR.value)
        warning_count = sum(1 for i in issues if i.severity == IssueSeverity.WARNING.value)
        
        if error_count > 0:
            return f"静态检查发现 {error_count} 个错误，{warning_count} 个警告，请修复错误后重新提交。"
        elif warning_count > 0:
            return f"静态检查通过，但发现 {warning_count} 个警告，建议优化。"
        else:
            return f"静态检查通过，发现 {len(issues)} 个建议项。"


# 便捷函数
def check_code_static(code_content: str, language: str) -> Dict:
    """
    便捷的静态检查函数
    
    Args:
        code_content: 代码内容
        language: 语言 (python/bash)
        
    Returns:
        Dict: 评价结果字典
    """
    checker = StaticCodeChecker()
    result = checker.check(code_content, language)
    return result.to_dict()


# 示例用法
if __name__ == "__main__":
    # 测试Python代码
    python_code = '''
def hello():
    print("Hello, World!")
    x = 1  # 未使用的变量
    
hello()
'''
    
    checker = StaticCodeChecker()
    result = checker.check(python_code, 'python')
    print("=== Python检查结果 ===")
    print(result.to_json())
    
    # 测试Bash代码
    bash_code = '''#!/bin/bash
echo "Hello World"
cat $UNDEFINED_VAR
'''
    
    result = checker.check(bash_code, 'bash')
    print("\n=== Bash检查结果 ===")
    print(result.to_json())