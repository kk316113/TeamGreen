"""
静态代码检查器单元测试
"""

import pytest
import json
from app.analyzers.static_checker import (
    StaticCodeChecker, 
    StaticEvaluation,
    check_code_static
)


class TestStaticCodeChecker:
    """静态检查器测试类"""
    
    def setup_method(self):
        self.checker = StaticCodeChecker()
    
    # ========== Python测试用例 ==========
    
    def test_valid_python_code(self):
        """测试：正确的Python代码"""
        code = '''
def add(a, b):
    """Add two numbers"""
    return a + b

result = add(1, 2)
print(result)
'''
        result = self.checker.check(code, 'python')
        
        assert isinstance(result, StaticEvaluation)
        assert result.passed is True
        assert result.overall_score >= 80
        assert result.error_count == 0
    
    def test_python_syntax_error(self):
        """测试：Python语法错误"""
        code = '''
def broken_function(
    print("Missing parenthesis"
'''
        result = self.checker.check(code, 'python')
        
        assert result.passed is False
        assert result.error_count > 0
        assert "语法错误" in result.summary
    
    def test_python_unused_variable_warning(self):
        """测试：未使用变量警告"""
        code = '''
def calculate():
    x = 100  # 未使用
    y = 200
    return y
'''
        result = self.checker.check(code, 'python')
        
        # 可能触发警告
        assert result.warning_count >= 0
        # 有警告但不影响通过
        assert result.passed is True
    
    def test_python_import_error(self):
        """测试：导入不存在的模块"""
        code = '''
import nonexistent_module_xyz

def test():
    pass
'''
        result = self.checker.check(code, 'python')
        
        # Pylint会报告导入错误
        assert result.error_count > 0 or result.warning_count > 0
    
    # ========== Bash测试用例 ==========
    
    def test_valid_bash_code(self):
        """测试：正确的Bash代码"""
        code = '''#!/bin/bash
echo "Hello, World!"
name="Student"
echo "Welcome, $name"
'''
        result = self.checker.check(code, 'bash')
        
        assert isinstance(result, StaticEvaluation)
        assert result.passed is True
        assert result.error_count == 0
    
    def test_bash_syntax_error(self):
        """测试：Bash语法错误"""
        code = '''#!/bin/bash
if [ $1 == "test"
    echo "Missing then/fi"
'''
        result = self.checker.check(code, 'bash')
        
        assert result.passed is False
        assert result.error_count > 0
    
    def test_bash_unquoted_variable_warning(self):
        """测试：未加引号的变量"""
        code = '''#!/bin/bash
filename=$1
cat $filename  # 应该加引号
'''
        result = self.checker.check(code, 'bash')
        
        # ShellCheck会报告SC2086
        assert result.warning_count >= 0
    
    def test_bash_shebang_check(self):
        """测试：正确的shebang"""
        code = '''#!/bin/bash
echo "Test"
'''
        result = self.checker.check(code, 'bash')
        
        assert result.passed is True
    
    # ========== 边界测试 ==========
    
    def test_empty_code(self):
        """测试：空代码"""
        result = self.checker.check('', 'python')
        
        assert result.passed is True
        assert result.overall_score == 100
    
    def test_unsupported_language(self):
        """测试：不支持的语言"""
        with pytest.raises(ValueError, match="不支持的语言"):
            self.checker.check('code', 'java')
    
    def test_language_case_insensitive(self):
        """测试：语言名称大小写不敏感"""
        code = 'print("Hello")'
        
        result_lower = self.checker.check(code, 'python')
        result_upper = self.checker.check(code, 'PYTHON')
        result_mixed = self.checker.check(code, 'Python')
        
        assert result_lower.overall_score == result_upper.overall_score
        assert result_lower.overall_score == result_mixed.overall_score
    
    # ========== 评分测试 ==========
    
    def test_score_calculation_perfect(self):
        """测试：满分计算"""
        code = 'print("Perfect code")'
        result = self.checker.check(code, 'python')
        
        assert 90 <= result.overall_score <= 100
    
    def test_score_calculation_with_errors(self):
        """测试：有错误时的评分"""
        code = 'print(undefined_variable'  # 语法错误
        result = self.checker.check(code, 'python')
        
        assert result.overall_score < 80
        assert result.error_count > 0
    
    def test_result_json_serializable(self):
        """测试：结果可JSON序列化"""
        code = 'print("test")'
        result = self.checker.check(code, 'python')
        
        json_str = result.to_json()
        parsed = json.loads(json_str)
        
        assert parsed['overall_score'] == result.overall_score
        assert parsed['passed'] == result.passed
        assert 'details' in parsed


class TestConvenienceFunction:
    """便捷函数测试"""
    
    def test_check_code_static_python(self):
        result = check_code_static('print("test")', 'python')
        
        assert isinstance(result, dict)
        assert 'overall_score' in result
        assert 'passed' in result
    
    def test_check_code_static_bash(self):
        result = check_code_static('echo "test"', 'bash')
        
        assert isinstance(result, dict)
        assert 'overall_score' in result


if __name__ == "__main__":
    pytest.main([__file__, "-v"])