"""
评价结果数据模型定义
符合RQ-B-2-40：包含总体评价与细节评价
"""

from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime
from enum import Enum


class SeverityEnum(str, Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"
    CONVENTION = "convention"


class StaticIssueSchema(BaseModel):
    """静态检查问题模型"""
    line: int = Field(..., description="问题所在行号")
    column: int = Field(default=0, description="问题所在列号")
    severity: SeverityEnum = Field(..., description="严重程度")
    message: str = Field(..., description="问题描述")
    rule_id: str = Field(..., description="规则ID")
    symbol: str = Field(default="", description="规则符号")
    
    class Config:
        json_schema_extra = {
            "example": {
                "line": 5,
                "column": 4,
                "severity": "warning",
                "message": "Unused variable 'x'",
                "rule_id": "W0612",
                "symbol": "unused-variable"
            }
        }


class StaticEvaluationSchema(BaseModel):
    """静态检查评价结果模型 - 符合RQ-B-2-40"""
    submission_id: str = Field(..., description="提交ID")
    overall_score: float = Field(..., ge=0, le=100, description="总体评分 0-100")
    passed: bool = Field(..., description="是否通过检查")
    issue_count: int = Field(..., description="问题总数")
    error_count: int = Field(..., description="错误数量")
    warning_count: int = Field(..., description="警告数量")
    details: List[StaticIssueSchema] = Field(default_factory=list, description="细节评价列表")
    summary: str = Field(..., description="总体评价文字描述")
    checked_at: datetime = Field(default_factory=datetime.now, description="检查时间")
    language: str = Field(..., description="代码语言")
    
    class Config:
        json_schema_extra = {
            "example": {
                "submission_id": "sub_20240415_001",
                "overall_score": 85.0,
                "passed": True,
                "issue_count": 3,
                "error_count": 0,
                "warning_count": 3,
                "details": [],
                "summary": "静态检查通过，但发现3个警告，建议优化。",
                "checked_at": "2024-04-15T10:30:00",
                "language": "python"
            }
        }


class EvaluationResponseSchema(BaseModel):
    """API响应模型"""
    success: bool = Field(..., description="请求是否成功")
    data: Optional[StaticEvaluationSchema] = Field(None, description="评价数据")
    error: Optional[str] = Field(None, description="错误信息")