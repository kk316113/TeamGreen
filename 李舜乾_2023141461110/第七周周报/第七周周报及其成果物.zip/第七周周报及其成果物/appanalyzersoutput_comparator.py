"""
B-2模块 - 输出比较器
功能：比较预期输出与实际输出
"""

import re
import difflib
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)


@dataclass
class ComparisonResult:
    """比较结果"""
    match: bool
    expected: str
    actual: str
    error_message: Optional[str] = None
    diff: Optional[str] = None
    similarity: float = 0.0


class OutputComparator:
    """
    输出比较器
    支持多种比较策略
    """
    
    def __init__(
        self,
        ignore_whitespace: bool = True,
        ignore_case: bool = False,
        tolerance: float = 1e-6,
        normalize_line_endings: bool = True
    ):
        """
        初始化比较器
        
        Args:
            ignore_whitespace: 是否忽略空白字符差异
            ignore_case: 是否忽略大小写
            tolerance: 浮点数比较容差
            normalize_line_endings: 是否规范化换行符
        """
        self.ignore_whitespace = ignore_whitespace
        self.ignore_case = ignore_case
        self.tolerance = tolerance
        self.normalize_line_endings = normalize_line_endings
    
    def compare(
        self,
        expected: str,
        actual: str,
        test_case: Optional[object] = None
    ) -> ComparisonResult:
        """
        比较预期输出与实际输出
        
        Args:
            expected: 预期输出
            actual: 实际输出
            test_case: 测试用例（用于获取比较配置）
            
        Returns:
            ComparisonResult: 比较结果
        """
        # 预处理
        expected_norm = self._normalize(expected)
        actual_norm = self._normalize(actual)
        
        # 检查是否完全匹配
        if expected_norm == actual_norm:
            return ComparisonResult(
                match=True,
                expected=expected,
                actual=actual,
                similarity=1.0
            )
        
        # 尝试浮点数比较
        if self._is_numeric(expected_norm) and self._is_numeric(actual_norm):
            if self._compare_float(expected_norm, actual_norm):
                return ComparisonResult(
                    match=True,
                    expected=expected,
                    actual=actual,
                    similarity=1.0
                )
        
        # 逐行比较
        line_match = self._compare_lines(expected_norm, actual_norm)
        if line_match:
            return ComparisonResult(
                match=True,
                expected=expected,
                actual=actual,
                similarity=0.95
            )
        
        # 计算相似度
        similarity = self._calculate_similarity(expected_norm, actual_norm)
        
        # 生成diff
        diff = self._generate_diff(expected, actual)
        
        # 生成错误信息
        error_message = self._generate_error_message(expected, actual)
        
        return ComparisonResult(
            match=False,
            expected=expected,
            actual=actual,
            error_message=error_message,
            diff=diff,
            similarity=similarity
        )
    
    def _normalize(self, text: str) -> str:
        """规范化文本"""
        if not text:
            return ""
        
        # 规范化换行符
        if self.normalize_line_endings:
            text = text.replace('\r\n', '\n').replace('\r', '\n')
        
        # 移除首尾空白
        text = text.strip()
        
        # 忽略空白字符
        if self.ignore_whitespace:
            # 将多个空白替换为单个空格
            text = re.sub(r'\s+', ' ', text)
        
        # 忽略大小写
        if self.ignore_case:
            text = text.lower()
        
        return text
    
    def _is_numeric(self, text: str) -> bool:
        """检查文本是否为数值"""
        try:
            float(text.strip())
            return True
        except ValueError:
            return False
    
    def _compare_float(self, expected: str, actual: str) -> bool:
        """比较浮点数"""
        try:
            exp_val = float(expected.strip())
            act_val = float(actual.strip())
            return abs(exp_val - act_val) <= self.tolerance
        except ValueError:
            return False
    
    def _compare_lines(self, expected: str, actual: str) -> bool:
        """逐行比较"""
        exp_lines = expected.split('\n')
        act_lines = actual.split('\n')
        
        # 忽略空行
        exp_lines = [l for l in exp_lines if l.strip()]
        act_lines = [l for l in act_lines if l.strip()]
        
        if len(exp_lines) != len(act_lines):
            return False
        
        for exp, act in zip(exp_lines, act_lines):
            exp_norm = self._normalize(exp)
            act_norm = self._normalize(act)
            
            if exp_norm != act_norm:
                # 检查是否为数值
                if self._is_numeric(exp_norm) and self._is_numeric(act_norm):
                    if not self._compare_float(exp_norm, act_norm):
                        return False
                else:
                    return False
        
        return True
    
    def _calculate_similarity(self, expected: str, actual: str) -> float:
        """计算相似度"""
        if not expected and not actual:
            return 1.0
        if not expected or not actual:
            return 0.0
        
        # 使用SequenceMatcher计算相似度
        matcher = difflib.SequenceMatcher(None, expected, actual)
        return matcher.ratio()
    
    def _generate_diff(self, expected: str, actual: str) -> str:
        """生成差异报告"""
        diff_lines = []
        
        exp_lines = expected.splitlines()
        act_lines = actual.splitlines()
        
        differ = difflib.unified_diff(
            exp_lines,
            act_lines,
            fromfile='预期输出',
            tofile='实际输出',
            lineterm=''
        )
        
        diff_lines = list(differ)
        
        if diff_lines:
            return '\n'.join(diff_lines)
        
        return "无法生成差异（输出过长）"
    
    def _generate_error_message(self, expected: str, actual: str) -> str:
        """生成错误信息"""
        if not actual:
            return "程序无输出"
        
        if not expected:
            return f"预期无输出，但实际输出: {actual[:100]}"
        
        # 截取前100个字符用于显示
        exp_preview = expected[:100] + "..." if len(expected) > 100 else expected
        act_preview = actual[:100] + "..." if len(actual) > 100 else actual
        
        return f"输出不匹配\n预期: {exp_preview}\n实际: {act_preview}"


class StrictComparator(OutputComparator):
    """严格比较器（不忽略任何差异）"""
    
    def __init__(self):
        super().__init__(
            ignore_whitespace=False,
            ignore_case=False,
            tolerance=0,
            normalize_line_endings=True
        )


class LooseComparator(OutputComparator):
    """宽松比较器（忽略空白和大小写）"""
    
    def __init__(self):
        super().__init__(
            ignore_whitespace=True,
            ignore_case=True,
            tolerance=1e-3,
            normalize_line_endings=True
        )