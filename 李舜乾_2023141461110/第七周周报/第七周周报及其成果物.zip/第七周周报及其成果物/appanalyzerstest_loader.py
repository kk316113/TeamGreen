"""
B-2模块 - 测试用例加载器
功能：从题库加载测试用例
符合需求：RQ-B-3-20至RQ-B-3-50
"""

import json
import os
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class TestType(str, Enum):
    """测试类型"""
    STDIN = "stdin"      # 命令行接收测试数据（RQ-B-3-30）
    FILE = "file"        # 文件读取测试数据（RQ-B-3-40）
    MODULE = "module"    # import/include调用（RQ-B-3-50）


@dataclass
class TestCase:
    """测试用例数据模型"""
    id: str
    name: str
    description: str
    test_type: TestType
    input_data: Optional[str] = None
    input_files: Optional[Dict[str, str]] = None
    expected_output: str = ""
    function_name: Optional[str] = None
    function_args: Optional[List[Any]] = None
    points: float = 1.0
    timeout_seconds: int = 5
    tags: List[str] = field(default_factory=list)
    metadata: Dict = field(default_factory=dict)


class TestCaseLoader:
    """
    测试用例加载器
    从题库系统加载测试用例
    """
    
    def __init__(self, base_path: Optional[str] = None):
        """
        初始化加载器
        
        Args:
            base_path: 题库根目录
        """
        if base_path:
            self.base_path = Path(base_path)
        else:
            self.base_path = Path(os.environ.get('TEST_CASES_PATH', './test_cases'))
        
        self.base_path.mkdir(parents=True, exist_ok=True)
        self._cache: Dict[str, List[TestCase]] = {}
        
        logger.info(f"测试用例加载器初始化完成，题库路径: {self.base_path}")
    
    def load_test_cases(
        self,
        assignment_id: str,
        language: str
    ) -> List[TestCase]:
        """
        加载指定作业的测试用例
        
        Args:
            assignment_id: 作业ID
            language: 编程语言
            
        Returns:
            List[TestCase]: 测试用例列表
        """
        cache_key = f"{assignment_id}_{language}"
        
        if cache_key in self._cache:
            logger.debug(f"从缓存加载测试用例: {cache_key}")
            return self._cache[cache_key]
        
        # 构建测试用例路径
        test_path = self.base_path / assignment_id / language
        
        if not test_path.exists():
            logger.warning(f"测试用例目录不存在: {test_path}")
            return self._get_default_test_cases(assignment_id, language)
        
        test_cases = []
        
        # 加载JSON格式的测试用例
        for json_file in test_path.glob('*.json'):
            try:
                cases = self._load_from_json(json_file)
                test_cases.extend(cases)
            except Exception as e:
                logger.error(f"加载测试用例失败 {json_file}: {e}")
        
        # 加载YAML格式的测试用例（如果存在）
        for yaml_file in test_path.glob('*.yaml'):
            try:
                cases = self._load_from_yaml(yaml_file)
                test_cases.extend(cases)
            except Exception as e:
                logger.error(f"加载测试用例失败 {yaml_file}: {e}")
        
        # 按ID排序
        test_cases.sort(key=lambda x: x.id)
        
        self._cache[cache_key] = test_cases
        logger.info(f"加载测试用例完成: {assignment_id}/{language} - {len(test_cases)} 个用例")
        
        return test_cases
    
    def _load_from_json(self, file_path: Path) -> List[TestCase]:
        """从JSON文件加载测试用例"""
        data = json.loads(file_path.read_text(encoding='utf-8'))
        
        # 支持单个用例或用例数组
        if isinstance(data, dict):
            data = [data]
        
        test_cases = []
        for item in data:
            test_case = TestCase(
                id=item.get('id', file_path.stem),
                name=item.get('name', '未命名测试'),
                description=item.get('description', ''),
                test_type=TestType(item.get('test_type', 'stdin')),
                input_data=item.get('input_data'),
                input_files=item.get('input_files'),
                expected_output=item.get('expected_output', ''),
                function_name=item.get('function_name'),
                function_args=item.get('function_args'),
                points=item.get('points', 1.0),
                timeout_seconds=item.get('timeout_seconds', 5),
                tags=item.get('tags', []),
                metadata=item.get('metadata', {})
            )
            test_cases.append(test_case)
        
        return test_cases
    
    def _load_from_yaml(self, file_path: Path) -> List[TestCase]:
        """从YAML文件加载测试用例"""
        try:
            import yaml
        except ImportError:
            logger.warning("PyYAML未安装，跳过YAML测试用例")
            return []
        
        data = yaml.safe_load(file_path.read_text(encoding='utf-8'))
        
        if isinstance(data, dict):
            data = [data]
        
        test_cases = []
        for item in data:
            test_case = TestCase(
                id=item.get('id', file_path.stem),
                name=item.get('name', '未命名测试'),
                description=item.get('description', ''),
                test_type=TestType(item.get('test_type', 'stdin')),
                input_data=item.get('input_data'),
                input_files=item.get('input_files'),
                expected_output=item.get('expected_output', ''),
                function_name=item.get('function_name'),
                function_args=item.get('function_args'),
                points=item.get('points', 1.0),
                timeout_seconds=item.get('timeout_seconds', 5),
                tags=item.get('tags', []),
                metadata=item.get('metadata', {})
            )
            test_cases.append(test_case)
        
        return test_cases
    
    def _get_default_test_cases(self, assignment_id: str, language: str) -> List[TestCase]:
        """
        获取默认测试用例（当题库不存在时）
        用于开发测试阶段
        """
        logger.info(f"使用默认测试用例: {assignment_id}/{language}")
        
        if language == 'python':
            return [
                TestCase(
                    id="test_001",
                    name="基本功能测试",
                    description="测试加法函数",
                    test_type=TestType.STDIN,
                    input_data="1 2",
                    expected_output="3",
                    points=50.0
                ),
                TestCase(
                    id="test_002",
                    name="边界值测试",
                    description="测试负数",
                    test_type=TestType.STDIN,
                    input_data="-5 3",
                    expected_output="-2",
                    points=50.0
                )
            ]
        elif language in ['bash', 'shell']:
            return [
                TestCase(
                    id="test_001",
                    name="基本功能测试",
                    description="测试echo命令",
                    test_type=TestType.STDIN,
                    input_data="",
                    expected_output="Hello World",
                    points=100.0
                )
            ]
        
        return []
    
    def create_test_case(
        self,
        assignment_id: str,
        language: str,
        test_case: TestCase
    ) -> bool:
        """
        创建/更新测试用例（符合RQ-B-3-60：题库维护）
        
        Args:
            assignment_id: 作业ID
            language: 编程语言
            test_case: 测试用例
            
        Returns:
            bool: 是否成功
        """
        test_path = self.base_path / assignment_id / language
        test_path.mkdir(parents=True, exist_ok=True)
        
        # 保存为JSON格式
        file_path = test_path / f"{test_case.id}.json"
        
        data = {
            'id': test_case.id,
            'name': test_case.name,
            'description': test_case.description,
            'test_type': test_case.test_type.value,
            'input_data': test_case.input_data,
            'input_files': test_case.input_files,
            'expected_output': test_case.expected_output,
            'function_name': test_case.function_name,
            'function_args': test_case.function_args,
            'points': test_case.points,
            'timeout_seconds': test_case.timeout_seconds,
            'tags': test_case.tags,
            'metadata': test_case.metadata
        }
        
        try:
            file_path.write_text(
                json.dumps(data, ensure_ascii=False, indent=2),
                encoding='utf-8'
            )
            
            # 清除缓存
            cache_key = f"{assignment_id}_{language}"
            if cache_key in self._cache:
                del self._cache[cache_key]
            
            logger.info(f"测试用例已保存: {file_path}")
            return True
            
        except Exception as e:
            logger.error(f"保存测试用例失败: {e}")
            return False
    
    def delete_test_case(
        self,
        assignment_id: str,
        language: str,
        test_id: str
    ) -> bool:
        """
        删除测试用例
        
        Args:
            assignment_id: 作业ID
            language: 编程语言
            test_id: 测试用例ID
            
        Returns:
            bool: 是否成功
        """
        test_path = self.base_path / assignment_id / language
        file_path = test_path / f"{test_id}.json"
        
        if file_path.exists():
            file_path.unlink()
            
            # 清除缓存
            cache_key = f"{assignment_id}_{language}"
            if cache_key in self._cache:
                del self._cache[cache_key]
            
            logger.info(f"测试用例已删除: {file_path}")
            return True
        
        return False
    
    def list_assignments(self) -> List[str]:
        """列出所有有测试用例的作业"""
        assignments = []
        for path in self.base_path.iterdir():
            if path.is_dir():
                assignments.append(path.name)
        return assignments


# 示例：创建测试用例文件
def create_sample_test_case():
    """创建示例测试用例"""
    loader = TestCaseLoader()
    
    # 创建Python测试用例
    test_case = TestCase(
        id="add_test_001",
        name="加法基本测试",
        description="测试两个正整数的加法",
        test_type=TestType.STDIN,
        input_data="10\n20\n",
        expected_output="30",
        points=50.0
    )
    
    loader.create_test_case("CS101_HW01", "python", test_case)
    
    # 创建Bash测试用例
    bash_test = TestCase(
        id="hello_test_001",
        name="Hello World测试",
        description="测试基本输出",
        test_type=TestType.STDIN,
        input_data="",
        expected_output="Hello, World!",
        points=100.0
    )
    
    loader.create_test_case("CS101_HW01", "bash", bash_test)
    
    print("示例测试用例已创建")


if __name__ == "__main__":
    create_sample_test_case()