"""
B-2模块 - Docker安全沙箱
功能：在隔离环境中安全执行待测代码
符合需求：RQ-B-2-50（动态运行测试）
"""

import docker
import tempfile
import os
import shutil
import time
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class SandboxConfig:
    """沙箱配置"""
    image: str = "python:3.11-slim"
    timeout_seconds: int = 10
    memory_limit: str = "256m"
    cpu_limit: float = 1.0
    network_disabled: bool = True
    read_only: bool = True
    no_new_privileges: bool = True
    working_dir: str = "/code"
    user: str = "nobody"
    
    # 允许的系统调用（seccomp profile）
    allowed_syscalls: List[str] = field(default_factory=lambda: [
        'read', 'write', 'open', 'close', 'stat', 'fstat', 'lstat',
        'poll', 'lseek', 'mmap', 'mprotect', 'munmap', 'brk',
        'rt_sigaction', 'rt_sigprocmask', 'rt_sigreturn',
        'ioctl', 'pread64', 'pwrite64', 'readv', 'writev',
        'access', 'pipe', 'select', 'sched_yield', 'mremap',
        'msync', 'mincore', 'madvise', 'shmget', 'shmat',
        'shmctl', 'dup', 'dup2', 'pause', 'nanosleep',
        'getitimer', 'setitimer', 'alarm', 'getpid',
        'sendfile', 'socket', 'connect', 'accept', 'sendto',
        'recvfrom', 'sendmsg', 'recvmsg', 'shutdown', 'bind',
        'listen', 'getsockname', 'getpeername', 'socketpair',
        'setsockopt', 'getsockopt', 'clone', 'fork', 'vfork',
        'execve', 'exit', 'wait4', 'kill', 'uname', 'semget',
        'semop', 'semctl', 'shmdt', 'msgget', 'msgsnd',
        'msgrcv', 'msgctl', 'fcntl', 'flock', 'fsync',
        'fdatasync', 'truncate', 'ftruncate', 'getdents',
        'getcwd', 'chdir', 'fchdir', 'rename', 'mkdir',
        'rmdir', 'creat', 'link', 'unlink', 'symlink',
        'readlink', 'chmod', 'fchmod', 'chown', 'fchown',
        'lchown', 'umask', 'gettimeofday', 'getrlimit',
        'getrusage', 'sysinfo', 'times', 'ptrace',
        'getuid', 'syslog', 'getgid', 'setuid', 'setgid',
        'geteuid', 'getegid', 'setpgid', 'getppid',
        'getpgrp', 'setsid', 'setreuid', 'setregid',
        'getgroups', 'setgroups', 'setresuid', 'getresuid',
        'setresgid', 'getresgid', 'getpgid', 'setfsuid',
        'setfsgid', 'getsid', 'capget', 'capset'
    ])


@dataclass
class ExecutionResult:
    """代码执行结果"""
    stdout: str
    stderr: str
    exit_code: int
    execution_time_ms: int
    memory_used_kb: Optional[int] = None
    status: str = "success"  # success, timeout, error, killed
    error_message: Optional[str] = None


class DockerSandbox:
    """
    Docker安全沙箱
    在隔离容器中执行待测代码
    """
    
    # 语言执行配置
    LANGUAGE_CONFIG = {
        'python': {
            'command': ['python', '-u', 'code.py'],
            'filename': 'code.py',
            'wrapper': None
        },
        'bash': {
            'command': ['bash', 'code.sh'],
            'filename': 'code.sh',
            'wrapper': '#!/bin/bash\nset -e\n'
        },
        'shell': {
            'command': ['sh', 'code.sh'],
            'filename': 'code.sh',
            'wrapper': '#!/bin/sh\nset -e\n'
        }
    }
    
    def __init__(self, config: Optional[SandboxConfig] = None):
        """初始化沙箱"""
        self.config = config or SandboxConfig()
        
        try:
            self.client = docker.from_env()
            # 确保镜像存在
            self._ensure_image()
            logger.info(f"Docker沙箱初始化完成，镜像: {self.config.image}")
        except Exception as e:
            logger.error(f"Docker连接失败: {e}")
            self.client = None
    
    def _ensure_image(self):
        """确保Docker镜像存在"""
        try:
            self.client.images.get(self.config.image)
            logger.debug(f"镜像 {self.config.image} 已存在")
        except docker.errors.ImageNotFound:
            logger.info(f"拉取镜像 {self.config.image}...")
            self.client.images.pull(self.config.image)
        except Exception as e:
            logger.warning(f"检查镜像失败: {e}")
    
    def execute(
        self,
        code: str,
        language: str,
        stdin_data: Optional[str] = None,
        files: Optional[Dict[str, str]] = None
    ) -> ExecutionResult:
        """
        在沙箱中执行代码
        
        Args:
            code: 代码内容
            language: 编程语言
            stdin_data: 标准输入数据
            files: 额外文件 {文件名: 内容}
            
        Returns:
            ExecutionResult: 执行结果
        """
        if not self.client:
            return self._fallback_execute(code, language, stdin_data)
        
        lang_config = self.LANGUAGE_CONFIG.get(language.lower())
        if not lang_config:
            return ExecutionResult(
                stdout='',
                stderr=f'不支持的语言: {language}',
                exit_code=-1,
                execution_time_ms=0,
                status='error',
                error_message=f'Unsupported language: {language}'
            )
        
        # 创建临时目录
        temp_dir = tempfile.mkdtemp(prefix='sandbox_')
        
        try:
            # 准备代码文件
            code_file = Path(temp_dir) / lang_config['filename']
            
            if lang_config.get('wrapper'):
                code = lang_config['wrapper'] + code
            
            code_file.write_text(code, encoding='utf-8')
            
            # 准备额外文件
            if files:
                for filename, content in files.items():
                    file_path = Path(temp_dir) / filename
                    file_path.parent.mkdir(parents=True, exist_ok=True)
                    file_path.write_text(content, encoding='utf-8')
            
            # 设置文件权限
            os.chmod(code_file, 0o644)
            
            # 创建并运行容器
            start_time = time.time()
            
            container = self.client.containers.run(
                image=self.config.image,
                command=lang_config['command'],
                volumes={temp_dir: {'bind': self.config.working_dir, 'mode': 'ro'}},
                working_dir=self.config.working_dir,
                stdin_open=stdin_data is not None,
                mem_limit=self.config.memory_limit,
                nano_cpus=int(self.config.cpu_limit * 1e9),
                network_disabled=self.config.network_disabled,
                read_only=self.config.read_only,
                user=self.config.user,
                security_opt=['no-new-privileges:true'] if self.config.no_new_privileges else [],
                detach=True,
                remove=False
            )
            
            try:
                # 等待执行完成
                result = container.wait(timeout=self.config.timeout_seconds + 5)
                exit_code = result['StatusCode']
                
                # 获取输出
                stdout = container.logs(stdout=True, stderr=False).decode('utf-8', errors='replace')
                stderr = container.logs(stdout=False, stderr=True).decode('utf-8', errors='replace')
                
                # 获取资源使用统计
                stats = container.stats(stream=False)
                memory_used = stats.get('memory_stats', {}).get('max_usage', 0) // 1024
                
                status = 'success'
                if exit_code != 0 and stderr:
                    status = 'error'
                
                execution_time = int((time.time() - start_time) * 1000)
                
                return ExecutionResult(
                    stdout=stdout.strip(),
                    stderr=stderr.strip(),
                    exit_code=exit_code,
                    execution_time_ms=execution_time,
                    memory_used_kb=memory_used,
                    status=status
                )
                
            except docker.errors.APIError as e:
                if 'timed out' in str(e).lower():
                    return ExecutionResult(
                        stdout='',
                        stderr='',
                        exit_code=-1,
                        execution_time_ms=self.config.timeout_seconds * 1000,
                        status='timeout',
                        error_message=f'执行超时'
                    )
                raise
                
            finally:
                # 清理容器
                try:
                    container.remove(force=True)
                except:
                    pass
                    
        except Exception as e:
            logger.error(f"沙箱执行失败: {e}")
            return ExecutionResult(
                stdout='',
                stderr=str(e),
                exit_code=-1,
                execution_time_ms=0,
                status='error',
                error_message=str(e)
            )
        finally:
            # 清理临时目录
            shutil.rmtree(temp_dir, ignore_errors=True)
    
    def execute_module(
        self,
        code: str,
        language: str,
        function_name: str,
        args: List = None,
        files: Optional[Dict[str, str]] = None
    ) -> ExecutionResult:
        """
        以模块方式执行代码（符合RQ-B-3-50）
        适用于需要import/include后调用的代码
        
        Args:
            code: 代码内容
            language: 编程语言
            function_name: 要调用的函数名
            args: 函数参数
            files: 额外文件
            
        Returns:
            ExecutionResult: 执行结果
        """
        if language == 'python':
            # 生成调用包装代码
            wrapper_code = f'''
{code}

import sys
import json

if __name__ == "__main__":
    try:
        result = {function_name}(*json.loads(sys.stdin.read()))
        print(json.dumps(result))
    except Exception as e:
        print(f"Error: {{e}}", file=sys.stderr)
        sys.exit(1)
'''
            stdin_data = json.dumps(args or [])
            
            return self.execute(
                code=wrapper_code,
                language='python',
                stdin_data=stdin_data,
                files=files
            )
        
        elif language in ['bash', 'shell']:
            # Bash函数调用
            wrapper_code = f'''
{code}

# 调用函数并捕获输出
{function_name} {" ".join(map(str, args or []))}
'''
            return self.execute(
                code=wrapper_code,
                language=language,
                stdin_data=None,
                files=files
            )
        
        else:
            return ExecutionResult(
                stdout='',
                stderr=f'Module execution not supported for {language}',
                exit_code=-1,
                execution_time_ms=0,
                status='error'
            )
    
    def _fallback_execute(self, code: str, language: str, stdin_data: Optional[str] = None) -> ExecutionResult:
        """
        降级执行方案（当Docker不可用时）
        使用subprocess在本地执行（仅用于开发测试）
        """
        import subprocess
        import tempfile
        
        logger.warning("使用降级执行方案（非沙箱模式）")
        
        lang_config = self.LANGUAGE_CONFIG.get(language.lower(), {})
        suffix = '.py' if language == 'python' else '.sh'
        
        with tempfile.NamedTemporaryFile(mode='w', suffix=suffix, delete=False) as f:
            if language in ['bash', 'shell']:
                f.write('#!/bin/bash\nset -e\n')
            f.write(code)
            temp_path = f.name
        
        try:
            os.chmod(temp_path, 0o755)
            
            start_time = time.time()
            
            if language == 'python':
                cmd = ['python', '-u', temp_path]
            else:
                cmd = ['bash', temp_path]
            
            process = subprocess.run(
                cmd,
                input=stdin_data.encode() if stdin_data else None,
                capture_output=True,
                timeout=self.config.timeout_seconds,
                text=True
            )
            
            execution_time = int((time.time() - start_time) * 1000)
            
            return ExecutionResult(
                stdout=process.stdout.strip(),
                stderr=process.stderr.strip(),
                exit_code=process.returncode,
                execution_time_ms=execution_time,
                status='success' if process.returncode == 0 else 'error'
            )
            
        except subprocess.TimeoutExpired:
            return ExecutionResult(
                stdout='',
                stderr='',
                exit_code=-1,
                execution_time_ms=self.config.timeout_seconds * 1000,
                status='timeout',
                error_message='执行超时'
            )
        except Exception as e:
            return ExecutionResult(
                stdout='',
                stderr=str(e),
                exit_code=-1,
                execution_time_ms=0,
                status='error',
                error_message=str(e)
            )
        finally:
            os.unlink(temp_path)
    
    def cleanup(self):
        """清理资源"""
        if self.client:
            try:
                self.client.close()
            except:
                pass


# 安全验证装饰器
def validate_code_safety(code: str, language: str) -> Tuple[bool, Optional[str]]:
    """
    验证代码安全性（符合RQ-B-3-10）
    
    Args:
        code: 代码内容
        language: 编程语言
        
    Returns:
        Tuple[bool, Optional[str]]: (是否安全, 风险描述)
    """
    # 禁止的关键词/模式
    forbidden_patterns = {
        'python': [
            ('__import__', '禁止使用__import__'),
            ('eval', '禁止使用eval'),
            ('exec', '禁止使用exec'),
            ('compile', '禁止使用compile'),
            ('os.system', '禁止执行系统命令'),
            ('subprocess', '禁止使用subprocess'),
            ('popen', '禁止使用popen'),
            ('socket', '禁止使用socket网络编程'),
            ('urllib', '禁止网络请求'),
            ('requests', '禁止网络请求'),
            ('open', '禁止文件操作'),
            ('shutil', '禁止文件操作'),
            ('os.remove', '禁止删除文件'),
            ('os.unlink', '禁止删除文件'),
            ('os.rmdir', '禁止删除目录'),
        ],
        'bash': [
            ('rm -rf', '禁止删除命令'),
            ('mkfs', '禁止格式化命令'),
            ('dd if=', '禁止磁盘操作'),
            (':(){ :|:& };:', '禁止fork炸弹'),
            ('/dev/tcp', '禁止网络连接'),
            ('wget', '禁止下载文件'),
            ('curl', '禁止网络请求'),
            ('nc ', '禁止netcat'),
            ('telnet', '禁止telnet'),
            ('chmod 777', '禁止修改权限'),
            ('sudo', '禁止提权操作'),
        ]
    }
    
    patterns = forbidden_patterns.get(language.lower(), [])
    
    for pattern, message in patterns:
        if pattern.lower() in code.lower():
            return False, message
    
    # 检查代码长度限制
    if len(code) > 1024 * 1024:  # 1MB
        return False, "代码文件过大"
    
    return True, None