"""
B-2模块 - 动态运行测试器
功能：在安全沙箱中运行待测代码，验证输出正确性
符合需求：RQ-B-2-50（测试代码的动态运行逻辑准确性）
"""

import logging
import time
import json
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum

from app.analyzers.sandbox import DockerSandbox, SandboxConfig, ExecutionResult
from app.analyzers.test_loader import TestCaseLoader, TestCase
from app.analyzers.output_comparator import OutputComparator, ComparisonResult

logger = logging.getLogger(__name__)


class TestStatus(Enum):
    """测试状态"""
    PASSED = "passed"
    FAILED = "failed"
    ERROR = "error"
    TIMEOUT = "timeout"
    SKIPPED = "skipped"


@dataclass
class TestResult:
    """单个测试用例的执行结果"""
    test_id: str
    test_name: str
    status: TestStatus
    expected_output: str
    actual_output: str
    execution_time_ms: int
    memory_used_kb: Optional[int] = None
    error_message: Optional[str] = None
    diff_details: Optional[str] = None
    
    @property
    def passed(self) -> bool:
        return self.status == TestStatus.PASSED


@dataclass
class DynamicEvaluation:
    """动态测试评价结果 - 符合RQ-B-2-50"""
    submission_id: str
    overall_score: float  # 总体评分 0-100
    passed: bool          # 是否通过所有测试
    total_tests: int      # 测试用例总数
    passed_tests: int     # 通过的测试数
    failed_tests: int     # 失败的测试数
    error_tests: int      # 执行错误的测试数
    total_execution_time_ms: int  # 总执行时间
    test_results: List[Dict]  # 详细测试结果
    summary: str          # 总体评价文字描述
    evaluated_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict:
        return {
            'submission_id': self.submission_id,
            'overall_score': self.overall_score,
            'passed': self.passed,
            'total_tests': self.total_tests,
            'passed_tests': self.passed_tests,
            'failed_tests': self.failed_tests,
            'error_tests': self.error_tests,
            'total_execution_time_ms': self.total_execution_time_ms,
            'test_results': self.test_results,
            'summary': self.summary,
            'evaluated_at': self.evaluated_at.isoformat()
        }
    
    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)


class DynamicTester:
    """
    动态代码测试器
    在Docker沙箱中执行待测代码，与预期输出进行比对
    符合RQ-B-2-50：测试代码的动态运行逻辑准确性
    """
    
    def __init__(self, config: Optional[Dict] = None):
        """
        初始化动态测试器
        
        Args:
            config: 配置字典，可包含：
                - sandbox_image: Docker镜像
                - timeout_seconds: 超时时间
                - memory_limit: 内存限制
                - cpu_limit: CPU限制
                - network_disabled: 是否禁用网络
        """
        self.config = config or {}
        
        # 初始化沙箱
        sandbox_config = SandboxConfig(
            image=self.config.get('sandbox_image', 'python:3.11-slim'),
            timeout_seconds=self.config.get('timeout_seconds', 10),
            memory_limit=self.config.get('memory_limit', '256m'),
            cpu_limit=self.config.get('cpu_limit', 1.0),
            network_disabled=self.config.get('network_disabled', True),
            read_only=True,
            no_new_privileges=True
        )
        self.sandbox = DockerSandbox(sandbox_config)
        
        # 初始化测试用例加载器
        self.test_loader = TestCaseLoader()
        
        # 初始化输出比较器
        self.comparator = OutputComparator(
            ignore_whitespace=self.config.get('ignore_whitespace', True),
            ignore_case=self.config.get('ignore_case', False),
            tolerance=self.config.get('float_tolerance', 1e-6)
        )
        
        logger.info("动态测试器初始化完成")
    
    def test(
        self,
        submission_id: str,
        code_content: str,
        language: str,
        assignment_id: str,
        stdin_inputs: Optional[List[str]] = None
    ) -> DynamicEvaluation:
        """
        执行动态测试
        
        Args:
            submission_id: 提交ID
            code_content: 待测代码内容
            language: 编程语言 (python/bash)
            assignment_id: 作业ID（用于加载对应的测试用例）
            stdin_inputs: 命令行输入数据（可选，符合RQ-B-3-30）
            
        Returns:
            DynamicEvaluation: 动态评价结果
        """
        logger.info(f"开始动态测试: {submission_id} - {language}")
        start_time = time.time()
        
        # 1. 加载测试用例
        test_cases = self.test_loader.load_test_cases(assignment_id, language)
        
        if not test_cases:
            logger.warning(f"未找到作业 {assignment_id} 的测试用例")
            return self._create_empty_evaluation(submission_id, "未找到测试用例")
        
        # 2. 执行所有测试用例
        test_results = []
        passed_count = 0
        failed_count = 0
        error_count = 0
        total_execution_time = 0
        
        for test_case in test_cases:
            result = self._run_single_test(
                submission_id=submission_id,
                code_content=code_content,
                language=language,
                test_case=test_case,
                stdin_inputs=stdin_inputs
            )
            
            test_results.append(result)
            total_execution_time += result.execution_time_ms
            
            if result.passed:
                passed_count += 1
            elif result.status == TestStatus.FAILED:
                failed_count += 1
            elif result.status in [TestStatus.ERROR, TestStatus.TIMEOUT]:
                error_count += 1
        
        # 3. 计算评分
        total_tests = len(test_cases)
        if total_tests > 0:
            score = (passed_count / total_tests) * 100
        else:
            score = 0
        
        passed = (passed_count == total_tests and error_count == 0)
        
        # 4. 生成评价结果
        summary = self._generate_summary(
            passed_count, failed_count, error_count, total_tests, passed
        )
        
        evaluation = DynamicEvaluation(
            submission_id=submission_id,
            overall_score=round(score, 2),
            passed=passed,
            total_tests=total_tests,
            passed_tests=passed_count,
            failed_tests=failed_count,
            error_tests=error_count,
            total_execution_time_ms=total_execution_time,
            test_results=[asdict(r) for r in test_results],
            summary=summary
        )
        
        elapsed = (time.time() - start_time) * 1000
        logger.info(f"动态测试完成: {submission_id} - 分数: {score:.1f} - 耗时: {elapsed:.0f}ms")
        
        return evaluation
    
    def _run_single_test(
        self,
        submission_id: str,
        code_content: str,
        language: str,
        test_case: TestCase,
        stdin_inputs: Optional[List[str]] = None
    ) -> TestResult:
        """
        执行单个测试用例
        
        Args:
            submission_id: 提交ID
            code_content: 代码内容
            language: 编程语言
            test_case: 测试用例
            stdin_inputs: 额外的stdin输入
            
        Returns:
            TestResult: 测试结果
        """
        start_time = time.time()
        
        try:
            # 准备stdin输入
            stdin_data = test_case.input_data
            if stdin_inputs:
                stdin_data = '\n'.join(stdin_inputs) + '\n' + stdin_data
            
            # 根据测试类型执行
            if test_case.test_type == 'stdin':
                # 通过stdin传递测试数据（符合RQ-B-3-30）
                result = self.sandbox.execute(
                    code=code_content,
                    language=language,
                    stdin_data=stdin_data,
                    files=test_case.input_files
                )
            elif test_case.test_type == 'file':
                # 通过文件读取测试数据（符合RQ-B-3-40）
                result = self.sandbox.execute(
                    code=code_content,
                    language=language,
                    stdin_data='',
                    files=test_case.input_files
                )
            elif test_case.test_type == 'module':
                # 通过import/include调用（符合RQ-B-3-50）
                result = self.sandbox.execute_module(
                    code=code_content,
                    language=language,
                    function_name=test_case.function_name,
                    args=test_case.function_args,
                    files=test_case.input_files
                )
            else:
                # 默认stdin模式
                result = self.sandbox.execute(
                    code=code_content,
                    language=language,
                    stdin_data=stdin_data
                )
            
            execution_time = result.execution_time_ms
            
            # 检查执行状态
            if result.status == 'timeout':
                return TestResult(
                    test_id=test_case.id,
                    test_name=test_case.name,
                    status=TestStatus.TIMEOUT,
                    expected_output=test_case.expected_output,
                    actual_output='',
                    execution_time_ms=execution_time,
                    error_message=f"执行超时（超过{self.config.get('timeout_seconds', 10)}秒）"
                )
            
            if result.status == 'error':
                return TestResult(
                    test_id=test_case.id,
                    test_name=test_case.name,
                    status=TestStatus.ERROR,
                    expected_output=test_case.expected_output,
                    actual_output=result.stderr or result.stdout,
                    execution_time_ms=execution_time,
                    error_message=result.stderr or "执行错误"
                )
            
            # 比较输出
            comparison = self.comparator.compare(
                expected=test_case.expected_output,
                actual=result.stdout,
                test_case=test_case
            )
            
            if comparison.match:
                status = TestStatus.PASSED
                error_message = None
                diff_details = None
            else:
                status = TestStatus.FAILED
                error_message = comparison.error_message
                diff_details = comparison.diff
            
            return TestResult(
                test_id=test_case.id,
                test_name=test_case.name,
                status=status,
                expected_output=test_case.expected_output,
                actual_output=result.stdout[:1000] if result.stdout else '',  # 截断过长输出
                execution_time_ms=execution_time,
                memory_used_kb=result.memory_used_kb,
                error_message=error_message,
                diff_details=diff_details
            )
            
        except Exception as e:
            execution_time = int((time.time() - start_time) * 1000)
            logger.error(f"测试执行异常: {test_case.id} - {e}")
            
            return TestResult(
                test_id=test_case.id,
                test_name=test_case.name,
                status=TestStatus.ERROR,
                expected_output=test_case.expected_output,
                actual_output='',
                execution_time_ms=execution_time,
                error_message=str(e)
            )
    
    def _create_empty_evaluation(self, submission_id: str, reason: str) -> DynamicEvaluation:
        """创建空的评价结果"""
        return DynamicEvaluation(
            submission_id=submission_id,
            overall_score=0,
            passed=False,
            total_tests=0,
            passed_tests=0,
            failed_tests=0,
            error_tests=0,
            total_execution_time_ms=0,
            test_results=[],
            summary=f"无法执行测试: {reason}"
        )
    
    def _generate_summary(
        self,
        passed: int,
        failed: int,
        errors: int,
        total: int,
        all_passed: bool
    ) -> str:
        """生成评价摘要"""
        if total == 0:
            return "无测试用例"
        
        if all_passed:
            return f"动态测试全部通过！共 {total} 个测试用例均正确执行。"
        elif errors > 0:
            return f"动态测试部分失败：{passed} 通过，{failed} 失败，{errors} 个执行错误（共 {total} 个用例）。"
        else:
            return f"动态测试部分通过：{passed} 通过，{failed} 失败（共 {total} 个用例）。"
    
    def cleanup(self):
        """清理资源"""
        self.sandbox.cleanup()


# 便捷函数
def test_code_dynamic(
    submission_id: str,
    code_content: str,
    language: str,
    assignment_id: str,
    config: Optional[Dict] = None
) -> Dict:
    """
    便捷的动态测试函数
    
    Args:
        submission_id: 提交ID
        code_content: 代码内容
        language: 编程语言
        assignment_id: 作业ID
        config: 配置
        
    Returns:
        Dict: 评价结果字典
    """
    tester = DynamicTester(config)
    try:
        result = tester.test(submission_id, code_content, language, assignment_id)
        return result.to_dict()
    finally:
        tester.cleanup()


# 示例用法
if __name__ == "__main__":
    # 测试Python代码
    python_code = '''
def add(a, b):
    return a + b

def main():
    import sys
    if len(sys.argv) > 1:
        a, b = map(int, sys.argv[1:3])
        print(add(a, b))
    else:
        a = int(input())
        b = int(input())
        print(add(a, b))

if __name__ == "__main__":
    main()
'''
    
    tester = DynamicTester({
        'timeout_seconds': 5,
        'memory_limit': '128m',
        'ignore_whitespace': True
    })
    
    # 注意：需要先创建测试用例
    result = tester.test(
        submission_id="test_sub_001",
        code_content=python_code,
        language="python",
        assignment_id="CS101_HW01"
    )
    
    print(result.to_json())
    tester.cleanup()