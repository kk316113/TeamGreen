import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useState } from "react";
import { Upload, FileText, CheckCircle, XCircle, AlertCircle, RefreshCw, Send, Eye, FileSpreadsheet } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";

/**
 * 学生信息导入组件
 * 实现文件上传、解析、校验和提交功能
 */
export function StudentImport() {
    // 状态管理
    const [file, setFile] = useState(null); // 选中的文件
    const [parsing, setParsing] = useState(false); // 解析中状态
    const [parsedData, setParsedData] = useState([]); // 解析后的数据
    const [validationErrors, setValidationErrors] = useState([]); // 校验错误信息
    const [classId, setClassId] = useState(""); // 班级ID(*)
    const [submitting, setSubmitting] = useState(false); // 提交中状态
    const [submitResult, setSubmitResult] = useState(null); // 提交结果

    // 处理文件选择
    const handleFileChange = (e) => {
        if (e.target.files && e.target.files[0]) {
            const selectedFile = e.target.files[0];
            setFile(selectedFile);
            setParsedData([]);
            setValidationErrors([]);
            setSubmitResult(null);
        }
    };

    // 前端解析文件（核心功能）
    const handleParse = () => {
        if (!file) return;
        setParsing(true);
        
        // 模拟前端解析过程
        setTimeout(() => {
            const fileExtension = file.name.split(".").pop()?.toLowerCase();
            if (fileExtension === "xlsx" || fileExtension === "xls") {
                // 模拟XLSX解析
                const mockData = [
                    {
                        student_no: "2024001",
                        name: "张三",
                        email: "zhangsan@example.com",
                        courseCode: "PYTHON101",
                        courseSeq: "01",
                        className: "计算机1班",
                    },
                    {
                        student_no: "2024002",
                        name: "李四",
                        email: "lisi@example.com",
                        courseCode: "PYTHON101",
                        courseSeq: "01",
                        className: "计算机1班",
                    },
                    {
                        student_no: "2024003",
                        name: "王五",
                        email: "wangwu@example.com",
                        courseCode: "BASH101",
                        courseSeq: "02",
                        className: "计算机2班",
                    },
                    {
                        student_no: "2024001",
                        name: "张三重复",
                        email: "zhangsan@example.com",
                        courseCode: "PYTHON101",
                        courseSeq: "01",
                        className: "计算机1班",
                    },
                    {
                        student_no: "2024005",
                        name: "",
                        email: "wangwu2@example.com",
                        courseCode: "PYTHON101",
                        courseSeq: "01",
                        className: "计算机1班",
                    },
                    {
                        student_no: "",
                        name: "孙七",
                        email: "sunqi@example.com",
                        courseCode: "INVALID",
                        courseSeq: "01",
                        className: "计算机1班",
                    },
                ];
                setParsedData(mockData);
                validateData(mockData);
            } else if (fileExtension === "pdf") {
                // 模拟PDF解析
                const mockData = [
                    {
                        studentId: "2024006",
                        name: "周八",
                        email: "zhouba@example.com",
                        courseCode: "PYTHON101",
                        courseSeq: "01",
                        className: "软件1班",
                    },
                    {
                        studentId: "2024007",
                        name: "吴九",
                        email: "wujiu@example.com",
                        courseCode: "BASH101",
                        courseSeq: "02",
                        className: "软件2班",
                    },
                ];
                setParsedData(mockData);
                validateData(mockData);
            }
            setParsing(false);
        }, 1500);
    };

    // 数据校验（前端校验）
    const validateData = (data) => {
        const errors = [];
        const studentIds = new Set();
        const validCourseCodes = ["PYTHON101", "BASH101"];
        
        data.forEach((record, index) => {
            const studentId = record.student_no || record.studentId;
            const email = record.email;
            
            // 检查必填字段
            if (!studentId) {
                errors.push({
                    row: index + 1,
                    field: "学号",
                    message: "学号不能为空",
                    severity: "error",
                });
            }
            if (!record.name) {
                errors.push({
                    row: index + 1,
                    field: "姓名",
                    message: "姓名不能为空",
                    severity: "error",
                });
            }
            // 检查重复学号
            if (studentId) {
                if (studentIds.has(studentId)) {
                    errors.push({
                        row: index + 1,
                        field: "学号",
                        message: `学号 ${studentId} 重复`,
                        severity: "error",
                    });
                } else {
                    studentIds.add(studentId);
                }
            }
            
            // 邮箱格式校验（可选）
            if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                errors.push({
                    row: index + 1,
                    field: "邮箱",
                    message: `邮箱格式不正确`,
                    severity: "warning",
                });
            }
            // 检查课程编号有效性
            if (record.courseCode && !validCourseCodes.includes(record.courseCode)) {
                errors.push({
                    row: index + 1,
                    field: "课程编号",
                    message: `课程编号 ${record.courseCode} 无效`,
                    severity: "warning",
                });
            }
            // 检查学号格式
            if (studentId && !/^\d{7}$/.test(studentId)) {
                errors.push({
                    row: index + 1,
                    field: "学号",
                    message: "学号格式错误（应为7位数字）",
                    severity: "warning",
                });
            }
        });
        setValidationErrors(errors);
    };

    // 提交到后端API
    const handleImport = async () => {
        // 过滤掉有严重错误的记录
        const validRecords = parsedData.filter((_, index) => {
            const hasError = validationErrors.some((err) => err.row === index + 1 && err.severity === "error");
            return !hasError;
        });

        // 转换数据格式以匹配后端API
        const studentData = validRecords.map((record) => ({
            student_no: record.student_no || record.studentId,
            name: record.name,
            email: record.email || `${record.student_no || record.studentId}@example.com`,
        }));

        // 验证班级ID
        if (!classId) {
            setSubmitResult({
                success: false,
                message: "班级ID不能为空",
                total: parsedData.length,
                successCount: 0,
                failedCount: parsedData.length,
                submitTime: new Date().toLocaleString(),
            });
            return;
        }

        setSubmitting(true);

        try {
            const response = await fetch('/api/v1/students/import', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    class_id: parseInt(classId),
                    students: studentData,
                }),
            });

            const result = await response.json();

            if (result.code === 0) {
                setSubmitResult({
                    success: true,
                    message: result.message || "导入成功",
                    total: parsedData.length,
                    successCount: result.data.success_count || studentData.length,
                    failedCount: result.data.fail_count || 0,
                    submitTime: new Date().toLocaleString(),
                });
            } else {
                setSubmitResult({
                    success: false,
                    message: result.message || "导入失败",
                    total: parsedData.length,
                    successCount: 0,
                    failedCount: parsedData.length,
                    submitTime: new Date().toLocaleString(),
                });
            }
        } catch (error) {
            console.error("提交失败", error);
            setSubmitResult({
                success: false,
                message: "网络错误，请稍后重试",
                total: parsedData.length,
                successCount: 0,
                failedCount: parsedData.length,
                submitTime: new Date().toLocaleString(),
            });
        } finally {
            setSubmitting(false);
        }
    };

    // 重新上传
    const handleReupload = () => {
        setFile(null);
        setParsedData([]);
        setValidationErrors([]);
        setSubmitResult(null);
        setClassId("");
    };

    const errorCount = validationErrors.filter((e) => e.severity === "error").length;
    const warningCount = validationErrors.filter((e) => e.severity === "warning").length;
    const validCount = parsedData.length - parsedData.filter((_, index) => 
        validationErrors.some((err) => err.row === index + 1 && err.severity === "error")
    ).length;

    const historyRecords = [
        {
            id: 1,
            fileName: "2024春季-Python程序设计-学生名单.xlsx",
            date: "2026-04-05 14:30",
            total: 45,
            success: 45,
            failed: 0,
            status: "completed",
        },
        {
            id: 2,
            fileName: "2024春季-Bash Shell程序设计-学生名单.xlsx",
            date: "2026-04-04 09:15",
            total: 38,
            success: 36,
            failed: 2,
            status: "partial",
        },
        {
            id: 3,
            fileName: "2024春季-综合名单.pdf",
            date: "2026-04-03 16:45",
            total: 52,
            success: 52,
            failed: 0,
            status: "completed",
        },
    ];

    return (
        <div className="space-y-6">
            {/* 页面标题 */}
            <div>
                <h1 className="text-2xl text-gray-900 mb-1">学生信息导入</h1>
                <p className="text-gray-600">上传文件并导入学生信息</p>
            </div>

            {/* 班级信息 */}
            <Card className="border-0 shadow-sm">
                <CardHeader className="border-b border-gray-100">
                    <CardTitle>班级信息</CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                    <div className="space-y-2">
                        <label className="text-sm font-medium text-gray-700">
                            选择班级 <span className="text-red-500">*</span>
                        </label>
                        <input
                            type="text"
                            placeholder="请输入班级ID（数字）"
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            value={classId}
                            onChange={(e) => setClassId(e.target.value)}
                        />
                        <p className="text-xs text-gray-500">例如：1、2、3...</p>
                    </div>
                </CardContent>
            </Card>

            {/* 步骤1：上传文件 */}
            <Card className="border-0 shadow-sm">
                <CardHeader className="border-b border-gray-100">
                    <div className="flex items-center justify-between">
                        <CardTitle>步骤1：上传文件</CardTitle>
                        {file && !parsedData.length && (
                            <Button onClick={handleParse} disabled={parsing} className="gap-2 bg-blue-600 hover:bg-blue-700">
                                <RefreshCw className={`w-4 h-4 ${parsing ? "animate-spin" : ""}`} />
                                {parsing ? "解析中..." : "开始解析"}
                            </Button>
                        )}
                    </div>
                </CardHeader>
                <CardContent className="p-6 space-y-6">
                    {!file ? (
                        <>
                            <div className="border-2 border-dashed border-gray-300 rounded-xl p-12 text-center hover:border-blue-400 transition-colors">
                                <input
                                    type="file"
                                    accept=".pdf,.xlsx,.xls"
                                    onChange={handleFileChange}
                                    className="hidden"
                                    id="file-upload"
                                />
                                <label htmlFor="file-upload" className="cursor-pointer flex flex-col items-center">
                                    <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mb-4">
                                        <Upload className="w-8 h-8 text-blue-600" />
                                    </div>
                                    <p className="text-gray-900 mb-1">点击上传或拖拽文件到此区域</p>
                                    <p className="text-sm text-gray-500">支持 PDF、XLSX 格式，单个文件不超过 10MB</p>
                                </label>
                            </div>
                            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                                <div className="flex gap-3">
                                    <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                                    <div className="text-sm text-gray-700">
                                        <p className="mb-2">文件格式要求：</p>
                                        <ul className="list-disc list-inside space-y-1 text-gray-600">
                                            <li>Excel 文件必填字段：学号、姓名、课程编号、课序号、班级</li>
                                            <li>学号格式：7位数字（如 2024001）</li>
                                            <li>课程编号：PYTHON101 或 BASH101</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </>
                    ) : (
                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                            <div className="flex items-center gap-3">
                                <FileText className="w-10 h-10 text-blue-600" />
                                <div className="flex-1 min-w-0">
                                    <p className="text-sm text-gray-900 truncate">{file.name}</p>
                                    <p className="text-xs text-gray-600">{(file.size / 1024).toFixed(2)} KB</p>
                                </div>
                                {parsedData.length > 0 && (
                                    <Button variant="outline" onClick={handleReupload} className="gap-2">
                                        <Upload className="w-4 h-4" />重新上传
                                    </Button>
                                )}
                            </div>
                        </div>
                    )}
                </CardContent>
            </Card>

            {/* 步骤2-4：数据预览和校验 */}
            {parsedData.length > 0 && (
                <>
                    {/* 步骤2-3：解析结果预览 */}
                    <Card className="border-0 shadow-sm">
                        <CardHeader className="border-b border-gray-100">
                            <div className="flex items-center justify-between">
                                <CardTitle>步骤2-3：解析结果预览</CardTitle>
                                <div className="flex items-center gap-2">
                                    <Badge className="bg-blue-50 text-blue-700 border-blue-200">共 {parsedData.length} 条</Badge>
                                    <Badge className="bg-green-50 text-green-700 border-green-200">有效 {validCount} 条</Badge>
                                </div>
                            </div>
                        </CardHeader>
                        <CardContent className="p-0">
                            <div className="overflow-x-auto">
                                <table className="w-full">
                                    <thead>
                                        <tr className="border-b border-gray-200 bg-gray-50">
                                            <th className="text-left py-3 px-4 text-sm text-gray-600">行号</th>
                                            <th className="text-left py-3 px-4 text-sm text-gray-600">学号</th>
                                            <th className="text-left py-3 px-4 text-sm text-gray-600">姓名</th>
                                            <th className="text-left py-3 px-4 text-sm text-gray-600">邮箱</th>
                                            <th className="text-left py-3 px-4 text-sm text-gray-600">课程编号</th>
                                            <th className="text-left py-3 px-4 text-sm text-gray-600">课序号</th>
                                            <th className="text-left py-3 px-4 text-sm text-gray-600">班级</th>
                                            <th className="text-center py-3 px-4 text-sm text-gray-600">状态</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-200">
                                        {parsedData.map((record, index) => {
                                            const rowErrors = validationErrors.filter((e) => e.row === index + 1);
                                            const hasError = rowErrors.some((e) => e.severity === "error");
                                            const hasWarning = rowErrors.some((e) => e.severity === "warning");
                                            return (
                                                <tr key={index} className={`hover:bg-gray-50 ${hasError ? "bg-red-50" : hasWarning ? "bg-amber-50" : ""}`}>
                                                    <td className="py-3 px-4 text-sm text-gray-900">{index + 1}</td>
                                                    <td className="py-3 px-4 text-sm text-gray-900">
                                                        {record.student_no || record.studentId || <span className="text-red-500">缺失</span>}
                                                    </td>
                                                    <td className="py-3 px-4 text-sm text-gray-900">
                                                        {record.name || <span className="text-red-500">缺失</span>}
                                                    </td>
                                                    <td className="py-3 px-4 text-sm text-gray-900">
                                                        {record.email || <span className="text-gray-400">未提供</span>}
                                                    </td>
                                                    <td className="py-3 px-4 text-sm text-gray-900">{record.courseCode}</td>
                                                    <td className="py-3 px-4 text-sm text-gray-900">{record.courseSeq}</td>
                                                    <td className="py-3 px-4 text-sm text-gray-900">{record.className}</td>
                                                    <td className="py-3 px-4 text-center">
                                                        {hasError ? (
                                                            <Badge className="bg-red-100 text-red-700 border-red-200 text-xs">
                                                                <XCircle className="w-3 h-3 mr-1" />错误
                                                            </Badge>
                                                        ) : hasWarning ? (
                                                            <Badge className="bg-amber-100 text-amber-700 border-amber-200 text-xs">
                                                                <AlertCircle className="w-3 h-3 mr-1" />警告
                                                            </Badge>
                                                        ) : (
                                                            <Badge className="bg-green-100 text-green-700 border-green-200 text-xs">
                                                                <CheckCircle className="w-3 h-3 mr-1" />正常
                                                            </Badge>
                                                        )}
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                        </CardContent>
                    </Card>

                    {/* 步骤4：数据校验结果 */}
                    <Card className="border-0 shadow-sm">
                        <CardHeader className="border-b border-gray-100">
                            <CardTitle>步骤4：数据校验结果</CardTitle>
                        </CardHeader>
                        <CardContent className="p-6">
                            <Tabs defaultValue="errors">
                                <TabsList className="grid w-full grid-cols-3">
                                    <TabsTrigger value="errors" className="gap-2">
                                        <XCircle className="w-4 h-4" />错误 ({errorCount})
                                    </TabsTrigger>
                                    <TabsTrigger value="warnings" className="gap-2">
                                        <AlertCircle className="w-4 h-4" />警告 ({warningCount})
                                    </TabsTrigger>
                                    <TabsTrigger value="summary" className="gap-2">
                                        <Eye className="w-4 h-4" />汇总
                                    </TabsTrigger>
                                </TabsList>
                                
                                <TabsContent value="errors" className="space-y-2 mt-4">
                                    {errorCount === 0 ? (
                                        <div className="text-center py-8">
                                            <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-2" />
                                            <p className="text-gray-600">没有发现错误</p>
                                        </div>
                                    ) : (
                                        <div className="space-y-2">
                                            {validationErrors
                                                .filter((e) => e.severity === "error")
                                                .map((error, idx) => (
                                                    <div key={idx} className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
                                                        <XCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                                                        <div className="flex-1">
                                                            <p className="text-sm text-red-900">第 {error.row} 行 - {error.field}</p>
                                                            <p className="text-xs text-red-700 mt-1">{error.message}</p>
                                                        </div>
                                                    </div>
                                                ))}
                                        </div>
                                    )}
                                </TabsContent>
                                
                                <TabsContent value="warnings" className="space-y-2 mt-4">
                                    {warningCount === 0 ? (
                                        <div className="text-center py-8">
                                            <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-2" />
                                            <p className="text-gray-600">没有发现警告</p>
                                        </div>
                                    ) : (
                                        <div className="space-y-2">
                                            {validationErrors
                                                .filter((e) => e.severity === "warning")
                                                .map((error, idx) => (
                                                    <div key={idx} className="p-3 bg-amber-50 border border-amber-200 rounded-lg flex items-start gap-3">
                                                        <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                                                        <div className="flex-1">
                                                            <p className="text-sm text-amber-900">第 {error.row} 行 - {error.field}</p>
                                                            <p className="text-xs text-amber-700 mt-1">{error.message}</p>
                                                        </div>
                                                    </div>
                                                ))}
                                        </div>
                                    )}
                                </TabsContent>
                                
                                <TabsContent value="summary" className="mt-4">
                                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                        <div className="bg-gray-50 rounded-lg p-4 text-center">
                                            <p className="text-3xl text-gray-900 mb-1">{parsedData.length}</p>
                                            <p className="text-sm text-gray-600">解析总数</p>
                                        </div>
                                        <div className="bg-green-50 rounded-lg p-4 text-center border border-green-200">
                                            <p className="text-3xl text-green-600 mb-1">{validCount}</p>
                                            <p className="text-sm text-gray-600">可提交数</p>
                                        </div>
                                        <div className="bg-red-50 rounded-lg p-4 text-center border border-red-200">
                                            <p className="text-3xl text-red-600 mb-1">{parsedData.length - validCount}</p>
                                            <p className="text-sm text-gray-600">错误条数</p>
                                        </div>
                                    </div>
                                </TabsContent>
                            </Tabs>
                        </CardContent>
                    </Card>

                    {/* 步骤5：确认提交 */}
                    <Card className="border-0 shadow-sm">
                        <CardHeader className="border-b border-gray-100">
                            <CardTitle>步骤5：确认提交</CardTitle>
                        </CardHeader>
                        <CardContent className="p-6">
                            <div className="flex items-center gap-4">
                                <Button variant="outline" onClick={handleReupload} className="gap-2">
                                    <Upload className="w-4 h-4" />重新上传
                                </Button>
                                <Button variant="outline" onClick={handleParse} disabled={parsing} className="gap-2">
                                    <RefreshCw className={`w-4 h-4 ${parsing ? "animate-spin" : ""}`} />重新解析
                                </Button>
                                <Button
                                    onClick={handleImport}
                                    disabled={submitting || validCount === 0 || !classId}
                                    className="gap-2 bg-green-600 hover:bg-green-700 ml-auto"
                                >
                                    <Send className="w-4 h-4" />
                                    {submitting ? "提交中..." : `确认提交 (${validCount}条)`}
                                </Button>
                            </div>
                            
                            {validCount < parsedData.length && (
                                <div className="mt-4 bg-amber-50 border border-amber-200 rounded-lg p-4">
                                    <div className="flex gap-3">
                                        <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                                        <p className="text-sm text-amber-900">
                                            检测到 {parsedData.length - validCount} 条记录存在错误，提交时将自动跳过这些记录
                                        </p>
                                    </div>
                                </div>
                            )}
                            
                            {submitResult && (
                                <div className={`mt-4 rounded-lg p-4 ${submitResult.success ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
                                    <div className="flex items-start gap-3">
                                        {submitResult.success ? 
                                            <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" /> : 
                                            <XCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-0.5" />
                                        }
                                        <div className="flex-1">
                                            <h3 className={`${submitResult.success ? 'text-green-900' : 'text-red-900'} mb-1 font-semibold`}>
                                                {submitResult.success ? "提交成功！" : "提交失败"}
                                            </h3>
                                            <p className={`text-sm ${submitResult.success ? 'text-green-700' : 'text-red-700'}`}>
                                                {submitResult.message || (submitResult.success ? "已成功导入学生信息" : "导入过程出现错误")}
                                            </p>
                                            <div className="mt-2 grid grid-cols-2 gap-2 text-sm">
                                                <div className="text-gray-600">总记录数：{submitResult.total}</div>
                                                <div className="text-green-600">成功：{submitResult.successCount || submitResult.success}</div>
                                                <div className="text-red-600">失败：{submitResult.failedCount || submitResult.failed}</div>
                                            </div>
                                            <p className="text-xs text-gray-500 mt-2">提交时间：{submitResult.submitTime}</p>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </>
            )}

            {/* 历史导入记录 */}
            <Card className="border-0 shadow-sm">
                <CardHeader className="border-b border-gray-100">
                    <CardTitle>历史导入记录</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead>
                                <tr className="border-b border-gray-200 bg-gray-50">
                                    <th className="text-left py-3 px-4 text-sm text-gray-600">文件名</th>
                                    <th className="text-left py-3 px-4 text-sm text-gray-600">导入时间</th>
                                    <th className="text-center py-3 px-4 text-sm text-gray-600">总数</th>
                                    <th className="text-center py-3 px-4 text-sm text-gray-600">成功</th>
                                    <th className="text-center py-3 px-4 text-sm text-gray-600">失败</th>
                                    <th className="text-center py-3 px-4 text-sm text-gray-600">状态</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-200">
                                {historyRecords.map((record) => (
                                    <tr key={record.id} className="hover:bg-gray-50">
                                        <td className="py-3 px-4 text-sm text-gray-900">{record.fileName}</td>
                                        <td className="py-3 px-4 text-sm text-gray-600">{record.date}</td>
                                        <td className="py-3 px-4 text-sm text-gray-900 text-center">{record.total}</td>
                                        <td className="py-3 px-4 text-sm text-green-600 text-center">{record.success}</td>
                                        <td className="py-3 px-4 text-sm text-red-600 text-center">{record.failed}</td>
                                        <td className="py-3 px-4 text-center">
                                            {record.status === "completed" ? (
                                                <Badge className="bg-green-50 text-green-700 border-green-200 text-xs">
                                                    <CheckCircle className="w-3 h-3 mr-1" />完成
                                                </Badge>
                                            ) : (
                                                <Badge className="bg-amber-50 text-amber-700 border-amber-200 text-xs">
                                                    <AlertCircle className="w-3 h-3 mr-1" />部分成功
                                                </Badge>
                                            )}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}