import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { Search, Edit, Trash2, Plus, Filter, Download, RefreshCw } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../components/ui/dialog";
import { Label } from "../components/ui/label";

export function StudentManagement() {
    // 状态管理
    const [students, setStudents] = useState([]);
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState("");
    const [editingStudent, setEditingStudent] = useState(null);
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [submitting, setSubmitting] = useState(false);
    const [error, setError] = useState(null);
    const [successMessage, setSuccessMessage] = useState(null);

    // 获取学生列表
    const fetchStudents = async () => {
        setLoading(true);
        setError(null);
        try {
            const token = localStorage.getItem("token"); // 从 localStorage 获取 token
            const response = await fetch("/api/v1/students", {
                headers: {
                    "Authorization": `Bearer ${token}`,
                },
            });

            const result = await response.json();

            if (result.code === 0) {
                setStudents(result.data || []);
            } else {
                setError(result.message || "获取学生列表失败");
            }
        } catch (err) {
            console.error("获取学生列表失败", err);
            setError("网络错误，请稍后重试");
        } finally {
            setLoading(false);
        }
    };

    // 初始加载
    useEffect(() => {
        fetchStudents();
    }, []);

    // 处理编辑
    const handleEdit = (student) => {
        setEditingStudent(student);
        setIsDialogOpen(true);
        setError(null);
        setSuccessMessage(null);
    };

    // 处理删除
    const handleDelete = async (studentId) => {
        if (!confirm(`确定要删除学号为 ${studentId} 的学生信息吗？`)) {
            return;
        }

        try {
            const token = localStorage.getItem("token");
            const response = await fetch(`/api/v1/students/${studentId}`, {
                method: "DELETE",
                headers: {
                    "Authorization": `Bearer ${token}`,
                },
            });

            const result = await response.json();

            if (result.code === 0) {
                setSuccessMessage("删除成功");
                fetchStudents(); // 刷新列表
            } else {
                alert(result.message || "删除失败");
            }
        } catch (err) {
            console.error("删除失败", err);
            alert("网络错误，请稍后重试");
        }
    };

    // 处理保存（新增或编辑）
    const handleSave = async () => {
        if (!editingStudent) return;

        // 基础校验
        if (!editingStudent.student_no || !editingStudent.name) {
            setError("学号和姓名不能为空");
            return;
        }

        setSubmitting(true);
        setError(null);

        try {
            const token = localStorage.getItem("token");
            const isEdit = !!editingStudent.id;
            
            const url = isEdit 
                ? `/api/v1/students/${editingStudent.id}` 
                : "/api/v1/students";
            
            const method = isEdit ? "PUT" : "POST";

            const requestBody = {
                student_no: editingStudent.student_no,
                name: editingStudent.name,
                major: editingStudent.major,
                class_name: editingStudent.class_name,
                course_code: editingStudent.course_code,
                course_seq: editingStudent.course_seq,
                email: editingStudent.email,
                phone: editingStudent.phone,
            };

            const response = await fetch(url, {
                method,
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`,
                },
                body: JSON.stringify(requestBody),
            });

            const result = await response.json();

            if (result.code === 0) {
                setSuccessMessage(isEdit ? "更新成功" : "添加成功");
                setIsDialogOpen(false);
                setEditingStudent(null);
                fetchStudents(); // 刷新列表
            } else {
                setError(result.message || "操作失败");
            }
        } catch (err) {
            console.error("保存失败", err);
            setError("网络错误，请稍后重试");
        } finally {
            setSubmitting(false);
        }
    };

    // 处理添加新学生
    const handleAdd = () => {
        setEditingStudent({
            student_no: "",
            name: "",
            major: "",
            class_name: "",
            course_code: "",
            course_seq: "",
            email: "",
            phone: "",
        });
        setError(null);
        setSuccessMessage(null);
        setIsDialogOpen(true);
    };

    // 过滤学生列表
    const filteredStudents = students.filter((student) =>
        student.student_no?.includes(searchTerm) ||
        student.name?.includes(searchTerm) ||
        student.major?.includes(searchTerm) ||
        student.class_name?.includes(searchTerm)
    );

    return (
        <div className="space-y-6">
            {/* 页面标题 */}
            <div>
                <h1 className="text-2xl text-gray-900 mb-1">学生信息维护</h1>
                <p className="text-gray-600">查询、编辑和删除学生信息</p>
            </div>

            {/* 操作栏 */}
            <Card className="border-0 shadow-sm">
                <CardContent className="p-6">
                    <div className="flex flex-col sm:flex-row gap-4">
                        <div className="flex-1 relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                            <Input
                                placeholder="搜索学号、姓名、专业或班级..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="pl-10"
                            />
                        </div>
                        <div className="flex gap-2">
                            <Button variant="outline" className="gap-2">
                                <Filter className="w-4 h-4" />筛选
                            </Button>
                            <Button variant="outline" className="gap-2">
                                <Download className="w-4 h-4" />导出
                            </Button>
                            <Button 
                                variant="outline" 
                                className="gap-2"
                                onClick={fetchStudents}
                                disabled={loading}
                            >
                                <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
                                刷新
                            </Button>
                            <Button 
                                className="gap-2 bg-blue-600 hover:bg-blue-700"
                                onClick={handleAdd}
                            >
                                <Plus className="w-4 h-4" />添加学生
                            </Button>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* 提示消息 */}
            {error && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
                    {error}
                </div>
            )}
            {successMessage && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-green-700">
                    {successMessage}
                </div>
            )}

            {/* 学生列表 */}
            <Card className="border-0 shadow-sm">
                <CardHeader>
                    <CardTitle>学生列表 ({filteredStudents.length})</CardTitle>
                </CardHeader>
                <CardContent>
                    {loading ? (
                        <div className="text-center py-12">
                            <RefreshCw className="w-8 h-8 text-gray-400 mx-auto mb-2 animate-spin" />
                            <p className="text-gray-500">加载中...</p>
                        </div>
                    ) : (
                        <>
                            <div className="overflow-x-auto">
                                <table className="w-full">
                                    <thead>
                                        <tr className="border-b border-gray-200">
                                            <th className="text-left py-3 px-4 text-sm text-gray-600">学号</th>
                                            <th className="text-left py-3 px-4 text-sm text-gray-600">姓名</th>
                                            <th className="text-left py-3 px-4 text-sm text-gray-600">专业</th>
                                            <th className="text-left py-3 px-4 text-sm text-gray-600">班级</th>
                                            <th className="text-left py-3 px-4 text-sm text-gray-600">课程编号</th>
                                            <th className="text-left py-3 px-4 text-sm text-gray-600">课序号</th>
                                            <th className="text-left py-3 px-4 text-sm text-gray-600">邮箱</th>
                                            <th className="text-left py-3 px-4 text-sm text-gray-600">手机</th>
                                            <th className="text-center py-3 px-4 text-sm text-gray-600">操作</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-200">
                                        {filteredStudents.map((student) => (
                                            <tr key={student.id} className="hover:bg-gray-50">
                                                <td className="py-3 px-4 text-sm text-gray-900">{student.student_no}</td>
                                                <td className="py-3 px-4 text-sm text-gray-900">{student.name}</td>
                                                <td className="py-3 px-4 text-sm text-gray-600">{student.major}</td>
                                                <td className="py-3 px-4 text-sm text-gray-600">{student.class_name}</td>
                                                <td className="py-3 px-4 text-sm text-gray-600">{student.course_code}</td>
                                                <td className="py-3 px-4 text-sm text-gray-600">{student.course_seq}</td>
                                                <td className="py-3 px-4 text-sm text-gray-600">{student.email}</td>
                                                <td className="py-3 px-4 text-sm text-gray-600">{student.phone}</td>
                                                <td className="py-3 px-4">
                                                    <div className="flex items-center justify-center gap-2">
                                                        <Button 
                                                            variant="ghost" 
                                                            size="sm" 
                                                            onClick={() => handleEdit(student)}
                                                        >
                                                            <Edit className="w-4 h-4" />
                                                        </Button>
                                                        <Button 
                                                            variant="ghost" 
                                                            size="sm" 
                                                            onClick={() => handleDelete(student.student_no)}
                                                        >
                                                            <Trash2 className="w-4 h-4 text-red-600" />
                                                        </Button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                            {filteredStudents.length === 0 && !loading && (
                                <div className="text-center py-12">
                                    <p className="text-gray-500">没有找到匹配的学生信息</p>
                                </div>
                            )}
                        </>
                    )}
                </CardContent>
            </Card>

            {/* 编辑/添加对话框 */}
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogContent className="max-w-2xl">
                    <DialogHeader>
                        <DialogTitle>{editingStudent?.id ? "编辑学生信息" : "添加学生"}</DialogTitle>
                    </DialogHeader>
                    {editingStudent && (
                        <div className="grid grid-cols-2 gap-4 py-4">
                            <div className="space-y-2">
                                <Label htmlFor="student_no">学号 *</Label>
                                <Input
                                    id="student_no"
                                    value={editingStudent.student_no}
                                    onChange={(e) => setEditingStudent({
                                        ...editingStudent,
                                        student_no: e.target.value,
                                    })}
                                    disabled={!!editingStudent.id} // 编辑时学号不可修改
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="name">姓名 *</Label>
                                <Input
                                    id="name"
                                    value={editingStudent.name}
                                    onChange={(e) => setEditingStudent({
                                        ...editingStudent,
                                        name: e.target.value,
                                    })}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="major">专业</Label>
                                <Input
                                    id="major"
                                    value={editingStudent.major}
                                    onChange={(e) => setEditingStudent({
                                        ...editingStudent,
                                        major: e.target.value,
                                    })}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="class_name">班级</Label>
                                <Input
                                    id="class_name"
                                    value={editingStudent.class_name}
                                    onChange={(e) => setEditingStudent({
                                        ...editingStudent,
                                        class_name: e.target.value,
                                    })}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="course_code">课程编号</Label>
                                <Input
                                    id="course_code"
                                    value={editingStudent.course_code}
                                    onChange={(e) => setEditingStudent({
                                        ...editingStudent,
                                        course_code: e.target.value,
                                    })}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="course_seq">课序号</Label>
                                <Input
                                    id="course_seq"
                                    value={editingStudent.course_seq}
                                    onChange={(e) => setEditingStudent({
                                        ...editingStudent,
                                        course_seq: e.target.value,
                                    })}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="email">邮箱</Label>
                                <Input
                                    id="email"
                                    type="email"
                                    value={editingStudent.email}
                                    onChange={(e) => setEditingStudent({
                                        ...editingStudent,
                                        email: e.target.value,
                                    })}
                                />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="phone">手机</Label>
                                <Input
                                    id="phone"
                                    value={editingStudent.phone}
                                    onChange={(e) => setEditingStudent({
                                        ...editingStudent,
                                        phone: e.target.value,
                                    })}
                                />
                            </div>
                        </div>
                    )}
                    {error && (
                        <div className="text-sm text-red-600 mb-4">{error}</div>
                    )}
                    <DialogFooter>
                        <Button 
                            variant="outline" 
                            onClick={() => {
                                setIsDialogOpen(false);
                                setEditingStudent(null);
                                setError(null);
                            }}
                        >
                            取消
                        </Button>
                        <Button 
                            onClick={handleSave} 
                            disabled={submitting}
                            className="bg-blue-600 hover:bg-blue-700"
                        >
                            {submitting ? "保存中..." : "保存"}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}