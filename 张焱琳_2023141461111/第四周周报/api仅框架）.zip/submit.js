// api/submit.js

// 1. Web端代码提交
export function submitCodeWeb(studentId, courseId, homeworkId, codeFile) {
  const formData = new FormData();
  formData.append('student_id', studentId);
  formData.append('course_id', courseId);
  formData.append('homework_id', homeworkId);
  formData.append('code_file', codeFile);
  return request('/submit/web', { method: 'POST', body: formData });
}

// 2. 邮件端代码提交
export function submitCodeMail(mailTopic, codeAttachment, senderEmail) {
  return request('/submit/mail', { method: 'POST', body: JSON.stringify({ mail_topic: mailTopic, code_attachment: codeAttachment, sender_email: senderEmail }) });
}

// 3. 测评状态查询
export function getSubmissionStatus(studentId, submissionId, homeworkId) {
  const query = new URLSearchParams({ student_id: studentId, submission_id: submissionId, ...(homeworkId && { homework_id: homeworkId }) });
  return request(`/submit/status?${query}`);
}