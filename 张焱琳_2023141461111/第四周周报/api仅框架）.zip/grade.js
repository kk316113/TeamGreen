// api/grade.js

// 1. 班级成绩分布
export function getClassDistribution(courseId, classSeq, homeworkId) {
  const query = new URLSearchParams({ course_id: courseId, class_seq: classSeq, ...(homeworkId && { homework_id: homeworkId }) });
  return request(`/grade/class-distribution?${query}`);
}

// 2. 课程成绩列表
export function getCourseGradeList(courseId, page = 1, pageSize = 20) {
  const query = new URLSearchParams({ course_id: courseId, page, page_size: pageSize });
  return request(`/grade/course-list?${query}`);
}

// 3. 个人成绩列表
export function getStudentGradeList(studentId, page = 1, pageSize = 20) {
  const query = new URLSearchParams({ student_id: studentId, page, page_size: pageSize });
  return request(`/grade/student-list?${query}`);
}

// 4. 单次作业详情
export function getHomeworkDetail(studentId, homeworkId, submissionId) {
  const query = new URLSearchParams({ student_id: studentId, ...(homeworkId && { homework_id: homeworkId }), ...(submissionId && { submission_id: submissionId }) });
  return request(`/grade/homework-detail?${query}`);
}