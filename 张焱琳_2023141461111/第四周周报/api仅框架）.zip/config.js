// api/config.js
const BASE_URL = '/api/b1';

// 统一请求函数
async function request(url, options = {}) {
  const token = localStorage.getItem('token');
  const headers = {
    'Content-Type': 'application/json',
    ...(token && { 'Authorization': `Bearer ${token}` }),
    ...options.headers,
  };
  
  // 框架预留：请求拦截、错误处理等
  const response = await fetch(`${BASE_URL}${url}`, { ...options, headers });
  return response.json();
}