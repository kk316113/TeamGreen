// api/student.js

// 1. 批量导入学生
export function importStudents(courseId, file) {
  const formData = new FormData();
  formData.append('course_id', courseId);
  formData.append('file', file);
  return request('/student/import', { method: 'POST', body: formData });
}

// 2. 查询学生信息
export function getStudentList(params) {
  const { studentId, name, courseId, classSeq, page = 1, pageSize = 20 } = params;
  const query = new URLSearchParams({ page, page_size: pageSize, ...(studentId && { student_id: studentId }), ...(name && { name }), ...(courseId && { course_id: courseId }), ...(classSeq && { class_seq: classSeq }) });
  return request(`/student/list?${query}`);
}

// 3. 编辑学生信息
export function updateStudent(studentId, updateData) {
  return request('/student/update', { method: 'PUT', body: JSON.stringify({ student_id: studentId, update_data: updateData }) });
}

// 4. 删除学生信息
export function deleteStudent(studentId) {
  return request('/student/delete', { method: 'DELETE', body: JSON.stringify({ student_id: studentId }) });
}

// 5. 分班查看
export function getClassView(courseId, classSeq) {
  const query = new URLSearchParams({ course_id: courseId, ...(classSeq && { class_seq: classSeq }) });
  return request(`/class/view?${query}`);
}

// 6. 调整学生班级
export function adjustStudentClass(studentId, courseId, classSeq) {
  return request('/class/adjust', { method: 'PUT', body: JSON.stringify({ student_id: studentId, course_id: courseId, class_seq: classSeq }) });
}