// api/auth.js

// 1. 用户登录
export function login(username, password) {
  return request('/auth/login', { method: 'POST', body: JSON.stringify({ username, password }) });
}

// 2. 会话验证
export function verifyToken() {
  return request('/auth/verify');
}

// 3. 权限校验
export function checkPermission(userRole, resource, operation) {
  return request('/auth/check-permission', { method: 'POST', body: JSON.stringify({ user_role: userRole, resource, operation }) });
}