// src/mock/studentSubmit.js
import { assignments } from './data/assignmentsData';
import { problems } from './data/problemsData';

const mockResponse = (data, code = 0, message = 'success') => ({
  code,
  message,
  data,
});

const BASE_PATH = '/api/v1/student';

// 获取学生课程列表 GET /api/v1/student/courses
export function mockGetStudentCourseList() {
  return Promise.resolve(mockResponse([
    {
      courseId: 'course_001',
      courseName: 'Python程序设计',
      courseCode: 'CS101',
      className: '计科2101',
      teacherName: '张老师',
      semester: '2025-2026-2',
    },
    {
      courseId: 'course_002',
      courseName: 'Bash Shell编程',
      courseCode: 'CS201',
      className: '计科2102',
      teacherName: '李老师',
      semester: '2025-2026-2',
    },
  ]));
}

// 获取课程任务列表 GET /api/v1/student/courses/{courseId}/assignments
export function mockGetStudentAssignmentList(config) {
  const courseId = config.url?.match(/\/courses\/([^/]+)\/assignments/)?.[1];
  const courseAssignments = assignments.filter(a => a.course_id === courseId);

  return Promise.resolve(mockResponse(
    courseAssignments.map(a => ({
      assignmentId: a.id,
      assignmentName: a.name,
      courseId: a.course_id,
      courseName: a.course_name,
      startTime: a.start_time,
      deadline: a.deadline,
      status: a.status,
      submitStatus: ['submitted', 'unsubmitted', 'submitted', 'unsubmitted'][Math.floor(Math.random() * 4)],
      score: Math.random() > 0.3 ? Math.floor(Math.random() * 40) + 60 : null,
      totalScore: a.total_score,
    }))
  ));
}

// 获取任务详情 GET /api/v1/student/assignments/{assignmentId}
export function mockGetStudentAssignmentDetail(config) {
  const assignmentId = config.url?.match(/\/assignments\/([^/]+)(?:\/|$)/)?.[1];
  const assignment = assignments.find(a => a.id === assignmentId);

  if (!assignment) {
    return Promise.resolve(mockResponse(null, 404, '任务不存在'));
  }

  const assignmentProblems = problems.filter(p => assignment.problem_ids.includes(p.id));

  return Promise.resolve(mockResponse({
    assignmentId: assignment.id,
    assignmentName: assignment.name,
    courseId: assignment.course_id,
    courseName: assignment.course_name,
    description: assignment.description,
    startTime: assignment.start_time,
    deadline: assignment.deadline,
    status: assignment.status,
    submitStatus: 'unsubmitted',
    allowedLanguages: assignment.allowed_languages,
    maxFileSize: assignment.max_file_size,
    totalScore: assignment.total_score,
    problems: assignmentProblems.map(p => ({
      problemId: p.id,
      title: p.title,
      description: p.description,
      inputDescription: p.input_description,
      outputDescription: p.output_description,
      sampleInput: p.sample_input,
      sampleOutput: p.sample_output,
      score: p.score,
    })),
  }));
}

// 获取邮件提交配置 GET /api/v1/student/assignments/{assignmentId}/email-config
export function mockGetSubmissionEmailConfig(config) {
  const assignmentId = config.url?.match(/\/assignments\/([^/]+)\/email-config/)?.[1];

  return Promise.resolve(mockResponse({
    assignmentId,
    enableEmailSubmit: true,
    emailAddress: 'submit@autograder.com',
    subjectFormat: '学号-姓名-任务ID',
    attachmentFormat: ['.py', '.java', '.cpp', '.zip'],
    maxAttachmentSize: 10,
    description: '请将代码文件作为附件发送，邮件主题格式为：学号-姓名-任务ID',
  }));
}

// 运行代码 POST /api/v1/student/submissions/run
export function mockRunCode(config) {
  const body = JSON.parse(config.body || '{}');

  return Promise.resolve(mockResponse({
    status: 'success',
    output: 'Hello World\n3.14159\n程序执行成功',
    error: '',
    executionTime: `${(Math.random() * 0.1).toFixed(3)}s`,
    memory: `${(Math.random() * 5 + 1).toFixed(1)}MB`,
  }));
}

// 提交代码 POST /api/v1/student/submissions
export function mockStudentSubmitCode(config) {
  const body = JSON.parse(config.body || '{}');
  const submissionId = `submission_${Date.now()}`;

  return Promise.resolve(mockResponse({
    submissionId,
    assignmentId: body.assignmentId,
    problemId: body.problemId,
    status: 'pending',
    submittedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
  }, 0, 'submit success'));
}

// 获取提交状态 GET /api/v1/student/submissions/{submissionId}/status
export function mockStudentGetSubmissionStatus(config) {
  const submissionId = config.url?.match(/\/submissions\/([^/]+)\/status/)?.[1];
  const statuses = ['judging', 'finished'];
  const status = statuses[Math.floor(Math.random() * statuses.length)];

  return Promise.resolve(mockResponse({
    submissionId,
    status,
    progress: status === 'finished' ? 100 : Math.floor(Math.random() * 60) + 40,
    message: status === 'judging' ? '正在运行测试点 2/5' : '评测完成',
  }));
}

// 获取提交详情 GET /api/v1/student/submissions/{submissionId}
export function mockStudentGetSubmissionDetail(config) {
  const submissionId = config.url?.match(/\/submissions\/([^/]+)$/)?.[1];

  return Promise.resolve(mockResponse({
    submissionId,
    assignmentId: 'assignment_001',
    assignmentName: '实验一：Python基础语法',
    problemId: 1,
    problemTitle: '计算两个数之和',
    language: 'python',
    code: `a, b = map(int, input().split())\nprint(a + b)`,
    status: 'accepted',
    score: 100,
    totalScore: 100,
    submitTime: '2026-04-14 13:48:31',
    executionTime: '0.023s',
    memory: '2.4MB',
    compileError: '',
    runtimeError: '',
    testCases: [
      {
        id: 1,
        name: '测试点1',
        status: 'passed',
        score: 50,
        totalScore: 50,
        input: '3 5',
        expectedOutput: '8',
        actualOutput: '8',
        time: '0.012s',
        memory: '2.1MB',
        error: '',
      },
      {
        id: 2,
        name: '测试点2',
        status: 'passed',
        score: 50,
        totalScore: 50,
        input: '10 20',
        expectedOutput: '30',
        actualOutput: '30',
        time: '0.011s',
        memory: '2.3MB',
        error: '',
      },
    ],
  }));
}

// 保存草稿 POST /api/v1/student/assignments/{assignmentId}/draft
export function mockSaveDraft(config) {
  const assignmentId = config.url?.match(/\/assignments\/([^/]+)\/draft/)?.[1];
  const body = JSON.parse(config.body || '{}');

  return Promise.resolve(mockResponse({
    draftId: `draft_${Date.now()}`,
    assignmentId,
    language: body.language,
    savedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
  }, 0, 'draft saved'));
}

// 获取草稿 GET /api/v1/student/assignments/{assignmentId}/draft
export function mockGetDraft(config) {
  const assignmentId = config.url?.match(/\/assignments\/([^/]+)\/draft/)?.[1];

  return Promise.resolve(mockResponse({
    draftId: 'draft_20001',
    assignmentId,
    language: 'python',
    code: '# 你的代码草稿\nprint("Hello")',
    savedAt: '2026-04-14 14:25:00',
  }));
}