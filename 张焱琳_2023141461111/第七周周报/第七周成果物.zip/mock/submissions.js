// src/mock/submissions.js
import { submissions } from './data/submissionsData';

const mockResponse = (data, code = 0, message = 'success') => ({
  code,
  message,
  data,
});

// 9. 学生提交代码 POST /api/v1/submissions
export function mockSubmitCode(config) {
  const body = JSON.parse(config.body || '{}');
  const submissionId = `submission_${Date.now()}`;
  
  return Promise.resolve(mockResponse({
    submissionId,
    ...body,
    status: 'pending',
    submittedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
  }, 0, 'submit success'));
}

// 10. 查询提交状态 GET /api/v1/submissions/{id}/status
export function mockGetSubmissionStatus(config) {
  const submissionId = config.url?.match(/\/submissions\/([^/]+)\/status/)?.[1];
  
  const statuses = ['pending', 'judging', 'finished'];
  const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
  
  return Promise.resolve(mockResponse({
    submissionId,
    status: randomStatus,
    progress: randomStatus === 'finished' ? 100 : Math.floor(Math.random() * 80) + 20,
    message: randomStatus === 'judging' ? '正在运行测试点 3/5' : '',
  }));
}