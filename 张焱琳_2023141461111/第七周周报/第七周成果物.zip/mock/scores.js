// src/mock/scores.js
const mockResponse = (data, code = 0, message = 'success') => ({
  code,
  message,
  data,
});

// 13. 查询个人成绩 GET /api/v1/scores/me
export function mockGetPersonalScores(config) {
  return Promise.resolve(mockResponse({
    studentId: 1,
    studentNo: '20210001',
    studentName: '张三',
    totalScore: 260,
    gpa: 3.5,
    courses: [
      {
        courseId: 'course_001',
        courseName: 'Python程序设计',
        courseCode: 'CS101',
        score: 260,
        totalScore: 300,
        grade: 'B+',
      },
      {
        courseId: 'course_002',
        courseName: 'Bash Shell编程',
        courseCode: 'CS201',
        score: 180,
        totalScore: 200,
        grade: 'A-',
      },
    ],
  }));
}