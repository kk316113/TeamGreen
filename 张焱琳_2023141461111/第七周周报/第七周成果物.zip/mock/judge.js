// src/mock/judge.js
import { pendingTasks } from './data/submissionsData';

const mockResponse = (data, code = 0, message = 'success') => ({
  code,
  message,
  data,
});

// 11. 获取待评测任务 GET /api/v1/judge/tasks/pending
export function mockGetPendingTasks(config) {
  const tasks = [...pendingTasks];
  return Promise.resolve(mockResponse({
    total: tasks.length,
    tasks,
  }));
}

// 12. 回传评测结果 POST /api/v1/judge/results
export function mockSubmitJudgeResult(config) {
  const body = JSON.parse(config.body || '{}');
  return Promise.resolve(mockResponse({
    submissionId: body.submissionId,
    status: 'accepted',
    score: body.score || 100,
  }, 0, '评测结果已接收'));
}