// src/mock/problems.js
import { problems } from './data/problemsData';

const mockResponse = (data, code = 0, message = 'success') => ({
  code,
  message,
  data,
});

// 6. 创建题目 POST /api/v1/problems
export function mockCreateProblem(config) {
  const body = JSON.parse(config.body || '{}');
  const newProblem = {
    id: problems.length + 1,
    ...body,
    created_at: new Date().toISOString(),
  };
  problems.push(newProblem);
  return Promise.resolve(mockResponse(newProblem, 0, '创建成功'));
}

// 7. 查询题目列表 GET /api/v1/problems
export function mockGetProblemList(config) {
  const params = new URLSearchParams(config.url?.split('?')[1] || '');
  const keyword = params.get('keyword') || '';
  const difficulty = params.get('difficulty') || '';

  let filteredProblems = [...problems];

  if (keyword) {
    filteredProblems = filteredProblems.filter(p => p.title.includes(keyword));
  }
  if (difficulty) {
    filteredProblems = filteredProblems.filter(p => p.difficulty === difficulty);
  }

  return Promise.resolve(mockResponse({
    total: filteredProblems.length,
    problems: filteredProblems,
  }));
}