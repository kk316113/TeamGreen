// src/mock/reports.js
const mockResponse = (data, code = 0, message = 'success') => ({
  code,
  message,
  data,
});

// 14. 成绩统计报表 GET /api/v1/reports/score-summary
export function mockGetScoreSummary(config) {
  const params = new URLSearchParams(config.url?.split('?')[1] || '');
  const courseId = params.get('courseId') || 'course_001';

  return Promise.resolve(mockResponse({
    courseId,
    courseName: 'Python程序设计',
    courseCode: 'CS101',
    totalStudents: 45,
    averageScore: 78.5,
    highestScore: 98,
    lowestScore: 35,
    passRate: 0.86,
    excellentRate: 0.32,
    scoreDistribution: [
      { range: '90-100', count: 8 },
      { range: '80-89', count: 15 },
      { range: '70-79', count: 12 },
      { range: '60-69', count: 5 },
      { range: '0-59', count: 5 },
    ],
    assignmentStats: [
      {
        assignmentId: 'assignment_001',
        assignmentName: '实验一',
        averageScore: 85.2,
        passRate: 0.90,
      },
      {
        assignmentId: 'assignment_002',
        assignmentName: '实验二',
        averageScore: 80.1,
        passRate: 0.85,
      },
    ],
  }));
}