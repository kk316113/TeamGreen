// src/mock/grades.js
import { gradeOverview, studentGrades } from './data/gradesData';

const mockResponse = (data, code = 0, message = 'success') => ({
  code,
  message,
  data,
});

// 获取教师端成绩总览 GET /api/v1/teacher/grades/overview
export function mockGetGradeOverview(config) {
  const params = new URLSearchParams(config.url?.split('?')[1] || '');
  const keyword = params.get('keyword') || '';
  const courseId = params.get('courseId') || '';

  let result = { ...gradeOverview };

  if (courseId) {
    result.courses = result.courses.filter(c => c.courseId === courseId);
  }

  if (keyword) {
    result.courses = result.courses.filter(
      c => c.courseName.includes(keyword) || c.courseCode.includes(keyword) || c.className.includes(keyword)
    );
  }

  return Promise.resolve(mockResponse(result));
}

// 获取某门课程的成绩详情 GET /api/v1/teacher/grades/courses/{courseId}
export function mockGetCourseGradeDetail(config) {
  const courseId = config.url?.match(/\/grades\/courses\/([^/]+)(?:\/|$)/)?.[1];
  const course = gradeOverview.courses.find(c => c.courseId === courseId);

  if (!course) {
    return Promise.resolve(mockResponse(null, 404, '课程不存在'));
  }

  const courseStudents = Object.values(studentGrades[courseId] || {});

  return Promise.resolve(mockResponse({
    ...course,
    students: courseStudents,
  }));
}

// 获取课程作业成绩统计 GET /api/v1/teacher/grades/courses/{courseId}/assignments
export function mockGetCourseAssignmentGrades(config) {
  const courseId = config.url?.match(/\/grades\/courses\/([^/]+)\/assignments/)?.[1];
  const course = gradeOverview.courses.find(c => c.courseId === courseId);

  if (!course) {
    return Promise.resolve(mockResponse(null, 404, '课程不存在'));
  }

  return Promise.resolve(mockResponse({
    courseId: course.courseId,
    courseName: course.courseName,
    assignments: course.assignments,
  }));
}

// 获取某次作业的学生成绩明细 GET /api/v1/teacher/grades/assignments/{assignmentId}
export function mockGetAssignmentGradeDetail(config) {
  const assignmentId = config.url?.match(/\/grades\/assignments\/([^/]+)/)?.[1];

  return Promise.resolve(mockResponse({
    assignmentId,
    assignmentName: '实验一：Python基础语法',
    courseId: 'course_001',
    courseName: 'Python程序设计',
    totalStudents: 45,
    submittedCount: 40,
    unsubmittedCount: 5,
    averageScore: 85.2,
    highestScore: 100,
    lowestScore: 50,
    passRate: 0.90,
    students: [
      {
        studentId: 1,
        studentNo: '20210001',
        studentName: '张三',
        submitStatus: 'submitted',
        judgeStatus: 'finished',
        score: 90,
        submitTime: '2026-04-10 15:30:00',
        rank: 3,
      },
      {
        studentId: 2,
        studentNo: '20210002',
        studentName: '李四',
        submitStatus: 'submitted',
        judgeStatus: 'finished',
        score: 80,
        submitTime: '2026-04-10 16:00:00',
        rank: 8,
      },
      {
        studentId: 3,
        studentNo: '20210003',
        studentName: '王五',
        submitStatus: 'unsubmitted',
        judgeStatus: 'pending',
        score: null,
        submitTime: null,
        rank: null,
      },
    ],
  }));
}

// 获取学生课程成绩详情 GET /api/v1/teacher/grades/courses/{courseId}/students/{studentId}
export function mockGetStudentCourseGradeDetail(config) {
  const match = config.url?.match(/\/grades\/courses\/([^/]+)\/students\/([^/]+)/);
  const courseId = match?.[1];
  const studentId = match?.[2];

  const studentGrade = studentGrades[courseId]?.[`student_${studentId}`] || {
    studentId: parseInt(studentId),
    studentNo: `2021000${studentId}`,
    studentName: '未知学生',
    totalScore: 0,
    averageScore: 0,
    rank: 0,
    submittedCount: 0,
    missingCount: 0,
    assignments: [],
  };

  return Promise.resolve(mockResponse(studentGrade));
}