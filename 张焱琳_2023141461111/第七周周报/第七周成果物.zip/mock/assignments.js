// src/mock/assignments.js
import { assignments } from './data/assignmentsData';
import { problems } from './data/problemsData';

const mockResponse = (data, code = 0, message = 'success') => ({
  code,
  message,
  data,
});

// 8. 创建作业 POST /api/v1/assignments
export function mockCreateAssignment(config) {
  const body = JSON.parse(config.body || '{}');
  const newAssignment = {
    id: `assignment_${String(assignments.length + 1).padStart(3, '0')}`,
    ...body,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };
  assignments.push(newAssignment);
  return Promise.resolve(mockResponse(newAssignment, 0, '创建成功'));
}