// src/mock/knowledge.js
import { knowledgeTags, studentKnowledgeProfiles } from './data/knowledgeData';

const mockResponse = (data, code = 0, message = 'success') => ({
  code,
  message,
  data,
});

// 15. 查询题目知识点标签 GET /api/v1/knowledge/tags/{problem_id}
export function mockGetKnowledgeTags(config) {
  const problemId = config.url?.match(/\/knowledge\/tags\/(\d+)/)?.[1];
  const data = knowledgeTags[problemId] || { problem_id: parseInt(problemId), tags: [], description: '暂无标签' };
  return Promise.resolve(mockResponse(data));
}

// 16. 查询学生知识薄弱项 GET /api/v1/knowledge/profile/{student_id}
export function mockGetStudentKnowledgeProfile(config) {
  const studentId = config.url?.match(/\/knowledge\/profile\/(\d+)/)?.[1];
  const key = `student_${studentId}`;
  const data = studentKnowledgeProfiles[key] || {
    student_id: parseInt(studentId),
    student_no: `2021000${studentId}`,
    name: '未知学生',
    weak_points: [],
    strong_points: [],
    overall_level: 0.5,
  };
  return Promise.resolve(mockResponse(data));
}