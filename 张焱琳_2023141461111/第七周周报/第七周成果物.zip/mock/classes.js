// src/mock/classes.js
import { classes } from './data/classesData';
import { students } from './data/studentsData';

const mockResponse = (data, code = 0, message = 'success') => ({
  code,
  message,
  data,
});

const BASE_PATH = '/api/v1/teacher/classes';

// 获取班级列表 GET /api/v1/teacher/classes
export function mockGetClassList(config) {
  const params = new URLSearchParams(config.url?.split('?')[1] || '');
  const search = params.get('search') || '';

  let filtered = [...classes];
  if (search) {
    filtered = filtered.filter(
      c => c.class_name.includes(search) || c.course_name.includes(search)
    );
  }

  return Promise.resolve(mockResponse(filtered));
}

// 获取课程分组班级列表 GET /api/v1/teacher/classes/grouped
export function mockGetGroupedClasses(config) {
  const grouped = {};
  classes.forEach(c => {
    if (!grouped[c.course_code]) {
      grouped[c.course_code] = {
        course_name: c.course_name,
        classes: [],
      };
    }
    grouped[c.course_code].classes.push({
      id: c.id,
      class_name: c.class_name,
      student_count: c.student_count,
    });
  });
  return Promise.resolve(mockResponse(grouped));
}

// 获取课程班级 GET /api/v1/teacher/classes/course
export function mockGetCourseClasses(config) {
  const params = new URLSearchParams(config.url?.split('?')[1] || '');
  const courseCode = params.get('courseCode') || '';
  return Promise.resolve(mockResponse(classes.filter(c => c.course_code === courseCode)));
}

// 获取班级学生列表 GET /api/v1/teacher/classes/{classId}/students
export function mockGetClassStudents(config) {
  const classId = config.url?.match(/\/classes\/(\d+)\/students/)?.[1];
  const targetClass = classes.find(c => c.id === parseInt(classId));
  const classStudents = students.filter(s => s.class_name === targetClass?.class_name);
  
  return Promise.resolve(mockResponse({
    total: classStudents.length,
    page: 1,
    pageSize: 20,
    students: classStudents,
  }));
}

// 获取课程学生列表 GET /api/v1/teacher/classes/students
export function mockGetCourseStudents(config) {
  const params = new URLSearchParams(config.url?.split('?')[1] || '');
  const courseCode = params.get('courseCode') || '';
  const courseStudents = students.filter(s => s.course_code === courseCode);
  return Promise.resolve(mockResponse(courseStudents));
}

// 调整学生班级 POST /api/v1/teacher/classes/adjust
export function mockAdjustStudentClass(config) {
  const body = JSON.parse(config.body || '{}');
  return Promise.resolve(mockResponse({
    success_count: body.studentIds?.length || 0,
    failed_count: 0,
    failed_students: [],
  }, 0, '调整成功'));
}

// 批量调整学生班级 POST /api/v1/teacher/classes/batch-adjust
export function mockBatchAdjustStudentClass(config) {
  const body = JSON.parse(config.body || '{}');
  return Promise.resolve(mockResponse({
    total_adjustments: body.adjustments?.length || 0,
    success_count: body.adjustments?.length || 0,
    failed_count: 0,
    failed_adjustments: [],
  }, 0, '批量调整成功'));
}

// 获取班级统计信息 GET /api/v1/teacher/classes/statistics
export function mockGetClassStatistics() {
  return Promise.resolve(mockResponse({
    total_classes: classes.length,
    total_students: students.length,
    average_students_per_class: Math.round(students.length / classes.length),
    class_distribution: {
      '计算机科学与技术': classes.filter(c => c.major === '计算机科学与技术').length,
      '软件工程': classes.filter(c => c.major === '软件工程').length,
      '网络工程': classes.filter(c => c.major === '网络工程').length,
      '信息安全': classes.filter(c => c.major === '信息安全').length,
    },
  }));
}

// 获取课程统计信息 GET /api/v1/teacher/classes/course-statistics
export function mockGetCourseStatistics() {
  const courseStats = {};
  classes.forEach(c => {
    if (!courseStats[c.course_code]) {
      courseStats[c.course_code] = {
        course_code: c.course_code,
        course_name: c.course_name,
        class_count: 0,
        student_count: 0,
      };
    }
    courseStats[c.course_code].class_count += 1;
    courseStats[c.course_code].student_count += c.student_count;
  });

  return Promise.resolve(mockResponse({
    total_courses: Object.keys(courseStats).length,
    total_classes: classes.length,
    courses: Object.values(courseStats),
  }));
}

// 创建新班级 POST /api/v1/teacher/classes
export function mockCreateClass(config) {
  const body = JSON.parse(config.body || '{}');
  const newClass = {
    id: classes.length + 1,
    ...body,
    student_count: 0,
    created_at: new Date().toISOString(),
  };
  classes.push(newClass);
  return Promise.resolve(mockResponse(newClass, 0, '创建成功'));
}

// 更新班级信息 PUT /api/v1/teacher/classes/{classId}
export function mockUpdateClass(config) {
  const classId = config.url?.match(/\/classes\/(\d+)/)?.[1];
  const body = JSON.parse(config.body || '{}');
  const target = classes.find(c => c.id === parseInt(classId));
  if (target) {
    Object.assign(target, body, { updated_at: new Date().toISOString() });
  }
  return Promise.resolve(mockResponse(target, 0, '更新成功'));
}

// 删除班级 DELETE /api/v1/teacher/classes/{classId}
export function mockDeleteClass(config) {
  const classId = config.url?.match(/\/classes\/(\d+)/)?.[1];
  const index = classes.findIndex(c => c.id === parseInt(classId));
  if (index > -1) {
    classes.splice(index, 1);
  }
  return Promise.resolve(mockResponse(null, 0, '删除成功'));
}

// 导出班级数据 GET /api/v1/teacher/classes/export
export function mockExportClasses(config) {
  return Promise.resolve(mockResponse({
    download_url: '/mock/download/classes_export.xlsx',
  }));
}

// 学生管理相关 - 复用 students mock

// 添加学生 POST /api/v1/teacher/students
export function mockAddStudent(config) {
  const body = JSON.parse(config.body || '{}');
  const newStudent = {
    id: students.length + 1,
    ...body,
  };
  students.push(newStudent);
  return Promise.resolve(mockResponse(newStudent, 0, '添加成功'));
}

// 更新学生信息 PUT /api/v1/teacher/students/{id}
export function mockUpdateStudent(config) {
  const studentId = config.url?.match(/\/students\/(\d+)/)?.[1];
  const body = JSON.parse(config.body || '{}');
  const target = students.find(s => s.id === parseInt(studentId));
  if (target) {
    Object.assign(target, body);
  }
  return Promise.resolve(mockResponse(target, 0, '更新成功'));
}

// 删除学生 DELETE /api/v1/teacher/students/{studentNo}
export function mockDeleteStudent(config) {
  const studentNo = config.url?.match(/\/students\/([^/]+)/)?.[1];
  const index = students.findIndex(s => s.student_no === studentNo);
  if (index > -1) {
    students.splice(index, 1);
  }
  return Promise.resolve(mockResponse(null, 0, '删除成功'));
}

// 学生文件解析 Mock
export function mockParseFile() {
  return Promise.resolve(mockResponse(
    students.slice(0, 5).map(s => ({
      student_no: s.student_no,
      name: s.name,
      email: s.email,
      courseCode: s.course_code,
      courseSeq: s.course_seq,
      className: s.class_name,
    })),
    0,
    '解析成功，共 5 条记录'
  ));
}

// 导入学生 POST /api/v1/teacher/students/import
export function mockImportStudentsTeacher(config) {
  const body = JSON.parse(config.body || '{}');
  return Promise.resolve(mockResponse({
    success_count: body.students?.length || 0,
    failed_count: 0,
  }, 0, '导入成功'));
}

// 获取导入历史 GET /api/v1/teacher/students/import/history
export function mockGetImportHistory(config) {
  return Promise.resolve(mockResponse({
    total: 2,
    page: 1,
    page_size: 10,
    records: [
      {
        id: 1,
        class_id: 1,
        class_name: '计科2101',
        import_time: '2024-01-15 10:30:00',
        total_count: 50,
        success_count: 48,
        failed_count: 2,
      },
      {
        id: 2,
        class_id: 2,
        class_name: '计科2102',
        import_time: '2024-01-16 14:20:00',
        total_count: 45,
        success_count: 45,
        failed_count: 0,
      },
    ],
  }));
}

// 获取导入记录详情 GET /api/v1/teacher/students/import/history/{recordId}
export function mockGetImportRecordDetail(config) {
  const recordId = config.url?.match(/\/history\/(\d+)/)?.[1];
  return Promise.resolve(mockResponse({
    id: parseInt(recordId),
    class_id: 1,
    class_name: '计科2101',
    import_time: '2024-01-15 10:30:00',
    total_count: 50,
    success_count: 48,
    failed_count: 2,
    failed_records: [
      { row: 5, student_no: '2024005', error_message: '学号重复' },
      { row: 12, student_no: '', error_message: '学号不能为空' },
    ],
  }));
}

// 删除导入记录 DELETE /api/v1/teacher/students/import/history/{recordId}
export function mockDeleteImportRecord(config) {
  return Promise.resolve(mockResponse(null, 0, '删除成功'));
}

// 重新导入 POST /api/v1/teacher/students/import/history/{recordId}/reimport
export function mockReimportStudents(config) {
  return Promise.resolve(mockResponse({
    success_count: 50,
    failed_count: 0,
  }, 0, '重新导入成功'));
}

// 导出失败记录 GET /api/v1/teacher/students/import/history/{recordId}/export-failed
export function mockExportFailedRecords(config) {
  return Promise.resolve(mockResponse({
    download_url: '/mock/download/failed_records.xlsx',
  }));
}