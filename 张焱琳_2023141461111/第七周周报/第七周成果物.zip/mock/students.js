// src/mock/students.js
import { students, importHistory } from './data/studentsData';
import { classes } from './data/classesData';

const mockResponse = (data, code = 0, message = 'success') => ({
  code,
  message,
  data,
});

// 4. 批量导入学生名单 POST /api/v1/students/import
export function mockImportStudents(config) {
  const { class_id, students: importStudents } = JSON.parse(config.body || '{}');
  
  return Promise.resolve(mockResponse({
    success_count: importStudents.length,
    failed_count: 0,
    import_id: Date.now(),
  }));
}

// 5. 查询学生列表 GET /api/v1/students
export function mockGetStudentList(config) {
  const params = new URLSearchParams(config.url?.split('?')[1] || '');
  const search = params.get('search') || '';
  const name = params.get('name') || '';
  const courseCode = params.get('courseCode') || '';
  const className = params.get('className') || '';

  let filteredStudents = [...students];

  if (search) {
    filteredStudents = filteredStudents.filter(
      s => s.name.includes(search) || s.student_no.includes(search)
    );
  }
  if (name) {
    filteredStudents = filteredStudents.filter(s => s.name.includes(name));
  }
  if (courseCode) {
    filteredStudents = filteredStudents.filter(s => s.course_code === courseCode);
  }
  if (className) {
    filteredStudents = filteredStudents.filter(s => s.class_name === className);
  }

  return Promise.resolve(mockResponse(filteredStudents));
}