// src/mock/index.js
// Mock 入口文件，整合所有 mock 模块

import './auth';
import './students';
import './problems';
import '../assignments';
import '../submissions';
import './judge';
import './scores';
import './reports';
import './knowledge';
import './classes';
import './grades';
import './studentSubmit';

console.log('[Mock] 所有 Mock 接口已注册');