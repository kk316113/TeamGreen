// src/mock/data/studentsData.js

export const students = [
  {
    id: 1,
    student_no: '20210001',
    name: '张三',
    major: '计算机科学与技术',
    class_name: '计科2101',
    course_code: 'CS101',
    course_seq: '01',
    email: 'zhangsan@example.com',
    phone: '13800138001',
  },
  {
    id: 2,
    student_no: '20210002',
    name: '李四',
    major: '软件工程',
    class_name: '软工2101',
    course_code: 'SE201',
    course_seq: '01',
    email: 'lisi@example.com',
    phone: '13800138002',
  },
  {
    id: 3,
    student_no: '20210003',
    name: '王五',
    major: '计算机科学与技术',
    class_name: '计科2101',
    course_code: 'CS101',
    course_seq: '01',
    email: 'wangwu@example.com',
    phone: '13800138003',
  },
  {
    id: 4,
    student_no: '20210004',
    name: '赵六',
    major: '计算机科学与技术',
    class_name: '计科2102',
    course_code: 'CS101',
    course_seq: '02',
    email: 'zhaoliu@example.com',
    phone: '13800138004',
  },
  {
    id: 5,
    student_no: '20210005',
    name: '孙七',
    major: '网络工程',
    class_name: '网络2101',
    course_code: 'CS201',
    course_seq: '01',
    email: 'sunqi@example.com',
    phone: '13800138005',
  },
  {
    id: 6,
    student_no: '20210006',
    name: '周八',
    major: '计算机科学与技术',
    class_name: '计科2102',
    course_code: 'CS101',
    course_seq: '02',
    email: 'zhouba@example.com',
    phone: '13800138006',
  },
];

// 生成更多学生数据
for (let i = 7; i <= 100; i++) {
  students.push({
    id: i,
    student_no: `2021${String(i).padStart(4, '0')}`,
    name: `学生${i}`,
    major: ['计算机科学与技术', '软件工程', '网络工程', '信息安全'][i % 4],
    class_name: `计科210${(i % 3) + 1}`,
    course_code: i % 2 === 0 ? 'CS101' : 'SE201',
    course_seq: `0${(i % 3) + 1}`,
    email: `student${i}@example.com`,
    phone: `138${String(i).padStart(8, '0')}`,
  });
}

export const importHistory = [
  {
    id: 1,
    class_id: 1,
    class_name: '计科2101',
    import_time: '2024-01-15 10:30:00',
    total_count: 50,
    success_count: 48,
    failed_count: 2,
    failed_records: [
      { row: 5, student_no: '2024005', error_message: '学号重复' },
      { row: 12, student_no: '', error_message: '学号不能为空' },
    ],
  },
  {
    id: 2,
    class_id: 2,
    class_name: '计科2102',
    import_time: '2024-01-16 14:20:00',
    total_count: 45,
    success_count: 45,
    failed_count: 0,
    failed_records: [],
  },
];