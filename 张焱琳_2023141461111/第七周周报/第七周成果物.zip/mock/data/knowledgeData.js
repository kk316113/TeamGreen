// src/mock/data/knowledgeData.js

export const knowledgeTags = {
  1: {
    problem_id: 1,
    tags: ['变量', '输入输出', '基本运算'],
    description: 'Python基础语法知识',
  },
  2: {
    problem_id: 2,
    tags: ['条件判断', '取模运算'],
    description: '条件判断与数学运算',
  },
  3: {
    problem_id: 3,
    tags: ['循环', '递归', '数学运算'],
    description: '循环结构与递归算法',
  },
  4: {
    problem_id: 4,
    tags: ['字符串', '数组操作'],
    description: '字符串处理基础',
  },
  5: {
    problem_id: 5,
    tags: ['排序', '数组', '算法'],
    description: '经典排序算法',
  },
  6: {
    problem_id: 6,
    tags: ['文件操作', 'Shell脚本', '命令行参数'],
    description: 'Shell脚本与文件操作',
  },
};

export const studentKnowledgeProfiles = {
  'student_1': {
    student_id: 1,
    student_no: '20210001',
    name: '张三',
    weak_points: [
      { tag: '循环', mastery_level: 0.45, suggest_practice: [3, 5] },
      { tag: '递归', mastery_level: 0.30, suggest_practice: [3] },
    ],
    strong_points: [
      { tag: '变量', mastery_level: 0.95 },
      { tag: '输入输出', mastery_level: 0.90 },
    ],
    overall_level: 0.72,
  },
  'student_2': {
    student_id: 2,
    student_no: '20210002',
    name: '李四',
    weak_points: [
      { tag: '数组操作', mastery_level: 0.50, suggest_practice: [4, 5] },
      { tag: 'Shell脚本', mastery_level: 0.35, suggest_practice: [6] },
    ],
    strong_points: [
      { tag: '条件判断', mastery_level: 0.88 },
      { tag: '字符串', mastery_level: 0.85 },
    ],
    overall_level: 0.68,
  },
};