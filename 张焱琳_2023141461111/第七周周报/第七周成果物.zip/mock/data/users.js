// src/mock/data/users.js

export const users = [
  {
    id: 1,
    username: 'admin',
    password: 'admin123',
    role: 'admin',
    name: '系统管理员',
    email: 'admin@school.edu.cn',
    token: 'mock_token_admin_001',
  },
  {
    id: 2,
    username: 'teacher_zhang',
    password: 'teacher123',
    role: 'teacher',
    name: '张老师',
    email: 'zhang@school.edu.cn',
    token: 'mock_token_teacher_001',
  },
  {
    id: 3,
    username: 'student_001',
    password: 'student123',
    role: 'student',
    name: '张三',
    student_no: '20210001',
    email: 'zhangsan@example.com',
    token: 'mock_token_student_001',
  },
  {
    id: 4,
    username: 'student_002',
    password: 'student123',
    role: 'student',
    name: '李四',
    student_no: '20210002',
    email: 'lisi@example.com',
    token: 'mock_token_student_002',
  },
];

export const teachers = [
  {
    id: 2,
    username: 'teacher_zhang',
    name: '张老师',
    email: 'zhang@school.edu.cn',
    phone: '13800138000',
    department: '计算机科学与技术学院',
    title: '副教授',
  },
  {
    id: 5,
    username: 'teacher_li',
    name: '李老师',
    email: 'li@school.edu.cn',
    phone: '13900139000',
    department: '软件学院',
    title: '讲师',
  },
];

export const getCurrentUser = (token) => {
  return users.find(u => u.token === token) || null;
};