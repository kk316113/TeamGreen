// src/mock/data/submissionsData.js

export const submissions = [];

// 预生成一些提交记录
const statuses = ['pending', 'judging', 'finished', 'failed'];
const judgeResults = ['accepted', 'rejected', 'failed'];

for (let i = 1; i <= 20; i++) {
  submissions.push({
    id: `submission_${i}`,
    student_id: (i % 5) + 1,
    student_no: `2021000${(i % 5) + 1}`,
    student_name: ['张三', '李四', '王五', '赵六', '孙七'][i % 5],
    assignment_id: `assignment_00${(i % 4) + 1}`,
    assignment_name: [
      '实验一：Python基础语法',
      '实验二：循环与条件判断',
      '实验三：Bash脚本基础',
      '实验四：算法实现',
    ][i % 4],
    problem_id: (i % 6) + 1,
    language: ['python', 'java', 'cpp', 'bash shell'][i % 4],
    code: `print("Hello World ${i}")`,
    status: judgeResults[i % 3],
    score: Math.floor(Math.random() * 100),
    total_score: 100,
    submit_time: `2026-04-${String(10 + (i % 14)).padStart(2, '0')} ${String(8 + (i % 16)).padStart(2, '0')}:${String(i % 60).padStart(2, '0')}:00`,
    execution_time: `${(Math.random() * 0.5).toFixed(3)}s`,
    memory: `${(Math.random() * 20 + 1).toFixed(1)}MB`,
    compile_error: '',
    runtime_error: '',
    test_cases: [
      {
        id: 1,
        name: '测试点1',
        status: i % 3 === 0 ? 'passed' : 'failed',
        score: i % 3 === 0 ? 50 : 0,
        total_score: 50,
        input: '3 5',
        expected_output: '8',
        actual_output: i % 3 === 0 ? '8' : '0',
        time: '0.012s',
        memory: '2.1MB',
        error: '',
      },
      {
        id: 2,
        name: '测试点2',
        status: 'passed',
        score: 50,
        total_score: 50,
        input: '10 20',
        expected_output: '30',
        actual_output: '30',
        time: '0.015s',
        memory: '2.3MB',
        error: '',
      },
    ],
  });
}

export const pendingTasks = [
  {
    submission_id: 'submission_21',
    assignment_id: 'assignment_001',
    problem_id: 1,
    language: 'python',
    code: 'print("pending test")',
    status: 'pending',
    submitted_at: '2026-04-12 10:00:00',
  },
  {
    submission_id: 'submission_22',
    assignment_id: 'assignment_002',
    problem_id: 3,
    language: 'java',
    code: 'public class Main { public static void main(String[] args) { System.out.println("test"); } }',
    status: 'pending',
    submitted_at: '2026-04-12 11:00:00',
  },
];