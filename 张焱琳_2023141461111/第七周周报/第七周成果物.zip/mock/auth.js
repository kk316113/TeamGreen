// src/mock/auth.js
import { users, getCurrentUser } from './data/users';

// Mock 响应辅助函数
const mockResponse = (data, code = 0, message = 'success') => ({
  code,
  message,
  data,
});

const getTokenFromHeaders = (headers) => {
  const authHeader = headers?.Authorization || '';
  return authHeader.replace('Bearer ', '');
};

// 1. 用户登录 POST /api/v1/auth/login
export function mockUserLogin(config) {
  const { username, password } = JSON.parse(config.body || '{}');
  const user = users.find(u => u.username === username && u.password === password);

  if (!user) {
    return Promise.resolve(mockResponse(null, 401, '用户名或密码错误'));
  }

  const { password: _, ...userInfo } = user;
  return Promise.resolve(mockResponse({
    ...userInfo,
    token: user.token,
  }));
}

// 2. Token校验 GET /api/v1/auth/verify
export function mockTokenVerify(config) {
  const token = getTokenFromHeaders(config.headers);
  const user = getCurrentUser(token);

  if (!user) {
    return Promise.resolve(mockResponse(null, 401, 'Token无效或已过期'));
  }

  return Promise.resolve(mockResponse({
    valid: true,
    expires_at: '2026-12-31 23:59:59',
  }));
}

// 3. 获取当前用户信息 GET /api/v1/auth/me
export function mockGetCurrentUser(config) {
  const token = getTokenFromHeaders(config.headers);
  const user = getCurrentUser(token);

  if (!user) {
    return Promise.resolve(mockResponse(null, 401, '未登录'));
  }

  const { password: _, token: __, ...userInfo } = user;
  return Promise.resolve(mockResponse(userInfo));
}

// 需要安装 mockjs: npm install mockjs --save-dev
// 如果使用 vite-plugin-mock，可以按需适配