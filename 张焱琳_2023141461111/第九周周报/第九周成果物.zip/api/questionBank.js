import { get, upload } from "../request";

/**
 * 获取教师课程列表
 * GET /api/v1/teacher/courses
 *
 * 用途：
 * - 获取当前教师可管理的课程
 * - 用于题库选题页面的“目标课程”下拉框
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: [
 *     {
 *       courseId: string,
 *       courseName: string,
 *       courseCode: string,
 *       className: string,
 *       semester: string
 *     }
 *   ]
 * }
 */
export function getQuestionBankCourses() {
  return get("/teacher/courses");
}

/**
 * 获取题库编程题列表
 * GET /api/v1/teacher/questions
 *
 * 用途：
 * - 获取题库选题页面的编程题列表
 * - 支持按课程、关键词、难度筛选
 * - 题型已固定为编程题，因此不再传 type
 *
 * query params:
 * {
 *   courseId?: string,
 *   keyword?: string,
 *   difficulty?: string
 * }
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: [
 *     {
 *       questionId: string,
 *       title: string,
 *       difficulty: string,
 *       description: string,
 *       languages: string[],
 *       maxScore: number,
 *       tags: string[]
 *     }
 *   ]
 * }
 */
export function getQuestionBankList(params = {}) {
  return get("/teacher/questions", params);
}

/**
 * 获取题目详情
 * GET /api/v1/teacher/questions/{questionId}
 *
 * 用途：
 * - 点击“查看详情”后获取题目完整信息
 *
 * path params:
 * - questionId: string
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: {
 *     questionId: string,
 *     title: string,
 *     difficulty: string,
 *     description: string,
 *     languages: string[],
 *     maxScore: number,
 *     tags: string[],
 *     inputDescription: string,
 *     outputDescription: string,
 *     sampleInput: string,
 *     sampleOutput: string,
 *     timeLimit: number,
 *     memoryLimit: number
 *   }
 * }
 */
export function getQuestionDetail(questionId) {
  if (!questionId) {
    throw new Error("questionId 不能为空");
  }

  return get(`/teacher/questions/${encodeURIComponent(questionId)}`);
}

export function importQuestions(courseId, file, onProgress) {
  if (!courseId) {
    throw new Error("courseId 不能为空");
  }
  if (!file) {
    throw new Error("请选择要导入的文件");
  }

  const formData = new FormData();
  formData.append("file", file);
  formData.append("courseId", courseId);

  return upload("/teacher/questions/import", formData, onProgress);
}

/**
 * 解析 PDF/Word 文件获取题目预览
 * POST /api/v1/teacher/questions/parse
 *
 * 用途：
 * - 导入题目时预览解析结果
 * - 仅解析不保存，用于用户确认
 *
 * body:
 * - file: File (PDF/Word 文件)
 * - type: string (pdf/doc/docx)
 *
 * response:
 * {
 *   code: 0,
 *   message: "success",
 *   data: {
 *     questions: [
 *       {
 *         title: string,           // 题目名称
 *         difficulty: string,      // 难度 (easy/medium/hard)
 *         description: string,     // 题目描述
 *         inputDescription: string, // 输入说明
 *         outputDescription: string, // 输出说明
 *         sampleInput: string,     // 样例输入
 *         sampleOutput: string,    // 样例输出
 *         requirements: string,    // 题目要求
 *         constraints: string,     // 限制条件
 *         images: string[],        // 图片URL列表
 *         maxScore: number,        // 满分
 *         tags: string[],          // 标签
 *         languages: string[],      // 支持的语言
 *         timeLimit: number,       // 时间限制(ms)
 *         memoryLimit: number       // 内存限制(MB)
 *       }
 *     ]
 *   }
 * }
 */
export function parseQuestionsFile(file, fileType) {
  if (!file) {
    throw new Error("请选择要解析的文件");
  }

  const formData = new FormData();
  formData.append("file", file);
  formData.append("type", fileType);

  return upload("/teacher/questions/parse", formData);
}