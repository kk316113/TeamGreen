// src/app/api/teacher/StudentManagement.js
import { get, post, put, del } from '../request';

// 学生管理相关接口
const BASE_PATH = '/students';

/**
 * 获取学生列表
 * @returns {Promise}
 * 接口地址: GET /api/v1/teacher/students
 * 请求参数: 无
 * 响应示例：
  * {
 *   "code": 0,
 *   "message": "success",
 *   "data": [
 *     {
 *       "id": 1,
 *       "student_no": "20210001",
 *       "name": "张三",
 *       "major": "计算机科学与技术",
 *       "class_name": "计科2101",
 *       "course_code": "CS101",
 *       "course_seq": "01",
 *       "email": "zhangsan@example.com",
 *       "phone": "13800138000"
 *     },
 *     // 更多学生数据...
 *   ]
 * }
 */
export const getStudentList = async () => {
  return get(BASE_PATH);
};

/**
 * 添加学生
 * 接口地址: POST /api/v1/teacher/students
 * * 请求示例:
 * {
 *   "student_no": "20210002",
 *   "name": "李四",
 *   "major": "软件工程",
 *   "class_name": "软工2101",
 *   "course_code": "SE101",
 *   "course_seq": "01",
 *   "email": "lisi@example.com",
 *   "phone": "13900139000"
 * }
 * 响应示例:
 * {
 *   "code": 0,
 *   "message": "添加成功",
 *   "data": {
 *     "id": 2,
 *     "student_no": "20210002",
 *     "name": "李四",
 *     "major": "软件工程",
 *     "class_name": "软工2101",
 *     "course_code": "SE101",
 *   "   "course_seq": "01",
 *     "email": "lisi@example.com",
 *     "phone": "13900139000"
 *   }
 * }
 * @param {Object} studentData - 学生信息
 * @param {string} studentData.student_no - 学号
 * @param {string} studentData.name - 姓名
 * @param {string} studentData.major - 专业
 * @param {string} studentData.class_name - 班级
 * @param {string} studentData.course_code - 课程编号
 * @param {string} studentData.course_seq - 课序号
 * @param {string} studentData.email - 邮箱
 * @param {string} studentData.phone - 手机
 * @returns {Promise}
 */
export const addStudent = async (studentData) => {
  return post(BASE_PATH, studentData);
};

/**
 * 更新学生信息
 * 接口地址: PUT /api/v1/teacher/students/{id}
 * 请求示例:
 * PUT /api/v1/teacher/students/2
 * {
 *   "name": "李四",
 *   "email": "lisi_new@example.com",
 *   "phone": "13900139001"
 * }
 * 响应示例:
 *  {
 *   "code": 0,
 *   "message": "更新成功",
 *   "data": {
 *     "id": 2,
 *     "student_no": "20210002",
 *     "name": "李四",
 *     "major": "软件工程",
 *     "class_name": "软工2101",
 *     "course_code": "SE101",
 *     "course_seq": "01",
 *     "email": "lisi_new@example.com",
 *     "phone": "13900139001"
 *   }
 * }
 * @param {number|string} id - 学生ID
 * @param {Object} studentData - 学生信息
 * @returns {Promise}
 */
export const updateStudent = async (id, studentData) => {
  return put(`${BASE_PATH}/${id}`, studentData);
};

/**
 * 删除学生
 * 接口地址: DELETE /api/v1/teacher/students/{studentNo}
 * 请求示例:
 * DELETE /api/v1/teacher/students/20210002
 *  响应示例:
 * {
 *   "code": 0,
 *   "message": "删除成功",
 *   "data": null
 * }
 * @param {number|string} studentNo - 学号
 * @returns {Promise}
 */
export const deleteStudent = async (studentNo) => {
  return del(`${BASE_PATH}/${studentNo}`);
};

/**
 * 导出学生列表
 * 接口地址: GET /api/v1/teacher/students/export
 * 请求示例:
 * GET /api/v1/teacher/students/export?courseCode=CS101&className=计科2101
 * 响应示例:
 * 返回Excel文件流
 *
 * @param {Object} params - 导出参数
 * @returns {Promise<Blob>}
 */
export const exportStudents = async (params = {}) => {
  const { download } = await import('../request');
  return download('/students/export', params);
};

/**
 * 根据条件搜索学生
 * 接口地址: GET /api/v1/teacher/students
 * 请求示例:
 * GET /api/v1/teacher/students?name=张&major=计算机
 * 响应示例:
 * {
 *   "code": 0,
 *   "message": "success",
 *   "data": [
 *     {
 *       "id": 1,
 *       "student_no": "20210001",
 *       "name": "张三",
 *       "major": "计算机科学与技术",
 *       "class_name": "计科2101",
 *       "course_code": "CS101",
 *       "course_seq": "01",
 *       "email": "zhangsan@example.com",
 *       "phone": "13800138000"
 *     }
 *   ]
 * }
 * @param {Object} searchParams - 搜索参数
 * @param {string} searchParams.name - 学生姓名 (可选)
 * @param {string} searchParams.student_no - 学号 (可选)
 * @param {string} searchParams.major - 专业 (可选)
 * @param {string} searchParams.class_name - 班级 (可选)
 * @param {string} searchParams.course_code - 课程编号 (可选)
 * @returns {Promise}
 */
export const searchStudents = async (searchParams) => {
  return get(BASE_PATH, searchParams);
};

export default {
  getStudentList,
  addStudent,
  updateStudent,
  deleteStudent,
  exportStudents,
  searchStudents,
};