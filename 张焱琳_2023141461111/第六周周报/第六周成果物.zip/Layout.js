import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Outlet, Link, useLocation, useNavigate } from "react-router";
import { Home, Upload, Edit, BookOpen, BarChart3, User, LogOut, Menu, Library, ClipboardList, } from "lucide-react";
import { useState } from "react";

/**
 * 教师端布局组件
 * 包含顶部导航栏、侧边栏和主要内容区域
 */
export function Layout() {
  
  // 使用React Router的hook获取当前位置和导航功能
  const location = useLocation();
  const navigate = useNavigate();
 
  // 控制侧边栏展开/收起的状态
  const [sidebarOpen, setSidebarOpen] = useState(true);
  
  /**
   * 处理登出功能
   * 点击后将导航到首页
   */
  const handleLogout = () => {
    navigate("/");
  };
  
  /**
   * 判断当前路径是否完全匹配指定路径
   * @param {string} path - 需要匹配的路径
   * @returns {boolean} 是否匹配
   */
  const isActive = (path) => {
    return location.pathname === path;
  };


  /**
   * 判断当前路径是否包含指定路径数组中的任何一个
   * @param {Array} paths - 需要匹配的路径数组
   * @returns {boolean} 是否匹配
   */
  const isActiveSection = (paths) => {
    return paths.some((path) => location.pathname.includes(path));
  };
  return _jsxs("div", {
    className: "min-h-screen bg-gray-50",
    children: [
      // 顶部导航栏
      _jsx("header", {
        className:
          "bg-white border-b border-gray-100 fixed top-0 left-0 right-0 z-10 h-16",
        children: _jsxs("div", {
          className: "h-full px-6 flex items-center justify-between",
          children: [
            // 左侧：菜单按钮和标题
            _jsxs("div", {
              className: "flex items-center gap-4",
              children: [
                // 菜单按钮，用于切换侧边栏
                _jsx("button", {
                  onClick: () => setSidebarOpen(!sidebarOpen),
                  className:
                    "p-2 hover:bg-gray-50 rounded-lg transition-colors",
                  children: _jsx(Menu, { className: "w-5 h-5 text-gray-500" }),
                }),
                // 应用标题和标识
                _jsxs("div", {
                  className: "flex items-center gap-3",
                  children: [
                    _jsx("div", {
                      className:
                        "w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-sm",
                      children: _jsx(BarChart3, {
                        className: "w-5 h-5 text-white",
                      }),
                    }),
                    _jsxs("div", {
                      className: "flex items-center gap-2",
                      children: [
                        _jsx("h1", {
                          className: "text-xl font-semibold text-gray-900",
                          children: "AutoGrader",
                        }),
                        _jsx("span", {
                          className:
                            "px-2.5 py-0.5 bg-blue-50 text-blue-600 text-xs font-medium rounded-full",
                          children: "\u6559\u5E08\u7AEF",
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            }),
            // 右侧：用户信息和登出按钮
            _jsxs("div", {
              className: "flex items-center gap-4",
              children: [
                // 用户信息卡片
                _jsxs("div", {
                  className:
                    "flex items-center gap-3 px-3 py-2 bg-gray-50 rounded-xl",
                  children: [
                    _jsx("div", {
                      className:
                        "w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center",
                      children: _jsx(User, { className: "w-4 h-4 text-white" }),
                    }),
                    _jsxs("div", {
                      className: "text-sm",
                      children: [
                        _jsx("div", {
                          className: "text-gray-900 font-medium",
                          children: "\u5F20\u8001\u5E08",
                        }),
                        _jsx("div", {
                          className: "text-gray-500 text-xs",
                          children: "\u8BA1\u7B97\u673A\u79D1\u5B66\u7CFB",
                        }),
                      ],
                    }),
                  ],
                }),
                // 登出按钮
                _jsx("button", {
                  onClick: handleLogout,
                  className:
                    "p-2 hover:bg-gray-50 rounded-lg text-gray-500 hover:text-gray-700 transition-colors",
                  title: "\u9000\u51FA\u767B\u5F55",
                  children: _jsx(LogOut, { className: "w-5 h-5" }),
                }),
              ],
            }),
          ],
        }),
      }),
      // 侧边栏导航
      _jsx("aside", {
        className: `fixed left-0 top-16 bottom-0 bg-white border-r border-gray-100 transition-all duration-300 z-20 overflow-y-auto ${sidebarOpen ? "w-64" : "w-0 overflow-hidden"}`,
        children: _jsxs("nav", {
          className: "p-4 space-y-2",
          children: [
            // 首页导航
            _jsxs(Link, {
              to: "/teacher",
              className: `flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                isActive("/teacher")
                  ? "bg-blue-50 text-blue-600 shadow-sm"
                  : "text-gray-600 hover:bg-gray-50"
              }`,
              children: [
                _jsx(Home, { className: "w-5 h-5" }),
                _jsx("span", {
                  className: "font-medium",
                  children: "\u9996\u9875",
                }),
              ],
            }),
            // 学生信息管理分组
            _jsx("div", {
              className: "pt-6 pb-2",
              children: _jsx("div", {
                className:
                  "px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider",
                children: "\u5B66\u751F\u4FE1\u606F\u7BA1\u7406",
              }),
            }),
            // 学生信息导入
            _jsxs(Link, {
              to: "/teacher/student-import",
              className: `flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                isActive("/teacher/student-import")
                  ? "bg-blue-50 text-blue-600 shadow-sm"
                  : "text-gray-600 hover:bg-gray-50"
              }`,
              children: [
                _jsx(Upload, { className: "w-5 h-5" }),
                _jsx("span", {
                  className: "font-medium",
                  children: "\u5B66\u751F\u4FE1\u606F\u5BFC\u5165",
                }),
              ],
            }),
            // 学生信息维护
            _jsxs(Link, {
              to: "/teacher/student-management",
              className: `flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                isActive("/teacher/student-management")
                  ? "bg-blue-50 text-blue-600 shadow-sm"
                  : "text-gray-600 hover:bg-gray-50"
              }`,
              children: [
                _jsx(Edit, { className: "w-5 h-5" }),
                _jsx("span", {
                  className: "font-medium",
                  children: "\u5B66\u751F\u4FE1\u606F\u7EF4\u62A4",
                }),
              ],
            }),
            // 课程管理分组
            _jsx("div", {
              className: "pt-6 pb-2",
              children: _jsx("div", {
                className:
                  "px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider",
                children: "\u8BFE\u7A0B\u7BA1\u7406",
              }),
            }),
            // 分班管理
            _jsxs(Link, {
              to: "/teacher/class-management",
              className: `flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                isActive("/teacher/class-management")
                  ? "bg-blue-50 text-blue-600 shadow-sm"
                  : "text-gray-600 hover:bg-gray-50"
              }`,
              children: [
                _jsx(BookOpen, { className: "w-5 h-5" }),
                _jsx("span", {
                  className: "font-medium",
                  children: "\u5206\u73ED\u7BA1\u7406",
                }),
              ],
            }),
            // 任务管理分组
            _jsx("div", {
              className: "pt-6 pb-2",
              children: _jsx("div", {
                className:
                  "px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider",
                children: "\u4EFB\u52A1\u7BA1\u7406",
              }),
            }),
            // 题库选题
            _jsxs(Link, {
              to: "/teacher/question-bank",
              className: `flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                isActive("/teacher/question-bank")
                  ? "bg-blue-50 text-blue-600 shadow-sm"
                  : "text-gray-600 hover:bg-gray-50"
              }`,
              children: [
                _jsx(Library, { className: "w-5 h-5" }),
                _jsx("span", {
                  className: "font-medium",
                  children: "\u9898\u5E93\u9009\u9898",
                }),
              ],
            }),
            // 课程任务管理
            _jsxs(Link, {
              to: "/teacher/task-management",
              className: `flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                isActive("/teacher/task-management")
                  ? "bg-blue-50 text-blue-600 shadow-sm"
                  : "text-gray-600 hover:bg-gray-50"
              }`,
              children: [
                _jsx(ClipboardList, { className: "w-5 h-5" }),
                _jsx("span", {
                  className: "font-medium",
                  children: "\u8BFE\u7A0B\u4EFB\u52A1\u7BA1\u7406",
                }),
              ],
            }),
            // 成绩管理分组
            _jsx("div", {
              className: "pt-6 pb-2",
              children: _jsx("div", {
                className:
                  "px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider",
                children: "\u6210\u7EE9\u7BA1\u7406",
              }),
            }),
            // 成绩总览
            _jsxs(Link, {
              to: "/teacher/grade-overview",
              className: `flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                isActive("/teacher/grade-overview")
                  ? "bg-blue-50 text-blue-600 shadow-sm"
                  : "text-gray-600 hover:bg-gray-50"
              }`,
              children: [
                _jsx(BarChart3, { className: "w-5 h-5" }),
                _jsx("span", {
                  className: "font-medium",
                  children: "\u6210\u7EE9\u603B\u89C8",
                }),
              ],
            }),
            // 个人分组
            _jsx("div", {
              className: "pt-6 pb-2",
              children: _jsx("div", {
                className:
                  "px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider",
                children: "\u4E2A\u4EBA",
              }),
            }),
            // 个人中心
            _jsxs(Link, {
              to: "/teacher/profile",
              className: `flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                isActive("/teacher/profile")
                  ? "bg-blue-50 text-blue-600 shadow-sm"
                  : "text-gray-600 hover:bg-gray-50"
              }`,
              children: [
                _jsx(User, { className: "w-5 h-5" }),
                _jsx("span", {
                  className: "font-medium",
                  children: "\u4E2A\u4EBA\u4E2D\u5FC3",
                }),
              ],
            }),
          ],
        }),
      }),
      // 主要内容区域
      _jsx("main", {
        className: `pt-16 transition-all duration-300 ${sidebarOpen ? "ml-64" : "ml-0"}`,
        children: _jsx("div", { className: "p-8", children: _jsx(Outlet, {}) }),
      }),
    ],
  });
}
