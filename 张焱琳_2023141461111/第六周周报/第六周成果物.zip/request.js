// src/app/api/request.js

// API 基础地址
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api/v1/teacher';

// 获取存储的 token
export const getToken = () => {
  return localStorage.getItem('token') || sessionStorage.getItem('token');
};

// 设置 token
export const setToken = (token) => {
  localStorage.setItem('token', token);
};

// 移除 token
export const removeToken = () => {
  localStorage.removeItem('token');
  sessionStorage.removeItem('token');
};

/**
 * 通用请求方法
 * @param {string} url - 请求地址
 * @param {object} options - 请求选项
 * @returns {Promise} 响应数据
 */
export const request = async (url, options = {}) => {
  const token = getToken();
  
  const headers = {
    'Content-Type': 'application/json',
    ...(token && { 'Authorization': `Bearer ${token}` }),
    ...options.headers,
  };

  // 如果是 FormData，删除 Content-Type 让浏览器自动设置
  if (options.body instanceof FormData) {
    delete headers['Content-Type'];
  }

  const response = await fetch(`${API_BASE_URL}${url}`, {
    ...options,
    headers,
  });

  const result = await response.json();
  
  if (result.code !== 0) {
    // 处理特定错误码
    if (result.code === 401) {
      // token 过期或无效，清除本地存储
      removeToken();
      // 可以在这里触发登录跳转
      window.location.href = '/login';
    }
    throw new Error(result.message || '请求失败');
  }
  
  return result;
};

/**
 * GET 请求
 * @param {string} url - 请求地址
 * @param {object} params - 查询参数
 * @returns {Promise}
 */
export const get = async (url, params = {}) => {
  const queryString = new URLSearchParams(params).toString();
  const fullUrl = queryString ? `${url}?${queryString}` : url;
  return request(fullUrl, { method: 'GET' });
};

/**
 * POST 请求
 * @param {string} url - 请求地址
 * @param {object} data - 请求体数据
 * @returns {Promise}
 */
export const post = async (url, data = {}) => {
  return request(url, {
    method: 'POST',
    body: JSON.stringify(data),
  });
};

/**
 * PUT 请求
 * @param {string} url - 请求地址
 * @param {object} data - 请求体数据
 * @returns {Promise}
 */
export const put = async (url, data = {}) => {
  return request(url, {
    method: 'PUT',
    body: JSON.stringify(data),
  });
};

/**
 * DELETE 请求
 * @param {string} url - 请求地址
 * @returns {Promise}
 */
export const del = async (url) => {
  return request(url, { method: 'DELETE' });
};

/**
 * 文件上传请求
 * @param {string} url - 请求地址
 * @param {FormData} formData - 表单数据
 * @param {Function} onProgress - 上传进度回调
 * @returns {Promise}
 */
export const upload = async (url, formData, onProgress = null) => {
  const token = getToken();
  
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    
    xhr.open('POST', `${API_BASE_URL}${url}`);
    xhr.setRequestHeader('Authorization', `Bearer ${token}`);
    
    if (onProgress) {
      xhr.upload.addEventListener('progress', (e) => {
        if (e.lengthComputable) {
          const progress = Math.round((e.loaded / e.total) * 100);
          onProgress(progress);
        }
      });
    }
    
    xhr.onload = () => {
      if (xhr.status === 200) {
        try {
          const result = JSON.parse(xhr.responseText);
          if (result.code === 0) {
            resolve(result);
          } else {
            reject(new Error(result.message || '上传失败'));
          }
        } catch (error) {
          reject(new Error('解析响应失败'));
        }
      } else {
        reject(new Error(`上传失败: ${xhr.status}`));
      }
    };
    
    xhr.onerror = () => {
      reject(new Error('网络错误'));
    };
    
    xhr.send(formData);
  });
};

/**
 * 下载文件请求
 * @param {string} url - 请求地址
 * @param {object} params - 查询参数
 * @returns {Promise<Blob>}
 */
export const download = async (url, params = {}) => {
  const token = getToken();
  const queryString = new URLSearchParams(params).toString();
  const fullUrl = queryString ? `${url}?${queryString}` : url;
  
  const response = await fetch(`${API_BASE_URL}${fullUrl}`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  });
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || '下载失败');
  }
  
  return response.blob();
};

/**
 * 并发请求
 * @param {Array} requests - 请求数组
 * @returns {Promise}
 */
export const all = async (requests) => {
  return Promise.all(requests);
};

/**
 * 轮询请求
 * @param {string} url - 请求地址
 * @param {Function} condition - 停止条件函数
 * @param {number} interval - 轮询间隔（毫秒）
 * @param {number} maxAttempts - 最大尝试次数
 * @returns {Promise}
 */
export const poll = async (url, condition, interval = 2000, maxAttempts = 30) => {
  let attempts = 0;
  
  const pollRequest = async () => {
    attempts++;
    const result = await get(url);
    
    if (condition(result)) {
      return result;
    }
    
    if (attempts >= maxAttempts) {
      throw new Error('轮询超时');
    }
    
    await new Promise(resolve => setTimeout(resolve, interval));
    return pollRequest();
  };
  
  return pollRequest();
};

// 默认导出
export default {
  request,
  get,
  post,
  put,
  del,
  upload,
  download,
  all,
  poll,
  getToken,
  setToken,
  removeToken,
};