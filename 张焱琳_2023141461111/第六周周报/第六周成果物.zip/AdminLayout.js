import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Outlet, Link, useLocation, useNavigate } from "react-router";
import { Home, Users, Shield, Settings, User, LogOut, Menu, BarChart3, Database, } from "lucide-react";
import { useState } from "react";
/**
 * 管理员布局组件
 * 提供了管理界面的整体布局结构，包括顶部导航栏、侧边栏和主内容区域
 */
export function AdminLayout() {
  // 使用React Router的location和navigate钩子
  const location = useLocation();
  const navigate = useNavigate();
  // 控制侧边栏展开/收起的状态
  const [sidebarOpen, setSidebarOpen] = useState(true);
  /**
   * 处理登出功能
   * 将用户导航到首页
   */
  const handleLogout = () => {
    navigate("/");
  };
  /**
   * 判断当前路径是否激活
   * @param {string} path - 需要检查的路径
   * @returns {boolean} - 如果当前路径与传入路径匹配则返回true
   */
  const isActive = (path) => {
    return location.pathname === path;
  };
  return _jsxs("div", {
    className: "min-h-screen bg-gray-50",
    children: [
      // 顶部导航栏
      _jsx("header", {
        className:
          "bg-white border-b border-gray-100 fixed top-0 left-0 right-0 z-10 h-16",
        children: _jsxs("div", {
          className: "h-full px-6 flex items-center justify-between",
          children: [
            // 左侧导航区域
            _jsxs("div", {
              className: "flex items-center gap-4",
              children: [
                // 侧边栏切换按钮
                _jsx("button", {
                  onClick: () => setSidebarOpen(!sidebarOpen),
                  className:
                    "p-2 hover:bg-gray-50 rounded-lg transition-colors",
                  children: _jsx(Menu, { className: "w-5 h-5 text-gray-500" }),
                }),
                // 系统标题和标识
                _jsxs("div", {
                  className: "flex items-center gap-3",
                  children: [
                    _jsx("div", {
                      className:
                        "w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-sm",
                      children: _jsx(BarChart3, {
                        className: "w-5 h-5 text-white",
                      }),
                    }),
                    _jsxs("div", {
                      className: "flex items-center gap-2",
                      children: [
                        _jsx("h1", {
                          className: "text-xl font-semibold text-gray-900",
                          children: "AutoGrader",
                        }),
                        _jsx("span", {
                          className:
                            "px-2.5 py-0.5 bg-purple-50 text-purple-600 text-xs font-medium rounded-full",
                          children: "\u7BA1\u7406\u5458",
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            }),
            // 右侧用户信息区域
            _jsxs("div", {
              className: "flex items-center gap-4",
              children: [
                // 用户信息卡片
                _jsxs("div", {
                  className:
                    "flex items-center gap-3 px-3 py-2 bg-gray-50 rounded-xl",
                  children: [
                    _jsx("div", {
                      className:
                        "w-8 h-8 bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg flex items-center justify-center",
                      children: _jsx(User, { className: "w-4 h-4 text-white" }),
                    }),
                    _jsxs("div", {
                      className: "text-sm",
                      children: [
                        _jsx("div", {
                          className: "text-gray-900 font-medium",
                          children: "\u7CFB\u7EDF\u7BA1\u7406\u5458",
                        }),
                        _jsx("div", {
                          className: "text-gray-500 text-xs",
                          children: "admin@system",
                        }),
                      ],
                    }),
                  ],
                }),
                // 登出按钮
                _jsx("button", {
                  onClick: handleLogout,
                  className:
                    "p-2 hover:bg-gray-50 rounded-lg text-gray-500 hover:text-gray-700 transition-colors",
                  title: "\u9000\u51FA\u767B\u5F55",
                  children: _jsx(LogOut, { className: "w-5 h-5" }),
                }),
              ],
            }),
          ],
        }),
      }),
      // 侧边导航栏
      _jsx("aside", {
        className: `fixed left-0 top-16 bottom-0 bg-white border-r border-gray-100 transition-all duration-300 z-20 overflow-y-auto ${sidebarOpen ? "w-64" : "w-0 overflow-hidden"}`,
        children: _jsxs("nav", {
          className: "p-4 space-y-2",
          children: [
            // 首页链接
            _jsxs(Link, {
              to: "/admin",
              className: `flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                isActive("/admin")
                  ? "bg-blue-50 text-blue-600 shadow-sm"
                  : "text-gray-600 hover:bg-gray-50"
              }`,
              children: [
                _jsx(Home, { className: "w-5 h-5" }),
                _jsx("span", {
                  className: "font-medium",
                  children: "\u9996\u9875",
                }),
              ],
            }),
            // 系统管理分组
            _jsx("div", {
              className: "pt-6 pb-2",
              children: _jsx("div", {
                className:
                  "px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider",
                children: "\u7CFB\u7EDF\u7BA1\u7406",
              }),
            }),
            // 用户管理链接
            _jsxs(Link, {
              to: "/admin/user-management",
              className: `flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                isActive("/admin/user-management")
                  ? "bg-blue-50 text-blue-600 shadow-sm"
                  : "text-gray-600 hover:bg-gray-50"
              }`,
              children: [
                _jsx(Users, { className: "w-5 h-5" }),
                _jsx("span", {
                  className: "font-medium",
                  children: "\u7528\u6237\u7BA1\u7406",
                }),
              ],
            }),
            // 权限管理链接
            _jsxs(Link, {
              to: "/admin/permission-management",
              className: `flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                isActive("/admin/permission-management")
                  ? "bg-blue-50 text-blue-600 shadow-sm"
                  : "text-gray-600 hover:bg-gray-50"
              }`,
              children: [
                _jsx(Shield, { className: "w-5 h-5" }),
                _jsx("span", {
                  className: "font-medium",
                  children: "\u6743\u9650\u7BA1\u7406",
                }),
              ],
            }),
            // 题库管理链接
            _jsxs(Link, {
              to: "/admin/question-bank-management",
              className: `flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                isActive("/admin/question-bank-management")
                  ? "bg-blue-50 text-blue-600 shadow-sm"
                  : "text-gray-600 hover:bg-gray-50"
              }`,
              children: [
                _jsx(Database, { className: "w-5 h-5" }),
                _jsx("span", {
                  className: "font-medium",
                  children: "\u9898\u5E93\u7BA1\u7406",
                }),
              ],
            }),
            // 系统维护链接
            _jsxs(Link, {
              to: "/admin/system-maintenance",
              className: `flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                isActive("/admin/system-maintenance")
                  ? "bg-blue-50 text-blue-600 shadow-sm"
                  : "text-gray-600 hover:bg-gray-50"
              }`,
              children: [
                _jsx(Settings, { className: "w-5 h-5" }),
                _jsx("span", {
                  className: "font-medium",
                  children: "\u7CFB\u7EDF\u7EF4\u62A4",
                }),
              ],
            }),
            // 个人分组
            _jsx("div", {
              className: "pt-6 pb-2",
              children: _jsx("div", {
                className:
                  "px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider",
                children: "\u4E2A\u4EBA",
              }),
            }),
            // 个人中心链接
            _jsxs(Link, {
              to: "/admin/profile",
              className: `flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                isActive("/admin/profile")
                  ? "bg-blue-50 text-blue-600 shadow-sm"
                  : "text-gray-600 hover:bg-gray-50"
              }`,
              children: [
                _jsx(User, { className: "w-5 h-5" }),
                _jsx("span", {
                  className: "font-medium",
                  children: "\u4E2A\u4EBA\u4E2D\u5FC3",
                }),
              ],
            }),
          ],
        }),
      }),
      // 主内容区域
      _jsx("main", {
        className: `pt-16 transition-all duration-300 ${sidebarOpen ? "ml-64" : "ml-0"}`,
        children: _jsx("div", { className: "p-8", children: _jsx(Outlet, {}) }),
      }),
    ],
  });
}
