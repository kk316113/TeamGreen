import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { useNavigate, Link } from "react-router";
import { BarChart3, LogIn } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";

/**
 * 学生登录组件
 * 用于处理学生用户的登录功能，包括表单验证、登录请求和状态管理
 */
export function StudentLogin() {
    // 使用React Router的useNavigate钩子进行页面导航
    const navigate = useNavigate();
    // 使用useState钩子管理学号输入状态
    const [studentId, setStudentId] = useState("");
    // 使用useState钩子管理密码输入状态
    const [password, setPassword] = useState("");
    // 使用useState钩子管理加载状态，用于控制按钮禁用和显示加载提示
    const [loading, setLoading] = useState(false);

    /**
     * 处理登录请求的异步函数
     * @param {Object} e - 表单提交事件对象
     */
    const handleLogin = async (e) => {
        // 阻止表单默认提交行为
        e.preventDefault();

        // 验证学号和密码是否为空
        if (!studentId || !password) {
            alert("请输入学号和密码");
            return;
        }

        // 设置加载状态为true
        setLoading(true);
        try {
            // 发送POST请求到后端登录接口
            const res = await fetch("http://localhost:8000/api/v1/auth/login", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    username: studentId,
                    password: password,
                }),
            });

            const data = await res.json();
            if (data.code === 0) {
                localStorage.setItem("student_token", data.data.token);
                localStorage.setItem("student_role", "student");
                navigate("/student");
            } else {
                alert(data.message || "登录失败：学号或密码错误");
            }
        } catch (err) {
            console.error("登录请求异常", err);
            alert("登录失败，请检查网络或后端服务");
        } finally {
            setLoading(false);
        }
    };

    return (_jsx("div", { className: "min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 flex items-center justify-center p-4", children:
        _jsx("div", { className: "w-full max-w-md", children:
            _jsxs("div", { className: "bg-white rounded-2xl shadow-xl p-8", children: [
                _jsxs("div", { className: "text-center mb-8", children: [
                    _jsx("div", { className: "inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl mb-4 shadow-sm", children:
                        _jsx(BarChart3, { className: "w-8 h-8 text-white" })
                    }),
                    _jsx("h1", { className: "text-2xl font-semibold text-gray-900 mb-2", children: "AutoGrader" }),
                    _jsx("p", { className: "text-gray-500", children: "课程任务代码自动评分系统 - 学生端" })
                ]}),

                _jsxs("form", { onSubmit: handleLogin, className: "space-y-5", children: [
                    _jsxs("div", { className: "space-y-2", children: [
                        _jsx(Label, { htmlFor: "studentId", children: "学号" }),
                        _jsx(Input, {
                            id: "studentId",
                            type: "text",
                            placeholder: "请输入学号",
                            value: studentId,
                            onChange: (e) => setStudentId(e.target.value),
                            className: "h-11 border-gray-200",
                            disabled: loading
                        })
                    ]}),
                    _jsxs("div", { className: "space-y-2", children: [
                        _jsx(Label, { htmlFor: "password", children: "密码" }),
                        _jsx(Input, {
                            id: "password",
                            type: "password",
                            placeholder: "请输入密码",
                            value: password,
                            onChange: (e) => setPassword(e.target.value),
                            className: "h-11 border-gray-200",
                            disabled: loading
                        })
                    ]}),
                    _jsxs("div", { className: "flex items-center justify-between text-sm", children: [
                        _jsxs("label", { className: "flex items-center gap-2 text-gray-600 cursor-pointer", children: [
                            _jsx("input", { type: "checkbox", className: "rounded border-gray-300 text-green-600 focus:ring-green-500" }),
                            "记住我"
                        ]}),
                        _jsx(Link, { to: "/student/forgot-password", className: "text-green-600 hover:text-green-700 transition-colors", children: "忘记密码？" })
                    ]}),

                    _jsx(Button, {
                        type: "submit",
                        className: "w-full h-11 bg-green-600 hover:bg-green-700 shadow-sm",
                        disabled: loading,
                        children: loading ? "登录中..." : "登录"
                    })
                ]}),

                _jsx("div", { className: "mt-8 pt-6 border-t border-gray-100 text-center text-sm text-gray-500", children: "© 2024 AutoGrader. 学生端系统" })
            ]})
        })
    }));
}