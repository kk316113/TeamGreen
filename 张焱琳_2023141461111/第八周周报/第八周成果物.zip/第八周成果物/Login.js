import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { useNavigate, Link } from "react-router";
import { BarChart3, LogIn } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";

export function Login() {
    const navigate = useNavigate();
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [loading, setLoading] = useState(false);

    const handleLogin = async (e) => {
        e.preventDefault();

        if (!username || !password) {
            alert("请输入用户名和密码");
            return;
        }

        setLoading(true);
        try {
            const res = await fetch("/api/v1/auth/teacher/login", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    username: username,
                    password: password,
                }),
            });

            const data = await res.json();
            if (data.code === 0) {
                localStorage.setItem("token", data.data.token);
                localStorage.setItem("user_role", "teacher");
                navigate("/teacher");
            } else {
                alert(data.message || "登录失败：用户名或密码错误");
            }
        } catch (err) {
            console.error("登录请求异常", err);
            alert("登录失败，请检查网络或后端服务");
        } finally {
            setLoading(false);
        }
    };

    return (_jsx("div", { className: "min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4", children: _jsx("div", { className: "w-full max-w-md", children: _jsxs("div", { className: "bg-white rounded-2xl shadow-xl p-8", children: [_jsxs("div", { className: "text-center mb-8", children: [_jsx("div", { className: "inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl mb-4 shadow-sm", children: _jsx(BarChart3, { className: "w-8 h-8 text-white" }) }), _jsx("h1", { className: "text-2xl font-semibold text-gray-900 mb-2", children: "AutoGrader" }), _jsx("p", { className: "text-gray-500", children: "课程任务型代码自动评分系统" })] }), _jsxs("form", { onSubmit: handleLogin, className: "space-y-5", children: [_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "username", children: "用户名" }), _jsx(Input, { id: "username", type: "text", placeholder: "请输入工号或用户名", value: username, onChange: (e) => setUsername(e.target.value), className: "h-11 border-gray-200" })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "password", children: "密码" }), _jsx(Input, { id: "password", type: "password", placeholder: "请输入密码", value: password, onChange: (e) => setPassword(e.target.value), className: "h-11 border-gray-200" })] }), _jsxs("div", { className: "flex items-center justify-between text-sm", children: [_jsxs("label", { className: "flex items-center gap-2 text-gray-600 cursor-pointer", children: [_jsx("input", { type: "checkbox", className: "rounded border-gray-300 text-blue-600 focus:ring-blue-500" }), "记住我"] }), _jsx(Link, { to: "/forgot-password", className: "text-blue-600 hover:text-blue-700 transition-colors", children: "忘记密码？" })] }), _jsxs(Button, { type: "submit", className: "w-full h-11 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700", disabled: loading, children: [loading ? "登录中..." : "登录", _jsx(LogIn, { className: "w-4 h-4 ml-2" })] })] }), _jsx("div", { className: "mt-6 pt-6 border-t border-gray-100 text-center", children: _jsxs("p", { className: "text-sm text-gray-500", children: ["学生登录请", _jsx(Link, { to: "/student/login", className: "text-blue-600 hover:text-blue-700 ml-1", children: "点击这里" })] }) })] }) }) }));
}
