import { createBrowserRouter } from "react-router";
import { Dashboard } from "./pages/Dashboard";
import { Login } from "./pages/Login";
import { ForgotPassword } from "./pages/ForgotPassword";
import { Layout } from "./components/Layout";
import { StudentImport } from "./pages/StudentImport";
import { StudentManagement } from "./pages/StudentManagement";
import { ClassManagement } from "./pages/ClassManagement";
import { GradeOverview } from "./pages/GradeOverview";
import { StudentGradeDetail } from "./pages/StudentGradeDetail";
import { Profile } from "./pages/Profile";
import { QuestionBank } from "./pages/QuestionBank";
import { TaskManagement } from "./pages/TaskManagement";
import { TaskForm } from "./pages/TaskForm";
import { TaskDetail } from "./pages/TaskDetail";
import { StudentLayout } from "./components/StudentLayout";
import { StudentLogin } from "./pages/student/StudentLogin";
import { StudentForgotPassword } from "./pages/student/ForgotPassword";
import { StudentDashboard } from "./pages/student/StudentDashboard";
import { AssignmentSubmit } from "./pages/student/AssignmentSubmit";
import { SubmissionHistory } from "./pages/student/SubmissionHistory";
import { MyGrades } from "./pages/student/MyGrades";
import { GradeDetail } from "./pages/student/GradeDetail";
import { StudentProfile } from "./pages/student/StudentProfile";
import { MyTasks } from "./pages/student/MyTasks";
import { TaskDetail as StudentTaskDetail } from "./pages/student/TaskDetail";
import { Welcome } from "./pages/Welcome";
import { AdminLayout } from "./components/AdminLayout";
import { AdminLogin } from "./pages/admin/AdminLogin";
import { AdminForgotPassword } from "./pages/admin/ForgotPassword";
import { AdminDashboard } from "./pages/admin/AdminDashboard";
import { UserManagement } from "./pages/admin/UserManagement";
import { PermissionManagement } from "./pages/admin/PermissionManagement";
import { QuestionBankManagement } from "./pages/admin/QuestionBankManagement";
import { SystemMaintenance } from "./pages/admin/SystemMaintenance";
import { AdminProfile } from "./pages/admin/AdminProfile";
export const router = createBrowserRouter([
    {
        path: "/",
        Component: Welcome,
    },
    {
        path: "/login",
        Component: Login,
    },
    {
        path: "/forgot-password",
        Component: ForgotPassword,
    },
    {
        path: "/teacher",
        Component: Layout,
        children: [
            { index: true, Component: Dashboard },
            { path: "student-import", Component: StudentImport },
            { path: "student-management", Component: StudentManagement },
            { path: "class-management", Component: ClassManagement },
            { path: "question-bank", Component: QuestionBank },
            { path: "task-management", Component: TaskManagement },
            { path: "task-form", Component: TaskForm },
            { path: "task-form/:taskId", Component: TaskForm },
            { path: "task-detail/:taskId", Component: TaskDetail },
            { path: "grade-overview", Component: GradeOverview },
            { path: "student-grade-detail/:studentId", Component: StudentGradeDetail },
            { path: "profile", Component: Profile },
        ],
    },
    {
        path: "/student/login",
        Component: StudentLogin,
    },
    {
        path: "/student/forgot-password",
        Component: StudentForgotPassword,
    },
    {
        path: "/student",
        Component: StudentLayout,
        children: [
            { index: true, Component: StudentDashboard },
            { path: "tasks", Component: MyTasks },
            { path: "task-detail/:taskId", Component: StudentTaskDetail },
            { path: "submit", Component: AssignmentSubmit },
            { path: "history", Component: SubmissionHistory },
            { path: "grades", Component: MyGrades },
            { path: "grade-detail/:gradeId", Component: GradeDetail },
            { path: "profile", Component: StudentProfile },
        ],
    },
    {
        path: "/admin/login",
        Component: AdminLogin,
    },
    {
        path: "/admin/forgot-password",
        Component: AdminForgotPassword,
    },
    {
        path: "/admin",
        Component: AdminLayout,
        children: [
            { index: true, Component: AdminDashboard },
            { path: "user-management", Component: UserManagement },
            { path: "permission-management", Component: PermissionManagement },
            { path: "question-bank-management", Component: QuestionBankManagement },
            { path: "system-maintenance", Component: SystemMaintenance },
            { path: "profile", Component: AdminProfile },
        ],
    },
]);
