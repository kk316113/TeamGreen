import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { Link } from "react-router";
import { Users, Upload, BarChart3, Clock, BookOpen, ArrowRight, CheckCircle, Library, ClipboardList, Edit, } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";

export function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [teacherInfo, setTeacherInfo] = useState({ name: "", department: "" });
  const [stats, setStats] = useState([]);
  const [recentImports, setRecentImports] = useState([]);
  const [recentGrades, setRecentGrades] = useState([]);

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        setLoading(true);
        const token = localStorage.getItem("token");
        const res = await fetch("/api/v1/teacher/dashboard", {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        });
        const data = await res.json();
        if (data.code === 0) {
          setTeacherInfo({
            name: data.data.teacher_name || "",
            department: data.data.department || ""
          });
          setStats(data.data.stats || []);
          setRecentImports(data.data.recent_imports || []);
          setRecentGrades(data.data.recent_grades || []);
        }
      } catch (err) {
        console.error("获取仪表盘数据失败", err);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboard();
  }, []);

  const getIcon = (iconName) => {
    const icons = { BookOpen, Users, ClipboardList, Clock };
    return icons[iconName] || BookOpen;
  };

  const getColorClasses = (color) => ({
    blue: "bg-blue-50 text-blue-600",
    green: "bg-green-50 text-green-600",
    orange: "bg-orange-50 text-orange-600",
    purple: "bg-purple-50 text-purple-600",
  });

  if (loading) {
    return _jsx("div", { className: "p-10 text-center", children: "加载中..." });
  }

  return _jsxs("div", {
    className: "space-y-6",
    children: [
      _jsxs("div", {
        children: [
          _jsx("h1", {
            className: "text-2xl text-gray-900 mb-1",
            children: `欢迎回来，${teacherInfo.name}`,
          }),
          _jsx("p", {
            className: "text-gray-600",
            children: teacherInfo.department || "这是您的工作台概览",
          }),
        ],
      }),
      _jsx("div", {
        className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6",
        children: stats.map((stat, index) => {
          const Icon = getIcon(stat.icon);
          return _jsx(
            Card,
            {
              className: "border-0 shadow-sm",
              children: _jsx(CardContent, {
                className: "p-6",
                children: _jsxs("div", {
                  className: "flex items-start justify-between",
                  children: [
                    _jsxs("div", {
                      children: [
                        _jsx("p", {
                          className: "text-sm text-gray-600 mb-1",
                          children: stat.title,
                        }),
                        _jsxs("div", {
                          className: "flex items-end gap-2",
                          children: [
                            _jsx("h3", {
                              className: "text-3xl text-gray-900",
                              children: stat.value,
                            }),
                            stat.change && _jsx("span", {
                              className: `text-sm mb-1 ${stat.trend === "up" ? "text-green-600" : "text-red-600"}`,
                              children: stat.change,
                            }),
                          ],
                        }),
                      ],
                    }),
                    _jsx("div", {
                      className: `w-12 h-12 rounded-xl flex items-center justify-center ${getColorClasses(stat.color)}`,
                      children: _jsx(Icon, { className: "w-6 h-6" }),
                    }),
                  ],
                }),
              }),
            },
            index,
          );
        }),
      }),
      _jsxs("div", {
        children: [
          _jsx("h2", {
            className: "text-lg text-gray-900 mb-4",
            children: "快捷功能",
          }),
          _jsx("div", {
            className: "grid grid-cols-1 md:grid-cols-3 gap-6",
            children: [
              { title: "学生信息导入", description: "批量导入学生信息", icon: Upload, link: "/teacher/student-import", color: "blue" },
              { title: "学生信息维护", description: "编辑和维护学生信息", icon: Edit, link: "/teacher/student-management", color: "purple" },
              { title: "分班管理", description: "管理课程班级信息", icon: BookOpen, link: "/teacher/class-management", color: "green" },
              { title: "题库选题", description: "从题库中选择题目", icon: Library, link: "/teacher/question-bank", color: "indigo" },
              { title: "课程任务管理", description: "创建和管理课程任务", icon: ClipboardList, link: "/teacher/task-management", color: "cyan" },
              { title: "成绩总览", description: "查看任务成绩分析", icon: BarChart3, link: "/teacher/grade-overview", color: "emerald" },
            ].map((action, index) => {
              const Icon = action.icon;
              const colorClasses = {
                blue: "bg-blue-600 hover:bg-blue-700",
                green: "bg-green-600 hover:bg-green-700",
                purple: "bg-purple-600 hover:bg-purple-700",
                indigo: "bg-indigo-600 hover:bg-indigo-700",
                cyan: "bg-cyan-600 hover:bg-cyan-700",
                emerald: "bg-emerald-600 hover:bg-emerald-700",
              };
              return _jsx(
                Link,
                {
                  to: action.link,
                  children: _jsx(Card, {
                    className: "border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer",
                    children: _jsx(CardContent, {
                      className: "p-6",
                      children: _jsxs("div", {
                        className: "flex items-start gap-4",
                        children: [
                          _jsx("div", {
                            className: `w-12 h-12 rounded-xl flex items-center justify-center ${colorClasses[action.color]}`,
                            children: _jsx(Icon, { className: "w-6 h-6 text-white" }),
                          }),
                          _jsxs("div", {
                            className: "flex-1",
                            children: [
                              _jsx("h3", { className: "text-gray-900 mb-1", children: action.title }),
                              _jsx("p", { className: "text-sm text-gray-600", children: action.description }),
                            ],
                          }),
                          _jsx(ArrowRight, { className: "w-5 h-5 text-gray-400" }),
                        ],
                      }),
                    }),
                  }),
                },
                index,
              );
            }),
          }),
        ],
      }),
      _jsxs("div", {
        className: "grid grid-cols-1 lg:grid-cols-2 gap-6",
        children: [
          _jsxs(Card, {
            className: "border-0 shadow-sm",
            children: [
              _jsx(CardHeader, {
                children: _jsx(CardTitle, { children: "最近导入记录" }),
              }),
              _jsx(CardContent, {
                children: [
                  _jsx("div", {
                    className: "space-y-4",
                    children: recentImports.length > 0 ? recentImports.map((item) =>
                      _jsxs("div", {
                        className: "flex items-start gap-3 pb-4 border-b border-gray-100 last:border-0 last:pb-0",
                        children: [
                          _jsx("div", {
                            className: "w-10 h-10 bg-green-50 rounded-lg flex items-center justify-center flex-shrink-0",
                            children: _jsx(CheckCircle, { className: "w-5 h-5 text-green-600" }),
                          }),
                          _jsxs("div", {
                            className: "flex-1 min-w-0",
                            children: [
                              _jsx("p", { className: "text-sm text-gray-900 truncate", children: item.file_name || item.fileName }),
                              _jsxs("div", { className: "flex items-center gap-3 mt-1", children: [
                                _jsxs("span", { className: "text-xs text-gray-500 flex items-center gap-1", children: [_jsx(Clock, { className: "w-3 h-3" }), item.import_time || item.date] }),
                                _jsx("span", { className: "text-xs text-blue-600", children: `${item.student_count || item.count} 名学生` }),
                              ]}),
                            ],
                          }),
                        ],
                      }, item.id || item.import_id)
                    ) : _jsx("p", { className: "text-sm text-gray-500 text-center py-4", children: "暂无导入记录" }),
                  }),
                  _jsx(Link, {
                    to: "/teacher/student-import",
                    children: _jsxs(Button, { variant: "ghost", className: "w-full mt-4", children: ["查看全部", _jsx(ArrowRight, { className: "w-4 h-4 ml-2" })] }),
                  }),
                ],
              }),
            ],
          }),
          _jsxs(Card, {
            className: "border-0 shadow-sm",
            children: [
              _jsx(CardHeader, { children: _jsx(CardTitle, { children: "最近成绩摘要" }) }),
              _jsx(CardContent, {
                children: [
                  _jsx("div", {
                    className: "space-y-4",
                    children: recentGrades.length > 0 ? recentGrades.map((item, index) =>
                      _jsxs("div", {
                        className: "pb-4 border-b border-gray-100 last:border-0 last:pb-0",
                        children: [
                          _jsxs("div", { className: "flex items-start justify-between mb-2", children: [
                            _jsxs("div", { className: "flex-1 min-w-0", children: [
                              _jsx("p", { className: "text-sm text-gray-900", children: item.course_name || item.course }),
                              _jsx("p", { className: "text-xs text-gray-600 mt-1", children: item.assignment_title || item.assignment }),
                            ]}),
                            _jsxs("div", { className: "text-right ml-4", children: [
                              _jsx("p", { className: "text-sm text-gray-900", children: `${item.avg_score || item.avgScore}分` }),
                              _jsx("p", { className: "text-xs text-gray-600 mt-1", children: "平均分" }),
                            ]}),
                          ]}),
                          _jsxs("div", { className: "flex items-center gap-2 mt-2", children: [
                            _jsx("div", { className: "flex-1 bg-gray-100 rounded-full h-2", children: _jsx("div", { className: "bg-blue-600 h-2 rounded-full", style: { width: `${((item.submitted_count || item.submitted) / (item.total_count || item.total)) * 100}%` } }) }),
                            _jsx("span", { className: "text-xs text-gray-600", children: `${item.submitted_count || item.submitted}/${item.total_count || item.total}` }),
                          ]}),
                        ],
                      }, index)
                    ) : _jsx("p", { className: "text-sm text-gray-500 text-center py-4", children: "暂无成绩数据" }),
                  }),
                  _jsx(Link, {
                    to: "/teacher/grade-overview",
                    children: _jsxs(Button, { variant: "ghost", className: "w-full mt-4", children: ["查看全部", _jsx(ArrowRight, { className: "w-4 h-4 ml-2" })] }),
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
