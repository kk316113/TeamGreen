import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Outlet, Link, useLocation, useNavigate } from "react-router";
import { Home, Upload, History, BarChart3, User, LogOut, Menu, CheckSquare, } from "lucide-react";
import { useState, useEffect } from "react";

export function StudentLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("student_token");
    const role = localStorage.getItem("student_role");
    if (!token || role !== "student") {
      navigate("/student/login", { replace: true });
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("student_token");
    localStorage.removeItem("student_role");
    navigate("/");
  };
 
  /**
   * 判断当前路径是否激活
   * @param {string} path - 要检查的路径
   * @returns {boolean} 如果当前路径匹配则返回true
   */
  const isActive = (path) => {
    return location.pathname === path;
  };
  return _jsxs("div", {
    className: "min-h-screen bg-gray-50",
    children: [
      // 顶部导航栏
      _jsx("header", {
        className:
          "bg-white border-b border-gray-100 fixed top-0 left-0 right-0 z-10 h-16",
        children: _jsxs("div", {
          className: "h-full px-6 flex items-center justify-between",
          children: [
            // 左侧区域：菜单按钮和品牌标识
            _jsxs("div", {
              className: "flex items-center gap-4",
              children: [
                // 侧边栏切换按钮
                _jsx("button", {
                  onClick: () => setSidebarOpen(!sidebarOpen),
                  className:
                    "p-2 hover:bg-gray-50 rounded-lg transition-colors",
                  children: _jsx(Menu, { className: "w-5 h-5 text-gray-500" }),
                }),
                // 品牌标识区域
                _jsxs("div", {
                  className: "flex items-center gap-3",
                  children: [
                    // Logo图标
                    _jsx("div", {
                      className:
                        "w-9 h-9 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-sm",
                      children: _jsx(BarChart3, {
                        className: "w-5 h-5 text-white",
                      }),
                    }),
                    // 品牌名称和标签
                    _jsxs("div", {
                      className: "flex items-center gap-2",
                      children: [
                        _jsx("h1", {
                          className: "text-xl font-semibold text-gray-900",
                          children: "AutoGrader",
                        }),
                        _jsx("span", {
                          className:
                            "px-2.5 py-0.5 bg-green-50 text-green-600 text-xs font-medium rounded-full",
                          children: "\u5B66\u751F\u7AEF",
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            }),
            // 右侧区域：用户信息和登出按钮
            _jsxs("div", {
              className: "flex items-center gap-4",
              children: [
                // 用户信息卡片
                _jsxs("div", {
                  className:
                    "flex items-center gap-3 px-3 py-2 bg-gray-50 rounded-xl",
                  children: [
                    // 用户头像
                    _jsx("div", {
                      className:
                        "w-8 h-8 bg-gradient-to-br from-green-500 to-green-600 rounded-lg flex items-center justify-center",
                      children: _jsx(User, { className: "w-4 h-4 text-white" }),
                    }),
                    // 用户详细信息
                    _jsxs("div", {
                      className: "text-sm",
                      children: [
                        _jsx("div", {
                          className: "text-gray-900 font-medium",
                          children: "\u5F20\u4E09",
                        }),
                        _jsx("div", {
                          className: "text-gray-500 text-xs",
                          children: "2024001",
                        }),
                      ],
                    }),
                  ],
                }),
                // 登出按钮
                _jsx("button", {
                  onClick: handleLogout,
                  className:
                    "p-2 hover:bg-gray-50 rounded-lg text-gray-500 hover:text-gray-700 transition-colors",
                  title: "\u9000\u51FA\u767B\u5F55",
                  children: _jsx(LogOut, { className: "w-5 h-5" }),
                }),
              ],
            }),
          ],
        }),
      }),
      // 侧边栏导航
      _jsx("aside", {
        className: `fixed left-0 top-16 bottom-0 bg-white border-r border-gray-100 transition-all duration-300 z-20 ${sidebarOpen ? "w-64" : "w-0 overflow-hidden"}`,
        children: _jsxs("nav", {
          className: "p-4 space-y-2",
          children: [
            // 首页导航项
            _jsxs(Link, {
              to: "/student",
              className: `flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                isActive("/student")
                  ? "bg-green-50 text-green-600 shadow-sm"
                  : "text-gray-600 hover:bg-gray-50"
              }`,
              children: [
                _jsx(Home, { className: "w-5 h-5" }),
                _jsx("span", {
                  className: "font-medium",
                  children: "\u9996\u9875",
                }),
              ],
            }),
            // 任务导航项
            _jsxs(Link, {
              to: "/student/tasks",
              className: `flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                isActive("/student/tasks")
                  ? "bg-green-50 text-green-600 shadow-sm"
                  : "text-gray-600 hover:bg-gray-50"
              }`,
              children: [
                _jsx(CheckSquare, { className: "w-5 h-5" }),
                _jsx("span", {
                  className: "font-medium",
                  children: "\u6211\u7684\u4EFB\u52A1",
                }),
              ],
            }),
            // 代码提交导航项
            _jsxs(Link, {
              to: "/student/submit",
              className: `flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                isActive("/student/submit")
                  ? "bg-green-50 text-green-600 shadow-sm"
                  : "text-gray-600 hover:bg-gray-50"
              }`,
              children: [
                _jsx(Upload, { className: "w-5 h-5" }),
                _jsx("span", {
                  className: "font-medium",
                  children: "\u63D0\u4EA4\u4EE3\u7801",
                }),
              ],
            }),
            // 历史记录导航项
            _jsxs(Link, {
              to: "/student/history",
              className: `flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                isActive("/student/history")
                  ? "bg-green-50 text-green-600 shadow-sm"
                  : "text-gray-600 hover:bg-gray-50"
              }`,
              children: [
                _jsx(History, { className: "w-5 h-5" }),
                _jsx("span", {
                  className: "font-medium",
                  children: "\u63D0\u4EA4\u5386\u53F2",
                }),
              ],
            }),
            // 成绩查询导航项
            _jsxs(Link, {
              to: "/student/grades",
              className: `flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                isActive("/student/grades")
                  ? "bg-green-50 text-green-600 shadow-sm"
                  : "text-gray-600 hover:bg-gray-50"
              }`,
              children: [
                _jsx(BarChart3, { className: "w-5 h-5" }),
                _jsx("span", {
                  className: "font-medium",
                  children: "\u6211\u7684\u6210\u7EE9",
                }),
              ],
            }),
            // 分隔线
            _jsx("div", {
              className: "pt-6 pb-2",
              children: _jsx("div", {
                className:
                  "px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider",
                children: "\u4E2A\u4EBA",
              }),
            }),
            // 个人中心导航项
            _jsxs(Link, {
              to: "/student/profile",
              className: `flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                isActive("/student/profile")
                  ? "bg-green-50 text-green-600 shadow-sm"
                  : "text-gray-600 hover:bg-gray-50"
              }`,
              children: [
                _jsx(User, { className: "w-5 h-5" }),
                _jsx("span", {
                  className: "font-medium",
                  children: "\u4E2A\u4EBA\u4E2D\u5FC3",
                }),
              ],
            }),
          ],
        }),
      }),
      // 主内容区域
      _jsx("main", {
        className: `pt-16 transition-all duration-300 ${sidebarOpen ? "ml-64" : "ml-0"}`,
        children: _jsx("div", { className: "p-8", children: _jsx(Outlet, {}) }),
      }),
    ],
  });
}
