import { Navigate, useLocation } from "react-router";
import { jsx as _jsx } from "react/jsx-runtime";

const ROLE_CONFIG = {
  teacher: {
    tokenKey: "token",
    roleKey: "user_role",
    loginPath: "/login",
    dashboardPath: "/teacher",
  },
  student: {
    tokenKey: "student_token",
    roleKey: "student_role",
    loginPath: "/student/login",
    dashboardPath: "/student",
  },
};

export function AuthGuard({ children, role = "teacher" }) {
  const location = useLocation();
  const config = ROLE_CONFIG[role];
  const token = localStorage.getItem(config.tokenKey);
  const userRole = localStorage.getItem(config.roleKey);

  if (!token) {
    return _jsx(Navigate, {
      to: config.loginPath,
      state: { from: location.pathname },
      replace: true,
    });
  }

  if (userRole && userRole !== role) {
    const from = config.dashboardPath;
    return _jsx(Navigate, {
      to: from,
      replace: true,
    });
  }

  return children;
}

export function GuestGuard({ children, role = "teacher" }) {
  const location = useLocation();
  const config = ROLE_CONFIG[role];
  const token = localStorage.getItem(config.tokenKey);

  if (token) {
    const from = location.state?.from || config.dashboardPath;
    return _jsx(Navigate, {
      to: from,
      replace: true,
    });
  }

  return children;
}

export function checkAuth(role = "teacher") {
  const config = ROLE_CONFIG[role];
  const token = localStorage.getItem(config.tokenKey);
  return !!token;
}

export function getToken(role = "teacher") {
  const config = ROLE_CONFIG[role];
  return localStorage.getItem(config.tokenKey);
}

export function setToken(token, role = "teacher") {
  const config = ROLE_CONFIG[role];
  localStorage.setItem(config.tokenKey, token);
  localStorage.setItem(config.roleKey, role);
}

export function removeToken(role = "teacher") {
  const config = ROLE_CONFIG[role];
  localStorage.removeItem(config.tokenKey);
  localStorage.removeItem(config.roleKey);
}

export function logout(role = "teacher") {
  removeToken(role);
  const config = ROLE_CONFIG[role];
  window.location.href = config.loginPath;
}
