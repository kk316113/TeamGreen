import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
//import { useState } from "react";
import { Link } from "react-router";
import { Search, Calendar, AlertCircle, CheckCircle, Clock, XCircle, FileCode, Eye, Send, BookOpen, } from "lucide-react";
import { Card, CardContent } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Badge } from "../../components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, } from "../../components/ui/select";
import { useState, useEffect } from "react";
// export function MyTasks() {
//     const [searchTerm, setSearchTerm] = useState("");
//     const [filterCourse, setFilterCourse] = useState("all");
//     const [filterStatus, setFilterStatus] = useState("all");
//     const courses = [
//         { id: "all", name: "全部课程" },
//         { id: "PY101", name: "Python程序设计" },
//         { id: "SH201", name: "Bash Shell程序设计" },
//     ];
//     const tasks = [
//         {
//             id: 1,
//             taskName: "实验4：列表与字典",
//             courseId: "PY101",
//             courseName: "Python程序设计",
//             deadline: "2026-05-06 23:59",
//             status: "pending",
//             statusText: "未提交",
//             daysLeft: 7,
//             description: "使用列表和字典数据结构存储和处理数据，按成绩从高到低排序输出学号",
//             difficulty: "中等",
//         },
//         {
//             id: 2,
//             taskName: "实验4：文件与进程操作",
//             courseId: "SH201",
//             courseName: "Bash Shell程序设计",
//             deadline: "2026-05-09 23:59",
//             status: "pending",
//             statusText: "未提交",
//             daysLeft: 10,
//             description: "编写脚本实现文件备份和进程监控功能，添加时间戳并检查备份是否成功",
//             difficulty: "困难",
//         },
//         {
//             id: 3,
//             taskName: "实验3：函数设计",
//             courseId: "PY101",
//             courseName: "Python程序设计",
//             deadline: "2026-04-29 23:59",
//             status: "submitted",
//             statusText: "已提交",
//             submitTime: "2026-04-28 16:30",
//             description: "定义函数实现特定功能，使用辗转相除法计算最大公约数",
//             difficulty: "中等",
//         },
//         {
//             id: 4,
//             taskName: "实验3：条件判断与循环",
//             courseId: "SH201",
//             courseName: "Bash Shell程序设计",
//             deadline: "2026-05-02 23:59",
//             status: "pending",
//             statusText: "未提交",
//             daysLeft: 4,
//             description: "使用if条件判断和for/while循环处理批量任务，列出所有.txt文件",
//             difficulty: "中等",
//         },
//         {
//             id: 5,
//             taskName: "实验2：分支与循环",
//             courseId: "PY101",
//             courseName: "Python程序设计",
//             deadline: "2026-04-22 23:59",
//             status: "graded",
//             statusText: "已评分",
//             score: 92,
//             submitTime: "2026-04-21 18:10",
//             description: "使用if-elif-else分支结构和for/while循环结构解决实际问题",
//             difficulty: "简单",
//         },
//         {
//             id: 6,
//             taskName: "实验2：Shell脚本编写",
//             courseId: "SH201",
//             courseName: "Bash Shell程序设计",
//             deadline: "2026-04-25 23:59",
//             status: "graded",
//             statusText: "已评分",
//             score: 88,
//             submitTime: "2026-04-24 20:45",
//             description: "编写完整的Shell脚本实现文本处理功能，统计文件行数、单词数和字符数",
//             difficulty: "中等",
//         },
//         {
//             id: 7,
//             taskName: "实验1：变量与输入输出",
//             courseId: "PY101",
//             courseName: "Python程序设计",
//             deadline: "2026-04-15 23:59",
//             status: "graded",
//             statusText: "已评分",
//             score: 95,
//             submitTime: "2026-04-14 19:20",
//             description: "掌握Python的基本数据类型、变量定义和输入输出操作，完成简单的计算任务",
//             difficulty: "简单",
//         },
//         {
//             id: 8,
//             taskName: "实验1：Linux基础命令",
//             courseId: "SH201",
//             courseName: "Bash Shell程序设计",
//             deadline: "2026-04-18 23:59",
//             status: "graded",
//             statusText: "已评分",
//             score: 90,
//             submitTime: "2026-04-17 15:30",
//             description: "编写Shell脚本使用基础Linux命令完成文件和目录操作，统计目录下的文件数量和子目录数量",
//             difficulty: "简单",
//         },
//     ];
//     const filteredTasks = tasks.filter((task) => {
//         const matchesSearch = task.taskName.toLowerCase().includes(searchTerm.toLowerCase()) ||
//             task.courseName.toLowerCase().includes(searchTerm.toLowerCase()) ||
//             task.description.toLowerCase().includes(searchTerm.toLowerCase());
//         const matchesCourse = filterCourse === "all" || task.courseId === filterCourse;
//         const matchesStatus = filterStatus === "all" || task.status === filterStatus;
//         return matchesSearch && matchesCourse && matchesStatus;
//     });
//     const getStatusBadge = (status, text) => {
//         const colorClasses = {
//             pending: "bg-orange-50 text-orange-700 border-orange-200",
//             submitted: "bg-blue-50 text-blue-700 border-blue-200",
//             graded: "bg-green-50 text-green-700 border-green-200",
//             overdue: "bg-red-50 text-red-700 border-red-200",
//         };
//         return (_jsx(Badge, { variant: "outline", className: colorClasses[status], children: text }));
//     };
//     const getStatusIcon = (status) => {
//         switch (status) {
//             case "pending":
//                 return _jsx(AlertCircle, { className: "w-5 h-5 text-orange-600" });
//             case "submitted":
//                 return _jsx(Clock, { className: "w-5 h-5 text-blue-600" });
//             case "graded":
//                 return _jsx(CheckCircle, { className: "w-5 h-5 text-green-600" });
//             case "overdue":
//                 return _jsx(XCircle, { className: "w-5 h-5 text-red-600" });
//             default:
//                 return null;
//         }
//     };
//     const getDifficultyBadge = (difficulty) => {
//         const colorClasses = {
//             简单: "bg-green-50 text-green-700",
//             中等: "bg-amber-50 text-amber-700",
//             困难: "bg-red-50 text-red-700",
//         };
//         return (_jsx(Badge, { variant: "secondary", className: colorClasses[difficulty], children: difficulty }));
//     };
//     const stats = [
//         {
//             label: "总任务数",
//             value: tasks.length,
//             color: "blue",
//         },
//         {
//             label: "待完成",
//             value: tasks.filter((t) => t.status === "pending").length,
//             color: "orange",
//         },
//         {
//             label: "已完成",
//             value: tasks.filter((t) => t.status === "graded").length,
//             color: "green",
//         },
//         {
//             label: "已截止",
//             value: tasks.filter((t) => t.status === "overdue").length,
//             color: "red",
//         },
//     ];
export function MyTasks() {
    const [searchTerm, setSearchTerm] = useState("");
    const [filterCourse, setFilterCourse] = useState("all");
    const [filterStatus, setFilterStatus] = useState("all");

    // ======================新增接口状态 ======================
    const [taskList, setTaskList] = useState([]);
    const [loading, setLoading] = useState(true);

    const courses = [
        { id: "all", name: "全部课程" },
        { id: "PY101", name: "Python程序设计" },
        { id: "SH201", name: "Bash Shell程序设计" },
    ];

    // ======================对接 B4 接口：获取作业列表 /api/v1/assignments ======================
    useEffect(() => {
        const fetchAssignments = async () => {
            try {
                setLoading(true);
                const token = localStorage.getItem("token");
                const res = await fetch("http://localhost:8000/api/v1/assignments", {
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${token}`
                    }
                });
                const data = await res.json();
                if (data.code === 0) {
                    // 接口数据映射为页面所需结构
                    const formattedTasks = data.data.items.map(item => ({
                        id: item.assignment_id,
                        taskName: item.title,
                        courseId: item.course_code || "PY101",
                        courseName: item.course_name || "Python程序设计",
                        deadline: item.end_time,
                        // 根据时间与提交状态判断
                        status: item.status || "pending",
                        statusText: item.status === "pending" ? "未提交" : item.status === "submitted" ? "已提交" : "已评分",
                        daysLeft: Math.max(0, Math.floor((new Date(item.end_time) - new Date()) / (1000 * 60 * 60 * 24))),
                        description: item.description,
                        difficulty: item.difficulty || "中等",
                        score: item.score,
                        submitTime: item.submit_time
                    }));
                    setTaskList(formattedTasks);
                }
            } catch (err) {
                console.error("获取作业列表失败", err);
            } finally {
                setLoading(false);
            }
        };

        fetchAssignments();
    }, []);

    // ======================使用接口数据替代模拟数据 ======================
    const filteredTasks = taskList.filter((task) => {
        const matchesSearch = task.taskName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            task.courseName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            task.description?.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesCourse = filterCourse === "all" || task.courseId === filterCourse;
        const matchesStatus = filterStatus === "all" || task.status === filterStatus;
        return matchesSearch && matchesCourse && matchesStatus;
    });

    const getStatusBadge = (status, text) => {
        const colorClasses = {
            pending: "bg-orange-50 text-orange-700 border-orange-200",
            submitted: "bg-blue-50 text-blue-700 border-blue-200",
            graded: "bg-green-50 text-green-700 border-green-200",
            overdue: "bg-red-50 text-red-700 border-red-200",
        };
        return (_jsx(Badge, { variant: "outline", className: colorClasses[status], children: text }));
    };

    const getStatusIcon = (status) => {
        switch (status) {
            case "pending": return _jsx(AlertCircle, { className: "w-5 h-5 text-orange-600" });
            case "submitted": return _jsx(Clock, { className: "w-5 h-5 text-blue-600" });
            case "graded": return _jsx(CheckCircle, { className: "w-5 h-5 text-green-600" });
            case "overdue": return _jsx(XCircle, { className: "w-5 h-5 text-red-600" });
            default: return null;
        }
    };

    const getDifficultyBadge = (difficulty) => {
        const colorClasses = {
            简单: "bg-green-50 text-green-700",
            中等: "bg-amber-50 text-amber-700",
            困难: "bg-red-50 text-red-700",
        };
        return (_jsx(Badge, { variant: "secondary", className: colorClasses[difficulty], children: difficulty }));
    };

    // ======================统计数据从接口数据计算 ======================
    const stats = [
        { label: "总任务数", value: taskList.length, color: "blue" },
        { label: "待完成", value: taskList.filter(t => t.status === "pending").length, color: "orange" },
        { label: "已完成", value: taskList.filter(t => t.status === "graded").length, color: "green" },
        { label: "已截止", value: taskList.filter(t => t.status === "overdue").length, color: "red" },
    ];

    // ======================加载状态 ======================
    if (loading) {
        return _jsx("div", { className: "p-10 text-center", children: "加载中..." });
    }
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { children: [_jsx("h1", { className: "text-2xl text-gray-900 mb-1", children: "\u6211\u7684\u4EFB\u52A1" }), _jsx("p", { className: "text-gray-600", children: "\u67E5\u770B\u8BFE\u7A0B\u4EFB\u52A1\u5217\u8868\uFF0C\u9009\u62E9\u4EFB\u52A1\u8FDB\u884C\u63D0\u4EA4" })] }), _jsx("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-6", children: stats.map((stat, index) => {
                    const colorClasses = {
                        blue: "bg-blue-50 text-blue-600",
                        green: "bg-green-50 text-green-600",
                        orange: "bg-orange-50 text-orange-600",
                        red: "bg-red-50 text-red-600",
                    };
                    return (_jsx(Card, { className: "border-0 shadow-sm", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "text-center", children: [_jsx("p", { className: `text-3xl mb-1 ${colorClasses[stat.color]}`, children: stat.value }), _jsx("p", { className: "text-sm text-gray-600", children: stat.label })] }) }) }, index));
                }) }), _jsx(Card, { className: "border-0 shadow-sm", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "flex flex-col lg:flex-row gap-4", children: [_jsxs("div", { className: "flex-1 relative", children: [_jsx(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" }), _jsx(Input, { placeholder: "\u641C\u7D22\u4EFB\u52A1\u540D\u79F0\u3001\u8BFE\u7A0B\u6216\u63CF\u8FF0...", value: searchTerm, onChange: (e) => setSearchTerm(e.target.value), className: "pl-10" })] }), _jsx("div", { className: "w-full lg:w-48", children: _jsxs(Select, { value: filterCourse, onValueChange: setFilterCourse, children: [_jsx(SelectTrigger, { children: _jsx(SelectValue, {}) }), _jsx(SelectContent, { children: courses.map((course) => (_jsx(SelectItem, { value: course.id, children: course.name }, course.id))) })] }) }), _jsx("div", { className: "w-full lg:w-48", children: _jsxs(Select, { value: filterStatus, onValueChange: setFilterStatus, children: [_jsx(SelectTrigger, { children: _jsx(SelectValue, {}) }), _jsxs(SelectContent, { children: [_jsx(SelectItem, { value: "all", children: "\u5168\u90E8\u72B6\u6001" }), _jsx(SelectItem, { value: "pending", children: "\u672A\u63D0\u4EA4" }), _jsx(SelectItem, { value: "submitted", children: "\u5DF2\u63D0\u4EA4" }), _jsx(SelectItem, { value: "graded", children: "\u5DF2\u8BC4\u5206" }), _jsx(SelectItem, { value: "overdue", children: "\u5DF2\u622A\u6B62" })] })] }) })] }) }) }), _jsx("div", { className: "grid grid-cols-1 gap-4", children: filteredTasks.map((task) => (_jsx(Card, { className: "border-0 shadow-sm hover:shadow-md transition-shadow", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "flex flex-col lg:flex-row gap-4", children: [_jsxs("div", { className: "flex-1 space-y-3", children: [_jsx("div", { className: "flex items-start justify-between gap-4", children: _jsxs("div", { className: "flex-1", children: [_jsxs("div", { className: "flex items-center gap-3 mb-2", children: [_jsx("h3", { className: "text-lg text-gray-900", children: task.taskName }), getDifficultyBadge(task.difficulty)] }), _jsxs("div", { className: "flex items-center gap-2 text-sm text-gray-600 mb-2", children: [_jsx(BookOpen, { className: "w-4 h-4" }), _jsx(Badge, { variant: "secondary", className: "bg-green-50 text-green-700", children: task.courseId }), _jsx("span", { children: task.courseName })] }), _jsx("p", { className: "text-sm text-gray-600 line-clamp-2", children: task.description })] }) }), _jsxs("div", { className: "flex flex-wrap items-center gap-4 text-sm", children: [_jsxs("div", { className: "flex items-center gap-2 text-gray-600", children: [_jsx(Calendar, { className: "w-4 h-4" }), _jsxs("span", { children: ["\u622A\u6B62\uFF1A", task.deadline] })] }), task.status === "pending" && task.daysLeft && (_jsxs(Badge, { variant: "secondary", className: task.daysLeft <= 3
                                                        ? "bg-red-50 text-red-700"
                                                        : "bg-gray-100 text-gray-700", children: ["\u5269\u4F59 ", task.daysLeft, " \u5929"] })), task.submitTime && (_jsxs("div", { className: "flex items-center gap-2 text-gray-600", children: [_jsx(Clock, { className: "w-4 h-4" }), _jsxs("span", { children: ["\u63D0\u4EA4\u65F6\u95F4\uFF1A", task.submitTime] })] })), task.score !== undefined && (_jsxs("div", { className: "flex items-center gap-2", children: [_jsx("span", { className: "text-gray-600", children: "\u5206\u6570\uFF1A" }), _jsx("span", { className: `text-lg ${task.score >= 90
                                                                ? "text-green-600"
                                                                : task.score >= 80
                                                                    ? "text-blue-600"
                                                                    : "text-amber-600"}`, children: task.score })] }))] })] }), _jsxs("div", { className: "flex lg:flex-col items-center gap-3 lg:justify-between lg:min-w-[140px]", children: [_jsxs("div", { className: "flex items-center gap-2", children: [getStatusIcon(task.status), getStatusBadge(task.status, task.statusText)] }), _jsxs("div", { className: "flex lg:flex-col gap-2 w-full", children: [_jsx(Link, { to: `/student/task-detail/${task.id}`, className: "flex-1", children: _jsxs(Button, { variant: "outline", size: "sm", className: "w-full gap-2", children: [_jsx(Eye, { className: "w-4 h-4" }), "\u67E5\u770B\u8BE6\u60C5"] }) }), task.status === "pending" && (_jsx(Link, { to: "/student/submit", className: "flex-1", children: _jsxs(Button, { size: "sm", className: "w-full gap-2 bg-blue-600 hover:bg-blue-700", children: [_jsx(Send, { className: "w-4 h-4" }), "\u53BB\u63D0\u4EA4"] }) })), task.status === "graded" && (_jsx(Link, { to: `/student/grade-detail/${task.id}`, className: "flex-1", children: _jsxs(Button, { size: "sm", variant: "outline", className: "w-full gap-2", children: [_jsx(FileCode, { className: "w-4 h-4" }), "\u67E5\u770B\u8BC4\u5206"] }) }))] })] })] }) }) }, task.id))) }), filteredTasks.length === 0 && (_jsx(Card, { className: "border-0 shadow-sm", children: _jsx(CardContent, { className: "py-12", children: _jsx("div", { className: "text-center", children: _jsx("p", { className: "text-gray-500", children: "\u6CA1\u6709\u627E\u5230\u5339\u914D\u7684\u4EFB\u52A1" }) }) }) }))] }));
}
