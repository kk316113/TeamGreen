import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { useNavigate, Link } from "react-router";
import { BarChart3, LogIn } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";

export function StudentLogin() {
    const navigate = useNavigate();
    const [studentId, setStudentId] = useState("");
    const [password, setPassword] = useState("");
    const [loading, setLoading] = useState(false);

    const handleLogin = async (e) => {
        e.preventDefault();

        if (!studentId || !password) {
            alert("请输入学号和密码");
            return;
        }

        setLoading(true);
        try {
            const res = await fetch("http://localhost:8000/api/v1/auth/login", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    username: studentId,
                    password: password,
                }),
            });

            const data = await res.json();
            if (data.code === 0) {
                localStorage.setItem("token", data.data.token);
                navigate("/student");
            } else {
                alert(data.message || "登录失败：学号或密码错误");
            }
        } catch (err) {
            console.error("登录请求异常", err);
            alert("登录失败，请检查网络或后端服务");
        } finally {
            setLoading(false);
        }
    };

    return (_jsx("div", { className: "min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 flex items-center justify-center p-4", children:
        _jsx("div", { className: "w-full max-w-md", children:
            _jsxs("div", { className: "bg-white rounded-2xl shadow-xl p-8", children: [
                _jsxs("div", { className: "text-center mb-8", children: [
                    _jsx("div", { className: "inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl mb-4 shadow-sm", children:
                        _jsx(BarChart3, { className: "w-8 h-8 text-white" })
                    }),
                    _jsx("h1", { className: "text-2xl font-semibold text-gray-900 mb-2", children: "AutoGrader" }),
                    _jsx("p", { className: "text-gray-500", children: "课程任务代码自动评分系统 - 学生端" })
                ]}),

                _jsxs("form", { onSubmit: handleLogin, className: "space-y-5", children: [
                    _jsxs("div", { className: "space-y-2", children: [
                        _jsx(Label, { htmlFor: "studentId", children: "学号" }),
                        _jsx(Input, {
                            id: "studentId",
                            type: "text",
                            placeholder: "请输入学号",
                            value: studentId,
                            onChange: (e) => setStudentId(e.target.value),
                            className: "h-11 border-gray-200",
                            disabled: loading
                        })
                    ]}),
                    _jsxs("div", { className: "space-y-2", children: [
                        _jsx(Label, { htmlFor: "password", children: "密码" }),
                        _jsx(Input, {
                            id: "password",
                            type: "password",
                            placeholder: "请输入密码",
                            value: password,
                            onChange: (e) => setPassword(e.target.value),
                            className: "h-11 border-gray-200",
                            disabled: loading
                        })
                    ]}),
                    _jsxs("div", { className: "flex items-center justify-between text-sm", children: [
                        _jsxs("label", { className: "flex items-center gap-2 text-gray-600 cursor-pointer", children: [
                            _jsx("input", { type: "checkbox", className: "rounded border-gray-300 text-green-600 focus:ring-green-500" }),
                            "记住我"
                        ]}),
                        _jsx(Link, { to: "/student/forgot-password", className: "text-green-600 hover:text-green-700 transition-colors", children: "忘记密码？" })
                    ]}),

                    _jsx(Button, {
                        type: "submit",
                        className: "w-full h-11 bg-green-600 hover:bg-green-700 shadow-sm",
                        disabled: loading,
                        children: loading ? "登录中..." : "登录"
                    })
                ]}),

                _jsx("div", { className: "mt-8 pt-6 border-t border-gray-100 text-center text-sm text-gray-500", children: "© 2024 AutoGrader. 学生端系统" })
            ]})
        })
    }));
}