import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useParams, Link } from "react-router";
import { ArrowLeft, Award, Calendar, FileCode, CheckCircle, XCircle, Clock, Download, AlertCircle, ThumbsUp, ThumbsDown, } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Badge } from "../../components/ui/badge";
import { Progress } from "../../components/ui/progress";
// import { useState, useEffect } from "react";

export function GradeDetail() {
    const { gradeId } = useParams();

    // ======================把写死数据改为状态变量
    const [gradeInfo, setGradeInfo] = useState(null);
    const [overallEvaluation, setOverallEvaluation] = useState(null);
    const [testCases, setTestCases] = useState([]);
    const [codeQuality, setCodeQuality] = useState(null);
    const [suggestions, setSuggestions] = useState([]);
    const [loading, setLoading] = useState(true);

    // ====================== 对接 B4 成绩详情接口
    useEffect(() => {
        const fetchGradeDetail = async () => {
            if (!gradeId) return;

            try {
                setLoading(true);
                const token = localStorage.getItem("token");
                const res = await fetch(`http://localhost:8000/api/v1/submissions/${gradeId}`, {
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`,
                    },
                });

                const data = await res.json();
                if (data.code !== 0) throw new Error("获取失败");

                const detail = data.data;
                setGradeInfo({
                    course: detail.course_name || "Python程序设计",
                    courseCode: detail.course_code || "PY101",
                    assignment: detail.assignment_title || "实验作业",
                    fileName: `${detail.problem_id}.py`,
                    submitTime: detail.created_at,
                    gradeTime: detail.judged_at || detail.created_at,
                    score: detail.score || 0,
                    maxScore: 100,
                    rank: detail.score >= 90 ? "优秀" : detail.score >= 80 ? "良好" : "及格",
                });

                setTestCases(detail.test_cases || []);
                setOverallEvaluation({
                    summary: detail.evaluation || "作业已完成评测",
                    strengths: detail.strengths || ["代码规范，逻辑清晰"],
                    improvements: detail.improvements || ["可优化性能"],
                });
                setCodeQuality(detail.code_quality || {
                    complexity: { score: 85, feedback: "代码复杂度适中" },
                    readability: { score: 90, feedback: "代码可读性好" },
                    maintainability: { score: 88, feedback: "结构合理" },
                    documentation: { score: 92, feedback: "注释完善" },
                });
                setSuggestions(detail.suggestions || [
                    { type: "优化建议", content: "建议优化递归", priority: "medium" },
                ]);
            } catch (err) {
                console.error("加载成绩详情失败", err);
            } finally {
                setLoading(false);
            }
        };

        fetchGradeDetail();
    }, [gradeId]);

    const passedTests = testCases.filter((t) => t.status === "passed").length;
    const totalTests = testCases.length;


    if (loading) {
        return _jsx("div", { className: "flex justify-center py-10", children: "加载中..." });
    }

    return (_jsxs("div", { className: "space-y-6", children: [
        _jsx(Link, { to: "/student/grades", children:
            _jsxs(Button, { variant: "ghost", className: "gap-2", children: [
                _jsx(ArrowLeft, { className: "w-4 h-4" }),
                "返回成绩列表"
            ]})
        }),
        _jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-6", children: [
            _jsxs(Card, { className: "border-0 shadow-sm lg:col-span-2", children: [
                _jsx(CardHeader, { children: _jsx(CardTitle, { children: "作业信息" }) }),
                _jsxs(CardContent, { className: "space-y-4", children: [
                    _jsxs("div", { children: [
                        _jsx("h3", { className: "text-lg text-gray-900 mb-1", children: gradeInfo.assignment }),
                        _jsxs("p", { className: "text-sm text-gray-600", children: [gradeInfo.courseCode, " - ", gradeInfo.course] })
                    ]}),
                    _jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
                        _jsxs("div", { className: "flex items-center gap-3", children: [
                            _jsx(FileCode, { className: "w-5 h-5 text-gray-400" }),
                            _jsxs("div", { children: [
                                _jsx("p", { className: "text-xs text-gray-600", children: "提交文件" }),
                                _jsx("p", { className: "text-sm text-gray-900", children: gradeInfo.fileName })
                            ]})
                        ]}),
                        _jsxs("div", { className: "flex items-center gap-3", children: [
                            _jsx(Calendar, { className: "w-5 h-5 text-gray-400" }),
                            _jsxs("div", { children: [
                                _jsx("p", { className: "text-xs text-gray-600", children: "提交时间" }),
                                _jsx("p", { className: "text-sm text-gray-900", children: gradeInfo.submitTime })
                            ]})
                        ]}),
                        _jsxs("div", { className: "flex items-center gap-3", children: [
                            _jsx(Clock, { className: "w-5 h-5 text-gray-400" }),
                            _jsxs("div", { children: [
                                _jsx("p", { className: "text-xs text-gray-600", children: "评分时间" }),
                                _jsx("p", { className: "text-sm text-gray-900", children: gradeInfo.gradeTime })
                            ]})
                        ]}),
                        _jsxs("div", { className: "flex items-center gap-3", children: [
                            _jsx(CheckCircle, { className: "w-5 h-5 text-green-600" }),
                            _jsxs("div", { children: [
                                _jsx("p", { className: "text-xs text-gray-600", children: "测试通过率" }),
                                _jsxs("p", { className: "text-sm text-gray-900", children: [passedTests, "/", totalTests, " (", ((passedTests / totalTests) * 100).toFixed(0), "%)"] })
                            ]})
                        ]})
                    ]}),
                    _jsxs("div", { className: "pt-4 border-t border-gray-100 flex gap-2", children: [
                        _jsx(Badge, { variant: "secondary", className: "bg-green-50 text-green-700", children: "已评分" }),
                        _jsx(Badge, { variant: "secondary", className: "bg-blue-50 text-blue-700", children: gradeInfo.rank })
                    ]})
                ]})
            ]}),
            _jsxs(Card, { className: "border-0 shadow-sm", children: [
                _jsx(CardHeader, { children: _jsx(CardTitle, { children: "总得分" }) }),
                _jsx(CardContent, { children: _jsxs("div", { className: "text-center", children: [
                    _jsx("div", { className: "inline-flex items-center justify-center w-32 h-32 rounded-full bg-gradient-to-br from-green-500 to-green-600 mb-4", children:
                        _jsxs("div", { className: "text-center", children: [
                            _jsx("p", { className: "text-4xl text-white", children: gradeInfo.score }),
                            _jsxs("p", { className: "text-sm text-green-100", children: ["/ ", gradeInfo.maxScore] })
                        ]})
                    }),
                    _jsxs("div", { className: "flex items-center justify-center gap-2 text-green-600", children: [
                        _jsx(Award, { className: "w-5 h-5" }),
                        _jsx("span", { children: gradeInfo.rank })
                    ]}),
                    _jsxs(Button, { variant: "outline", className: "w-full mt-4 gap-2", children: [
                        _jsx(Download, { className: "w-4 h-4" }),
                        "下载代码"
                    ]})
                ]}) })
            ]})
        ]}),
        _jsxs(Card, { className: "border-0 shadow-sm", children: [
            _jsx(CardHeader, { children: _jsx(CardTitle, { children: "总体评价" }) }),
            _jsxs(CardContent, { className: "space-y-4", children: [
                _jsx("p", { className: "text-gray-700 leading-relaxed", children: overallEvaluation.summary }),
                _jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6 pt-4", children: [
                    _jsxs("div", { children: [
                        _jsxs("div", { className: "flex items-center gap-2 mb-3", children: [
                            _jsx(ThumbsUp, { className: "w-5 h-5 text-green-600" }),
                            _jsx("h4", { className: "text-sm text-gray-900", children: "优点" })
                        ]}),
                        _jsx("ul", { className: "space-y-2", children: overallEvaluation.strengths.map((item, index) =>
                            _jsxs("li", { className: "flex items-start gap-2 text-sm", children: [
                                _jsx(CheckCircle, { className: "w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" }),
                                _jsx("span", { className: "text-gray-700", children: item })
                            ]}, index)
                        )})
                    ]}),
                    _jsxs("div", { children: [
                        _jsxs("div", { className: "flex items-center gap-2 mb-3", children: [
                            _jsx(ThumbsDown, { className: "w-5 h-5 text-amber-600" }),
                            _jsx("h4", { className: "text-sm text-gray-900", children: "改进建议" })
                        ]}),
                        _jsx("ul", { className: "space-y-2", children: overallEvaluation.improvements.map((item, index) =>
                            _jsxs("li", { className: "flex items-start gap-2 text-sm", children: [
                                _jsx(AlertCircle, { className: "w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" }),
                                _jsx("span", { className: "text-gray-700", children: item })
                            ]}, index)
                        )})
                    ]})
                ]})
            ]})
        ]}),
        _jsxs(Card, { className: "border-0 shadow-sm", children: [
            _jsx(CardHeader, { children: _jsx(CardTitle, { children: "测试用例详情" }) }),
            _jsx(CardContent, { className: "space-y-3", children: testCases.map((test) =>
                _jsxs("div", { className: `border rounded-lg p-4 ${test.status === "passed" ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}`, children: [
                    _jsxs("div", { className: "flex items-start justify-between mb-2", children: [
                        _jsxs("div", { className: "flex items-start gap-3 flex-1", children: [
                            test.status === "passed" ?
                                _jsx(CheckCircle, { className: "w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" }) :
                                _jsx(XCircle, { className: "w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" }),
                            _jsxs("div", { className: "flex-1 min-w-0", children: [
                                _jsx("h4", { className: "text-sm text-gray-900 mb-1", children: test.name }),
                                _jsx("p", { className: "text-xs text-gray-600 mb-2", children: test.description }),
                                test.errorMsg && _jsx("p", { className: "text-xs text-red-700 bg-red-100 px-2 py-1 rounded", children: test.errorMsg })
                            ]})
                        ]}),
                        _jsx("div", { className: "text-right ml-4", children:
                            _jsxs("p", { className: `${test.status === "passed" ? "text-green-700" : "text-red-700"} text-sm`, children: [test.score, "/", test.maxScore] })
                        })
                    ]}),
                    _jsxs("div", { className: "flex items-center gap-4 text-xs text-gray-600 ml-8", children: [
                        _jsxs("span", { children: ["运行时间: ", test.runtime] }),
                        _jsx("span", { children: "•" }),
                        _jsxs("span", { children: ["内存: ", test.memory] })
                    ]})
                ]}, test.id)
            )})
        ]}),
        _jsxs(Card, { className: "border-0 shadow-sm", children: [
            _jsx(CardHeader, { children: _jsx(CardTitle, { children: "代码质量分析" }) }),
            _jsx(CardContent, { className: "space-y-4", children: Object.entries(codeQuality).map(([key, value]) => {
                const labels = {
                    complexity: "代码复杂度",
                    readability: "可读性",
                    maintainability: "可维护性",
                    documentation: "文档完整性",
                };
                return (_jsxs("div", { children: [
                    _jsxs("div", { className: "flex justify-between mb-2", children: [
                        _jsx("span", { className: "text-sm text-gray-600", children: labels[key] }),
                        _jsxs("span", { className: "text-sm text-gray-900", children: [value.score, "%"] })
                    ]}),
                    _jsx(Progress, { value: value.score, className: "h-2 mb-2" }),
                    _jsx("p", { className: "text-xs text-gray-600", children: value.feedback })
                ]}, key));
            }) })
        ]}),
        _jsxs(Card, { className: "border-0 shadow-sm", children: [
            _jsx(CardHeader, { children: _jsx(CardTitle, { children: "改进建议" }) }),
            _jsx(CardContent, { className: "space-y-3", children: suggestions.map((suggestion, index) => {
                const priorityColors = {
                    high: "bg-red-50 text-red-700 border-red-200",
                    medium: "bg-amber-50 text-amber-700 border-amber-200",
                    low: "bg-blue-50 text-blue-700 border-blue-200",
                };
                return (_jsxs("div", { className: "flex items-start gap-3 p-4 bg-gray-50 rounded-lg", children: [
                    _jsx(AlertCircle, { className: "w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" }),
                    _jsxs("div", { className: "flex-1", children: [
                        _jsxs("div", { className: "flex items-center gap-2 mb-1", children: [
                            _jsx("h4", { className: "text-sm text-gray-900", children: suggestion.type }),
                            _jsx(Badge, { variant: "outline", className: `text-xs ${priorityColors[suggestion.priority]}`, children:
                                suggestion.priority === "high" ? "高优先级"
                                : suggestion.priority === "medium" ? "中优先级"
                                : "低优先级"
                            })
                        ]}),
                        _jsx("p", { className: "text-sm text-gray-700", children: suggestion.content })
                    ]})
                ]}, index));
            }) })
        ]})
    ]}));
}