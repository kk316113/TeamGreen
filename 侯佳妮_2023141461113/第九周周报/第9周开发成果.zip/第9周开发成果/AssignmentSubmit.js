import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState, useRef } from "react";
import Editor from "@monaco-editor/react";
import { Upload, Play, Send, Save, RotateCcw, CheckCircle, XCircle, Clock, FileCode, ChevronDown, ChevronUp, Mail, AlertCircle, Info, } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, } from "../../components/ui/select";
import { Badge } from "../../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/ui/tabs";
import React, { useEffect } from 'react';
export function AssignmentSubmit() {
    const [selectedCourse, setSelectedCourse] = useState("");
    const [selectedAssignment, setSelectedAssignment] = useState("");
    const [code, setCode] = useState("");
    const [isRunning, setIsRunning] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [runResult, setRunResult] = useState(null);
    const [submitResult, setSubmitResult] = useState(null);
    const [showResult, setShowResult] = useState(true);
    const fileInputRef = useRef(null);
    // const courses = [
    //     { id: "PY101", name: "Python程序设计", language: "python" },
    //     { id: "SH201", name: "Bash Shell程序设计", language: "shell" },
    // ];
    // const assignments = {
    //     PY101: [
    //         {
    //             id: "lab1",
    //             name: "实验1：变量与输入输出",
    //             deadline: "2026-04-15 23:59",
    //             description: "掌握Python的基本数据类型、变量定义和输入输出操作，完成简单的计算任务",
    //             input: "第一行输入整数n\n第二行输入n个整数，用空格分隔",
    //             output: "输出这n个整数的总和与平均值，用空格分隔，保留两位小数",
    //             sampleInput: "5\n10 20 30 40 50",
    //             sampleOutput: "150 30.00",
    //             requirements: "1. 使用input()函数获取输入\n2. 使用print()函数输出结果\n3. 注意数据类型转换\n4. 输出格式严格一致",
    //             limits: "时间限制：1秒\n内存限制：128MB"
    //         },
    //         {
    //             id: "lab2",
    //             name: "实验2：分支与循环",
    //             deadline: "2026-04-22 23:59",
    //             description: "使用if-elif-else分支结构和for/while循环结构解决实际问题",
    //             input: "输入一个正整数n",
    //             output: "输出1到n之间所有偶数的和",
    //             sampleInput: "10",
    //             sampleOutput: "30",
    //             requirements: "1. 正确使用循环结构\n2. 判断偶数条件\n3. 累加求和",
    //             limits: "时间限制：1秒\n内存限制：128MB"
    //         },
    //         {
    //             id: "lab3",
    //             name: "实验3：函数设计",
    //             deadline: "2026-04-29 23:59",
    //             description: "定义函数实现特定功能，理解函数参数、返回值和作用域",
    //             input: "输入两个整数a和b",
    //             output: "输出a和b的最大公约数",
    //             sampleInput: "12 18",
    //             sampleOutput: "6",
    //             requirements: "1. 定义函数gcd(a, b)\n2. 使用辗转相除法\n3. 返回计算结果",
    //             limits: "时间限制：1秒\n内存限制：128MB"
    //         },
    //         {
    //             id: "lab4",
    //             name: "实验4：列表与字典",
    //             deadline: "2026-05-06 23:59",
    //             description: "使用列表和字典数据结构存储和处理数据",
    //             input: "第一行输入学生人数n\n接下来n行，每行包含学号和成绩，用空格分隔",
    //             output: "按成绩从高到低输出学号",
    //             sampleInput: "3\n2024001 85\n2024002 92\n2024003 78",
    //             sampleOutput: "2024002\n2024001\n2024003",
    //             requirements: "1. 使用字典存储学号和成绩\n2. 按成绩排序\n3. 输出学号列表",
    //             limits: "时间限制：1秒\n内存限制：128MB"
    //         },
    //     ],
    //     SH201: [
    //         {
    //             id: "lab1",
    //             name: "实验1：Linux基础命令",
    //             deadline: "2026-04-18 23:59",
    //             description: "编写Shell脚本使用基础Linux命令完成文件和目录操作",
    //             input: "脚本接收一个目录路径作为参数",
    //             output: "统计该目录下的文件数量和子目录数量",
    //             sampleInput: "./test_dir",
    //             sampleOutput: "Files: 15\nDirectories: 3",
    //             requirements: "1. 使用ls、find等命令\n2. 处理命令行参数\n3. 使用wc统计数量",
    //             limits: "执行时间：5秒"
    //         },
    //         {
    //             id: "lab2",
    //             name: "实验2：Shell脚本编写",
    //             deadline: "2026-04-25 23:59",
    //             description: "编写完整的Shell脚本实现文本处理功能",
    //             input: "文本文件路径",
    //             output: "输出文件的行数、单词数和字符数",
    //             sampleInput: "./sample.txt",
    //             sampleOutput: "Lines: 50\nWords: 320\nCharacters: 1856",
    //             requirements: "1. 使用#!/bin/bash声明\n2. 检查文件是否存在\n3. 使用wc命令统计",
    //             limits: "执行时间：5秒"
    //         },
    //         {
    //             id: "lab3",
    //             name: "实验3：条件判断与循环",
    //             deadline: "2026-05-02 23:59",
    //             description: "使用if条件判断和for/while循环处理批量任务",
    //             input: "目录路径",
    //             output: "列出所有.txt文件的文件名",
    //             sampleInput: "./documents",
    //             sampleOutput: "file1.txt\nfile2.txt\nfile3.txt",
    //             requirements: "1. 使用if判断文件类型\n2. 使用for循环遍历\n3. 使用通配符匹配",
    //             limits: "执行时间：10秒"
    //         },
    //         {
    //             id: "lab4",
    //             name: "实验4：文件与进程操作",
    //             deadline: "2026-05-09 23:59",
    //             description: "编写脚本实现文件备份和进程监控功能",
    //             input: "源文件路径和目标目录",
    //             output: "备份文件并输出备份路径",
    //             sampleInput: "./data.txt ./backup/",
    //             sampleOutput: "Backup created: ./backup/data.txt.bak",
    //             requirements: "1. 使用cp命令备份\n2. 添加时间戳\n3. 检查备份是否成功",
    //             limits: "执行时间：10秒"
    //         },
    //     ],
    // };
    // // 处理文件上传（导入代码到编辑器）
    // const handleFileUpload = (e) => {
    //     if (e.target.files && e.target.files[0]) {
    //         const file = e.target.files[0];
    //         const reader = new FileReader();
    //         reader.onload = (event) => {
    //             if (event.target?.result) {
    //                 setCode(event.target.result);
    //             }
    //         };
    //         reader.readAsText(file);
    //     }
    // };
    // // 运行代码
    // const handleRun = () => {
    //     if (!code.trim()) {
    //         alert("请先编写代码");
    //         return;
    //     }
    //     setIsRunning(true);
    //     setShowResult(true);
    //     // 模拟代码运行
    //     setTimeout(() => {
    //         setRunResult({
    //             status: "success",
    //             output: "150 30.00\n",
    //             error: "",
    //             executionTime: "0.023s",
    //             memory: "2.4MB",
    //         });
    //         setIsRunning(false);
    //     }, 1500);
    // };
    // // 提交代码
    // const handleSubmit = () => {
    //     if (!selectedCourse || !selectedAssignment) {
    //         alert("请选择课程和任务");
    //         return;
    //     }
    //     if (!code.trim()) {
    //         alert("请先编写代码");
    //         return;
    //     }
    //     setIsSubmitting(true);
    //     setShowResult(true);
    //     // 模拟提交和评测
    //     setTimeout(() => {
    //         setSubmitResult({
    //             status: "accepted",
    //             score: 95,
    //             totalScore: 100,
    //             testCases: [
    //                 { id: 1, name: "测试点1", status: "passed", time: "0.012s", memory: "2.1MB" },
    //                 { id: 2, name: "测试点2", status: "passed", time: "0.018s", memory: "2.3MB" },
    //                 { id: 3, name: "测试点3", status: "passed", time: "0.015s", memory: "2.2MB" },
    //                 { id: 4, name: "测试点4", status: "failed", time: "0.020s", memory: "2.4MB", error: "输出格式错误" },
    //                 { id: 5, name: "测试点5", status: "passed", time: "0.016s", memory: "2.3MB" },
    //             ],
    //             submitTime: new Date().toLocaleString(),
    //         });
    //         setIsSubmitting(false);
    //     }, 2500);
    // };
    // // 保存草稿
    // const handleSaveDraft = () => {
    //     alert("草稿已保存");
    // };
    // // 重置代码
    // const handleReset = () => {
    //     if (confirm("确定要重置代码吗？")) {
    //         setCode("");
    //         setRunResult(null);
    //         setSubmitResult(null);
    //     }
    // };
    // const currentAssignments = selectedCourse
    //     ? assignments[selectedCourse] || []
    //     : [];
    // const selectedAssignmentInfo = currentAssignments.find((a) => a.id === selectedAssignment);
    // const selectedCourseInfo = courses.find((c) => c.id === selectedCourse);
    // const editorLanguage = selectedCourseInfo?.language === "python" ? "python" : "shell";
    // const emailInfo = {
    //     email: "autograder@school.edu.cn",
    //     subjectFormat: "[课程编号]-[学号]-[作业名称]",
    //     examples: [
    //         { course: "PY101", student: "2024001", task: "实验2", subject: "PY101-2024001-实验2" },
    //         { course: "SH201", student: "2024002", task: "实验3", subject: "SH201-2024002-实验3" },
    //     ],
    //     attachmentFormat: "学号_姓名_作业名称",
    //     attachmentExamples: [
    //         "2024001_张三_实验2.py",
    //         "2024002_李四_实验3.sh",
    //         "2024003_王五_实验1.zip",
    //     ],
    //     supportedFormats: [".py", ".sh", ".zip"],
    //     maxSize: "10MB",
    //     syncTime: "5-10分钟",
    // };
    const [assignmentList, setAssignmentList] = useState([]);
    const [problemMap, setProblemMap] = useState({});

    const courses = [
        { id: "PY101", name: "Python程序设计", language: "python" },
        { id: "SH201", name: "Bash Shell程序设计", language: "shell" },
    ];

    // ======================新增 useEffect 获取作业列表（/api/v1/assignments） ======================
    useEffect(() => {
        const fetchAssignments = async () => {
            try {
                const token = localStorage.getItem("student_token");
                const res = await fetch("http://localhost:8000/api/v1/assignments", {
                    headers: {
                        "Authorization": `Bearer ${token}`,
                        "Content-Type": "application/json"
                    }
                });
                const data = await res.json();
                if (data.code === 0) {
                    setAssignmentList(data.data.items);
                }
            } catch (err) {
                console.error("获取作业列表失败", err);
            }
        };
        fetchAssignments();
    }, []);

    // ======================新增 根据 assignment_id 获取题目详情 ======================
    const fetchProblemDetail = async (problem_id) => {
        try {
            const token = localStorage.getItem("student_token");
            const res = await fetch(`http://localhost:8000/api/v1/problems/${problem_id}`, {
                headers: {
                    "Authorization": `Bearer ${token}`,
                    "Content-Type": "application/json"
                }
            });
            const data = await res.json();
            if (data.code === 0) {
                setProblemMap(prev => ({ ...prev, [problem_id]: data.data }));
            }
        } catch (err) {
            console.error("获取题目详情失败", err);
        }
    };

    const handleFileUpload = (e) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            const reader = new FileReader();
            reader.onload = (event) => {
                if (event.target?.result) {
                    setCode(event.target.result);
                }
            };
            reader.readAsText(file);
        }
    };

    const handleRun = () => {
        if (!code.trim()) {
            alert("请先编写代码");
            return;
        }
        setIsRunning(true);
        setShowResult(true);
        setTimeout(() => {
            setRunResult({
                status: "success",
                output: "运行成功\n",
                error: "",
                executionTime: "0.023s",
                memory: "2.4MB",
            });
            setIsRunning(false);
        }, 800);
    };

    // =====================对接真实提交接口 /api/v1/submissions ======================
    const handleSubmit = async () => {
        if (!selectedAssignment || !code.trim()) {
            alert("请选择作业并编写代码");
            return;
        }

        setIsSubmitting(true);
        setShowResult(true);

        try {
            const token = localStorage.getItem("student_token");
            const assign = assignmentList.find(a => a.assignment_id == selectedAssignment);

            // 按 B4 接口提交参数
            const submitData = {
                assignment_id: Number(selectedAssignment),
                problem_id: assign?.problem_ids[0] || 0,
                language: "python",
                code: code
            };

            const res = await fetch("http://localhost:8000/api/v1/submissions", {
                method: "POST",
                headers: {
                    "Authorization": `Bearer ${token}`,
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(submitData)
            });

            const data = await res.json();
            if (data.code === 0) {
                setSubmitResult({
                    status: "accepted",
                    score: null,
                    totalScore: 100,
                    testCases: [],
                    submitTime: new Date().toLocaleString(),
                    submission_id: data.data.submission_id
                });

                // 提交后轮询状态
                startStatusPoll(data.data.submission_id);
            } else {
                alert(data.message || "提交失败");
            }
        } catch (err) {
            console.error(err);
            alert("提交异常");
        } finally {
            setIsSubmitting(false);
        }
    };

    // ====================== 新增轮询查询提交状态 /api/v1/submissions/{id}/status ======================
    const startStatusPoll = (submissionId) => {
        const token = localStorage.getItem("student_token");
        const timer = setInterval(async () => {
            try {
                const res = await fetch(`http://localhost:8000/api/v1/submissions/${submissionId}/status`, {
                    headers: {
                        "Authorization": `Bearer ${token}`,
                        "Content-Type": "application/json"
                    }
                });
                const data = await res.json();
                if (data.code === 0) {
                    const status = data.data.status;
                    if (status === "finished" || status === "failed") {
                        clearInterval(timer);
                        fetchSubmitDetail(submissionId);
                    }
                }
            } catch (err) {
                clearInterval(timer);
            }
        }, 2000);
    };

    // ======================获取提交详情（含成绩） ======================
    const fetchSubmitDetail = async (submissionId) => {
        const token = localStorage.getItem("student_token");
        const res = await fetch(`http://localhost:8000/api/v1/submissions/${submissionId}`, {
            headers: {
                "Authorization": `Bearer ${token}`,
                "Content-Type": "application/json"
            }
        });
        const data = await res.json();
        if (data.code === 0) {
            setSubmitResult(prev => ({
                ...prev,
                score: data.data.score || 0,
                status: data.data.status === "finished" ? "accepted" : "failed"
            }));
        }
    };

    const handleSaveDraft = () => {
        localStorage.setItem(`draft_${selectedAssignment}`, code);
        alert("草稿已保存");
    };

    const handleReset = () => {
        if (confirm("确定要重置代码吗？")) {
            setCode("");
            setRunResult(null);
            setSubmitResult(null);
        }
    };

    const currentAssignments = selectedCourse
        ? assignments[selectedCourse] || []
        : [];
    const selectedAssignmentInfo = currentAssignments.find((a) => a.id === selectedAssignment);
    const selectedCourseInfo = courses.find((c) => c.id === selectedCourse);
    const editorLanguage = selectedCourseInfo?.language === "python" ? "python" : "shell";

    // ======================下拉选项从接口赋值 ======================
    const showAssignmentList = assignmentList;

    const emailInfo = {
        email: "autograder@school.edu.cn",
        subjectFormat: "[课程编号]-[学号]-[作业名称]",
        examples: [
            { course: "PY101", student: "2024001", task: "实验2", subject: "PY101-2024001-实验2" },
        ],
        attachmentFormat: "学号_姓名_作业名称",
        attachmentExamples: [
            "2024001_张三_实验2.py",
        ],
        supportedFormats: [".py", ".sh", ".zip"],
        maxSize: "10MB",
        syncTime: "5-10分钟",
    };
    return (_jsxs("div", { className: "space-y-4", children: [_jsxs("div", { children: [_jsx("h1", { className: "text-2xl text-gray-900 mb-1", children: "\u63D0\u4EA4\u4EE3\u7801" }), _jsx("p", { className: "text-gray-600", children: "\u5728\u7EBF\u7F16\u5199\u63D0\u4EA4\u4EE3\u7801\uFF0C\u6216\u901A\u8FC7\u90AE\u4EF6\u65B9\u5F0F\u63D0\u4EA4\u4F5C\u4E1A" })] }), _jsxs(Tabs, { defaultValue: "online", className: "space-y-4", children: [_jsxs(TabsList, { className: "grid w-full max-w-md grid-cols-2", children: [_jsxs(TabsTrigger, { value: "online", className: "gap-2", children: [_jsx(FileCode, { className: "w-4 h-4" }), "\u5728\u7EBF\u63D0\u4EA4"] }), _jsxs(TabsTrigger, { value: "email", className: "gap-2", children: [_jsx(Mail, { className: "w-4 h-4" }), "\u90AE\u4EF6\u63D0\u4EA4"] })] }), _jsxs(TabsContent, { value: "online", className: "space-y-4", children: [_jsx(Card, { className: "border-0 shadow-sm", children: _jsx(CardContent, { className: "p-4", children: _jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [_jsxs("div", { className: "space-y-2", children: [_jsx("label", { className: "text-sm text-gray-700", children: "\u8BFE\u7A0B" }), _jsxs(Select, { value: selectedCourse, onValueChange: (value) => {
                                                            setSelectedCourse(value);
                                                            setSelectedAssignment("");
                                                            setCode("");
                                                            setRunResult(null);
                                                            setSubmitResult(null);
                                                        }, children: [_jsx(SelectTrigger, { children: _jsx(SelectValue, { placeholder: "\u8BF7\u9009\u62E9\u8BFE\u7A0B" }) }), _jsx(SelectContent, { children: courses.map((course) => (_jsxs(SelectItem, { value: course.id, children: [course.id, " - ", course.name] }, course.id))) })] })] }), _jsxs("div", { className: "space-y-2", children: [_jsx("label", { className: "text-sm text-gray-700", children: "\u4EFB\u52A1" }), _jsxs(Select, { value: selectedAssignment, onValueChange: (value) => {
                                                            setSelectedAssignment(value);
                                                            setCode("");
                                                            setRunResult(null);
                                                            setSubmitResult(null);
                                                        }, disabled: !selectedCourse, children: [_jsx(SelectTrigger, { children: _jsx(SelectValue, { placeholder: "\u8BF7\u5148\u9009\u62E9\u8BFE\u7A0B" }) }), _jsx(SelectContent, { children: currentAssignments.map((assignment) => (_jsx(SelectItem, { value: assignment.id, children: assignment.name }, assignment.id))) })] })] })] }) }) }), selectedAssignmentInfo ? (_jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-5 gap-4", children: [_jsx("div", { className: "lg:col-span-2", children: _jsxs(Card, { className: "border-0 shadow-sm h-full", children: [_jsx(CardHeader, { className: "border-b border-gray-100", children: _jsxs("div", { className: "flex items-start justify-between", children: [_jsxs("div", { className: "flex-1", children: [_jsx(CardTitle, { className: "text-lg mb-2", children: selectedAssignmentInfo.name }), _jsxs("div", { className: "flex items-center gap-2 text-sm text-gray-600", children: [_jsx(Clock, { className: "w-4 h-4" }), _jsxs("span", { children: ["\u622A\u6B62\u65F6\u95F4\uFF1A", selectedAssignmentInfo.deadline] })] })] }), _jsx(Badge, { className: "bg-green-50 text-green-700 border-green-200", children: selectedCourseInfo?.name })] }) }), _jsxs(CardContent, { className: "p-6 space-y-6 overflow-y-auto", style: { maxHeight: "calc(100vh - 320px)" }, children: [_jsxs("div", { children: [_jsx("h3", { className: "text-sm font-semibold text-gray-900 mb-2", children: "\u9898\u76EE\u63CF\u8FF0" }), _jsx("p", { className: "text-sm text-gray-700 leading-relaxed", children: selectedAssignmentInfo.description })] }), _jsxs("div", { children: [_jsx("h3", { className: "text-sm font-semibold text-gray-900 mb-2", children: "\u8F93\u5165\u8BF4\u660E" }), _jsx("div", { className: "bg-gray-50 rounded-lg p-3", children: _jsx("pre", { className: "text-sm text-gray-700 whitespace-pre-wrap", children: selectedAssignmentInfo.input }) })] }), _jsxs("div", { children: [_jsx("h3", { className: "text-sm font-semibold text-gray-900 mb-2", children: "\u8F93\u51FA\u8BF4\u660E" }), _jsx("div", { className: "bg-gray-50 rounded-lg p-3", children: _jsx("pre", { className: "text-sm text-gray-700 whitespace-pre-wrap", children: selectedAssignmentInfo.output }) })] }), _jsxs("div", { className: "space-y-3", children: [_jsxs("div", { children: [_jsx("h3", { className: "text-sm font-semibold text-gray-900 mb-2", children: "\u6837\u4F8B\u8F93\u5165" }), _jsx("div", { className: "bg-blue-50 border border-blue-200 rounded-lg p-3", children: _jsx("pre", { className: "text-sm text-blue-900 font-mono", children: selectedAssignmentInfo.sampleInput }) })] }), _jsxs("div", { children: [_jsx("h3", { className: "text-sm font-semibold text-gray-900 mb-2", children: "\u6837\u4F8B\u8F93\u51FA" }), _jsx("div", { className: "bg-green-50 border border-green-200 rounded-lg p-3", children: _jsx("pre", { className: "text-sm text-green-900 font-mono", children: selectedAssignmentInfo.sampleOutput }) })] })] }), _jsxs("div", { children: [_jsx("h3", { className: "text-sm font-semibold text-gray-900 mb-2", children: "\u9898\u76EE\u8981\u6C42" }), _jsx("div", { className: "bg-amber-50 border border-amber-200 rounded-lg p-3", children: _jsx("pre", { className: "text-sm text-amber-900 whitespace-pre-wrap", children: selectedAssignmentInfo.requirements }) })] }), _jsxs("div", { children: [_jsx("h3", { className: "text-sm font-semibold text-gray-900 mb-2", children: "\u9650\u5236\u6761\u4EF6" }), _jsx("div", { className: "bg-gray-50 rounded-lg p-3", children: _jsx("pre", { className: "text-sm text-gray-700 whitespace-pre-wrap", children: selectedAssignmentInfo.limits }) })] })] })] }) }), _jsxs("div", { className: "lg:col-span-3 space-y-4", children: [_jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { className: "border-b border-gray-100", children: _jsxs("div", { className: "flex items-center justify-between", children: [_jsx(CardTitle, { className: "text-lg", children: "\u4EE3\u7801\u7F16\u8F91\u5668" }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsx("input", { type: "file", ref: fileInputRef, onChange: handleFileUpload, accept: editorLanguage === "python" ? ".py" : ".sh", className: "hidden" }), _jsxs(Button, { variant: "outline", size: "sm", onClick: () => fileInputRef.current?.click(), className: "gap-2", children: [_jsx(Upload, { className: "w-4 h-4" }), "\u4E0A\u4F20\u6587\u4EF6"] }), _jsx(Badge, { variant: "secondary", className: "bg-gray-100", children: editorLanguage === "python" ? "Python" : "Bash Shell" })] })] }) }), _jsxs(CardContent, { className: "p-0", children: [_jsx("div", { className: "border-b border-gray-100", children: _jsx(Editor, { height: "400px", language: editorLanguage, value: code, onChange: (value) => setCode(value || ""), theme: "vs-light", options: {
                                                                        fontSize: 14,
                                                                        minimap: { enabled: false },
                                                                        scrollBeyondLastLine: false,
                                                                        lineNumbers: "on",
                                                                        tabSize: 4,
                                                                    } }) }), _jsxs("div", { className: "p-4 bg-gray-50 flex items-center justify-between", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsxs(Button, { onClick: handleRun, disabled: isRunning || !code.trim(), className: "gap-2 bg-green-600 hover:bg-green-700", children: [_jsx(Play, { className: "w-4 h-4" }), isRunning ? "运行中..." : "运行"] }), _jsxs(Button, { onClick: handleSubmit, disabled: isSubmitting || !code.trim(), className: "gap-2 bg-blue-600 hover:bg-blue-700", children: [_jsx(Send, { className: "w-4 h-4" }), isSubmitting ? "提交中..." : "提交"] }), _jsxs(Button, { variant: "outline", onClick: handleSaveDraft, disabled: !code.trim(), className: "gap-2", children: [_jsx(Save, { className: "w-4 h-4" }), "\u4FDD\u5B58\u8349\u7A3F"] }), _jsxs(Button, { variant: "outline", onClick: handleReset, disabled: !code.trim(), className: "gap-2", children: [_jsx(RotateCcw, { className: "w-4 h-4" }), "\u91CD\u7F6E"] })] }), _jsxs(Button, { variant: "ghost", size: "sm", onClick: () => setShowResult(!showResult), className: "gap-2", children: [showResult ? _jsx(ChevronUp, { className: "w-4 h-4" }) : _jsx(ChevronDown, { className: "w-4 h-4" }), showResult ? "隐藏结果" : "显示结果"] })] })] })] }), showResult && (runResult || submitResult) && (_jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { className: "border-b border-gray-100", children: _jsx(CardTitle, { className: "text-lg", children: "\u8FD0\u884C\u7ED3\u679C" }) }), _jsx(CardContent, { className: "p-6", children: _jsxs(Tabs, { defaultValue: submitResult ? "submit" : "run", children: [_jsxs(TabsList, { className: "grid w-full grid-cols-2", children: [_jsx(TabsTrigger, { value: "run", disabled: !runResult, children: "\u8FD0\u884C\u8F93\u51FA" }), _jsx(TabsTrigger, { value: "submit", disabled: !submitResult, children: "\u63D0\u4EA4\u7ED3\u679C" })] }), runResult && (_jsxs(TabsContent, { value: "run", className: "space-y-4 mt-4", children: [_jsxs("div", { className: "flex items-center gap-2", children: [runResult.status === "success" ? (_jsx(CheckCircle, { className: "w-5 h-5 text-green-600" })) : (_jsx(XCircle, { className: "w-5 h-5 text-red-600" })), _jsx("span", { className: `font-medium ${runResult.status === "success" ? "text-green-600" : "text-red-600"}`, children: runResult.status === "success" ? "运行成功" : "运行失败" }), _jsxs("div", { className: "ml-auto flex items-center gap-4 text-sm text-gray-600", children: [_jsxs("span", { children: ["\u6267\u884C\u65F6\u95F4: ", runResult.executionTime] }), _jsxs("span", { children: ["\u5185\u5B58: ", runResult.memory] })] })] }), runResult.output && (_jsxs("div", { children: [_jsx("h4", { className: "text-sm font-semibold text-gray-900 mb-2", children: "\u8F93\u51FA" }), _jsx("div", { className: "bg-gray-900 rounded-lg p-4", children: _jsx("pre", { className: "text-sm text-green-400 font-mono whitespace-pre-wrap", children: runResult.output }) })] })), runResult.error && (_jsxs("div", { children: [_jsx("h4", { className: "text-sm font-semibold text-gray-900 mb-2", children: "\u9519\u8BEF\u4FE1\u606F" }), _jsx("div", { className: "bg-red-50 border border-red-200 rounded-lg p-4", children: _jsx("pre", { className: "text-sm text-red-900 font-mono whitespace-pre-wrap", children: runResult.error }) })] }))] })), submitResult && (_jsxs(TabsContent, { value: "submit", className: "space-y-4 mt-4", children: [_jsxs("div", { className: "flex items-center justify-between p-4 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg border border-green-200", children: [_jsxs("div", { className: "flex items-center gap-3", children: [submitResult.status === "accepted" ? (_jsx(CheckCircle, { className: "w-6 h-6 text-green-600" })) : (_jsx(XCircle, { className: "w-6 h-6 text-red-600" })), _jsxs("div", { children: [_jsx("p", { className: "font-semibold text-gray-900", children: submitResult.status === "accepted" ? "通过" : "未通过" }), _jsxs("p", { className: "text-sm text-gray-600", children: ["\u63D0\u4EA4\u65F6\u95F4\uFF1A", submitResult.submitTime] })] })] }), _jsxs("div", { className: "text-right", children: [_jsx("p", { className: "text-3xl font-bold text-green-600", children: submitResult.score }), _jsxs("p", { className: "text-sm text-gray-600", children: ["/ ", submitResult.totalScore] })] })] }), _jsxs("div", { children: [_jsx("h4", { className: "text-sm font-semibold text-gray-900 mb-3", children: "\u6D4B\u8BD5\u70B9\u8BE6\u60C5" }), _jsx("div", { className: "space-y-2", children: submitResult.testCases.map((testCase) => (_jsxs("div", { className: `p-3 rounded-lg border ${testCase.status === "passed"
                                                                                            ? "bg-green-50 border-green-200"
                                                                                            : "bg-red-50 border-red-200"}`, children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsxs("div", { className: "flex items-center gap-2", children: [testCase.status === "passed" ? (_jsx(CheckCircle, { className: "w-4 h-4 text-green-600" })) : (_jsx(XCircle, { className: "w-4 h-4 text-red-600" })), _jsx("span", { className: "text-sm font-medium text-gray-900", children: testCase.name })] }), _jsxs("div", { className: "flex items-center gap-4 text-xs text-gray-600", children: [_jsx("span", { children: testCase.time }), _jsx("span", { children: testCase.memory })] })] }), testCase.error && (_jsx("p", { className: "text-xs text-red-700 mt-2 ml-6", children: testCase.error }))] }, testCase.id))) })] })] }))] }) })] }))] })] })) : (_jsx(Card, { className: "border-0 shadow-sm", children: _jsxs(CardContent, { className: "p-12 text-center", children: [_jsx(FileCode, { className: "w-16 h-16 text-gray-400 mx-auto mb-4" }), _jsx("p", { className: "text-gray-600", children: "\u8BF7\u9009\u62E9\u8BFE\u7A0B\u548C\u4EFB\u52A1\u540E\u5F00\u59CB\u7F16\u7A0B" })] }) }))] }), _jsxs(TabsContent, { value: "email", className: "space-y-6", children: [_jsx(Card, { className: "border-0 shadow-sm bg-blue-50 border-blue-200", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "flex items-start gap-3", children: [_jsx(Info, { className: "w-6 h-6 text-blue-600 flex-shrink-0 mt-0.5" }), _jsxs("div", { children: [_jsx("h3", { className: "text-blue-900 mb-1", children: "\u90AE\u4EF6\u63D0\u4EA4\u8BF4\u660E" }), _jsx("p", { className: "text-sm text-blue-700", children: "\u5982\u679C\u5728\u7EBF\u63D0\u4EA4\u9047\u5230\u95EE\u9898\uFF0C\u60A8\u53EF\u4EE5\u901A\u8FC7\u53D1\u9001\u90AE\u4EF6\u7684\u65B9\u5F0F\u63D0\u4EA4\u4F5C\u4E1A\u3002\u8BF7\u4E25\u683C\u6309\u7167\u4EE5\u4E0B\u683C\u5F0F\u8981\u6C42\u53D1\u9001\u90AE\u4EF6\uFF0C\u7CFB\u7EDF\u5C06\u81EA\u52A8\u8BC6\u522B\u5E76\u5BFC\u5165\u60A8\u7684\u4F5C\u4E1A\u8BB0\u5F55\u3002" })] })] }) }) }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { className: "border-b border-gray-100", children: _jsxs(CardTitle, { className: "flex items-center gap-2", children: [_jsx(Mail, { className: "w-5 h-5" }), "\u63D0\u4EA4\u90AE\u7BB1\u5730\u5740"] }) }), _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "bg-gray-50 rounded-lg p-4 text-center", children: [_jsx("p", { className: "text-xs text-gray-600 mb-2", children: "\u8BF7\u5C06\u4F5C\u4E1A\u53D1\u9001\u81F3\u4EE5\u4E0B\u90AE\u7BB1" }), _jsx("div", { className: "text-2xl font-mono text-blue-600 mb-2", children: emailInfo.email }), _jsx("p", { className: "text-xs text-gray-500", children: "\u8BF7\u4F7F\u7528\u60A8\u7684\u5B66\u6821\u90AE\u7BB1\u53D1\u9001" })] }) })] }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { className: "border-b border-gray-100", children: _jsx(CardTitle, { children: "\u90AE\u4EF6\u4E3B\u9898\u683C\u5F0F" }) }), _jsx(CardContent, { className: "p-6 space-y-4", children: _jsxs("div", { className: "bg-amber-50 border border-amber-200 rounded-lg p-4", children: [_jsxs("p", { className: "text-sm text-amber-900 mb-3", children: [_jsx("span", { className: "font-semibold", children: "\u683C\u5F0F\u8981\u6C42\uFF1A" }), _jsx("code", { className: "ml-2 px-2 py-1 bg-white rounded text-amber-700", children: emailInfo.subjectFormat })] }), _jsxs("div", { className: "space-y-2", children: [_jsx("p", { className: "text-xs text-amber-800", children: "\u793A\u4F8B\uFF1A" }), emailInfo.examples.map((example, index) => (_jsxs("div", { className: "bg-white rounded px-3 py-2", children: [_jsx("code", { className: "text-sm text-gray-800", children: example.subject }), _jsxs("span", { className: "text-xs text-gray-500 ml-3", children: ["(", example.course, " \u8BFE\u7A0B\uFF0C\u5B66\u53F7 ", example.student, "\uFF0C", example.task, ")"] })] }, index)))] })] }) })] }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { className: "border-b border-gray-100", children: _jsx(CardTitle, { children: "\u9644\u4EF6\u547D\u540D\u4E0E\u683C\u5F0F" }) }), _jsxs(CardContent, { className: "p-6 space-y-4", children: [_jsxs("div", { children: [_jsx("h4", { className: "text-sm font-semibold text-gray-900 mb-2", children: "\u9644\u4EF6\u547D\u540D\u5EFA\u8BAE" }), _jsxs("p", { className: "text-sm text-gray-600 mb-3", children: ["\u683C\u5F0F\uFF1A", _jsx("code", { className: "px-2 py-1 bg-gray-100 rounded text-gray-800", children: emailInfo.attachmentFormat })] }), _jsx("div", { className: "space-y-2", children: emailInfo.attachmentExamples.map((example, index) => (_jsx("div", { className: "bg-gray-50 rounded px-3 py-2", children: _jsx("code", { className: "text-sm text-gray-700", children: example }) }, index))) })] }), _jsxs("div", { children: [_jsx("h4", { className: "text-sm font-semibold text-gray-900 mb-2", children: "\u652F\u6301\u7684\u6587\u4EF6\u683C\u5F0F" }), _jsx("div", { className: "flex gap-2", children: emailInfo.supportedFormats.map((format, index) => (_jsx(Badge, { variant: "secondary", className: "bg-green-50 text-green-700 border-green-200", children: format }, index))) })] }), _jsxs("div", { children: [_jsx("h4", { className: "text-sm font-semibold text-gray-900 mb-2", children: "\u6587\u4EF6\u5927\u5C0F\u9650\u5236" }), _jsxs("p", { className: "text-sm text-gray-600", children: ["\u5355\u4E2A\u9644\u4EF6\u4E0D\u8D85\u8FC7 ", _jsx("span", { className: "font-semibold text-gray-900", children: emailInfo.maxSize })] })] })] })] }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { className: "border-b border-gray-100", children: _jsx(CardTitle, { children: "\u6CE8\u610F\u4E8B\u9879" }) }), _jsx(CardContent, { className: "p-6", children: _jsx("div", { className: "space-y-3 text-sm text-gray-700", children: _jsxs("div", { className: "flex gap-3", children: [_jsx(AlertCircle, { className: "w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" }), _jsxs("div", { className: "space-y-2", children: [_jsxs("p", { children: ["\u2022 ", _jsx("span", { className: "font-semibold", children: "\u5FC5\u987B\u4F7F\u7528\u5B66\u6821\u90AE\u7BB1" }), "\u53D1\u9001\uFF0C\u5426\u5219\u7CFB\u7EDF\u65E0\u6CD5\u8BC6\u522B\u60A8\u7684\u8EAB\u4EFD"] }), _jsxs("p", { children: ["\u2022 \u90AE\u4EF6\u4E3B\u9898\u683C\u5F0F\u5FC5\u987B", _jsx("span", { className: "font-semibold", children: "\u4E25\u683C\u4E00\u81F4" }), "\uFF0C\u5426\u5219\u53EF\u80FD\u5BFC\u5165\u5931\u8D25"] }), _jsx("p", { children: "\u2022 \u9644\u4EF6\u6587\u4EF6\u540D\u5EFA\u8BAE\u5305\u542B\u5B66\u53F7\u548C\u4F5C\u4E1A\u540D\u79F0\uFF0C\u65B9\u4FBF\u540E\u7EED\u67E5\u8BE2" }), _jsxs("p", { children: ["\u2022 \u5982\u9700\u63D0\u4EA4\u591A\u4E2A\u6587\u4EF6\uFF0C\u8BF7\u6253\u5305\u4E3A ", _jsx("code", { className: "px-1 bg-gray-100 rounded", children: ".zip" }), " \u683C\u5F0F"] }), _jsxs("p", { children: ["\u2022 \u786E\u4FDD\u4EE3\u7801\u6587\u4EF6\u7F16\u7801\u4E3A ", _jsx("span", { className: "font-semibold", children: "UTF-8" })] }), _jsxs("p", { children: ["\u2022 \u90AE\u4EF6\u53D1\u9001\u540E\u7EA6 ", _jsx("span", { className: "font-semibold text-green-600", children: emailInfo.syncTime }), " \u5185\u4F1A\u540C\u6B65\u5230\u7CFB\u7EDF\uFF0C\u60A8\u53EF\u4EE5\u5728\"\u63D0\u4EA4\u8BB0\u5F55\"\u9875\u9762\u67E5\u770B"] }), _jsx("p", { children: "\u2022 \u90AE\u4EF6\u63D0\u4EA4\u540E\u7CFB\u7EDF\u5C06\u81EA\u52A8\u56DE\u590D\u786E\u8BA4\u90AE\u4EF6\uFF0C\u8BF7\u6CE8\u610F\u67E5\u6536" })] })] }) }) })] }), _jsxs(Card, { className: "border-0 shadow-sm bg-gradient-to-r from-green-50 to-blue-50 border-green-200", children: [_jsx(CardHeader, { className: "border-b border-gray-100", children: _jsx(CardTitle, { children: "\u90AE\u4EF6\u63D0\u4EA4\u6D41\u7A0B\u793A\u4F8B" }) }), _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "space-y-3", children: [_jsxs("div", { className: "flex items-center gap-3", children: [_jsx("div", { className: "w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-sm font-semibold text-green-600", children: "1" }), _jsx("p", { className: "text-sm text-gray-700", children: "\u4F7F\u7528\u5B66\u6821\u90AE\u7BB1\u767B\u5F55\u90AE\u4EF6\u5BA2\u6237\u7AEF" })] }), _jsxs("div", { className: "flex items-center gap-3", children: [_jsx("div", { className: "w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-sm font-semibold text-green-600", children: "2" }), _jsxs("p", { className: "text-sm text-gray-700", children: ["\u6536\u4EF6\u4EBA\u586B\u5199\uFF1A", _jsx("code", { className: "px-2 py-1 bg-white rounded text-blue-600", children: emailInfo.email })] })] }), _jsxs("div", { className: "flex items-center gap-3", children: [_jsx("div", { className: "w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-sm font-semibold text-green-600", children: "3" }), _jsxs("p", { className: "text-sm text-gray-700", children: ["\u4E3B\u9898\u586B\u5199\uFF1A", _jsx("code", { className: "px-2 py-1 bg-white rounded text-gray-700", children: "PY101-2024001-\u5B9E\u9A8C2" })] })] }), _jsxs("div", { className: "flex items-center gap-3", children: [_jsx("div", { className: "w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-sm font-semibold text-green-600", children: "4" }), _jsxs("p", { className: "text-sm text-gray-700", children: ["\u6DFB\u52A0\u9644\u4EF6\uFF1A", _jsx("code", { className: "px-2 py-1 bg-white rounded text-gray-700", children: "2024001_\u5F20\u4E09_\u5B9E\u9A8C2.py" })] })] }), _jsxs("div", { className: "flex items-center gap-3", children: [_jsx("div", { className: "w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-sm font-semibold text-green-600", children: "5" }), _jsx("p", { className: "text-sm text-gray-700", children: "\u70B9\u51FB\u53D1\u9001\uFF0C\u7B49\u5F85\u7CFB\u7EDF\u81EA\u52A8\u540C\u6B65\uFF085-10\u5206\u949F\uFF09" })] }), _jsxs("div", { className: "flex items-center gap-3", children: [_jsx("div", { className: "w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-sm font-semibold text-green-600", children: "6" }), _jsx("p", { className: "text-sm text-gray-700", children: "\u5728\"\u63D0\u4EA4\u8BB0\u5F55\"\u9875\u9762\u67E5\u770B\u63D0\u4EA4\u72B6\u6001\u548C\u8BC4\u6D4B\u7ED3\u679C" })] })] }) })] })] })] })] }));
}
