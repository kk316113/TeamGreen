// import { jsxs as _jsxs, jsx as _jsx } from "react/jsx-runtime";
// import { Link } from "react-router";
// import { Upload, History, BarChart3, Award, Clock, CheckCircle, ArrowRight, BookOpen, TrendingUp, CheckSquare, } from "lucide-react";
// import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
// import { Button } from "../../components/ui/button";
// import { Badge } from "../../components/ui/badge";
// export function StudentDashboard() {
//     const studentInfo = {
//         name: "张三",
//         studentId: "2024001",
//         major: "计算机科学与技术",
//         class: "计科2401",
//     };
//     const stats = [
//         {
//             title: "已选课程",
//             value: "5",
//             icon: BookOpen,
//             color: "blue",
//         },
//         {
//             title: "待完成任务",
//             value: "3",
//             icon: Clock,
//             color: "orange",
//         },
//         {
//             title: "已完成任务",
//             value: "12",
//             icon: CheckCircle,
//             color: "green",
//         },
//         {
//             title: "平均分",
//             value: "88.5",
//             icon: Award,
//             color: "purple",
//         },
//     ];
//     const quickActions = [
//         {
//             title: "我的任务",
//             description: "查看课程任务列表",
//             icon: CheckSquare,
//             link: "/student/tasks",
//             color: "orange",
//         },
//         {
//             title: "提交代码",
//             description: "上传代码文件完成任务",
//             icon: Upload,
//             link: "/student/submit",
//             color: "blue",
//         },
//         {
//             title: "查看成绩",
//             description: "查看历次任务成绩",
//             icon: BarChart3,
//             link: "/student/grades",
//             color: "green",
//         },
//         {
//             title: "提交记录",
//             description: "查看所有提交历史",
//             icon: History,
//             link: "/student/history",
//             color: "purple",
//         },
//     ];
//     const pendingAssignments = [
//         {
//             id: 1,
//             course: "Python程序设计",
//             assignment: "实验4：图的遍历",
//             deadline: "2024-04-05 23:59",
//             status: "未提交",
//             daysLeft: 7,
//         },
//         {
//             id: 2,
//             course: "Bash Shell程序设计",
//             assignment: "实验3：内存管理",
//             deadline: "2024-04-03 23:59",
//             status: "未提交",
//             daysLeft: 5,
//         },
//         {
//             id: 3,
//             course: "Python程序设计",
//             assignment: "实验5：路由算法实现",
//             deadline: "2024-04-02 23:59",
//             status: "未提交",
//             daysLeft: 4,
//         },
//     ];
//     const recentGrades = [
//         {
//             id: 1,
//             course: "Python程序设计",
//             assignment: "实验3：二叉树遍历",
//             score: 95,
//             maxScore: 100,
//             submitTime: "2024-03-28 14:30",
//             gradeTime: "2024-03-29 10:20",
//         },
//         {
//             id: 2,
//             course: "Bash Shell程序设计",
//             assignment: "实验2：进程调度",
//             score: 88,
//             maxScore: 100,
//             submitTime: "2024-03-26 16:45",
//             gradeTime: "2024-03-27 09:15",
//         },
//         {
//             id: 3,
//             course: "Python程序设计",
//             assignment: "实验4：TCP协议实现",
//             score: 92,
//             maxScore: 100,
//             submitTime: "2024-03-25 18:20",
//             gradeTime: "2024-03-26 11:30",
//         },
//     ];
//     return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { children: [_jsxs("h1", { className: "text-2xl text-gray-900 mb-1", children: ["\u6B22\u8FCE\u56DE\u6765\uFF0C", studentInfo.name] }), _jsxs("p", { className: "text-gray-600", children: [studentInfo.studentId, " \u2022 ", studentInfo.major, " \u2022 ", studentInfo.class] })] }), _jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6", children: stats.map((stat, index) => {
//                     const Icon = stat.icon;
//                     const colorClasses = {
//                         blue: "bg-blue-50 text-blue-600",
//                         green: "bg-green-50 text-green-600",
//                         orange: "bg-orange-50 text-orange-600",
//                         purple: "bg-purple-50 text-purple-600",
//                     };
//                     return (_jsx(Card, { className: "border-0 shadow-sm", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "flex items-start justify-between", children: [_jsxs("div", { children: [_jsx("p", { className: "text-sm text-gray-600 mb-1", children: stat.title }), _jsx("h3", { className: "text-3xl text-gray-900", children: stat.value })] }), _jsx("div", { className: `w-12 h-12 rounded-xl flex items-center justify-center ${colorClasses[stat.color]}`, children: _jsx(Icon, { className: "w-6 h-6" }) })] }) }) }, index));
//                 }) }), _jsxs("div", { children: [_jsx("h2", { className: "text-lg text-gray-900 mb-4", children: "\u5FEB\u6377\u529F\u80FD" }), _jsx("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: quickActions.map((action, index) => {
//                             const Icon = action.icon;
//                             const colorClasses = {
//                                 blue: "bg-blue-600 hover:bg-blue-700",
//                                 green: "bg-green-600 hover:bg-green-700",
//                                 purple: "bg-purple-600 hover:bg-purple-700",
//                                 orange: "bg-orange-600 hover:bg-orange-700",
//                             };
//                             return (_jsx(Link, { to: action.link, children: _jsx(Card, { className: "border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "flex items-start gap-4", children: [_jsx("div", { className: `w-12 h-12 rounded-xl flex items-center justify-center ${colorClasses[action.color]}`, children: _jsx(Icon, { className: "w-6 h-6 text-white" }) }), _jsxs("div", { className: "flex-1", children: [_jsx("h3", { className: "text-gray-900 mb-1", children: action.title }), _jsx("p", { className: "text-sm text-gray-600", children: action.description })] }), _jsx(ArrowRight, { className: "w-5 h-5 text-gray-400" })] }) }) }) }, index));
//                         }) })] }), _jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6", children: [_jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { className: "pb-3", children: _jsx(CardTitle, { className: "text-lg", children: "\u5F85\u5B8C\u6210\u4EFB\u52A1" }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "space-y-4", children: pendingAssignments.map((item) => (_jsxs("div", { className: "pb-4 border-b border-gray-100 last:border-0 last:pb-0", children: [_jsxs("div", { className: "flex items-start justify-between mb-2", children: [_jsxs("div", { className: "flex-1 min-w-0", children: [_jsx("p", { className: "text-sm text-gray-900 mb-1", children: item.assignment }), _jsx("p", { className: "text-xs text-gray-600", children: item.course })] }), _jsxs(Badge, { variant: "secondary", className: item.daysLeft <= 3
//                                                                 ? "bg-red-50 text-red-700"
//                                                                 : "bg-orange-50 text-orange-700", children: [item.daysLeft, "\u5929\u540E\u622A\u6B62"] })] }), _jsxs("div", { className: "flex items-center gap-2 text-xs text-gray-600", children: [_jsx(Clock, { className: "w-3 h-3" }), _jsxs("span", { children: ["\u622A\u6B62\u65F6\u95F4\uFF1A", item.deadline] })] })] }, item.id))) }), _jsx(Link, { to: "/student/tasks", children: _jsxs(Button, { variant: "ghost", className: "w-full mt-4", children: ["\u67E5\u770B\u5168\u90E8\u4EFB\u52A1", _jsx(ArrowRight, { className: "w-4 h-4 ml-2" })] }) })] })] }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { className: "pb-3", children: _jsx(CardTitle, { className: "text-lg", children: "\u6700\u8FD1\u6210\u7EE9" }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "space-y-4", children: recentGrades.map((item) => (_jsxs("div", { className: "pb-4 border-b border-gray-100 last:border-0 last:pb-0", children: [_jsxs("div", { className: "flex items-start justify-between mb-2", children: [_jsxs("div", { className: "flex-1 min-w-0", children: [_jsx("p", { className: "text-sm text-gray-900 mb-1", children: item.assignment }), _jsx("p", { className: "text-xs text-gray-600", children: item.course })] }), _jsxs("div", { className: "text-right ml-4", children: [_jsx("p", { className: `text-lg ${item.score >= 90
//                                                                         ? "text-green-600"
//                                                                         : item.score >= 80
//                                                                             ? "text-blue-600"
//                                                                             : "text-amber-600"}`, children: item.score }), _jsxs("p", { className: "text-xs text-gray-500", children: ["/", item.maxScore] })] })] }), _jsxs("div", { className: "flex items-center gap-2 text-xs text-gray-600", children: [_jsx(CheckCircle, { className: "w-3 h-3 text-green-600" }), _jsxs("span", { children: ["\u8BC4\u5206\u65F6\u95F4\uFF1A", item.gradeTime] })] })] }, item.id))) }), _jsx(Link, { to: "/student/grades", children: _jsxs(Button, { variant: "ghost", className: "w-full mt-4", children: ["\u67E5\u770B\u5168\u90E8\u6210\u7EE9", _jsx(ArrowRight, { className: "w-4 h-4 ml-2" })] }) })] })] })] }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { children: _jsx(CardTitle, { className: "text-lg", children: "\u672C\u5B66\u671F\u5B66\u4E60\u8FDB\u5C55" }) }), _jsx(CardContent, { children: _jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: [_jsxs("div", { className: "text-center p-4 bg-blue-50 rounded-xl", children: [_jsxs("div", { className: "flex items-center justify-center gap-2 mb-2", children: [_jsx(TrendingUp, { className: "w-5 h-5 text-blue-600" }), _jsx("p", { className: "text-2xl text-blue-600", children: "88.5" })] }), _jsx("p", { className: "text-sm text-gray-600", children: "\u5E73\u5747\u5206" })] }), _jsxs("div", { className: "text-center p-4 bg-green-50 rounded-xl", children: [_jsxs("div", { className: "flex items-center justify-center gap-2 mb-2", children: [_jsx(CheckCircle, { className: "w-5 h-5 text-green-600" }), _jsx("p", { className: "text-2xl text-green-600", children: "80%" })] }), _jsx("p", { className: "text-sm text-gray-600", children: "\u5B8C\u6210\u7387" })] }), _jsxs("div", { className: "text-center p-4 bg-purple-50 rounded-xl", children: [_jsxs("div", { className: "flex items-center justify-center gap-2 mb-2", children: [_jsx(Award, { className: "w-5 h-5 text-purple-600" }), _jsx("p", { className: "text-2xl text-purple-600", children: "12/15" })] }), _jsx("p", { className: "text-sm text-gray-600", children: "\u5DF2\u5B8C\u6210\u4EFB\u52A1" })] })] }) })] })] }));
// }
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { Link } from "react-router";
import { 
  BookOpen, Clock, CheckCircle, XCircle, Loader, 
  ArrowRight, Filter, Search 
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Badge } from "../../components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";

export function StudentDashboard() {
  const [loading, setLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState({
    totalTasks: 0,
    pendingTasks: 0,
    completedTasks: 0,
    recentSubmissions: []
  });

  // ====================== 对接仪表盘接口 ======================
  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        setLoading(true);
        const token = localStorage.getItem("student_token");
        const res = await fetch("/api/v1/student/dashboard", {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        });
        const data = await res.json();
        if (data.code === 0) {
          setDashboardData(data.data);
        }
      } catch (err) {
        console.error("获取仪表盘数据失败", err);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboard();
  }, []);

  // ====================== 加载状态 ======================
  if (loading) {
    return _jsx("div", { 
      className: "p-10 text-center", 
      children: "加载中..." 
    });
  }

  // ====================== 页面主体 ======================
  return _jsxs("div", { className: "space-y-6", children: [
    _jsxs("div", { children: [
      _jsx("h1", { className: "text-2xl text-gray-900 mb-1", children: "仪表盘" }),
      _jsx("p", { className: "text-gray-600", children: "欢迎使用自动测评系统" })
    ]}),

    _jsx("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: [
      _jsx(Card, { children: _jsxs(CardContent, { className: "p-6", children: [
        _jsx("div", { className: "text-3xl font-bold text-blue-600 mb-2", children: dashboardData.totalTasks }),
        _jsx("p", { className: "text-sm text-gray-600", children: "全部任务" })
      ]}) }),
      _jsx(Card, { children: _jsxs(CardContent, { className: "p-6", children: [
        _jsx("div", { className: "text-3xl font-bold text-orange-600 mb-2", children: dashboardData.pendingTasks }),
        _jsx("p", { className: "text-sm text-gray-600", children: "待提交" })
      ]}) }),
      _jsx(Card, { children: _jsxs(CardContent, { className: "p-6", children: [
        _jsx("div", { className: "text-3xl font-bold text-green-600 mb-2", children: dashboardData.completedTasks }),
        _jsx("p", { className: "text-sm text-gray-600", children: "已完成" })
      ]}) })
    ]}),

    _jsxs(Card, { children: [
      _jsx(CardHeader, { children: _jsxs(CardTitle, { children: ["最近提交"] }) }),
      _jsx(CardContent, { children: _jsx("div", { className: "space-y-4", children: dashboardData.recentSubmissions.map((item, idx) => 
        _jsxs("div", { className: "flex items-center justify-between", children: [
          _jsxs("div", { children: [
            _jsx("p", { className: "font-medium", children: item.assignment }),
            _jsx("p", { className: "text-xs text-gray-500", children: item.submit_time })
          ]}),
          _jsx(Badge, { className: item.status === "completed" ? "bg-green-100 text-green-800" : "bg-orange-100 text-orange-800", children: item.status_text })
        ]}, idx)
      )}) })
    ]}),

    _jsxs("div", { className: "flex justify-end", children: [
      _jsx(Link, { to: "/student/tasks", children: _jsxs(Button, { className: "gap-2", children: [
        "查看全部任务",
        _jsx(ArrowRight, { className: "w-4 h-4" })
      ]}) })
    ]})
  ]});
}