import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
//import { useState } from "react";
import { useState, useEffect } from "react";
import { Link } from "react-router";
import { Search, Clock, CheckCircle, XCircle, Loader, Eye, Download, } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Badge } from "../../components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, } from "../../components/ui/select";
// export function SubmissionHistory() {
//     const [searchTerm, setSearchTerm] = useState("");
//     const [filterStatus, setFilterStatus] = useState("all");
//     const submissions = [
//         {
//             id: 1,
//             course: "Python程序设计",
//             courseCode: "PY101",
//             assignment: "实验2：分支与循环",
//             fileName: "binary_tree_traversal.py",
//             submitTime: "2024-03-28 14:30:25",
//             status: "completed",
//             statusText: "已完成",
//             score: 95,
//         },
//         {
//             id: 2,
//             course: "Bash Shell程序设计",
//             courseCode: "SH201",
//             assignment: "实验2：Shell脚本编写",
//             fileName: "process_scheduler.cpp",
//             submitTime: "2024-03-26 16:45:12",
//             status: "completed",
//             statusText: "已完成",
//             score: 88,
//         },
//         {
//             id: 3,
//             course: "Python程序设计",
//             courseCode: "PY101",
//             assignment: "实验3：函数设计",
//             fileName: "tcp_implementation.java",
//             submitTime: "2024-03-25 18:20:33",
//             status: "completed",
//             statusText: "已完成",
//             score: 92,
//         },
//         {
//             id: 4,
//             course: "Python程序设计",
//             courseCode: "PY101",
//             assignment: "实验4：列表与字典",
//             fileName: "graph_traversal.py",
//             submitTime: "2024-03-29 10:15:47",
//             status: "testing",
//             statusText: "测评中",
//             score: null,
//         },
//         {
//             id: 5,
//             course: "Bash Shell程序设计",
//             courseCode: "SH201",
//             assignment: "实验3：条件判断与循环",
//             fileName: "index_optimization.sql",
//             submitTime: "2024-03-24 09:30:18",
//             status: "pending",
//             statusText: "待测评",
//             score: null,
//         },
//         {
//             id: 6,
//             course: "Bash Shell程序设计",
//             courseCode: "SH201",
//             assignment: "实验1：Linux基础命令",
//             fileName: "process_manager.c",
//             submitTime: "2024-03-20 15:22:41",
//             status: "failed",
//             statusText: "提交失败",
//             score: null,
//             errorMsg: "文件格式错误",
//         },
//     ];
//     const getStatusIcon = (status) => {
//         switch (status) {
//             case "completed":
//                 return _jsx(CheckCircle, { className: "w-5 h-5 text-green-600" });
//             case "testing":
//                 return _jsx(Loader, { className: "w-5 h-5 text-blue-600 animate-spin" });
//             case "pending":
//                 return _jsx(Clock, { className: "w-5 h-5 text-orange-600" });
//             case "failed":
//                 return _jsx(XCircle, { className: "w-5 h-5 text-red-600" });
//             default:
//                 return null;
//         }
//     };
//     const getStatusBadge = (status, text) => {
//         const colorClasses = {
//             completed: "bg-green-50 text-green-700 border-green-200",
//             testing: "bg-blue-50 text-blue-700 border-blue-200",
//             pending: "bg-orange-50 text-orange-700 border-orange-200",
//             failed: "bg-red-50 text-red-700 border-red-200",
//         };
//         return (_jsx(Badge, { variant: "outline", className: colorClasses[status], children: text }));
//     };
//     const filteredSubmissions = submissions.filter((submission) => {
//         const matchesSearch = submission.course.includes(searchTerm) ||
//             submission.assignment.includes(searchTerm) ||
//             submission.fileName.toLowerCase().includes(searchTerm.toLowerCase());
//         const matchesFilter = filterStatus === "all" || submission.status === filterStatus;
//         return matchesSearch && matchesFilter;
//     });
//     const stats = [
//         {
//             label: "总提交数",
//             value: submissions.length,
//             color: "blue",
//         },
//         {
//             label: "已完成",
//             value: submissions.filter((s) => s.status === "completed").length,
//             color: "green",
//         },
//         {
//             label: "测评中",
//             value: submissions.filter((s) => s.status === "testing").length,
//             color: "orange",
//         },
//         {
//             label: "失败",
//             value: submissions.filter((s) => s.status === "failed").length,
//             color: "red",
//         },
//     ];
export function SubmissionHistory() {
    const [searchTerm, setSearchTerm] = useState("");
    const [filterStatus, setFilterStatus] = useState("all");

    // ====================== 新增接口状态 ======================
    const [submissions, setSubmissions] = useState([]);
    const [loading, setLoading] = useState(true);

    // ====================== 对接 B4 提交历史接口 ======================
    useEffect(() => {
        const fetchSubmissions = async () => {
            try {
                setLoading(true);
                const token = localStorage.getItem("student_token");
                const res = await fetch("http://localhost:8000/api/v1/student/submissions", {
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`,
                    },
                });
                const data = await res.json();
                if (data.code === 0) {
                    setSubmissions(data.data.list || []);
                }
            } catch (err) {
                console.error("获取提交记录失败", err);
            } finally {
                setLoading(false);
            }
        };

        fetchSubmissions();
    }, []);

    // ====================== 接口字段映射（status对应） ======================
    const getStatusIcon = (status) => {
        switch (status) {
            case "completed":
                return _jsx(CheckCircle, { className: "w-5 h-5 text-green-600" });
            case "testing":
                return _jsx(Loader, { className: "w-5 h-5 text-blue-600 animate-spin" });
            case "pending":
                return _jsx(Clock, { className: "w-5 h-5 text-orange-600" });
            case "failed":
                return _jsx(XCircle, { className: "w-5 h-5 text-red-600" });
            default:
                return null;
        }
    };

    const getStatusBadge = (status, text) => {
        const colorClasses = {
            completed: "bg-green-50 text-green-700 border-green-200",
            testing: "bg-blue-50 text-blue-700 border-blue-200",
            pending: "bg-orange-50 text-orange-700 border-orange-200",
            failed: "bg-red-50 text-red-700 border-red-200",
        };
        return _jsx(Badge, { variant: "outline", className: colorClasses[status], children: text });
    };

    // ======================过滤逻辑======================
    const filteredSubmissions = submissions.filter((submission) => {
        const matchesSearch =
            (submission.course || "").includes(searchTerm) ||
            (submission.assignment || "").includes(searchTerm) ||
            (submission.file_name || "").toLowerCase().includes(searchTerm.toLowerCase());
        const matchesFilter = filterStatus === "all" || submission.status === filterStatus;
        return matchesSearch && matchesFilter;
    });

    // ====================== 统计从接口数据计算 ======================
    const stats = [
        { label: "总提交数", value: submissions.length, color: "blue" },
        {
            label: "已完成",
            value: submissions.filter((s) => s.status === "completed").length,
            color: "green",
        },
        {
            label: "测评中",
            value: submissions.filter((s) => s.status === "testing").length,
            color: "orange",
        },
        {
            label: "失败",
            value: submissions.filter((s) => s.status === "failed").length,
            color: "red",
        },
    ];

    // ====================== 加载中状态 ======================
    if (loading) {
        return _jsx("div", { className: "p-10 text-center", children: "加载中..." });
    }
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { children: [_jsx("h1", { className: "text-2xl text-gray-900 mb-1", children: "\u63D0\u4EA4\u8BB0\u5F55" }), _jsx("p", { className: "text-gray-600", children: "\u67E5\u770B\u6240\u6709\u4EFB\u52A1\u63D0\u4EA4\u5386\u53F2\u548C\u72B6\u6001" })] }), _jsx("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-6", children: stats.map((stat, index) => {
                    const colorClasses = {
                        blue: "bg-blue-50 text-blue-600",
                        green: "bg-green-50 text-green-600",
                        orange: "bg-orange-50 text-orange-600",
                        red: "bg-red-50 text-red-600",
                    };
                    return (_jsx(Card, { className: "border-0 shadow-sm", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "text-center", children: [_jsx("p", { className: `text-3xl mb-1 ${colorClasses[stat.color]}`, children: stat.value }), _jsx("p", { className: "text-sm text-gray-600", children: stat.label })] }) }) }, index));
                }) }), _jsx(Card, { className: "border-0 shadow-sm", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "flex flex-col sm:flex-row gap-4", children: [_jsxs("div", { className: "flex-1 relative", children: [_jsx(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" }), _jsx(Input, { placeholder: "\u641C\u7D22\u8BFE\u7A0B\u3001\u4F5C\u4E1A\u6216\u6587\u4EF6\u540D...", value: searchTerm, onChange: (e) => setSearchTerm(e.target.value), className: "pl-10" })] }), _jsx("div", { className: "w-full sm:w-48", children: _jsxs(Select, { value: filterStatus, onValueChange: setFilterStatus, children: [_jsx(SelectTrigger, { children: _jsx(SelectValue, {}) }), _jsxs(SelectContent, { children: [_jsx(SelectItem, { value: "all", children: "\u5168\u90E8\u72B6\u6001" }), _jsx(SelectItem, { value: "completed", children: "\u5DF2\u5B8C\u6210" }), _jsx(SelectItem, { value: "testing", children: "\u6D4B\u8BC4\u4E2D" }), _jsx(SelectItem, { value: "pending", children: "\u5F85\u6D4B\u8BC4" }), _jsx(SelectItem, { value: "failed", children: "\u63D0\u4EA4\u5931\u8D25" })] })] }) })] }) }) }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { children: _jsxs(CardTitle, { children: ["\u63D0\u4EA4\u5386\u53F2 (", filteredSubmissions.length, ")"] }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "overflow-x-auto", children: _jsxs("table", { className: "w-full", children: [_jsx("thead", { children: _jsxs("tr", { className: "border-b border-gray-200", children: [_jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u63D0\u4EA4\u65F6\u95F4" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u8BFE\u7A0B" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u4EFB\u52A1\u540D\u79F0" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u6587\u4EF6\u540D" }), _jsx("th", { className: "text-center py-3 px-4 text-sm text-gray-600", children: "\u72B6\u6001" }), _jsx("th", { className: "text-center py-3 px-4 text-sm text-gray-600", children: "\u5206\u6570" }), _jsx("th", { className: "text-center py-3 px-4 text-sm text-gray-600", children: "\u64CD\u4F5C" })] }) }), _jsx("tbody", { className: "divide-y divide-gray-200", children: filteredSubmissions.map((submission) => (_jsxs("tr", { className: "hover:bg-gray-50", children: [_jsx("td", { className: "py-3 px-4 text-sm text-gray-900", children: submission.submitTime }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: _jsxs("div", { children: [_jsx("p", { className: "text-gray-900", children: submission.course }), _jsx("p", { className: "text-xs text-gray-500", children: submission.courseCode })] }) }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-900", children: submission.assignment }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: _jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Download, { className: "w-4 h-4 text-gray-400" }), _jsx("span", { className: "truncate max-w-[200px]", children: submission.fileName })] }) }), _jsxs("td", { className: "py-3 px-4 text-center", children: [_jsxs("div", { className: "flex items-center justify-center gap-2", children: [getStatusIcon(submission.status), getStatusBadge(submission.status, submission.statusText)] }), submission.errorMsg && (_jsx("p", { className: "text-xs text-red-600 mt-1", children: submission.errorMsg }))] }), _jsx("td", { className: "py-3 px-4 text-center", children: submission.score !== null ? (_jsx("span", { className: `text-lg ${submission.score >= 90
                                                                ? "text-green-600"
                                                                : submission.score >= 80
                                                                    ? "text-blue-600"
                                                                    : submission.score >= 60
                                                                        ? "text-amber-600"
                                                                        : "text-red-600"}`, children: submission.score })) : (_jsx("span", { className: "text-gray-400", children: "-" })) }), _jsx("td", { className: "py-3 px-4 text-center", children: submission.status === "completed" ? (_jsx(Link, { to: `/student/grade-detail/${submission.id}`, children: _jsxs(Button, { variant: "ghost", size: "sm", className: "gap-2", children: [_jsx(Eye, { className: "w-4 h-4" }), "\u67E5\u770B\u8BE6\u60C5"] }) })) : (_jsx(Button, { variant: "ghost", size: "sm", disabled: true, children: "\u67E5\u770B\u8BE6\u60C5" })) })] }, submission.id))) })] }) }), filteredSubmissions.length === 0 && (_jsx("div", { className: "text-center py-12", children: _jsx("p", { className: "text-gray-500", children: "\u6CA1\u6709\u627E\u5230\u5339\u914D\u7684\u63D0\u4EA4\u8BB0\u5F55" }) }))] })] })] }));
}
