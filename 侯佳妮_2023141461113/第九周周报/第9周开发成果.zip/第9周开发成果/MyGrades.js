import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
//import { useState } from "react";
import React, { useState, useEffect } from "react";
import { Link } from "react-router";
import { Search, Eye, Download, Award, TrendingUp, Users, Trophy, } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, } from "../../components/ui/select";
import { Badge } from "../../components/ui/badge";

// export function MyGrades() {
//     const [searchTerm, setSearchTerm] = useState("");
//     const [filterCourse, setFilterCourse] = useState("PYTHON101");
//     const [filterClass, setFilterClass] = useState("1");
//     const [filterAssignment, setFilterAssignment] = useState("all");
//     // 当前登录学生信息
//     const currentStudent = {
//         id: "2024001",
//         name: "张三",
//     };
//     const courses = [
//         { id: "PY101", name: "Python程序设计" },
//         { id: "SH201", name: "Bash Shell程序设计" },
//     ];
//     const classes = [
//         { id: "1", name: "1班" },
//         { id: "2", name: "2班" },
//     ];
//     const assignments = {
//         PY101: [
//             { id: "all", name: "全部作业" },
//             { id: "lab1", name: "实验1：变量与输入输出" },
//             { id: "lab2", name: "实验2：分支与循环" },
//             { id: "lab3", name: "实验3：函数设计" },
//             { id: "lab4", name: "实验4：列表与字典" },
//         ],
//         SH201: [
//             { id: "all", name: "全部作业" },
//             { id: "lab1", name: "实验1：Linux基础命令" },
//             { id: "lab2", name: "实验2：Shell脚本编写" },
//             { id: "lab3", name: "实验3：条件判断与循环" },
//             { id: "lab4", name: "实验4：文件与进程操作" },
//         ],
//     };
//     // 全班学生成绩数据（模拟数据）
//     const allGrades = [
//         {
//             studentId: "2024001",
//             studentName: "张三",
//             course: "PY101",
//             courseName: "Python程序设计",
//             class: "1",
//             assignment: "lab1",
//             assignmentName: "实验1：变量与输入输出",
//             submitTime: "2026-04-14 18:30",
//             score: 95,
//             maxScore: 100,
//             testResults: { passed: 4, total: 5 },
//         },
//         {
//             studentId: "2024002",
//             studentName: "李四",
//             course: "PY101",
//             courseName: "Python程序设计",
//             class: "1",
//             assignment: "lab1",
//             assignmentName: "实验1：变量与输入输出",
//             submitTime: "2026-04-14 20:15",
//             score: 88,
//             maxScore: 100,
//             testResults: { passed: 4, total: 5 },
//         },
//         {
//             studentId: "2024003",
//             studentName: "王五",
//             course: "PY101",
//             courseName: "Python程序设计",
//             class: "1",
//             assignment: "lab1",
//             assignmentName: "实验1：变量与输入输出",
//             submitTime: "2026-04-14 19:45",
//             score: 92,
//             maxScore: 100,
//             testResults: { passed: 5, total: 5 },
//         },
//         {
//             studentId: "2024004",
//             studentName: "赵六",
//             course: "PY101",
//             courseName: "Python程序设计",
//             class: "1",
//             assignment: "lab1",
//             assignmentName: "实验1：变量与输入输出",
//             submitTime: "2026-04-14 21:00",
//             score: 78,
//             maxScore: 100,
//             testResults: { passed: 3, total: 5 },
//         },
//         {
//             studentId: "2024005",
//             studentName: "孙七",
//             course: "PY101",
//             courseName: "Python程序设计",
//             class: "1",
//             assignment: "lab1",
//             assignmentName: "实验1：变量与输入输出",
//             submitTime: "2026-04-14 17:20",
//             score: 85,
//             maxScore: 100,
//             testResults: { passed: 4, total: 5 },
//         },
//         {
//             studentId: "2024001",
//             studentName: "张三",
//             course: "PY101",
//             courseName: "Python程序设计",
//             class: "1",
//             assignment: "lab2",
//             assignmentName: "实验2：分支与循环",
//             submitTime: "2026-04-21 16:30",
//             score: 90,
//             maxScore: 100,
//             testResults: { passed: 5, total: 5 },
//         },
//         {
//             studentId: "2024002",
//             studentName: "李四",
//             course: "PY101",
//             courseName: "Python程序设计",
//             class: "1",
//             assignment: "lab2",
//             assignmentName: "实验2：分支与循环",
//             submitTime: "2026-04-21 18:10",
//             score: 86,
//             maxScore: 100,
//             testResults: { passed: 4, total: 5 },
//         },
//         {
//             studentId: "2024003",
//             studentName: "王五",
//             course: "PY101",
//             courseName: "Python程序设计",
//             class: "1",
//             assignment: "lab2",
//             assignmentName: "实验2：分支与循环",
//             submitTime: "2026-04-21 19:00",
//             score: 94,
//             maxScore: 100,
//             testResults: { passed: 5, total: 5 },
//         },
//     ];
//     const filteredGrades = allGrades.filter((grade) => {
//         const matchesSearch = grade.studentName.includes(searchTerm) ||
//             grade.studentId.includes(searchTerm) ||
//             grade.assignmentName.includes(searchTerm);
//         const matchesCourse = grade.course === filterCourse;
//         const matchesClass = grade.class === filterClass;
//         const matchesAssignment = filterAssignment === "all" || grade.assignment === filterAssignment;
//         return matchesSearch && matchesCourse && matchesClass && matchesAssignment;
//     });
//     // 计算班级统计数据
//     const classAvgScore = filteredGrades.length > 0
//         ? (filteredGrades.reduce((sum, g) => sum + g.score, 0) / filteredGrades.length).toFixed(1)
//         : "0";
//     const highestScore = filteredGrades.length > 0
//         ? Math.max(...filteredGrades.map((g) => g.score))
//         : 0;
//     const lowestScore = filteredGrades.length > 0
//         ? Math.min(...filteredGrades.map((g) => g.score))
//         : 0;
//     // 计算本人成绩和排名
//     const myGrades = filteredGrades.filter((g) => g.studentId === currentStudent.id);
//     const myAvgScore = myGrades.length > 0
//         ? (myGrades.reduce((sum, g) => sum + g.score, 0) / myGrades.length).toFixed(1)
//         : "0";
//     // 计算本人排名（基于平均分）
//     const studentScores = new Map();
//     filteredGrades.forEach((grade) => {
//         if (!studentScores.has(grade.studentId)) {
//             studentScores.set(grade.studentId, []);
//         }
//         studentScores.get(grade.studentId).push(grade.score);
//     });
//     const studentAvgScores = Array.from(studentScores.entries())
//         .map(([studentId, scores]) => ({
//         studentId,
//         avgScore: scores.reduce((a, b) => a + b, 0) / scores.length,
//     }))
//         .sort((a, b) => b.avgScore - a.avgScore);
//     const myRank = studentAvgScores.findIndex((s) => s.studentId === currentStudent.id) + 1;
//     const totalStudents = studentAvgScores.length;
//     const getRankColor = (score) => {
//         if (score >= 90)
//             return "text-green-600";
//         if (score >= 80)
//             return "text-blue-600";
//         if (score >= 70)
//             return "text-amber-600";
//         if (score >= 60)
//             return "text-orange-600";
//         return "text-red-600";
//     };
//     const getRankBadge = (score) => {
//         if (score >= 90)
//             return { text: "优秀", color: "bg-green-50 text-green-700 border-green-200" };
//         if (score >= 80)
//             return { text: "良好", color: "bg-blue-50 text-blue-700 border-blue-200" };
//         if (score >= 70)
//             return { text: "中等", color: "bg-amber-50 text-amber-700 border-amber-200" };
//         if (score >= 60)
//             return { text: "及格", color: "bg-orange-50 text-orange-700 border-orange-200" };
//         return { text: "不及格", color: "bg-red-50 text-red-700 border-red-200" };
//     };
//     const currentAssignments = filterCourse
//         ? assignments[filterCourse] || []
//         : [];
export function MyGrades() {
    const [searchTerm, setSearchTerm] = useState("");
    const [filterCourse, setFilterCourse] = useState("PY101");
    const [filterClass, setFilterClass] = useState("1");
    const [filterAssignment, setFilterAssignment] = useState("all");

    // ======================新增接口状态 ======================
    const [scoreList, setScoreList] = useState([]);
    const [loading, setLoading] = useState(true);
    const [currentStudent, setCurrentStudent] = useState({ id: "", name: "" });

    const courses = [
        { id: "PY101", name: "Python程序设计" },
        { id: "SH201", name: "Bash Shell程序设计" },
    ];
    const classes = [
        { id: "1", name: "1班" },
        { id: "2", name: "2班" },
    ];
    const assignments = {
        PY101: [
            { id: "all", name: "全部作业" },
            { id: "lab1", name: "实验1：变量与输入输出" },
            { id: "lab2", name: "实验2：分支与循环" },
        ],
        SH201: [
            { id: "all", name: "全部作业" },
            { id: "lab1", name: "实验1：Linux基础命令" },
            { id: "lab2", name: "实验2：Shell脚本编写" },
        ],
    };

    // ======================获取当前登录学生信息（/api/v1/auth/me）======================
    useEffect(() => {
        const fetchMe = async () => {
            try {
                const token = localStorage.getItem("student_token");
                const res = await fetch("http://localhost:8000/api/v1/auth/me", {
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`
                    }
                });
                const data = await res.json();
                if (data.code === 0) {
                    setCurrentStudent({
                        id: data.data.username,
                        name: data.data.real_name
                    });
                }
            } catch (err) {
                console.error("获取用户信息失败", err);
            }
        };
        fetchMe();
    }, []);

    // ======================获取个人成绩列表（/api/v1/scores/me）======================
    useEffect(() => {
        const fetchMyScores = async () => {
            setLoading(true);
            try {
                const token = localStorage.getItem("student_token");
                const res = await fetch("http://localhost:8000/api/v1/scores/me", {
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`
                    }
                });
                const data = await res.json();
                if (data.code === 0) {
                    // 接口数据映射为页面所需结构
                    const formatted = data.data.items.map(item => ({
                        studentId: item.student_id || currentStudent.id,
                        studentName: item.student_name || currentStudent.name,
                        course: item.course_code || "PY101",
                        courseName: item.course_name || "Python程序设计",
                        class: filterClass,
                        assignment: item.assignment_id || "lab1",
                        assignmentName: item.assignment_title || "作业",
                        submitTime: item.created_at || "",
                        score: item.score || 0,
                        maxScore: 100,
                        testResults: {
                            passed: item.result_detail?.passed_count || 0,
                            total: item.result_detail?.total_count || 0
                        }
                    }));
                    setScoreList(formatted);
                }
            } catch (err) {
                console.error("获取成绩失败", err);
            } finally {
                setLoading(false);
            }
        };

        if (currentStudent.id) fetchMyScores();
    }, [currentStudent, filterClass]);

    // ======================使用接口数据替代模拟数据 ======================
    const filteredGrades = scoreList.filter((grade) => {
        const matchesSearch =
            grade.studentName?.includes(searchTerm) ||
            grade.studentId?.includes(searchTerm) ||
            grade.assignmentName?.includes(searchTerm);
        const matchesCourse = grade.course === filterCourse;
        const matchesClass = grade.class === filterClass;
        const matchesAssignment = filterAssignment === "all" || grade.assignment === filterAssignment;
        return matchesSearch && matchesCourse && matchesClass && matchesAssignment;
    });

    const classAvgScore = filteredGrades.length > 0
        ? (filteredGrades.reduce((sum, g) => sum + g.score, 0) / filteredGrades.length).toFixed(1)
        : "0";
    const highestScore = filteredGrades.length > 0
        ? Math.max(...filteredGrades.map(g => g.score))
        : 0;
    const lowestScore = filteredGrades.length > 0
        ? Math.min(...filteredGrades.map(g => g.score))
        : 0;

    const myGrades = filteredGrades.filter(g => g.studentId === currentStudent.id);
    const myAvgScore = myGrades.length > 0
        ? (myGrades.reduce((sum, g) => sum + g.score, 0) / myGrades.length).toFixed(1)
        : "0";

    const studentScores = new Map();
    filteredGrades.forEach(grade => {
        if (!studentScores.has(grade.studentId)) {
            studentScores.set(grade.studentId, []);
        }
        studentScores.get(grade.studentId).push(grade.score);
    });
    const studentAvgScores = Array.from(studentScores.entries())
        .map(([studentId, scores]) => ({
            studentId,
            avgScore: scores.reduce((a, b) => a + b, 0) / scores.length
        }))
        .sort((a, b) => b.avgScore - a.avgScore);

    const myRank = studentAvgScores.findIndex(s => s.studentId === currentStudent.id) + 1;
    const totalStudents = studentAvgScores.length;

    const getRankColor = (score) => {
        if (score >= 90) return "text-green-600";
        if (score >= 80) return "text-blue-600";
        if (score >= 70) return "text-amber-600";
        if (score >= 60) return "text-orange-600";
        return "text-red-600";
    };
    const getRankBadge = (score) => {
        if (score >= 90) return { text: "优秀", color: "bg-green-50 text-green-700 border-green-200" };
        if (score >= 80) return { text: "良好", color: "bg-blue-50 text-blue-700 border-blue-200" };
        if (score >= 70) return { text: "中等", color: "bg-amber-50 text-amber-700 border-amber-200" };
        if (score >= 60) return { text: "及格", color: "bg-orange-50 text-orange-700 border-orange-200" };
        return { text: "不及格", color: "bg-red-50 text-red-700 border-red-200" };
    };

    const currentAssignments = filterCourse ? assignments[filterCourse] || [] : [];

    // ======================增加加载状态展示 ======================
    if (loading) {
        return _jsx("div", { className: "p-10 text-center", children: "加载中..." });
    }
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsxs("div", { children: [_jsx("h1", { className: "text-2xl text-gray-900 mb-1", children: "\u73ED\u7EA7\u6210\u7EE9\u67E5\u770B" }), _jsx("p", { className: "text-gray-600", children: "\u67E5\u770B\u73ED\u7EA7\u6240\u6709\u5B66\u751F\u7684\u6210\u7EE9\u548C\u6392\u540D\u60C5\u51B5" })] }), _jsxs(Button, { variant: "outline", className: "gap-2", children: [_jsx(Download, { className: "w-4 h-4" }), "\u5BFC\u51FA\u6210\u7EE9\u5355"] })] }), _jsx(Card, { className: "border-0 shadow-sm", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4", children: [_jsxs("div", { className: "space-y-2", children: [_jsx("label", { className: "text-sm text-gray-700", children: "\u8BFE\u7A0B" }), _jsxs(Select, { value: filterCourse, onValueChange: (value) => {
                                            setFilterCourse(value);
                                            setFilterAssignment("all");
                                        }, children: [_jsx(SelectTrigger, { children: _jsx(SelectValue, {}) }), _jsx(SelectContent, { children: courses.map((course) => (_jsx(SelectItem, { value: course.id, children: course.name }, course.id))) })] })] }), _jsxs("div", { className: "space-y-2", children: [_jsx("label", { className: "text-sm text-gray-700", children: "\u73ED\u7EA7" }), _jsxs(Select, { value: filterClass, onValueChange: setFilterClass, children: [_jsx(SelectTrigger, { children: _jsx(SelectValue, {}) }), _jsx(SelectContent, { children: classes.map((cls) => (_jsx(SelectItem, { value: cls.id, children: cls.name }, cls.id))) })] })] }), _jsxs("div", { className: "space-y-2", children: [_jsx("label", { className: "text-sm text-gray-700", children: "\u4F5C\u4E1A" }), _jsxs(Select, { value: filterAssignment, onValueChange: setFilterAssignment, children: [_jsx(SelectTrigger, { children: _jsx(SelectValue, {}) }), _jsx(SelectContent, { children: currentAssignments.map((assignment) => (_jsx(SelectItem, { value: assignment.id, children: assignment.name }, assignment.id))) })] })] }), _jsxs("div", { className: "space-y-2", children: [_jsx("label", { className: "text-sm text-gray-700", children: "\u641C\u7D22" }), _jsxs("div", { className: "relative", children: [_jsx(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" }), _jsx(Input, { placeholder: "\u5B66\u53F7/\u59D3\u540D...", value: searchTerm, onChange: (e) => setSearchTerm(e.target.value), className: "pl-10" })] })] })] }) }) }), _jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6", children: [_jsx(Card, { className: "border-0 shadow-sm", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "flex items-start justify-between", children: [_jsxs("div", { children: [_jsx("p", { className: "text-sm text-gray-600 mb-1", children: "\u73ED\u7EA7\u5E73\u5747\u5206" }), _jsx("h3", { className: "text-3xl text-gray-900", children: classAvgScore })] }), _jsx("div", { className: "w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center", children: _jsx(Users, { className: "w-6 h-6 text-blue-600" }) })] }) }) }), _jsx(Card, { className: "border-0 shadow-sm", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "flex items-start justify-between", children: [_jsxs("div", { children: [_jsx("p", { className: "text-sm text-gray-600 mb-1", children: "\u6700\u9AD8\u5206" }), _jsx("h3", { className: "text-3xl text-green-600", children: highestScore })] }), _jsx("div", { className: "w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center", children: _jsx(TrendingUp, { className: "w-6 h-6 text-green-600" }) })] }) }) }), _jsx(Card, { className: "border-0 shadow-sm", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "flex items-start justify-between", children: [_jsxs("div", { children: [_jsx("p", { className: "text-sm text-gray-600 mb-1", children: "\u6700\u4F4E\u5206" }), _jsx("h3", { className: "text-3xl text-amber-600", children: lowestScore })] }), _jsx("div", { className: "w-12 h-12 bg-amber-50 rounded-xl flex items-center justify-center", children: _jsx(Award, { className: "w-6 h-6 text-amber-600" }) })] }) }) }), _jsx(Card, { className: "border-0 shadow-sm bg-gradient-to-br from-green-50 to-blue-50 border-green-200", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "flex items-start justify-between", children: [_jsxs("div", { children: [_jsx("p", { className: "text-sm text-green-700 mb-1", children: "\u6211\u7684\u6210\u7EE9" }), _jsx("h3", { className: "text-3xl text-green-600", children: myAvgScore })] }), _jsx("div", { className: "w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center", children: _jsx(Award, { className: "w-6 h-6 text-green-600" }) })] }) }) }), _jsx(Card, { className: "border-0 shadow-sm bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "flex items-start justify-between", children: [_jsxs("div", { children: [_jsx("p", { className: "text-sm text-purple-700 mb-1", children: "\u6211\u7684\u6392\u540D" }), _jsxs("div", { className: "flex items-baseline gap-1", children: [_jsx("h3", { className: "text-3xl text-purple-600", children: myRank }), _jsxs("span", { className: "text-sm text-purple-600", children: ["/", totalStudents] })] })] }), _jsx("div", { className: "w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center", children: _jsx(Trophy, { className: "w-6 h-6 text-purple-600" }) })] }) }) })] }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { className: "border-b border-gray-100", children: _jsxs(CardTitle, { children: ["\u6210\u7EE9\u5217\u8868 (", filteredGrades.length, "\u6761\u8BB0\u5F55)"] }) }), _jsxs(CardContent, { className: "p-0", children: [_jsx("div", { className: "overflow-x-auto", children: _jsxs("table", { className: "w-full", children: [_jsx("thead", { children: _jsxs("tr", { className: "border-b border-gray-200 bg-gray-50", children: [_jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u5B66\u53F7" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u59D3\u540D" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u4F5C\u4E1A\u540D\u79F0" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u63D0\u4EA4\u65F6\u95F4" }), _jsx("th", { className: "text-center py-3 px-4 text-sm text-gray-600", children: "\u6D4B\u8BD5\u901A\u8FC7" }), _jsx("th", { className: "text-center py-3 px-4 text-sm text-gray-600", children: "\u5206\u6570" }), _jsx("th", { className: "text-center py-3 px-4 text-sm text-gray-600", children: "\u7B49\u7EA7" }), _jsx("th", { className: "text-center py-3 px-4 text-sm text-gray-600", children: "\u64CD\u4F5C" })] }) }), _jsx("tbody", { className: "divide-y divide-gray-200", children: filteredGrades.map((grade, index) => {
                                                const isMyGrade = grade.studentId === currentStudent.id;
                                                const rankBadge = getRankBadge(grade.score);
                                                return (_jsxs("tr", { className: `hover:bg-gray-50 ${isMyGrade ? "bg-green-50" : ""}`, children: [_jsxs("td", { className: "py-3 px-4 text-sm text-gray-900", children: [grade.studentId, isMyGrade && (_jsx(Badge, { className: "ml-2 bg-green-100 text-green-700 border-0 text-xs", children: "\u6211" }))] }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-900", children: grade.studentName }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-900", children: grade.assignmentName }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: grade.submitTime }), _jsx("td", { className: "py-3 px-4 text-center", children: _jsxs("span", { className: "text-sm text-gray-900", children: [grade.testResults.passed, "/", grade.testResults.total] }) }), _jsx("td", { className: "py-3 px-4 text-center", children: _jsxs("div", { className: "flex flex-col items-center", children: [_jsx("span", { className: `text-lg font-semibold ${getRankColor(grade.score)}`, children: grade.score }), _jsxs("span", { className: "text-xs text-gray-500", children: ["/", grade.maxScore] })] }) }), _jsx("td", { className: "py-3 px-4 text-center", children: _jsx(Badge, { className: `${rankBadge.color} border text-xs`, children: rankBadge.text }) }), _jsx("td", { className: "py-3 px-4 text-center", children: _jsx(Link, { to: `/student/grade-detail/${index + 1}`, children: _jsxs(Button, { variant: "ghost", size: "sm", className: "gap-2", children: [_jsx(Eye, { className: "w-4 h-4" }), "\u8BE6\u60C5"] }) }) })] }, index));
                                            }) })] }) }), filteredGrades.length === 0 && (_jsx("div", { className: "text-center py-12", children: _jsx("p", { className: "text-gray-500", children: "\u6CA1\u6709\u627E\u5230\u5339\u914D\u7684\u6210\u7EE9\u8BB0\u5F55" }) }))] })] })] }));
}
