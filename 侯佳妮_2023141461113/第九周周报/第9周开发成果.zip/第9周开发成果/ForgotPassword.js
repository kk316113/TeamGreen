import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { useNavigate, Link } from "react-router";
import { BarChart3, Mail, Lock, CheckCircle, ArrowLeft, Key } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
export function StudentForgotPassword() {
    const navigate = useNavigate();
    const [step, setStep] = useState("email");
    const [studentId, setStudentId] = useState("");
    const [email, setEmail] = useState("");
    const [verificationCode, setVerificationCode] = useState("");
    const [newPassword, setNewPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [countdown, setCountdown] = useState(0);
    // // 发送验证码
    // const handleSendCode = (e) => {
    //     e.preventDefault();
    //     if (!studentId || !email) {
    //         alert("请输入学号和邮箱地址");
    //         return;
    //     }
    //     // 模拟验证学号和邮箱是否匹配
    //     alert(`验证码已发送到 ${email}`);
    //     setStep("verify");
    //     setCountdown(60);
    //     const timer = setInterval(() => {
    //         setCountdown((prev) => {
    //             if (prev <= 1) {
    //                 clearInterval(timer);
    //                 return 0;
    //             }
    //             return prev - 1;
    //         });
    //     }, 1000);
    // };
    // // 重新发送验证码
    // const handleResendCode = () => {
    //     if (countdown > 0)
    //         return;
    //     alert(`验证码已重新发送到 ${email}`);
    //     setCountdown(60);
    //     const timer = setInterval(() => {
    //         setCountdown((prev) => {
    //             if (prev <= 1) {
    //                 clearInterval(timer);
    //                 return 0;
    //             }
    //             return prev - 1;
    //         });
    //     }, 1000);
    // };
    // // 验证验证码
    // const handleVerifyCode = (e) => {
    //     e.preventDefault();
    //     if (!verificationCode) {
    //         alert("请输入验证码");
    //         return;
    //     }
    //     // 模拟验证
    //     if (verificationCode === "123456") {
    //         setStep("reset");
    //     }
    //     else {
    //         alert("验证码错误，请重新输入（提示：123456）");
    //     }
    // };
    // // 重置密码
    // const handleResetPassword = (e) => {
    //     e.preventDefault();
    //     if (!newPassword || !confirmPassword) {
    //         alert("请输入新密码");
    //         return;
    //     }
    //     if (newPassword !== confirmPassword) {
    //         alert("两次输入的密码不一致");
    //         return;
    //     }
    //     if (newPassword.length < 6) {
    //         alert("密码长度至少6位");
    //         return;
    //     }
    //     // 模拟重置密码
    //     setStep("success");
    // };
    // // 返回登录
    // const handleBackToLogin = () => {
    //     navigate("/student/login");
    // };
        const [loading, setLoading] = useState(false);

    // ====================== 发送验证码，对接B4学生信息校验接口 ======================
    const handleSendCode = async (e) => {
        e.preventDefault();
        if (!studentId || !email) {
            alert("请输入学号和邮箱地址");
            return;
        }

        setLoading(true);
        try {
            // 对接 B4 接口：根据学号查询学生信息（校验学号+邮箱是否匹配）
            const token = localStorage.getItem("student_token");
            const res = await fetch(`http://localhost:8000/api/v1/students/${studentId}`, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    ...(token && { "Authorization": `Bearer ${token}` })
                }
            });
            const data = await res.json();

            if (data.code === 0 && data.data.email === email) {
                alert(`验证码已发送到 ${email}`);
                setStep("verify");
                setCountdown(60);
                const timer = setInterval(() => {
                    setCountdown((prev) => {
                        if (prev <= 1) {
                            clearInterval(timer);
                            return 0;
                        }
                        return prev - 1;
                    });
                }, 1000);
            } else {
                alert("学号与邮箱不匹配，请检查");
            }
        } catch (err) {
            console.error(err);
            alert("校验失败，请重试");
        } finally {
            setLoading(false);
        }
    };

    // ======================重发验证码======================
    const handleResendCode = () => {
        if (countdown > 0) return;
        alert(`验证码已重新发送到 ${email}`);
        setCountdown(60);
        const timer = setInterval(() => {
            setCountdown((prev) => {
                if (prev <= 1) {
                    clearInterval(timer);
                    return 0;
                }
                return prev - 1;
            });
        }, 1000);
    };

    // ======================验证验证码======================
    const handleVerifyCode = async (e) => {
        e.preventDefault();
        if (!verificationCode) {
            alert("请输入验证码");
            return;
        }

        setLoading(true);
        try {
            // 对接 B4 验证码校验接口（扩展接口）
            const res = await fetch("http://localhost:8000/api/v1/auth/verify-code", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    student_id: studentId,
                    code: verificationCode
                })
            });
            const data = await res.json();

            if (data.code === 0) {
                setStep("reset");
            } else {
                alert("验证码错误，请重新输入");
            }
        } catch (err) {
            console.error(err);
            alert("验证失败");
        } finally {
            setLoading(false);
        }
    };

    // ======================重置密码 ======================
    const handleResetPassword = async (e) => {
        e.preventDefault();
        if (!newPassword || !confirmPassword) {
            alert("请输入新密码");
            return;
        }
        if (newPassword !== confirmPassword) {
            alert("两次输入的密码不一致");
            return;
        }
        if (newPassword.length < 6) {
            alert("密码长度至少6位");
            return;
        }

        setLoading(true);
        try {
            // 对接 B4 密码重置接口（扩展接口）
            const res = await fetch("http://localhost:8000/api/v1/auth/reset-password", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    student_id: studentId,
                    new_password: newPassword,
                    code: verificationCode
                })
            });
            const data = await res.json();

            if (data.code === 0) {
                setStep("success");
            } else {
                alert(data.message || "重置失败");
            }
        } catch (err) {
            console.error(err);
            alert("重置失败，请重试");
        } finally {
            setLoading(false);
        }
    };

    const handleBackToLogin = () => {
        navigate("/student/login");
    };
    return (_jsx("div", { className: "min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 flex items-center justify-center p-4", children: _jsx("div", { className: "w-full max-w-md", children: _jsxs("div", { className: "bg-white rounded-2xl shadow-xl p-8", children: [_jsxs("div", { className: "text-center mb-8", children: [_jsx("div", { className: "inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl mb-4 shadow-sm", children: _jsx(BarChart3, { className: "w-8 h-8 text-white" }) }), _jsx("h1", { className: "text-2xl font-semibold text-gray-900 mb-2", children: "\u627E\u56DE\u5BC6\u7801" }), _jsx("p", { className: "text-gray-500", children: "\u5B66\u751F\u7AEF - \u5BC6\u7801\u91CD\u7F6E" })] }), step === "email" && (_jsxs("form", { onSubmit: handleSendCode, className: "space-y-5", children: [_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "studentId", children: "\u5B66\u53F7" }), _jsx(Input, { id: "studentId", type: "text", placeholder: "\u8BF7\u8F93\u5165\u5B66\u53F7", value: studentId, onChange: (e) => setStudentId(e.target.value), className: "h-11 border-gray-200" })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "email", children: "\u90AE\u7BB1\u5730\u5740" }), _jsxs("div", { className: "relative", children: [_jsx(Mail, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" }), _jsx(Input, { id: "email", type: "email", placeholder: "\u8BF7\u8F93\u5165\u6CE8\u518C\u65F6\u4F7F\u7528\u7684\u90AE\u7BB1", value: email, onChange: (e) => setEmail(e.target.value), className: "h-11 pl-10 border-gray-200" })] }), _jsx("p", { className: "text-xs text-gray-500", children: "\u8BF7\u8F93\u5165\u4E0E\u5B66\u53F7\u7ED1\u5B9A\u7684\u90AE\u7BB1\u5730\u5740" })] }), _jsxs(Button, { type: "submit", className: "w-full h-11 bg-green-600 hover:bg-green-700 shadow-sm", children: [_jsx(Mail, { className: "w-4 h-4 mr-2" }), "\u53D1\u9001\u9A8C\u8BC1\u7801"] }), _jsx("div", { className: "text-center", children: _jsxs(Link, { to: "/student/login", className: "text-sm text-gray-600 hover:text-gray-900 inline-flex items-center gap-1", children: [_jsx(ArrowLeft, { className: "w-4 h-4" }), "\u8FD4\u56DE\u767B\u5F55"] }) })] })), step === "verify" && (_jsxs("form", { onSubmit: handleVerifyCode, className: "space-y-5", children: [_jsx("div", { className: "p-4 bg-green-50 rounded-xl border border-green-100", children: _jsxs("p", { className: "text-sm text-green-700", children: ["\u9A8C\u8BC1\u7801\u5DF2\u53D1\u9001\u5230 ", _jsx("span", { className: "font-medium", children: email })] }) }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "code", children: "\u9A8C\u8BC1\u7801" }), _jsxs("div", { className: "relative", children: [_jsx(Key, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" }), _jsx(Input, { id: "code", type: "text", placeholder: "\u8BF7\u8F93\u51656\u4F4D\u9A8C\u8BC1\u7801", value: verificationCode, onChange: (e) => setVerificationCode(e.target.value), maxLength: 6, className: "h-11 pl-10 border-gray-200" })] }), _jsxs("div", { className: "flex items-center justify-between text-xs", children: [_jsx("span", { className: "text-gray-500", children: "\u8BF7\u67E5\u6536\u90AE\u4EF6\u4E2D\u7684\u9A8C\u8BC1\u7801" }), countdown > 0 ? (_jsxs("span", { className: "text-gray-400", children: [countdown, "\u79D2\u540E\u53EF\u91CD\u53D1"] })) : (_jsx("button", { type: "button", onClick: handleResendCode, className: "text-green-600 hover:text-green-700", children: "\u91CD\u65B0\u53D1\u9001" }))] })] }), _jsx(Button, { type: "submit", className: "w-full h-11 bg-green-600 hover:bg-green-700 shadow-sm", children: "\u9A8C\u8BC1\u5E76\u7EE7\u7EED" }), _jsx("div", { className: "text-center", children: _jsxs("button", { type: "button", onClick: () => setStep("email"), className: "text-sm text-gray-600 hover:text-gray-900 inline-flex items-center gap-1", children: [_jsx(ArrowLeft, { className: "w-4 h-4" }), "\u8FD4\u56DE\u4E0A\u4E00\u6B65"] }) })] })), step === "reset" && (_jsxs("form", { onSubmit: handleResetPassword, className: "space-y-5", children: [_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "newPassword", children: "\u65B0\u5BC6\u7801" }), _jsxs("div", { className: "relative", children: [_jsx(Lock, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" }), _jsx(Input, { id: "newPassword", type: "password", placeholder: "\u8BF7\u8F93\u5165\u65B0\u5BC6\u7801\uFF08\u81F3\u5C116\u4F4D\uFF09", value: newPassword, onChange: (e) => setNewPassword(e.target.value), className: "h-11 pl-10 border-gray-200" })] })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "confirmPassword", children: "\u786E\u8BA4\u5BC6\u7801" }), _jsxs("div", { className: "relative", children: [_jsx(Lock, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" }), _jsx(Input, { id: "confirmPassword", type: "password", placeholder: "\u8BF7\u518D\u6B21\u8F93\u5165\u65B0\u5BC6\u7801", value: confirmPassword, onChange: (e) => setConfirmPassword(e.target.value), className: "h-11 pl-10 border-gray-200" })] })] }), newPassword && confirmPassword && newPassword !== confirmPassword && (_jsx("p", { className: "text-sm text-red-600", children: "\u4E24\u6B21\u8F93\u5165\u7684\u5BC6\u7801\u4E0D\u4E00\u81F4" })), _jsxs(Button, { type: "submit", className: "w-full h-11 bg-green-600 hover:bg-green-700 shadow-sm", children: [_jsx(Lock, { className: "w-4 h-4 mr-2" }), "\u786E\u8BA4\u91CD\u7F6E\u5BC6\u7801"] })] })), step === "success" && (_jsxs("div", { className: "text-center space-y-6", children: [_jsx("div", { className: "inline-flex items-center justify-center w-20 h-20 bg-green-50 rounded-full", children: _jsx(CheckCircle, { className: "w-12 h-12 text-green-600" }) }), _jsxs("div", { children: [_jsx("h3", { className: "text-xl font-semibold text-gray-900 mb-2", children: "\u5BC6\u7801\u91CD\u7F6E\u6210\u529F\uFF01" }), _jsx("p", { className: "text-gray-500", children: "\u60A8\u7684\u5BC6\u7801\u5DF2\u6210\u529F\u91CD\u7F6E\uFF0C\u8BF7\u4F7F\u7528\u65B0\u5BC6\u7801\u767B\u5F55" })] }), _jsx(Button, { onClick: handleBackToLogin, className: "w-full h-11 bg-green-600 hover:bg-green-700 shadow-sm", children: "\u8FD4\u56DE\u767B\u5F55" })] })), _jsx("div", { className: "mt-8 pt-6 border-t border-gray-100 text-center text-sm text-gray-500", children: "\u00A9 2024 AutoGrader. \u5B66\u751F\u7AEF\u7CFB\u7EDF" })] }) }) }));
}
