// import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// import { Link, useParams } from "react-router";
// import { Calendar, Clock, BookOpen, FileCode, Send, CheckCircle, AlertTriangle, Info, ArrowLeft, Code, Target, FileText, } from "lucide-react";
// import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
// import { Button } from "../../components/ui/button";
// import { Badge } from "../../components/ui/badge";
// export function TaskDetail() {
//     const { taskId } = useParams();
//     // 模拟任务数据
//     const task = {
//         id: 1,
//         taskName: "实验4：列表与字典",
//         courseId: "PY101",
//         courseName: "Python程序设计",
//         deadline: "2024-04-05 23:59",
//         status: "pending",
//         statusText: "未提交",
//         daysLeft: 7,
//         difficulty: "中等",
//         maxScore: 100,
//         description: `## 任务目标

// 本实验要求使用列表和字典数据结构存储和处理数据。

// ## 功能要求

// ### 1. 数据存储
// - 使用列表存储学生成绩数据
// - 支持数据的读取、排序、查询操作

// ### 2. 数据排序
// - 按成绩从高到低排序
// - 使用字典存储学号和成绩的映射
// - 输出排序后的学号列表

// ### 3. 数据查询
// - 使用队列实现BFS
// - 输出排序后的学号列表
// - 能够找到从起点到其他顶点的最短路径

// ### 4. 测试用例
// - 提供至少3个测试用例
// - 包含有向图和无向图
// - 包含连通图和非连通图的情况

// ## 输入输出格式

// ### 输入格式
// \`\`\`
// 第一行：顶点数 n，边数 m，图类型（0表示无向图，1表示有向图）
// 接下来 m 行：每行两个整数 u v，表示顶点 u 和 v 之间有一条边
// 最后一行：起始顶点编号
// \`\`\`

// ### 输出格式
// \`\`\`
// 第一行：DFS遍历序列
// 第二行：BFS遍历序列
// \`\`\`

// ### 示例输入
// \`\`\`
// 5 6 0
// 0 1
// 0 2
// 1 3
// 1 4
// 2 4
// 3 4
// 0
// \`\`\`

// ### 示例输出
// \`\`\`
// DFS: 0 1 3 4 2
// BFS: 0 1 2 3 4
// \`\`\`

// ## 评分标准

// - **代码正确性 (60分)**
//   - DFS算法正确性：20分
//   - BFS算法正确性：20分
//   - 边界情况处理：20分

// - **代码质量 (25分)**
//   - 代码规范性：10分
//   - 注释完整性：8分
//   - 变量命名合理性：7分

// - **测试用例 (15分)**
//   - 测试用例完整性：10分
//   - 测试结果正确性：5分

// ## 提交要求

// - 支持的编程语言：C/C++、Java、Python
// - 文件命名：graph_traversal.{cpp|java|py}
// - 代码编码：UTF-8
// - 单文件提交或打包为.zip格式

// ## 注意事项

// 1. 代码必须能够独立编译运行
// 2. 不允许使用图算法库，需要手动实现
// 3. 注意处理空图、单节点图等边界情况
// 4. 确保代码有适当的注释说明
// 5. 提交前请充分测试代码的正确性`,
//         supportedLanguages: ["C/C++", "Java", "Python"],
//         fileFormats: [".c", ".cpp", ".java", ".py", ".zip"],
//         maxFileSize: "10MB",
//         submitInstructions: [
//             "确保代码编码为UTF-8",
//             "单个文件直接上传，多个文件打包为.zip",
//             "文件命名建议包含学号和任务名称",
//             "提交后系统自动测评，请耐心等待",
//         ],
//     };
//     return (_jsxs("div", { className: "space-y-6", children: [_jsx("div", { children: _jsx(Link, { to: "/student/tasks", children: _jsxs(Button, { variant: "ghost", className: "gap-2 -ml-2", children: [_jsx(ArrowLeft, { className: "w-4 h-4" }), "\u8FD4\u56DE\u4EFB\u52A1\u5217\u8868"] }) }) }), _jsx(Card, { className: "border-0 shadow-sm", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "space-y-4", children: [_jsxs("div", { className: "flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4", children: [_jsxs("div", { className: "flex-1", children: [_jsxs("div", { className: "flex items-center gap-3 mb-3", children: [_jsx("h1", { className: "text-2xl text-gray-900", children: task.taskName }), _jsx(Badge, { variant: "secondary", className: task.difficulty === "困难"
//                                                             ? "bg-red-50 text-red-700"
//                                                             : task.difficulty === "中等"
//                                                                 ? "bg-amber-50 text-amber-700"
//                                                                 : "bg-green-50 text-green-700", children: task.difficulty })] }), _jsxs("div", { className: "flex flex-wrap items-center gap-4 text-sm text-gray-600", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(BookOpen, { className: "w-4 h-4" }), _jsx("span", { children: task.courseName })] }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Target, { className: "w-4 h-4" }), _jsxs("span", { children: ["\u6EE1\u5206\uFF1A", task.maxScore, "\u5206"] })] }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Calendar, { className: "w-4 h-4" }), _jsxs("span", { children: ["\u622A\u6B62\u65F6\u95F4\uFF1A", task.deadline] })] }), _jsxs(Badge, { variant: "outline", className: task.daysLeft <= 3
//                                                             ? "bg-red-50 text-red-700 border-red-200"
//                                                             : "bg-orange-50 text-orange-700 border-orange-200", children: ["\u5269\u4F59 ", task.daysLeft, " \u5929"] })] })] }), _jsx("div", { className: "flex lg:flex-col gap-3", children: _jsx(Badge, { variant: "outline", className: task.status === "pending"
//                                                 ? "bg-orange-50 text-orange-700 border-orange-200"
//                                                 : task.status === "submitted"
//                                                     ? "bg-blue-50 text-blue-700 border-blue-200"
//                                                     : "bg-green-50 text-green-700 border-green-200", children: task.statusText }) })] }), task.status === "pending" && (_jsx("div", { className: "bg-amber-50 border border-amber-200 rounded-lg p-4", children: _jsxs("div", { className: "flex gap-3", children: [_jsx(AlertTriangle, { className: "w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" }), _jsxs("div", { children: [_jsx("p", { className: "text-sm text-amber-900 mb-1", children: "\u4EFB\u52A1\u5C1A\u672A\u63D0\u4EA4" }), _jsx("p", { className: "text-xs text-amber-700", children: "\u8BF7\u5728\u622A\u6B62\u65F6\u95F4\u524D\u5B8C\u6210\u4EE3\u7801\u63D0\u4EA4\uFF0C\u903E\u671F\u63D0\u4EA4\u53EF\u80FD\u5F71\u54CD\u6210\u7EE9" })] })] }) }))] }) }) }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { children: _jsxs(CardTitle, { className: "flex items-center gap-2", children: [_jsx(FileText, { className: "w-5 h-5" }), "\u4EFB\u52A1\u8BF4\u660E"] }) }), _jsx(CardContent, { children: _jsx("div", { className: "prose prose-sm max-w-none", children: _jsx("div", { className: "whitespace-pre-wrap text-gray-700 leading-relaxed", children: task.description }) }) })] }), _jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6", children: [_jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { children: _jsxs(CardTitle, { className: "flex items-center gap-2 text-lg", children: [_jsx(Code, { className: "w-5 h-5" }), "\u652F\u6301\u7684\u7F16\u7A0B\u8BED\u8A00"] }) }), _jsx(CardContent, { children: _jsx("div", { className: "flex flex-wrap gap-2", children: task.supportedLanguages.map((lang, index) => (_jsx(Badge, { variant: "secondary", className: "bg-blue-50 text-blue-700", children: lang }, index))) }) })] }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { children: _jsxs(CardTitle, { className: "flex items-center gap-2 text-lg", children: [_jsx(FileCode, { className: "w-5 h-5" }), "\u6587\u4EF6\u683C\u5F0F\u8981\u6C42"] }) }), _jsx(CardContent, { children: _jsxs("div", { className: "space-y-2", children: [_jsx("div", { className: "flex flex-wrap gap-2", children: task.fileFormats.map((format, index) => (_jsx(Badge, { variant: "secondary", className: "bg-purple-50 text-purple-700", children: format }, index))) }), _jsxs("p", { className: "text-sm text-gray-600", children: ["\u6587\u4EF6\u5927\u5C0F\u9650\u5236\uFF1A", task.maxFileSize] })] }) })] })] }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { children: _jsxs(CardTitle, { className: "flex items-center gap-2", children: [_jsx(Info, { className: "w-5 h-5" }), "\u63D0\u4EA4\u8BF4\u660E"] }) }), _jsx(CardContent, { children: _jsx("ul", { className: "space-y-2", children: task.submitInstructions.map((instruction, index) => (_jsxs("li", { className: "flex items-start gap-3 text-sm text-gray-700", children: [_jsx(CheckCircle, { className: "w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" }), _jsx("span", { children: instruction })] }, index))) }) })] }), _jsxs("div", { className: "flex gap-4", children: [task.status === "pending" && (_jsx(Link, { to: "/student/submit", className: "flex-1", children: _jsxs(Button, { className: "w-full gap-2 bg-blue-600 hover:bg-blue-700 h-12", children: [_jsx(Send, { className: "w-5 h-5" }), "\u53BB\u63D0\u4EA4\u4EE3\u7801"] }) })), task.status === "submitted" && (_jsxs(Button, { variant: "outline", className: "flex-1 gap-2 h-12", disabled: true, children: [_jsx(Clock, { className: "w-5 h-5" }), "\u7B49\u5F85\u8BC4\u5206\u4E2D"] })), task.status === "graded" && (_jsx(Link, { to: `/student/grade-detail/${task.id}`, className: "flex-1", children: _jsxs(Button, { className: "w-full gap-2 bg-green-600 hover:bg-green-700 h-12", children: [_jsx(FileCode, { className: "w-5 h-5" }), "\u67E5\u770B\u8BC4\u5206\u8BE6\u60C5"] }) }))] })] }));
// }
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { Link, useParams } from "react-router";
import { Calendar, Clock, BookOpen, FileCode, Send, CheckCircle, AlertTriangle, Info, ArrowLeft, Code, Target, FileText, } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Badge } from "../../components/ui/badge";

export function TaskDetail() {
    const { taskId } = useParams();
    const [task, setTask] = useState(null);
    const [loading, setLoading] = useState(true);

    // 获取任务详情接口
    useEffect(() => {
        const fetchTaskDetail = async () => {
            try {
                setLoading(true);
                const token = localStorage.getItem("student_token");
                const res = await fetch(`/api/v1/student/tasks/${taskId}`, {
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`,
                    },
                });
                const data = await res.json();
                if (data.code === 0) {
                    setTask({
                        id: data.data.id,
                        taskName: data.data.task_name,
                        courseId: data.data.course_id,
                        courseName: data.data.course_name,
                        deadline: data.data.deadline,
                        status: data.data.status,
                        statusText: data.data.status_text,
                        daysLeft: data.data.days_left,
                        difficulty: data.data.difficulty,
                        maxScore: data.data.max_score,
                        description: data.data.description,
                        supportedLanguages: data.data.supported_languages,
                        fileFormats: data.data.file_formats,
                        maxFileSize: data.data.max_file_size,
                        submitInstructions: data.data.submit_instructions,
                    });
                }
            } catch (err) {
                console.error("获取任务详情失败", err);
            } finally {
                setLoading(false);
            }
        };

        fetchTaskDetail();
    }, [taskId]);

    // 加载状态
    if (loading) {
        return _jsx("div", { className: "p-10 text-center", children: "加载中..." });
    }

    if (!task) {
        return _jsx("div", { className: "p-10 text-center", children: "任务不存在" });
    }

    return _jsxs("div", { className: "space-y-6", children: [
        _jsx("div", { children: _jsx(Link, { to: "/student/tasks", children: _jsxs(Button, { variant: "ghost", className: "gap-2 -ml-2", children: [
            _jsx(ArrowLeft, { className: "w-4 h-4" }),
            "返回任务列表"
        ] }) }) }),

        _jsx(Card, { className: "border-0 shadow-sm", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "space-y-4", children: [
            _jsxs("div", { className: "flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4", children: [
                _jsxs("div", { className: "flex-1", children: [
                    _jsxs("div", { className: "flex items-center gap-3 mb-3", children: [
                        _jsx("h1", { className: "text-2xl text-gray-900", children: task.taskName }),
                        _jsx(Badge, {
                            variant: "secondary",
                            className: task.difficulty === "困难"
                                ? "bg-red-50 text-red-700"
                                : task.difficulty === "中等"
                                    ? "bg-amber-50 text-amber-700"
                                    : "bg-green-50 text-green-700",
                            children: task.difficulty
                        })
                    ] }),
                    _jsxs("div", { className: "flex flex-wrap items-center gap-4 text-sm text-gray-600", children: [
                        _jsxs("div", { className: "flex items-center gap-2", children: [
                            _jsx(BookOpen, { className: "w-4 h-4" }),
                            _jsx("span", { children: task.courseName })
                        ] }),
                        _jsxs("div", { className: "flex items-center gap-2", children: [
                            _jsx(Target, { className: "w-4 h-4" }),
                            _jsxs("span", { children: ["满分：", task.maxScore, "分"] })
                        ] }),
                        _jsxs("div", { className: "flex items-center gap-2", children: [
                            _jsx(Calendar, { className: "w-4 h-4" }),
                            _jsxs("span", { children: ["截止时间：", task.deadline] })
                        ] }),
                        _jsx(Badge, {
                            variant: "outline",
                            className: task.daysLeft <= 3
                                ? "bg-red-50 text-red-700 border-red-200"
                                : "bg-orange-50 text-orange-700 border-orange-200",
                            children: ["剩余 ", task.daysLeft, " 天"]
                        })
                    ] })
                ] }),
                _jsx("div", { className: "flex lg:flex-col gap-3", children: _jsx(Badge, {
                    variant: "outline",
                    className: task.status === "pending"
                        ? "bg-orange-50 text-orange-700 border-orange-200"
                        : task.status === "submitted"
                            ? "bg-blue-50 text-blue-700 border-blue-200"
                            : "bg-green-50 text-green-700 border-green-200",
                    children: task.statusText
                }) })
            ] }),
            task.status === "pending" && (_jsx("div", { className: "bg-amber-50 border border-amber-200 rounded-lg p-4", children: _jsxs("div", { className: "flex gap-3", children: [
                _jsx(AlertTriangle, { className: "w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" }),
                _jsxs("div", { children: [
                    _jsx("p", { className: "text-sm text-amber-900 mb-1", children: "任务尚未提交" }),
                    _jsx("p", { className: "text-xs text-amber-700", children: "请在截止时间前完成代码提交，逾期提交可能会影响成绩" })
                ] })
            ] }) }))
        ] }) }) }),

        _jsxs(Card, { className: "border-0 shadow-sm", children: [
            _jsx(CardHeader, { children: _jsxs(CardTitle, { className: "flex items-center gap-2", children: [
                _jsx(FileText, { className: "w-5 h-5" }),
                "任务说明"
            ] }) }),
            _jsx(CardContent, { children: _jsx("div", { className: "prose prose-sm max-w-none", children: _jsx("div", { className: "whitespace-pre-wrap text-gray-700 leading-relaxed", children: task.description }) }) })
        ] }),

        _jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6", children: [
            _jsxs(Card, { className: "border-0 shadow-sm", children: [
                _jsx(CardHeader, { children: _jsxs(CardTitle, { className: "flex items-center gap-2 text-lg", children: [
                    _jsx(Code, { className: "w-5 h-5" }),
                    "支持的编程语言"
                ] }) }),
                _jsx(CardContent, { children: _jsx("div", { className: "flex flex-wrap gap-2", children: task.supportedLanguages.map((lang, i) => (
                    _jsx(Badge, { variant: "secondary", className: "bg-blue-50 text-blue-700", children: lang }, i)
                )) }) })
            ] }),
            _jsxs(Card, { className: "border-0 shadow-sm", children: [
                _jsx(CardHeader, { children: _jsxs(CardTitle, { className: "flex items-center gap-2 text-lg", children: [
                    _jsx(FileCode, { className: "w-5 h-5" }),
                    "文件格式要求"
                ] }) }),
                _jsx(CardContent, { children: _jsxs("div", { className: "space-y-2", children: [
                    _jsx("div", { className: "flex flex-wrap gap-2", children: task.fileFormats.map((fmt, i) => (
                        _jsx(Badge, { variant: "secondary", className: "bg-purple-50 text-purple-700", children: fmt }, i)
                    )) }),
                    _jsxs("p", { className: "text-sm text-gray-600", children: ["文件大小限制：", task.maxFileSize] })
                ] }) })
            ] })
        ] }),

        _jsxs(Card, { className: "border-0 shadow-sm", children: [
            _jsx(CardHeader, { children: _jsxs(CardTitle, { className: "flex items-center gap-2", children: [
                _jsx(Info, { className: "w-5 h-5" }),
                "提交说明"
            ] }) }),
            _jsx(CardContent, { children: _jsx("ul", { className: "space-y-2", children: task.submitInstructions.map((item, i) => (
                _jsxs("li", { className: "flex items-start gap-3 text-sm text-gray-700", children: [
                    _jsx(CheckCircle, { className: "w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" }),
                    _jsx("span", { children: item })
                ] }, i)
            )) }) })
        ] }),

        _jsxs("div", { className: "flex gap-4", children: [
            task.status === "pending" && (_jsx(Link, { to: "/student/submit", className: "flex-1", children: _jsxs(Button, { className: "w-full gap-2 bg-blue-600 hover:bg-blue-700 h-12", children: [
                _jsx(Send, { className: "w-5 h-5" }),
                "去提交代码"
            ] }) })),
            task.status === "submitted" && (_jsxs(Button, { variant: "outline", className: "flex-1 gap-2 h-12", disabled: true, children: [
                _jsx(Clock, { className: "w-4 h-4" }),
                "等待测评中"
            ] })),
            task.status === "graded" && (_jsx(Link, { to: `/student/grade-detail/${task.id}`, className: "flex-1", children: _jsxs(Button, { className: "w-full gap-2 bg-green-600 hover:bg-green-700 h-12", children: [
                _jsx(FileCode, { className: "w-5 h-5" }),
                "查看评分详情"
            ] }) }))
        ] })
    ] });
}