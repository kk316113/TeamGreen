import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { useNavigate, Link } from "react-router";
import { BarChart3, LogIn } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
// export function StudentLogin() {
//     const navigate = useNavigate();
//     const [studentId, setStudentId] = useState("");
//     const [password, setPassword] = useState("");
//     const handleLogin = (e) => {
//         e.preventDefault();
//         // 模拟登录 - 演示模式
//         navigate("/student");
//     };
//     return (_jsx("div", { className: "min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 flex items-center justify-center p-4", children: _jsx("div", { className: "w-full max-w-md", children: _jsxs("div", { className: "bg-white rounded-2xl shadow-xl p-8", children: [_jsxs("div", { className: "text-center mb-8", children: [_jsx("div", { className: "inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl mb-4 shadow-sm", children: _jsx(BarChart3, { className: "w-8 h-8 text-white" }) }), _jsx("h1", { className: "text-2xl font-semibold text-gray-900 mb-2", children: "AutoGrader" }), _jsx("p", { className: "text-gray-500", children: "\u8BFE\u7A0B\u4EFB\u52A1\u578B\u4EE3\u7801\u81EA\u52A8\u8BC4\u5206\u7CFB\u7EDF - \u5B66\u751F\u7AEF" })] }), _jsxs("form", { onSubmit: handleLogin, className: "space-y-5", children: [_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "studentId", children: "\u5B66\u53F7" }), _jsx(Input, { id: "studentId", type: "text", placeholder: "\u8BF7\u8F93\u5165\u5B66\u53F7", value: studentId, onChange: (e) => setStudentId(e.target.value), className: "h-11 border-gray-200" })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "password", children: "\u5BC6\u7801" }), _jsx(Input, { id: "password", type: "password", placeholder: "\u8BF7\u8F93\u5165\u5BC6\u7801", value: password, onChange: (e) => setPassword(e.target.value), className: "h-11 border-gray-200" })] }), _jsxs("div", { className: "flex items-center justify-between text-sm", children: [_jsxs("label", { className: "flex items-center gap-2 text-gray-600 cursor-pointer", children: [_jsx("input", { type: "checkbox", className: "rounded border-gray-300 text-green-600 focus:ring-green-500" }), "\u8BB0\u4F4F\u6211"] }), _jsx(Link, { to: "/student/forgot-password", className: "text-green-600 hover:text-green-700 transition-colors", children: "\u5FD8\u8BB0\u5BC6\u7801\uFF1F" })] }), _jsxs(Button, { type: "submit", className: "w-full h-11 bg-green-600 hover:bg-green-700 shadow-sm", children: [_jsx(LogIn, { className: "w-4 h-4 mr-2" }), "\u767B\u5F55"] })] }), _jsx("div", { className: "mt-8 pt-6 border-t border-gray-100 text-center text-sm text-gray-500", children: "\u00A9 2024 AutoGrader. \u5B66\u751F\u7AEF\u7CFB\u7EDF" })] }) }) }));
// }
export function StudentLogin() {
    const navigate = useNavigate();
    const [studentId, setStudentId] = useState("");
    const [password, setPassword] = useState("");

    // ====================== ✅ 修改 1：新增加载状态，防止重复提交 ======================
    const [loading, setLoading] = useState(false);

    // ====================== ✅ 修改 2：对接 B4 真实登录接口 /api/v1/auth/login ======================
    const handleLogin = async (e) => {
        e.preventDefault();

        // 简单校验
        if (!studentId || !password) {
            alert("请输入学号和密码");
            return;
        }

        setLoading(true);
        try {
            // 调用 B4 登录接口
            const res = await fetch("http://localhost:8000/api/v1/auth/login", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    username: studentId,  // B4 接口字段：username（学生=学号）
                    password: password,
                }),
            });

            const data = await res.json();
            if (data.code === 0) {
                // ====================== ✅ 修改 3：保存 Token 到本地 ======================
                localStorage.setItem("token", data.data.token);
                
                // 登录成功跳转到首页
                navigate("/student");
            } else {
                alert(data.message || "登录失败：学号或密码错误");
            }
        } catch (err) {
            console.error("登录请求异常", err);
            alert("登录失败，请检查网络或后端服务");
        } finally {
            setLoading(false);
        }
    };

    // ====================== ✅ 以下 return 渲染 100% 完全没动，和你原来一模一样 ======================
    return (_jsx("div", { className: "min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 flex items-center justify-center p-4", children:
        _jsx("div", { className: "w-full max-w-md", children:
            _jsxs("div", { className: "bg-white rounded-2xl shadow-xl p-8", children: [
                _jsxs("div", { className: "text-center mb-8", children: [
                    _jsx("div", { className: "inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl mb-4 shadow-sm", children:
                        _jsx(BarChart3, { className: "w-8 h-8 text-white" })
                    }),
                    _jsx("h1", { className: "text-2xl font-semibold text-gray-900 mb-2", children: "AutoGrader" }),
                    _jsx("p", { className: "text-gray-500", children: "课程任务代码自动评分系统 - 学生端" })
                ]}),

                _jsxs("form", { onSubmit: handleLogin, className: "space-y-5", children: [
                    _jsxs("div", { className: "space-y-2", children: [
                        _jsx(Label, { htmlFor: "studentId", children: "学号" }),
                        _jsx(Input, {
                            id: "studentId",
                            type: "text",
                            placeholder: "请输入学号",
                            value: studentId,
                            onChange: (e) => setStudentId(e.target.value),
                            className: "h-11 border-gray-200",
                            disabled: loading  // ✅ 修改 4：加载时禁用输入
                        })
                    ]}),
                    _jsxs("div", { className: "space-y-2", children: [
                        _jsx(Label, { htmlFor: "password", children: "密码" }),
                        _jsx(Input, {
                            id: "password",
                            type: "password",
                            placeholder: "请输入密码",
                            value: password,
                            onChange: (e) => setPassword(e.target.value),
                            className: "h-11 border-gray-200",
                            disabled: loading  // ✅ 修改 5：加载时禁用输入
                        })
                    ]}),
                    _jsxs("div", { className: "flex items-center justify-between text-sm", children: [
                        _jsxs("label", { className: "flex items-center gap-2 text-gray-600 cursor-pointer", children: [
                            _jsx("input", { type: "checkbox", className: "rounded border-gray-300 text-green-600 focus:ring-green-500" }),
                            "记住我"
                        ]}),
                        _jsx(Link, { to: "/student/forgot-password", className: "text-green-600 hover:text-green-700 transition-colors", children: "忘记密码？" })
                    ]}),

                    // ====================== ✅ 修改 6：按钮绑定 loading 状态 ======================
                    _jsx(Button, {
                        type: "submit",
                        className: "w-full h-11 bg-green-600 hover:bg-green-700 shadow-sm",
                        disabled: loading  // 加载中不可点击
                    },
                        loading ? "登录中..." : "登录"
                    )
                ]}),

                _jsx("div", { className: "mt-8 pt-6 border-t border-gray-100 text-center text-sm text-gray-500", children: "© 2024 AutoGrader. 学生端系统" })
            ]})
        })
    }));
}