import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
//import { useState } from "react";
import { User, Building, Save, BookOpen } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { useState, useEffect } from "react";
// export function StudentProfile() {
//     const [profile, setProfile] = useState({
//         name: "张三",
//         studentId: "2024001",
//         email: "zhangsan@student.university.edu.cn",
//         phone: "138****5678",
//         major: "计算机科学与技术",
//         class: "计科2401",
//         enrollmentYear: "2024",
//     });
//     const handleSave = () => {
//         console.log("保存个人信息", profile);
//         alert("个人信息已保存");
//     };
//     const stats = [
//         { label: "已选课程", value: "5" },
//         { label: "完成作业", value: "12" },
//         { label: "平均分", value: "88.5" },
//         { label: "优秀率", value: "60%" },
//     ];
//     const enrolledCourses = [
//         { code: "PY101", name: "Python程序设计", teacher: "张老师" },
//         { code: "SH201", name: "Bash Shell程序设计", teacher: "李老师" },
//     ];
//     return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { children: [_jsx("h1", { className: "text-2xl text-gray-900 mb-1", children: "\u4E2A\u4EBA\u4E2D\u5FC3" }), _jsx("p", { className: "text-gray-600", children: "\u7BA1\u7406\u60A8\u7684\u4E2A\u4EBA\u4FE1\u606F\u548C\u8D26\u6237\u8BBE\u7F6E" })] }), _jsx(Card, { className: "border-0 shadow-sm", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "flex items-start gap-6", children: [_jsx("div", { className: "w-24 h-24 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center", children: _jsx(User, { className: "w-12 h-12 text-white" }) }), _jsxs("div", { className: "flex-1", children: [_jsx("h2", { className: "text-2xl text-gray-900 mb-2", children: profile.name }), _jsxs("div", { className: "flex flex-wrap gap-4 text-sm text-gray-600 mb-4", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(User, { className: "w-4 h-4" }), profile.studentId] }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Building, { className: "w-4 h-4" }), profile.major] }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsx(BookOpen, { className: "w-4 h-4" }), profile.class] })] }), _jsx("div", { className: "grid grid-cols-4 gap-4 pt-4 border-t border-gray-100", children: stats.map((stat, index) => (_jsxs("div", { className: "text-center", children: [_jsx("p", { className: "text-2xl text-blue-600 mb-1", children: stat.value }), _jsx("p", { className: "text-xs text-gray-600", children: stat.label })] }, index))) })] })] }) }) }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { children: _jsx(CardTitle, { children: "\u57FA\u672C\u4FE1\u606F" }) }), _jsxs(CardContent, { className: "space-y-4", children: [_jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "name", children: "\u59D3\u540D" }), _jsx(Input, { id: "name", value: profile.name, onChange: (e) => setProfile({ ...profile, name: e.target.value }) })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "studentId", children: "\u5B66\u53F7" }), _jsx(Input, { id: "studentId", value: profile.studentId, disabled: true, className: "bg-gray-50" })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "email", children: "\u90AE\u7BB1" }), _jsx(Input, { id: "email", type: "email", value: profile.email, onChange: (e) => setProfile({ ...profile, email: e.target.value }) })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "phone", children: "\u624B\u673A" }), _jsx(Input, { id: "phone", value: profile.phone, onChange: (e) => setProfile({ ...profile, phone: e.target.value }) })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "major", children: "\u4E13\u4E1A" }), _jsx(Input, { id: "major", value: profile.major, disabled: true, className: "bg-gray-50" })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "class", children: "\u73ED\u7EA7" }), _jsx(Input, { id: "class", value: profile.class, disabled: true, className: "bg-gray-50" })] })] }), _jsx("div", { className: "flex justify-end pt-4", children: _jsxs(Button, { onClick: handleSave, className: "gap-2 bg-blue-600 hover:bg-blue-700", children: [_jsx(Save, { className: "w-4 h-4" }), "\u4FDD\u5B58\u4FEE\u6539"] }) })] })] }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { children: _jsx(CardTitle, { children: "\u5DF2\u9009\u8BFE\u7A0B" }) }), _jsx(CardContent, { children: _jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: enrolledCourses.map((course, index) => (_jsx("div", { className: "border border-gray-200 rounded-lg p-4 hover:border-blue-300 hover:shadow-sm transition-all", children: _jsxs("div", { className: "flex items-start justify-between", children: [_jsxs("div", { className: "flex-1", children: [_jsx("div", { className: "flex items-center gap-2 mb-1", children: _jsx("h3", { className: "text-sm text-gray-900", children: course.name }) }), _jsx("p", { className: "text-xs text-gray-600 mb-2", children: course.code }), _jsxs("p", { className: "text-xs text-gray-500", children: ["\u6388\u8BFE\u6559\u5E08\uFF1A", course.teacher] })] }), _jsx(BookOpen, { className: "w-5 h-5 text-blue-600" })] }) }, index))) }) })] }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { children: _jsx(CardTitle, { children: "\u8D26\u6237\u5B89\u5168" }) }), _jsx(CardContent, { className: "space-y-4", children: _jsxs("div", { className: "flex items-center justify-between p-4 bg-gray-50 rounded-lg", children: [_jsxs("div", { children: [_jsx("p", { className: "text-sm text-gray-900 mb-1", children: "\u4FEE\u6539\u5BC6\u7801" }), _jsx("p", { className: "text-xs text-gray-600", children: "\u5B9A\u671F\u4FEE\u6539\u5BC6\u7801\u4EE5\u4FDD\u62A4\u8D26\u6237\u5B89\u5168" })] }), _jsx(Button, { variant: "outline", children: "\u4FEE\u6539" })] }) })] }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { children: _jsx(CardTitle, { children: "\u7CFB\u7EDF\u8BBE\u7F6E" }) }), _jsxs(CardContent, { className: "space-y-4", children: [_jsxs("div", { className: "flex items-center justify-between p-4 bg-gray-50 rounded-lg", children: [_jsxs("div", { children: [_jsx("p", { className: "text-sm text-gray-900 mb-1", children: "\u90AE\u4EF6\u901A\u77E5" }), _jsx("p", { className: "text-xs text-gray-600", children: "\u63A5\u6536\u4F5C\u4E1A\u63D0\u9192\u548C\u6210\u7EE9\u76F8\u5173\u7684\u90AE\u4EF6\u901A\u77E5" })] }), _jsxs("label", { className: "relative inline-flex items-center cursor-pointer", children: [_jsx("input", { type: "checkbox", className: "sr-only peer", defaultChecked: true }), _jsx("div", { className: "w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" })] })] }), _jsxs("div", { className: "flex items-center justify-between p-4 bg-gray-50 rounded-lg", children: [_jsxs("div", { children: [_jsx("p", { className: "text-sm text-gray-900 mb-1", children: "\u4F5C\u4E1A\u63D0\u9192" }), _jsx("p", { className: "text-xs text-gray-600", children: "\u5728\u4F5C\u4E1A\u622A\u6B62\u524D24\u5C0F\u65F6\u53D1\u9001\u63D0\u9192" })] }), _jsxs("label", { className: "relative inline-flex items-center cursor-pointer", children: [_jsx("input", { type: "checkbox", className: "sr-only peer", defaultChecked: true }), _jsx("div", { className: "w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" })] })] })] })] })] }));
// }
export function StudentProfile() {
    // ====================== ✅ 修改 1：初始化为空，从接口获取 ======================
    const [profile, setProfile] = useState({
        name: "",
        studentId: "",
        email: "",
        phone: "",
        major: "",
        class: "",
        enrollmentYear: "",
    });

    // ====================== ✅ 修改 2：新增加载状态 ======================
    const [loading, setLoading] = useState(false);

    // ====================== ✅ 修改 3：获取学生个人信息接口 ======================
    useEffect(() => {
        const fetchProfile = async () => {
            try {
                setLoading(true);
                const token = localStorage.getItem("token");
                if (!token) return;

                const res = await fetch("/api/v1/student/profile", {
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`,
                    },
                });

                const data = await res.json();
                if (data.code === 0) {
                    setProfile({
                        name: data.data.name || "",
                        studentId: data.data.studentId || "",
                        email: data.data.email || "",
                        phone: data.data.phone || "",
                        major: data.data.major || "",
                        class: data.data.className || "",
                        enrollmentYear: data.data.enrollYear || "",
                    });
                }
            } catch (err) {
                console.error("获取个人信息失败", err);
            } finally {
                setLoading(false);
            }
        };

        fetchProfile();
    }, []);

    // ====================== ✅ 修改 4：保存个人信息接口 ======================
    const handleSave = async () => {
        try {
            setLoading(true);
            const token = localStorage.getItem("token");

            const res = await fetch("/api/v1/student/profile", {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({
                    email: profile.email,
                    phone: profile.phone,
                }),
            });

            const data = await res.json();
            if (data.code === 0) {
                alert("个人信息已保存");
            } else {
                alert(data.message || "保存失败");
            }
        } catch (err) {
            console.error(err);
            alert("保存失败，请检查网络");
        } finally {
            setLoading(false);
        }
    };

    const stats = [
        { label: "已选课程", value: "5" },
        { label: "完成作业", value: "12" },
        { label: "平均分", value: "88.5" },
        { label: "优秀率", value: "60%" },
    ];

    const enrolledCourses = [
        { code: "PY101", name: "Python程序设计", teacher: "张老师" },
        { code: "SH201", name: "Bash Shell程序设计", teacher: "李老师" },
    ];

    // ====================== ✅ 修改 5：加载中状态 ======================
    if (loading) {
        return _jsx("div", { className: "p-10 text-center", children: "加载中..." });
    }

    // ====================== 以下 UI 100% 修复语法，完全匹配你的原始格式 ======================
    return _jsxs("div", { className: "space-y-6", children: [
        _jsxs("div", { children: [
            _jsx("h1", { className: "text-2xl text-gray-900 mb-1", children: "个人中心" }),
            _jsx("p", { className: "text-gray-600", children: "管理您的个人信息和账户设置" })
        ]}),
        _jsx(Card, { className: "border-0 shadow-sm", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "flex items-start gap-6", children: [
            _jsx("div", { className: "w-24 h-24 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center", children: _jsx(User, { className: "w-12 h-12 text-white" }) }),
            _jsxs("div", { className: "flex-1", children: [
                _jsx("h2", { className: "text-2xl text-gray-900 mb-2", children: profile.name }),
                _jsxs("div", { className: "flex flex-wrap gap-4 text-sm text-gray-600 mb-4", children: [
                    _jsxs("div", { className: "flex items-center gap-2", children: [_jsx(User, { className: "w-4 h-4" }), profile.studentId] }),
                    _jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Building, { className: "w-4 h-4" }), profile.major] }),
                    _jsxs("div", { className: "flex items-center gap-2", children: [_jsx(BookOpen, { className: "w-4 h-4" }), profile.class] })
                ]}),
                _jsx("div", { className: "grid grid-cols-4 gap-4 pt-4 border-t border-gray-100", children: stats.map((stat, index) => _jsxs("div", { className: "text-center", children: [
                    _jsx("p", { className: "text-2xl text-blue-600 mb-1", children: stat.value }),
                    _jsx("p", { className: "text-xs text-gray-600", children: stat.label })
                ]}, index)) })
            ]})
        ]}) }) }),
        _jsxs(Card, { className: "border-0 shadow-sm", children: [
            _jsx(CardHeader, { children: _jsx(CardTitle, { children: "基本信息" }) }),
            _jsxs(CardContent, { className: "space-y-4", children: [
                _jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                    _jsxs("div", { className: "space-y-2", children: [
                        _jsx(Label, { htmlFor: "name", children: "姓名" }),
                        _jsx(Input, { id: "name", value: profile.name, onChange: (e) => setProfile({ ...profile, name: e.target.value }) })
                    ]}),
                    _jsxs("div", { className: "space-y-2", children: [
                        _jsx(Label, { htmlFor: "studentId", children: "学号" }),
                        _jsx(Input, { id: "studentId", value: profile.studentId, disabled: true, className: "bg-gray-50" })
                    ]}),
                    _jsxs("div", { className: "space-y-2", children: [
                        _jsx(Label, { htmlFor: "email", children: "邮箱" }),
                        _jsx(Input, { id: "email", type: "email", value: profile.email, onChange: (e) => setProfile({ ...profile, email: e.target.value }) })
                    ]}),
                    _jsxs("div", { className: "space-y-2", children: [
                        _jsx(Label, { htmlFor: "phone", children: "手机" }),
                        _jsx(Input, { id: "phone", value: profile.phone, onChange: (e) => setProfile({ ...profile, phone: e.target.value }) })
                    ]}),
                    _jsxs("div", { className: "space-y-2", children: [
                        _jsx(Label, { htmlFor: "major", children: "专业" }),
                        _jsx(Input, { id: "major", value: profile.major, disabled: true, className: "bg-gray-50" })
                    ]}),
                    _jsxs("div", { className: "space-y-2", children: [
                        _jsx(Label, { htmlFor: "class", children: "班级" }),
                        _jsx(Input, { id: "class", value: profile.class, disabled: true, className: "bg-gray-50" })
                    ]})
                ]}),
                _jsx("div", { className: "flex justify-end pt-4", children: _jsxs(Button, { 
                    onClick: handleSave, 
                    className: "gap-2 bg-blue-600 hover:bg-blue-700", 
                    disabled: loading, 
                    children: [
                        _jsx(Save, { className: "w-4 h-4" }),
                        loading ? "保存中..." : "保存修改"
                    ]
                }) })
            ]})
        ]}),
        _jsxs(Card, { className: "border-0 shadow-sm", children: [
            _jsx(CardHeader, { children: _jsx(CardTitle, { children: "已选课程" }) }),
            _jsx(CardContent, { children: _jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: enrolledCourses.map((course, index) => _jsx("div", { className: "border border-gray-200 rounded-lg p-4 hover:border-blue-300 hover:shadow-sm transition-all", children: _jsxs("div", { className: "flex items-start justify-between", children: [
                _jsxs("div", { className: "flex-1", children: [
                    _jsx("div", { className: "flex items-center gap-2 mb-1", children: _jsx("h3", { className: "text-sm text-gray-900", children: course.name }) }),
                    _jsx("p", { className: "text-xs text-gray-600 mb-2", children: course.code }),
                    _jsxs("p", { className: "text-xs text-gray-500", children: ["授课教师：", course.teacher] })
                ]}),
                _jsx(BookOpen, { className: "w-5 h-5 text-blue-600" })
            ]}) }, index)) }) })
        ]}),
        _jsxs(Card, { className: "border-0 shadow-sm", children: [
            _jsx(CardHeader, { children: _jsx(CardTitle, { children: "账户安全" }) }),
            _jsx(CardContent, { className: "space-y-4", children: _jsxs("div", { className: "flex items-center justify-between p-4 bg-gray-50 rounded-lg", children: [
                _jsxs("div", { children: [
                    _jsx("p", { className: "text-sm text-gray-900 mb-1", children: "修改密码" }),
                    _jsx("p", { className: "text-xs text-gray-600", children: "定期修改密码以保护账户安全" })
                ]}),
                _jsx(Button, { variant: "outline", children: "修改" })
            ]}) })
        ]}),
        _jsxs(Card, { className: "border-0 shadow-sm", children: [
            _jsx(CardHeader, { children: _jsx(CardTitle, { children: "系统设置" }) }),
            _jsxs(CardContent, { className: "space-y-4", children: [
                _jsxs("div", { className: "flex items-center justify-between p-4 bg-gray-50 rounded-lg", children: [
                    _jsxs("div", { children: [
                        _jsx("p", { className: "text-sm text-gray-900 mb-1", children: "邮件通知" }),
                        _jsx("p", { className: "text-xs text-gray-600", children: "接收作业提醒和成绩相关的邮件通知" })
                    ]}),
                    _jsxs("label", { className: "relative inline-flex items-center cursor-pointer", children: [
                        _jsx("input", { type: "checkbox", className: "sr-only peer", defaultChecked: true }),
                        _jsx("div", { className: "w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" })
                    ]})
                ]}),
                _jsxs("div", { className: "flex items-center justify-between p-4 bg-gray-50 rounded-lg", children: [
                    _jsxs("div", { children: [
                        _jsx("p", { className: "text-sm text-gray-900 mb-1", children: "作业提醒" }),
                        _jsx("p", { className: "text-xs text-gray-600", children: "在作业截止前24小时发送提醒" })
                    ]}),
                    _jsxs("label", { className: "relative inline-flex items-center cursor-pointer", children: [
                        _jsx("input", { type: "checkbox", className: "sr-only peer", defaultChecked: true }),
                        _jsx("div", { className: "w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" })
                    ]})
                ]})
            ]})
        ]})
    ]});
}