// import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// import { useState } from "react";
// import { Search, Edit, Trash2, Plus, Filter, Download } from "lucide-react";
// import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
// import { Button } from "../components/ui/button";
// import { Input } from "../components/ui/input";
// import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, } from "../components/ui/dialog";
// import { Label } from "../components/ui/label";
// export function StudentManagement() {
//     const [searchTerm, setSearchTerm] = useState("");
//     const [editingStudent, setEditingStudent] = useState(null);
//     const [isDialogOpen, setIsDialogOpen] = useState(false);
//     const students = [
//         {
//             id: 1,
//             studentId: "2024001",
//             name: "张三",
//             major: "计算机科学与技术",
//             class: "计科2401",
//             courseCode: "PY101",
//             courseSeq: "01",
//             email: "zhangsan@example.com",
//             phone: "138****1234",
//         },
//         {
//             id: 2,
//             studentId: "2024002",
//             name: "李四",
//             major: "软件工程",
//             class: "软工2401",
//             courseCode: "SH201",
//             courseSeq: "02",
//             email: "lisi@example.com",
//             phone: "139****5678",
//         },
//         {
//             id: 3,
//             studentId: "2024003",
//             name: "王五",
//             major: "计算机科学与技术",
//             class: "计科2401",
//             courseCode: "PY101",
//             courseSeq: "01",
//             email: "wangwu@example.com",
//             phone: "136****9012",
//         },
//         {
//             id: 4,
//             studentId: "2024004",
//             name: "赵六",
//             major: "数据科学与大数据技术",
//             class: "数据2401",
//             courseCode: "PY101",
//             courseSeq: "01",
//             email: "zhaoliu@example.com",
//             phone: "137****3456",
//         },
//     ];
//     const handleEdit = (student) => {
//         setEditingStudent(student);
//         setIsDialogOpen(true);
//     };
//     const handleDelete = (studentId) => {
//         if (confirm(`确定要删除学号为 ${studentId} 的学生信息吗？`)) {
//             // 删除逻辑
//             console.log("删除学生", studentId);
//         }
//     };
//     const handleSave = () => {
//         // 保存逻辑
//         console.log("保存学生信息", editingStudent);
//         setIsDialogOpen(false);
//         setEditingStudent(null);
//     };
//     const filteredStudents = students.filter((student) => student.name.includes(searchTerm) ||
//         student.studentId.includes(searchTerm) ||
//         student.major.includes(searchTerm) ||
//         student.class.includes(searchTerm));
//     return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { children: [_jsx("h1", { className: "text-2xl text-gray-900 mb-1", children: "\u5B66\u751F\u4FE1\u606F\u7EF4\u62A4" }), _jsx("p", { className: "text-gray-600", children: "\u67E5\u8BE2\u3001\u7F16\u8F91\u548C\u5220\u9664\u5B66\u751F\u4FE1\u606F" })] }), _jsx(Card, { className: "border-0 shadow-sm", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "flex flex-col sm:flex-row gap-4", children: [_jsxs("div", { className: "flex-1 relative", children: [_jsx(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" }), _jsx(Input, { placeholder: "\u641C\u7D22\u5B66\u53F7\u3001\u59D3\u540D\u3001\u4E13\u4E1A\u6216\u73ED\u7EA7...", value: searchTerm, onChange: (e) => setSearchTerm(e.target.value), className: "pl-10" })] }), _jsxs("div", { className: "flex gap-2", children: [_jsxs(Button, { variant: "outline", className: "gap-2", children: [_jsx(Filter, { className: "w-4 h-4" }), "\u7B5B\u9009"] }), _jsxs(Button, { variant: "outline", className: "gap-2", children: [_jsx(Download, { className: "w-4 h-4" }), "\u5BFC\u51FA"] }), _jsxs(Button, { className: "gap-2 bg-blue-600 hover:bg-blue-700", onClick: () => {
//                                             setEditingStudent({
//                                                 studentId: "",
//                                                 name: "",
//                                                 major: "",
//                                                 class: "",
//                                                 courseCode: "",
//                                                 courseSeq: "",
//                                                 email: "",
//                                                 phone: "",
//                                             });
//                                             setIsDialogOpen(true);
//                                         }, children: [_jsx(Plus, { className: "w-4 h-4" }), "\u6DFB\u52A0\u5B66\u751F"] })] })] }) }) }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { children: _jsxs(CardTitle, { children: ["\u5B66\u751F\u5217\u8868 (", filteredStudents.length, ")"] }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "overflow-x-auto", children: _jsxs("table", { className: "w-full", children: [_jsx("thead", { children: _jsxs("tr", { className: "border-b border-gray-200", children: [_jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u5B66\u53F7" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u59D3\u540D" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u4E13\u4E1A" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u73ED\u7EA7" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u8BFE\u7A0B\u7F16\u53F7" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u8BFE\u5E8F\u53F7" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u90AE\u7BB1" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u624B\u673A" }), _jsx("th", { className: "text-center py-3 px-4 text-sm text-gray-600", children: "\u64CD\u4F5C" })] }) }), _jsx("tbody", { className: "divide-y divide-gray-200", children: filteredStudents.map((student) => (_jsxs("tr", { className: "hover:bg-gray-50", children: [_jsx("td", { className: "py-3 px-4 text-sm text-gray-900", children: student.studentId }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-900", children: student.name }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: student.major }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: student.class }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: student.courseCode }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: student.courseSeq }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: student.email }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: student.phone }), _jsx("td", { className: "py-3 px-4", children: _jsxs("div", { className: "flex items-center justify-center gap-2", children: [_jsx(Button, { variant: "ghost", size: "sm", onClick: () => handleEdit(student), children: _jsx(Edit, { className: "w-4 h-4" }) }), _jsx(Button, { variant: "ghost", size: "sm", onClick: () => handleDelete(student.studentId), children: _jsx(Trash2, { className: "w-4 h-4 text-red-600" }) })] }) })] }, student.id))) })] }) }), filteredStudents.length === 0 && (_jsx("div", { className: "text-center py-12", children: _jsx("p", { className: "text-gray-500", children: "\u6CA1\u6709\u627E\u5230\u5339\u914D\u7684\u5B66\u751F\u4FE1\u606F" }) }))] })] }), _jsx(Dialog, { open: isDialogOpen, onOpenChange: setIsDialogOpen, children: _jsxs(DialogContent, { className: "max-w-2xl", children: [_jsx(DialogHeader, { children: _jsx(DialogTitle, { children: editingStudent?.id ? "编辑学生信息" : "添加学生" }) }), editingStudent && (_jsxs("div", { className: "grid grid-cols-2 gap-4 py-4", children: [_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "studentId", children: "\u5B66\u53F7" }), _jsx(Input, { id: "studentId", value: editingStudent.studentId, onChange: (e) => setEditingStudent({
//                                                 ...editingStudent,
//                                                 studentId: e.target.value,
//                                             }) })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "name", children: "\u59D3\u540D" }), _jsx(Input, { id: "name", value: editingStudent.name, onChange: (e) => setEditingStudent({
//                                                 ...editingStudent,
//                                                 name: e.target.value,
//                                             }) })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "major", children: "\u4E13\u4E1A" }), _jsx(Input, { id: "major", value: editingStudent.major, onChange: (e) => setEditingStudent({
//                                                 ...editingStudent,
//                                                 major: e.target.value,
//                                             }) })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "class", children: "\u73ED\u7EA7" }), _jsx(Input, { id: "class", value: editingStudent.class, onChange: (e) => setEditingStudent({
//                                                 ...editingStudent,
//                                                 class: e.target.value,
//                                             }) })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "courseCode", children: "\u8BFE\u7A0B\u7F16\u53F7" }), _jsx(Input, { id: "courseCode", value: editingStudent.courseCode, onChange: (e) => setEditingStudent({
//                                                 ...editingStudent,
//                                                 courseCode: e.target.value,
//                                             }) })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "courseSeq", children: "\u8BFE\u5E8F\u53F7" }), _jsx(Input, { id: "courseSeq", value: editingStudent.courseSeq, onChange: (e) => setEditingStudent({
//                                                 ...editingStudent,
//                                                 courseSeq: e.target.value,
//                                             }) })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "email", children: "\u90AE\u7BB1" }), _jsx(Input, { id: "email", type: "email", value: editingStudent.email, onChange: (e) => setEditingStudent({
//                                                 ...editingStudent,
//                                                 email: e.target.value,
//                                             }) })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "phone", children: "\u624B\u673A" }), _jsx(Input, { id: "phone", value: editingStudent.phone, onChange: (e) => setEditingStudent({
//                                                 ...editingStudent,
//                                                 phone: e.target.value,
//                                             }) })] })] })), _jsxs(DialogFooter, { children: [_jsx(Button, { variant: "outline", onClick: () => setIsDialogOpen(false), children: "\u53D6\u6D88" }), _jsx(Button, { onClick: handleSave, className: "bg-blue-600 hover:bg-blue-700", children: "\u4FDD\u5B58" })] })] }) })] }));
// }
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";

// ====================== ✅ 修改点 1：加入 useEffect 用于接口请求 ======================
import { useState, useEffect } from "react";

import { Search, Edit, Trash2, Plus, Filter, Download } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../components/ui/dialog";
import { Label } from "../components/ui/label";

export function StudentManagement() {
    const [searchTerm, setSearchTerm] = useState("");
    const [editingStudent, setEditingStudent] = useState(null);
    const [isDialogOpen, setIsDialogOpen] = useState(false);

    // ====================== ✅ 修改点 2：学生列表改为从接口获取 ======================
    const [students, setStudents] = useState([]);
    const [loading, setLoading] = useState(true);

    // ====================== ✅ 修改点 3：获取学生列表接口 GET /api/v1/student/list ======================
    useEffect(() => {
        const fetchStudents = async () => {
            try {
                setLoading(true);
                const token = localStorage.getItem("token");
                const res = await fetch("http://localhost:8000/api/v1/student/list", {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`
                    }
                });
                const data = await res.json();
                if (data.code === 0) {
                    setStudents(data.data);
                }
            } catch (err) {
                console.error("获取学生列表失败", err);
            } finally {
                setLoading(false);
            }
        };
        fetchStudents();
    }, []);

    // 打开编辑弹窗
    const handleEdit = (student) => {
        setEditingStudent(student);
        setIsDialogOpen(true);
    };

    // ====================== ✅ 修改点 4：删除学生接口 DELETE /api/v1/student/${studentId} ======================
    const handleDelete = async (studentId) => {
        if (!confirm(`确定要删除学号为 ${studentId} 的学生信息吗？`)) return;

        try {
            const token = localStorage.getItem("token");
            const res = await fetch(`http://localhost:8000/api/v1/student/${studentId}`, {
                method: "DELETE",
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            const data = await res.json();
            if (data.code === 0) {
                setStudents(prev => prev.filter(s => s.studentId !== studentId));
            }
        } catch (err) {
            console.error("删除失败", err);
        }
    };

    // ====================== ✅ 修改点 5：保存（新增/编辑）学生接口 POST /api/v1/student/save ======================
    const handleSave = async () => {
        if (!editingStudent) return;

        try {
            const token = localStorage.getItem("token");
            const res = await fetch("http://localhost:8000/api/v1/student/save", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify(editingStudent)
            });
            const data = await res.json();
            if (data.code === 0) {
                // 重新加载列表
                const res2 = await fetch("http://localhost:8000/api/v1/student/list", {
                    headers: { Authorization: `Bearer ${token}` }
                });
                const data2 = await res2.json();
                if (data2.code === 0) {
                    setStudents(data2.data);
                }
                setIsDialogOpen(false);
                setEditingStudent(null);
            }
        } catch (err) {
            console.error("保存失败", err);
        }
    };

    // 搜索过滤
    const filteredStudents = students.filter((student) =>
        (student.name || "").includes(searchTerm) ||
        (student.studentId || "").includes(searchTerm) ||
        (student.major || "").includes(searchTerm) ||
        (student.class || "").includes(searchTerm)
    );

    return (_jsxs("div", { className: "space-y-6", children: [
        _jsxs("div", { children: [
            _jsx("h1", { className: "text-2xl text-gray-900 mb-1", children: "学生信息维护" }),
            _jsx("p", { className: "text-gray-600", children: "查询、编辑和删除学生信息" })
        ] }),

        _jsx(Card, { className: "border-0 shadow-sm", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "flex flex-col sm:flex-row gap-4", children: [
            _jsxs("div", { className: "flex-1 relative", children: [
                _jsx(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" }),
                _jsx(Input, {
                    placeholder: "搜索学号、姓名、专业或班级...",
                    value: searchTerm,
                    onChange: (e) => setSearchTerm(e.target.value),
                    className: "pl-10"
                })
            ] }),
            _jsxs("div", { className: "flex gap-2", children: [
                _jsxs(Button, { variant: "outline", className: "gap-2", children: [
                    _jsx(Filter, { className: "w-4 h-4" }),
                    "筛选"
                ] }),
                _jsxs(Button, { variant: "outline", className: "gap-2", children: [
                    _jsx(Download, { className: "w-4 h-4" }),
                    "导出"
                ] }),
                _jsxs(Button, {
                    className: "gap-2 bg-blue-600 hover:bg-blue-700",
                    onClick: () => {
                        setEditingStudent({
                            studentId: "",
                            name: "",
                            major: "",
                            class: "",
                            courseCode: "",
                            courseSeq: "",
                            email: "",
                            phone: "",
                        });
                        setIsDialogOpen(true);
                    },
                    children: [
                        _jsx(Plus, { className: "w-4 h-4" }),
                        "添加学生"
                    ]
                })
            ] })
        ] }) }) }),

        _jsxs(Card, { className: "border-0 shadow-sm", children: [
            _jsx(CardHeader, { children: _jsxs(CardTitle, { children: ["学生列表 (", filteredStudents.length, ")"] }) }),
            _jsx(CardContent, { children: [
                loading ? _jsx("div", { className: "py-12 text-center", children: "加载中..." }) :
                _jsxs("div", { children: [
                    _jsx("div", { className: "overflow-x-auto", children: _jsxs("table", { className: "w-full", children: [
                        _jsx("thead", { children: _jsxs("tr", { className: "border-b border-gray-200", children: [
                            _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "学号" }),
                            _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "姓名" }),
                            _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "专业" }),
                            _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "班级" }),
                            _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "课程编号" }),
                            _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "课序号" }),
                            _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "邮箱" }),
                            _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "手机" }),
                            _jsx("th", { className: "text-center py-3 px-4 text-sm text-gray-600", children: "操作" })
                        ] }) }),
                        _jsx("tbody", { className: "divide-y divide-gray-200", children: filteredStudents.map((student) => _jsxs("tr", { className: "hover:bg-gray-50", children: [
                            _jsx("td", { className: "py-3 px-4 text-sm text-gray-900", children: student.studentId }),
                            _jsx("td", { className: "py-3 px-4 text-sm text-gray-900", children: student.name }),
                            _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: student.major }),
                            _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: student.class }),
                            _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: student.courseCode }),
                            _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: student.courseSeq }),
                            _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: student.email }),
                            _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: student.phone }),
                            _jsx("td", { className: "py-3 px-4", children: _jsxs("div", { className: "flex items-center justify-center gap-2", children: [
                                _jsx(Button, {
                                    variant: "ghost",
                                    size: "sm",
                                    onClick: () => handleEdit(student),
                                    children: _jsx(Edit, { className: "w-4 h-4" })
                                }),
                                _jsx(Button, {
                                    variant: "ghost",
                                    size: "sm",
                                    onClick: () => handleDelete(student.studentId),
                                    children: _jsx(Trash2, { className: "w-4 h-4 text-red-600" })
                                })
                            ] }) })
                        ] }, student.id)) })
                    ] }) }),
                    filteredStudents.length === 0 && !loading && (_jsx("div", { className: "text-center py-12", children: _jsx("p", { className: "text-gray-500", children: "没有找到匹配的学生信息" }) }))
                ] })
            ] })
        ] }),

        _jsx(Dialog, { open: isDialogOpen, onOpenChange: setIsDialogOpen, children: _jsxs(DialogContent, { className: "max-w-2xl", children: [
            _jsx(DialogHeader, { children: _jsx(DialogTitle, { children: editingStudent?.id ? "编辑学生信息" : "添加学生" }) }),
            editingStudent && (_jsxs("div", { className: "grid grid-cols-2 gap-4 py-4", children: [
                _jsxs("div", { className: "space-y-2", children: [
                    _jsx(Label, { htmlFor: "studentId", children: "学号" }),
                    _jsx(Input, {
                        id: "studentId",
                        value: editingStudent.studentId,
                        onChange: (e) => setEditingStudent({ ...editingStudent, studentId: e.target.value })
                    })
                ] }),
                _jsxs("div", { className: "space-y-2", children: [
                    _jsx(Label, { htmlFor: "name", children: "姓名" }),
                    _jsx(Input, {
                        id: "name",
                        value: editingStudent.name,
                        onChange: (e) => setEditingStudent({ ...editingStudent, name: e.target.value })
                    })
                ] }),
                _jsxs("div", { className: "space-y-2", children: [
                    _jsx(Label, { htmlFor: "major", children: "专业" }),
                    _jsx(Input, {
                        id: "major",
                        value: editingStudent.major,
                        onChange: (e) => setEditingStudent({ ...editingStudent, major: e.target.value })
                    })
                ] }),
                _jsxs("div", { className: "space-y-2", children: [
                    _jsx(Label, { htmlFor: "class", children: "班级" }),
                    _jsx(Input, {
                        id: "class",
                        value: editingStudent.class,
                        onChange: (e) => setEditingStudent({ ...editingStudent, class: e.target.value })
                    })
                ] }),
                _jsxs("div", { className: "space-y-2", children: [
                    _jsx(Label, { htmlFor: "courseCode", children: "课程编号" }),
                    _jsx(Input, {
                        id: "courseCode",
                        value: editingStudent.courseCode,
                        onChange: (e) => setEditingStudent({ ...editingStudent, courseCode: e.target.value })
                    })
                ] }),
                _jsxs("div", { className: "space-y-2", children: [
                    _jsx(Label, { htmlFor: "courseSeq", children: "课序号" }),
                    _jsx(Input, {
                        id: "courseSeq",
                        value: editingStudent.courseSeq,
                        onChange: (e) => setEditingStudent({ ...editingStudent, courseSeq: e.target.value })
                    })
                ] }),
                _jsxs("div", { className: "space-y-2", children: [
                    _jsx(Label, { htmlFor: "email", children: "邮箱" }),
                    _jsx(Input, {
                        id: "email",
                        type: "email",
                        value: editingStudent.email,
                        onChange: (e) => setEditingStudent({ ...editingStudent, email: e.target.value })
                    })
                ] }),
                _jsxs("div", { className: "space-y-2", children: [
                    _jsx(Label, { htmlFor: "phone", children: "手机" }),
                    _jsx(Input, {
                        id: "phone",
                        value: editingStudent.phone,
                        onChange: (e) => setEditingStudent({ ...editingStudent, phone: e.target.value })
                    })
                ] })
            ] })),
            _jsxs(DialogFooter, { children: [
                _jsx(Button, { variant: "outline", onClick: () => setIsDialogOpen(false), children: "取消" }),
                _jsx(Button, { onClick: handleSave, className: "bg-blue-600 hover:bg-blue-700", children: "保存" })
            ] })
        ] }) })
    ] }));
}