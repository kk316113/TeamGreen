import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useParams, Link } from "react-router";
import { ArrowLeft, User, Calendar, CheckCircle, XCircle, Award, Clock, Download, } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
export function StudentGradeDetail() {
    const { studentId } = useParams();
    // 学生基本信息
    const studentInfo = {
        studentId: "2024001",
        name: "张三",
        major: "计算机科学与技术",
        class: "计科2401",
        email: "zhangsan@example.com",
    };
    // 作业详情
    const assignmentDetail = {
        name: "实验3：二叉树遍历",
        course: "Python程序设计",
        courseCode: "PY101",
        deadline: "2024-03-30 23:59",
        submitTime: "2024-03-28 14:30",
        score: 95,
        maxScore: 100,
        status: "已批改",
    };
    // 测试用例结果
    const testCases = [
        {
            id: 1,
            name: "基础功能测试",
            description: "测试二叉树的创建和基本遍历",
            status: "passed",
            score: 20,
            maxScore: 20,
            runtime: "0.15s",
            memory: "2.3MB",
        },
        {
            id: 2,
            name: "前序遍历测试",
            description: "验证前序遍历的正确性",
            status: "passed",
            score: 15,
            maxScore: 15,
            runtime: "0.12s",
            memory: "2.1MB",
        },
        {
            id: 3,
            name: "中序遍历测试",
            description: "验证中序遍历的正确性",
            status: "passed",
            score: 15,
            maxScore: 15,
            runtime: "0.13s",
            memory: "2.2MB",
        },
        {
            id: 4,
            name: "后序遍历测试",
            description: "验证后序遍历的正确性",
            status: "passed",
            score: 15,
            maxScore: 15,
            runtime: "0.14s",
            memory: "2.1MB",
        },
        {
            id: 5,
            name: "层次遍历测试",
            description: "验证层次遍历的正确性",
            status: "passed",
            score: 15,
            maxScore: 15,
            runtime: "0.16s",
            memory: "2.4MB",
        },
        {
            id: 6,
            name: "边界条件测试",
            description: "测试空树和单节点树的情况",
            status: "passed",
            score: 10,
            maxScore: 10,
            runtime: "0.08s",
            memory: "1.8MB",
        },
        {
            id: 7,
            name: "性能测试",
            description: "测试大规模数据处理能力",
            status: "failed",
            score: 0,
            maxScore: 10,
            runtime: "2.51s",
            memory: "15.2MB",
            errorMsg: "运行超时 (限制: 2.0s)",
        },
    ];
    // 代码质量分析
    const codeQuality = {
        complexity: 85,
        readability: 90,
        maintainability: 88,
        documentation: 92,
    };
    // 历史成绩
    const historyGrades = [
        { assignment: "实验1：链表操作", score: 92, date: "2024-03-15" },
        { assignment: "实验2：栈与队列", score: 88, date: "2024-03-22" },
        { assignment: "实验3：二叉树遍历", score: 95, date: "2024-03-28" },
    ];
    const passedTests = testCases.filter((t) => t.status === "passed").length;
    const totalTests = testCases.length;
    const passRate = ((passedTests / totalTests) * 100).toFixed(1);
    return (_jsxs("div", { className: "space-y-6", children: [_jsx(Link, { to: "/teacher/grade-overview", children: _jsxs(Button, { variant: "ghost", className: "gap-2", children: [_jsx(ArrowLeft, { className: "w-4 h-4" }), "\u8FD4\u56DE\u6210\u7EE9\u603B\u89C8"] }) }), _jsx(Card, { className: "border-0 shadow-sm", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "flex items-start justify-between", children: [_jsxs("div", { className: "flex items-start gap-4", children: [_jsx("div", { className: "w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center", children: _jsx(User, { className: "w-8 h-8 text-blue-600" }) }), _jsxs("div", { children: [_jsx("h2", { className: "text-xl text-gray-900 mb-1", children: studentInfo.name }), _jsxs("div", { className: "flex flex-wrap gap-3 text-sm text-gray-600", children: [_jsxs("span", { children: ["\u5B66\u53F7\uFF1A", studentInfo.studentId] }), _jsx("span", { children: "\u2022" }), _jsx("span", { children: studentInfo.major }), _jsx("span", { children: "\u2022" }), _jsx("span", { children: studentInfo.class })] }), _jsx("p", { className: "text-sm text-gray-600 mt-2", children: studentInfo.email })] })] }), _jsxs(Button, { variant: "outline", className: "gap-2", children: [_jsx(Download, { className: "w-4 h-4" }), "\u5BFC\u51FA\u62A5\u544A"] })] }) }) }), _jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-6", children: [_jsxs(Card, { className: "border-0 shadow-sm lg:col-span-2", children: [_jsx(CardHeader, { children: _jsx(CardTitle, { children: "\u4F5C\u4E1A\u8BE6\u60C5" }) }), _jsxs(CardContent, { className: "space-y-4", children: [_jsxs("div", { children: [_jsx("h3", { className: "text-lg text-gray-900 mb-1", children: assignmentDetail.name }), _jsxs("p", { className: "text-sm text-gray-600", children: [assignmentDetail.courseCode, " - ", assignmentDetail.course] })] }), _jsxs("div", { className: "grid grid-cols-2 gap-4", children: [_jsxs("div", { className: "flex items-center gap-3", children: [_jsx(Calendar, { className: "w-5 h-5 text-gray-400" }), _jsxs("div", { children: [_jsx("p", { className: "text-xs text-gray-600", children: "\u622A\u6B62\u65F6\u95F4" }), _jsx("p", { className: "text-sm text-gray-900", children: assignmentDetail.deadline })] })] }), _jsxs("div", { className: "flex items-center gap-3", children: [_jsx(Clock, { className: "w-5 h-5 text-gray-400" }), _jsxs("div", { children: [_jsx("p", { className: "text-xs text-gray-600", children: "\u63D0\u4EA4\u65F6\u95F4" }), _jsx("p", { className: "text-sm text-gray-900", children: assignmentDetail.submitTime })] })] })] }), _jsx("div", { className: "pt-4 border-t border-gray-100", children: _jsx(Badge, { variant: "secondary", className: "bg-green-50 text-green-700", children: assignmentDetail.status }) })] })] }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { children: _jsx(CardTitle, { children: "\u603B\u5F97\u5206" }) }), _jsx(CardContent, { children: _jsxs("div", { className: "text-center", children: [_jsx("div", { className: "inline-flex items-center justify-center w-32 h-32 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 mb-4", children: _jsxs("div", { className: "text-center", children: [_jsx("p", { className: "text-4xl text-white", children: assignmentDetail.score }), _jsxs("p", { className: "text-sm text-blue-100", children: ["/ ", assignmentDetail.maxScore] })] }) }), _jsxs("div", { className: "flex items-center justify-center gap-2 text-green-600", children: [_jsx(Award, { className: "w-5 h-5" }), _jsx("span", { children: "\u4F18\u79C0" })] })] }) })] })] }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { children: _jsxs("div", { className: "flex items-center justify-between", children: [_jsx(CardTitle, { children: "\u6D4B\u8BD5\u7528\u4F8B\u7ED3\u679C" }), _jsxs("div", { className: "text-sm", children: [_jsx("span", { className: "text-gray-600", children: "\u901A\u8FC7\u7387\uFF1A" }), _jsxs("span", { className: "text-blue-600 ml-2", children: [passedTests, "/", totalTests, " (", passRate, "%)"] })] })] }) }), _jsx(CardContent, { className: "space-y-3", children: testCases.map((test) => (_jsxs("div", { className: `border rounded-lg p-4 ${test.status === "passed"
                                ? "border-green-200 bg-green-50"
                                : "border-red-200 bg-red-50"}`, children: [_jsxs("div", { className: "flex items-start justify-between mb-2", children: [_jsxs("div", { className: "flex items-start gap-3 flex-1", children: [test.status === "passed" ? (_jsx(CheckCircle, { className: "w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" })) : (_jsx(XCircle, { className: "w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" })), _jsxs("div", { className: "flex-1 min-w-0", children: [_jsx("h4", { className: "text-sm text-gray-900 mb-1", children: test.name }), _jsx("p", { className: "text-xs text-gray-600 mb-2", children: test.description }), test.errorMsg && (_jsx("p", { className: "text-xs text-red-700 bg-red-100 px-2 py-1 rounded", children: test.errorMsg }))] })] }), _jsx("div", { className: "text-right ml-4", children: _jsxs("p", { className: `text-sm ${test.status === "passed"
                                                    ? "text-green-700"
                                                    : "text-red-700"}`, children: [test.score, "/", test.maxScore] }) })] }), _jsxs("div", { className: "flex items-center gap-4 text-xs text-gray-600 ml-8", children: [_jsxs("span", { children: ["\u8FD0\u884C\u65F6\u95F4: ", test.runtime] }), _jsx("span", { children: "\u2022" }), _jsxs("span", { children: ["\u5185\u5B58: ", test.memory] })] })] }, test.id))) })] }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { children: _jsx(CardTitle, { children: "\u4EE3\u7801\u8D28\u91CF\u5206\u6790" }) }), _jsxs(CardContent, { className: "space-y-4", children: [_jsxs("div", { children: [_jsxs("div", { className: "flex justify-between mb-2", children: [_jsx("span", { className: "text-sm text-gray-600", children: "\u4EE3\u7801\u590D\u6742\u5EA6" }), _jsxs("span", { className: "text-sm text-gray-900", children: [codeQuality.complexity, "%"] })] }), _jsx(Progress, { value: codeQuality.complexity, className: "h-2" })] }), _jsxs("div", { children: [_jsxs("div", { className: "flex justify-between mb-2", children: [_jsx("span", { className: "text-sm text-gray-600", children: "\u53EF\u8BFB\u6027" }), _jsxs("span", { className: "text-sm text-gray-900", children: [codeQuality.readability, "%"] })] }), _jsx(Progress, { value: codeQuality.readability, className: "h-2" })] }), _jsxs("div", { children: [_jsxs("div", { className: "flex justify-between mb-2", children: [_jsx("span", { className: "text-sm text-gray-600", children: "\u53EF\u7EF4\u62A4\u6027" }), _jsxs("span", { className: "text-sm text-gray-900", children: [codeQuality.maintainability, "%"] })] }), _jsx(Progress, { value: codeQuality.maintainability, className: "h-2" })] }), _jsxs("div", { children: [_jsxs("div", { className: "flex justify-between mb-2", children: [_jsx("span", { className: "text-sm text-gray-600", children: "\u6587\u6863\u5B8C\u6574\u6027" }), _jsxs("span", { className: "text-sm text-gray-900", children: [codeQuality.documentation, "%"] })] }), _jsx(Progress, { value: codeQuality.documentation, className: "h-2" })] })] })] }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { children: _jsx(CardTitle, { children: "\u5386\u53F2\u6210\u7EE9" }) }), _jsx(CardContent, { children: _jsx("div", { className: "space-y-3", children: historyGrades.map((grade, index) => (_jsxs("div", { className: "flex items-center justify-between p-3 bg-gray-50 rounded-lg", children: [_jsxs("div", { children: [_jsx("p", { className: "text-sm text-gray-900", children: grade.assignment }), _jsx("p", { className: "text-xs text-gray-600 mt-1", children: grade.date })] }), _jsx("div", { className: `text-lg ${grade.score >= 90
                                            ? "text-green-600"
                                            : grade.score >= 80
                                                ? "text-blue-600"
                                                : "text-amber-600"}`, children: grade.score })] }, index))) }) })] })] }));
}
