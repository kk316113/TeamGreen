import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { Search, Edit, Trash2, Plus, Filter, Download } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, } from "../components/ui/dialog";
import { Label } from "../components/ui/label";
export function StudentManagement() {
    const [searchTerm, setSearchTerm] = useState("");
    const [editingStudent, setEditingStudent] = useState(null);
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const students = [
        {
            id: 1,
            studentId: "2024001",
            name: "张三",
            major: "计算机科学与技术",
            class: "计科2401",
            courseCode: "PY101",
            courseSeq: "01",
            email: "zhangsan@example.com",
            phone: "138****1234",
        },
        {
            id: 2,
            studentId: "2024002",
            name: "李四",
            major: "软件工程",
            class: "软工2401",
            courseCode: "SH201",
            courseSeq: "02",
            email: "lisi@example.com",
            phone: "139****5678",
        },
        {
            id: 3,
            studentId: "2024003",
            name: "王五",
            major: "计算机科学与技术",
            class: "计科2401",
            courseCode: "PY101",
            courseSeq: "01",
            email: "wangwu@example.com",
            phone: "136****9012",
        },
        {
            id: 4,
            studentId: "2024004",
            name: "赵六",
            major: "数据科学与大数据技术",
            class: "数据2401",
            courseCode: "PY101",
            courseSeq: "01",
            email: "zhaoliu@example.com",
            phone: "137****3456",
        },
    ];
    const handleEdit = (student) => {
        setEditingStudent(student);
        setIsDialogOpen(true);
    };
    const handleDelete = (studentId) => {
        if (confirm(`确定要删除学号为 ${studentId} 的学生信息吗？`)) {
            // 删除逻辑
            console.log("删除学生", studentId);
        }
    };
    const handleSave = () => {
        // 保存逻辑
        console.log("保存学生信息", editingStudent);
        setIsDialogOpen(false);
        setEditingStudent(null);
    };
    const filteredStudents = students.filter((student) => student.name.includes(searchTerm) ||
        student.studentId.includes(searchTerm) ||
        student.major.includes(searchTerm) ||
        student.class.includes(searchTerm));
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { children: [_jsx("h1", { className: "text-2xl text-gray-900 mb-1", children: "\u5B66\u751F\u4FE1\u606F\u7EF4\u62A4" }), _jsx("p", { className: "text-gray-600", children: "\u67E5\u8BE2\u3001\u7F16\u8F91\u548C\u5220\u9664\u5B66\u751F\u4FE1\u606F" })] }), _jsx(Card, { className: "border-0 shadow-sm", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "flex flex-col sm:flex-row gap-4", children: [_jsxs("div", { className: "flex-1 relative", children: [_jsx(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" }), _jsx(Input, { placeholder: "\u641C\u7D22\u5B66\u53F7\u3001\u59D3\u540D\u3001\u4E13\u4E1A\u6216\u73ED\u7EA7...", value: searchTerm, onChange: (e) => setSearchTerm(e.target.value), className: "pl-10" })] }), _jsxs("div", { className: "flex gap-2", children: [_jsxs(Button, { variant: "outline", className: "gap-2", children: [_jsx(Filter, { className: "w-4 h-4" }), "\u7B5B\u9009"] }), _jsxs(Button, { variant: "outline", className: "gap-2", children: [_jsx(Download, { className: "w-4 h-4" }), "\u5BFC\u51FA"] }), _jsxs(Button, { className: "gap-2 bg-blue-600 hover:bg-blue-700", onClick: () => {
                                            setEditingStudent({
                                                studentId: "",
                                                name: "",
                                                major: "",
                                                class: "",
                                                courseCode: "",
                                                courseSeq: "",
                                                email: "",
                                                phone: "",
                                            });
                                            setIsDialogOpen(true);
                                        }, children: [_jsx(Plus, { className: "w-4 h-4" }), "\u6DFB\u52A0\u5B66\u751F"] })] })] }) }) }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { children: _jsxs(CardTitle, { children: ["\u5B66\u751F\u5217\u8868 (", filteredStudents.length, ")"] }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "overflow-x-auto", children: _jsxs("table", { className: "w-full", children: [_jsx("thead", { children: _jsxs("tr", { className: "border-b border-gray-200", children: [_jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u5B66\u53F7" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u59D3\u540D" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u4E13\u4E1A" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u73ED\u7EA7" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u8BFE\u7A0B\u7F16\u53F7" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u8BFE\u5E8F\u53F7" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u90AE\u7BB1" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u624B\u673A" }), _jsx("th", { className: "text-center py-3 px-4 text-sm text-gray-600", children: "\u64CD\u4F5C" })] }) }), _jsx("tbody", { className: "divide-y divide-gray-200", children: filteredStudents.map((student) => (_jsxs("tr", { className: "hover:bg-gray-50", children: [_jsx("td", { className: "py-3 px-4 text-sm text-gray-900", children: student.studentId }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-900", children: student.name }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: student.major }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: student.class }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: student.courseCode }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: student.courseSeq }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: student.email }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: student.phone }), _jsx("td", { className: "py-3 px-4", children: _jsxs("div", { className: "flex items-center justify-center gap-2", children: [_jsx(Button, { variant: "ghost", size: "sm", onClick: () => handleEdit(student), children: _jsx(Edit, { className: "w-4 h-4" }) }), _jsx(Button, { variant: "ghost", size: "sm", onClick: () => handleDelete(student.studentId), children: _jsx(Trash2, { className: "w-4 h-4 text-red-600" }) })] }) })] }, student.id))) })] }) }), filteredStudents.length === 0 && (_jsx("div", { className: "text-center py-12", children: _jsx("p", { className: "text-gray-500", children: "\u6CA1\u6709\u627E\u5230\u5339\u914D\u7684\u5B66\u751F\u4FE1\u606F" }) }))] })] }), _jsx(Dialog, { open: isDialogOpen, onOpenChange: setIsDialogOpen, children: _jsxs(DialogContent, { className: "max-w-2xl", children: [_jsx(DialogHeader, { children: _jsx(DialogTitle, { children: editingStudent?.id ? "编辑学生信息" : "添加学生" }) }), editingStudent && (_jsxs("div", { className: "grid grid-cols-2 gap-4 py-4", children: [_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "studentId", children: "\u5B66\u53F7" }), _jsx(Input, { id: "studentId", value: editingStudent.studentId, onChange: (e) => setEditingStudent({
                                                ...editingStudent,
                                                studentId: e.target.value,
                                            }) })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "name", children: "\u59D3\u540D" }), _jsx(Input, { id: "name", value: editingStudent.name, onChange: (e) => setEditingStudent({
                                                ...editingStudent,
                                                name: e.target.value,
                                            }) })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "major", children: "\u4E13\u4E1A" }), _jsx(Input, { id: "major", value: editingStudent.major, onChange: (e) => setEditingStudent({
                                                ...editingStudent,
                                                major: e.target.value,
                                            }) })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "class", children: "\u73ED\u7EA7" }), _jsx(Input, { id: "class", value: editingStudent.class, onChange: (e) => setEditingStudent({
                                                ...editingStudent,
                                                class: e.target.value,
                                            }) })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "courseCode", children: "\u8BFE\u7A0B\u7F16\u53F7" }), _jsx(Input, { id: "courseCode", value: editingStudent.courseCode, onChange: (e) => setEditingStudent({
                                                ...editingStudent,
                                                courseCode: e.target.value,
                                            }) })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "courseSeq", children: "\u8BFE\u5E8F\u53F7" }), _jsx(Input, { id: "courseSeq", value: editingStudent.courseSeq, onChange: (e) => setEditingStudent({
                                                ...editingStudent,
                                                courseSeq: e.target.value,
                                            }) })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "email", children: "\u90AE\u7BB1" }), _jsx(Input, { id: "email", type: "email", value: editingStudent.email, onChange: (e) => setEditingStudent({
                                                ...editingStudent,
                                                email: e.target.value,
                                            }) })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "phone", children: "\u624B\u673A" }), _jsx(Input, { id: "phone", value: editingStudent.phone, onChange: (e) => setEditingStudent({
                                                ...editingStudent,
                                                phone: e.target.value,
                                            }) })] })] })), _jsxs(DialogFooter, { children: [_jsx(Button, { variant: "outline", onClick: () => setIsDialogOpen(false), children: "\u53D6\u6D88" }), _jsx(Button, { onClick: handleSave, className: "bg-blue-600 hover:bg-blue-700", children: "\u4FDD\u5B58" })] })] }) })] }));
}
