import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useState } from "react";
import { Upload, FileText, CheckCircle, XCircle, AlertCircle, RefreshCw, Send, Eye, FileSpreadsheet, } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
export function StudentImport() {
    const [file, setFile] = useState(null);
    const [parsing, setParsing] = useState(false);
    const [parsedData, setParsedData] = useState([]);
    const [validationErrors, setValidationErrors] = useState([]);
    const [submitting, setSubmitting] = useState(false);
    const [submitResult, setSubmitResult] = useState(null);
    // 处理文件选择
    const handleFileChange = (e) => {
        if (e.target.files && e.target.files[0]) {
            const selectedFile = e.target.files[0];
            setFile(selectedFile);
            setParsedData([]);
            setValidationErrors([]);
            setSubmitResult(null);
        }
    };
    // 前端解析文件（核心功能）
    const handleParse = () => {
        if (!file)
            return;
        setParsing(true);
        // 模拟前端解析过程
        setTimeout(() => {
            const fileExtension = file.name.split(".").pop()?.toLowerCase();
            if (fileExtension === "xlsx" || fileExtension === "xls") {
                // 模拟XLSX解析
                const mockData = [
                    {
                        studentId: "2024001",
                        name: "张三",
                        courseCode: "PYTHON101",
                        courseSeq: "01",
                        className: "计算机1班",
                    },
                    {
                        studentId: "2024002",
                        name: "李四",
                        courseCode: "PYTHON101",
                        courseSeq: "01",
                        className: "计算机1班",
                    },
                    {
                        studentId: "2024003",
                        name: "王五",
                        courseCode: "BASH101",
                        courseSeq: "02",
                        className: "计算机2班",
                    },
                    {
                        studentId: "2024001",
                        name: "张三重复",
                        courseCode: "PYTHON101",
                        courseSeq: "01",
                        className: "计算机1班",
                    },
                    {
                        studentId: "2024005",
                        name: "",
                        courseCode: "PYTHON101",
                        courseSeq: "01",
                        className: "计算机1班",
                    },
                    {
                        studentId: "",
                        name: "孙七",
                        courseCode: "INVALID",
                        courseSeq: "01",
                        className: "计算机1班",
                    },
                ];
                setParsedData(mockData);
                validateData(mockData);
            }
            else if (fileExtension === "pdf") {
                // 模拟PDF解析
                const mockData = [
                    {
                        studentId: "2024006",
                        name: "周八",
                        courseCode: "PYTHON101",
                        courseSeq: "01",
                        className: "软件1班",
                    },
                    {
                        studentId: "2024007",
                        name: "吴九",
                        courseCode: "BASH101",
                        courseSeq: "02",
                        className: "软件2班",
                    },
                ];
                setParsedData(mockData);
                validateData(mockData);
            }
            setParsing(false);
        }, 1500);
    };
    // 数据校验（前端校验）
    const validateData = (data) => {
        const errors = [];
        const studentIds = new Set();
        const validCourseCodes = ["PYTHON101", "BASH101"];
        data.forEach((record, index) => {
            // 检查必填字段
            if (!record.studentId) {
                errors.push({
                    row: index + 1,
                    field: "学号",
                    message: "学号不能为空",
                    severity: "error",
                });
            }
            if (!record.name) {
                errors.push({
                    row: index + 1,
                    field: "姓名",
                    message: "姓名不能为空",
                    severity: "error",
                });
            }
            // 检查重复学号
            if (record.studentId) {
                if (studentIds.has(record.studentId)) {
                    errors.push({
                        row: index + 1,
                        field: "学号",
                        message: `学号 ${record.studentId} 重复`,
                        severity: "error",
                    });
                }
                else {
                    studentIds.add(record.studentId);
                }
            }
            // 检查课程编号有效性
            if (record.courseCode && !validCourseCodes.includes(record.courseCode)) {
                errors.push({
                    row: index + 1,
                    field: "课程编号",
                    message: `课程编号 ${record.courseCode} 无效`,
                    severity: "warning",
                });
            }
            // 检查学号格式
            if (record.studentId && !/^\d{7}$/.test(record.studentId)) {
                errors.push({
                    row: index + 1,
                    field: "学号",
                    message: "学号格式错误（应为7位数字）",
                    severity: "warning",
                });
            }
        });
        setValidationErrors(errors);
    };
    // 提交到后端
    const handleSubmit = () => {
        // 过滤掉有严重错误的记录
        const validRecords = parsedData.filter((_, index) => {
            const hasError = validationErrors.some((err) => err.row === index + 1 && err.severity === "error");
            return !hasError;
        });
        setSubmitting(true);
        // 模拟提交到后端
        setTimeout(() => {
            setSubmitResult({
                total: parsedData.length,
                success: validRecords.length,
                failed: parsedData.length - validRecords.length,
                submitTime: new Date().toLocaleString(),
            });
            setSubmitting(false);
        }, 2000);
    };
    // 重新上传
    const handleReupload = () => {
        setFile(null);
        setParsedData([]);
        setValidationErrors([]);
        setSubmitResult(null);
    };
    const errorCount = validationErrors.filter((e) => e.severity === "error").length;
    const warningCount = validationErrors.filter((e) => e.severity === "warning").length;
    const validCount = parsedData.length - parsedData.filter((_, index) => validationErrors.some((err) => err.row === index + 1 && err.severity === "error")).length;
    const historyRecords = [
        {
            id: 1,
            fileName: "2024春季-Python程序设计-学生名单.xlsx",
            date: "2026-04-05 14:30",
            total: 45,
            success: 45,
            failed: 0,
            status: "completed",
        },
        {
            id: 2,
            fileName: "2024春季-Bash Shell程序设计-学生名单.xlsx",
            date: "2026-04-04 09:15",
            total: 38,
            success: 36,
            failed: 2,
            status: "partial",
        },
        {
            id: 3,
            fileName: "2024春季-综合名单.pdf",
            date: "2026-04-03 16:45",
            total: 52,
            success: 52,
            failed: 0,
            status: "completed",
        },
    ];
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { children: [_jsx("h1", { className: "text-2xl text-gray-900 mb-1", children: "\u5B66\u751F\u4FE1\u606F\u5BFC\u5165" }), _jsx("p", { className: "text-gray-600", children: "\u524D\u7AEF\u89E3\u6790\u6587\u4EF6\u5E76\u6821\u9A8C\u6570\u636E\uFF0C\u6574\u7406\u540E\u63D0\u4EA4\u81F3\u540E\u7AEF" })] }), _jsx(Card, { className: "border-0 shadow-sm bg-gradient-to-r from-blue-50 to-green-50 border-blue-200", children: _jsx(CardContent, { className: "p-6", children: _jsxs("div", { className: "flex items-center gap-4", children: [_jsx("div", { className: "w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center", children: _jsx(FileSpreadsheet, { className: "w-5 h-5 text-blue-600" }) }), _jsxs("div", { className: "flex-1", children: [_jsx("h3", { className: "text-sm font-semibold text-gray-900 mb-1", children: "\u524D\u7AEF\u89E3\u6790\u6D41\u7A0B\u8BF4\u660E" }), _jsx("p", { className: "text-sm text-gray-700", children: _jsxs("span", { className: "inline-flex items-center gap-1", children: [_jsx(Badge, { variant: "secondary", className: "bg-white text-xs", children: "1. \u4E0A\u4F20\u6587\u4EF6" }), _jsx("span", { className: "text-gray-400", children: "\u2192" }), _jsx(Badge, { variant: "secondary", className: "bg-white text-xs", children: "2. \u524D\u7AEF\u89E3\u6790" }), _jsx("span", { className: "text-gray-400", children: "\u2192" }), _jsx(Badge, { variant: "secondary", className: "bg-white text-xs", children: "3. \u6570\u636E\u9884\u89C8" }), _jsx("span", { className: "text-gray-400", children: "\u2192" }), _jsx(Badge, { variant: "secondary", className: "bg-white text-xs", children: "4. \u6821\u9A8C\u6574\u7406" }), _jsx("span", { className: "text-gray-400", children: "\u2192" }), _jsx(Badge, { variant: "secondary", className: "bg-white text-xs", children: "5. \u63D0\u4EA4\u540E\u7AEF" })] }) })] })] }) }) }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { className: "border-b border-gray-100", children: _jsxs("div", { className: "flex items-center justify-between", children: [_jsx(CardTitle, { children: "\u6B65\u9AA41\uFF1A\u4E0A\u4F20\u6587\u4EF6" }), file && !parsedData.length && (_jsxs(Button, { onClick: handleParse, disabled: parsing, className: "gap-2 bg-blue-600 hover:bg-blue-700", children: [_jsx(RefreshCw, { className: `w-4 h-4 ${parsing ? "animate-spin" : ""}` }), parsing ? "解析中..." : "开始解析"] }))] }) }), _jsx(CardContent, { className: "p-6 space-y-6", children: !file ? (_jsxs(_Fragment, { children: [_jsxs("div", { className: "border-2 border-dashed border-gray-300 rounded-xl p-12 text-center hover:border-blue-400 transition-colors", children: [_jsx("input", { type: "file", accept: ".pdf,.xlsx,.xls", onChange: handleFileChange, className: "hidden", id: "file-upload" }), _jsxs("label", { htmlFor: "file-upload", className: "cursor-pointer flex flex-col items-center", children: [_jsx("div", { className: "w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mb-4", children: _jsx(Upload, { className: "w-8 h-8 text-blue-600" }) }), _jsx("p", { className: "text-gray-900 mb-1", children: "\u70B9\u51FB\u4E0A\u4F20\u6216\u62D6\u62FD\u6587\u4EF6\u5230\u6B64\u533A\u57DF" }), _jsx("p", { className: "text-sm text-gray-500", children: "\u652F\u6301 PDF\u3001XLSX \u683C\u5F0F\uFF0C\u5355\u4E2A\u6587\u4EF6\u4E0D\u8D85\u8FC7 10MB" })] })] }), _jsx("div", { className: "bg-amber-50 border border-amber-200 rounded-lg p-4", children: _jsxs("div", { className: "flex gap-3", children: [_jsx(AlertCircle, { className: "w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" }), _jsxs("div", { className: "text-sm text-gray-700", children: [_jsx("p", { className: "mb-2", children: "\u6587\u4EF6\u683C\u5F0F\u8981\u6C42\uFF1A" }), _jsxs("ul", { className: "list-disc list-inside space-y-1 text-gray-600", children: [_jsx("li", { children: "Excel \u6587\u4EF6\u5FC5\u586B\u5B57\u6BB5\uFF1A\u5B66\u53F7\u3001\u59D3\u540D\u3001\u8BFE\u7A0B\u7F16\u53F7\u3001\u8BFE\u5E8F\u53F7\u3001\u73ED\u7EA7" }), _jsx("li", { children: "\u5B66\u53F7\u683C\u5F0F\uFF1A7\u4F4D\u6570\u5B57\uFF08\u5982 2024001\uFF09" }), _jsx("li", { children: "\u8BFE\u7A0B\u7F16\u53F7\uFF1APYTHON101 \u6216 BASH101" }), _jsx("li", { children: "\u524D\u7AEF\u5C06\u81EA\u52A8\u89E3\u6790\u5E76\u6821\u9A8C\u6570\u636E\u683C\u5F0F" })] })] })] }) })] })) : (_jsx("div", { className: "bg-blue-50 border border-blue-200 rounded-lg p-4", children: _jsxs("div", { className: "flex items-center gap-3", children: [_jsx(FileText, { className: "w-10 h-10 text-blue-600" }), _jsxs("div", { className: "flex-1 min-w-0", children: [_jsx("p", { className: "text-sm text-gray-900 truncate", children: file.name }), _jsxs("p", { className: "text-xs text-gray-600", children: [(file.size / 1024).toFixed(2), " KB"] })] }), parsedData.length > 0 && (_jsxs(Button, { variant: "outline", onClick: handleReupload, className: "gap-2", children: [_jsx(Upload, { className: "w-4 h-4" }), "\u91CD\u65B0\u4E0A\u4F20"] }))] }) })) })] }), parsedData.length > 0 && (_jsxs(_Fragment, { children: [_jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { className: "border-b border-gray-100", children: _jsxs("div", { className: "flex items-center justify-between", children: [_jsx(CardTitle, { children: "\u6B65\u9AA42-3\uFF1A\u89E3\u6790\u7ED3\u679C\u9884\u89C8" }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsxs(Badge, { className: "bg-blue-50 text-blue-700 border-blue-200", children: ["\u5171 ", parsedData.length, " \u6761"] }), _jsxs(Badge, { className: "bg-green-50 text-green-700 border-green-200", children: ["\u6709\u6548 ", validCount, " \u6761"] })] })] }) }), _jsx(CardContent, { className: "p-0", children: _jsx("div", { className: "overflow-x-auto", children: _jsxs("table", { className: "w-full", children: [_jsx("thead", { children: _jsxs("tr", { className: "border-b border-gray-200 bg-gray-50", children: [_jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u884C\u53F7" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u5B66\u53F7" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u59D3\u540D" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u8BFE\u7A0B\u7F16\u53F7" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u8BFE\u5E8F\u53F7" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u73ED\u7EA7" }), _jsx("th", { className: "text-center py-3 px-4 text-sm text-gray-600", children: "\u72B6\u6001" })] }) }), _jsx("tbody", { className: "divide-y divide-gray-200", children: parsedData.map((record, index) => {
                                                    const rowErrors = validationErrors.filter((e) => e.row === index + 1);
                                                    const hasError = rowErrors.some((e) => e.severity === "error");
                                                    const hasWarning = rowErrors.some((e) => e.severity === "warning");
                                                    return (_jsxs("tr", { className: `hover:bg-gray-50 ${hasError ? "bg-red-50" : hasWarning ? "bg-amber-50" : ""}`, children: [_jsx("td", { className: "py-3 px-4 text-sm text-gray-900", children: index + 1 }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-900", children: record.studentId || _jsx("span", { className: "text-red-500", children: "\u7F3A\u5931" }) }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-900", children: record.name || _jsx("span", { className: "text-red-500", children: "\u7F3A\u5931" }) }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-900", children: record.courseCode }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-900", children: record.courseSeq }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-900", children: record.className }), _jsx("td", { className: "py-3 px-4 text-center", children: hasError ? (_jsxs(Badge, { className: "bg-red-100 text-red-700 border-red-200 text-xs", children: [_jsx(XCircle, { className: "w-3 h-3 mr-1" }), "\u9519\u8BEF"] })) : hasWarning ? (_jsxs(Badge, { className: "bg-amber-100 text-amber-700 border-amber-200 text-xs", children: [_jsx(AlertCircle, { className: "w-3 h-3 mr-1" }), "\u8B66\u544A"] })) : (_jsxs(Badge, { className: "bg-green-100 text-green-700 border-green-200 text-xs", children: [_jsx(CheckCircle, { className: "w-3 h-3 mr-1" }), "\u6B63\u5E38"] })) })] }, index));
                                                }) })] }) }) })] }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { className: "border-b border-gray-100", children: _jsx(CardTitle, { children: "\u6B65\u9AA44\uFF1A\u6570\u636E\u6821\u9A8C\u7ED3\u679C" }) }), _jsx(CardContent, { className: "p-6", children: _jsxs(Tabs, { defaultValue: "errors", children: [_jsxs(TabsList, { className: "grid w-full grid-cols-3", children: [_jsxs(TabsTrigger, { value: "errors", className: "gap-2", children: [_jsx(XCircle, { className: "w-4 h-4" }), "\u9519\u8BEF (", errorCount, ")"] }), _jsxs(TabsTrigger, { value: "warnings", className: "gap-2", children: [_jsx(AlertCircle, { className: "w-4 h-4" }), "\u8B66\u544A (", warningCount, ")"] }), _jsxs(TabsTrigger, { value: "summary", className: "gap-2", children: [_jsx(Eye, { className: "w-4 h-4" }), "\u6C47\u603B"] })] }), _jsx(TabsContent, { value: "errors", className: "space-y-2 mt-4", children: errorCount === 0 ? (_jsxs("div", { className: "text-center py-8", children: [_jsx(CheckCircle, { className: "w-12 h-12 text-green-600 mx-auto mb-2" }), _jsx("p", { className: "text-gray-600", children: "\u6CA1\u6709\u53D1\u73B0\u9519\u8BEF" })] })) : (_jsx("div", { className: "space-y-2", children: validationErrors
                                                    .filter((e) => e.severity === "error")
                                                    .map((error, index) => (_jsxs("div", { className: "p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3", children: [_jsx(XCircle, { className: "w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" }), _jsxs("div", { className: "flex-1", children: [_jsxs("p", { className: "text-sm text-red-900", children: ["\u7B2C ", error.row, " \u884C - ", error.field] }), _jsx("p", { className: "text-xs text-red-700 mt-1", children: error.message })] })] }, index))) })) }), _jsx(TabsContent, { value: "warnings", className: "space-y-2 mt-4", children: warningCount === 0 ? (_jsxs("div", { className: "text-center py-8", children: [_jsx(CheckCircle, { className: "w-12 h-12 text-green-600 mx-auto mb-2" }), _jsx("p", { className: "text-gray-600", children: "\u6CA1\u6709\u53D1\u73B0\u8B66\u544A" })] })) : (_jsx("div", { className: "space-y-2", children: validationErrors
                                                    .filter((e) => e.severity === "warning")
                                                    .map((error, index) => (_jsxs("div", { className: "p-3 bg-amber-50 border border-amber-200 rounded-lg flex items-start gap-3", children: [_jsx(AlertCircle, { className: "w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" }), _jsxs("div", { className: "flex-1", children: [_jsxs("p", { className: "text-sm text-amber-900", children: ["\u7B2C ", error.row, " \u884C - ", error.field] }), _jsx("p", { className: "text-xs text-amber-700 mt-1", children: error.message })] })] }, index))) })) }), _jsx(TabsContent, { value: "summary", className: "mt-4", children: _jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [_jsxs("div", { className: "bg-gray-50 rounded-lg p-4 text-center", children: [_jsx("p", { className: "text-3xl text-gray-900 mb-1", children: parsedData.length }), _jsx("p", { className: "text-sm text-gray-600", children: "\u89E3\u6790\u603B\u6570" })] }), _jsxs("div", { className: "bg-green-50 rounded-lg p-4 text-center border border-green-200", children: [_jsx("p", { className: "text-3xl text-green-600 mb-1", children: validCount }), _jsx("p", { className: "text-sm text-gray-600", children: "\u53EF\u63D0\u4EA4\u6570" })] }), _jsxs("div", { className: "bg-red-50 rounded-lg p-4 text-center border border-red-200", children: [_jsx("p", { className: "text-3xl text-red-600 mb-1", children: parsedData.length - validCount }), _jsx("p", { className: "text-sm text-gray-600", children: "\u9519\u8BEF\u6761\u6570" })] })] }) })] }) })] }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { className: "border-b border-gray-100", children: _jsx(CardTitle, { children: "\u6B65\u9AA45\uFF1A\u786E\u8BA4\u63D0\u4EA4" }) }), _jsxs(CardContent, { className: "p-6", children: [_jsxs("div", { className: "flex items-center gap-4", children: [_jsxs(Button, { variant: "outline", onClick: handleReupload, className: "gap-2", children: [_jsx(Upload, { className: "w-4 h-4" }), "\u91CD\u65B0\u4E0A\u4F20"] }), _jsxs(Button, { variant: "outline", onClick: handleParse, disabled: parsing, className: "gap-2", children: [_jsx(RefreshCw, { className: `w-4 h-4 ${parsing ? "animate-spin" : ""}` }), "\u91CD\u65B0\u89E3\u6790"] }), _jsxs(Button, { onClick: handleSubmit, disabled: submitting || validCount === 0, className: "gap-2 bg-green-600 hover:bg-green-700 ml-auto", children: [_jsx(Send, { className: "w-4 h-4" }), submitting ? "提交中..." : `确认提交 (${validCount}条)`] })] }), validCount < parsedData.length && (_jsx("div", { className: "mt-4 bg-amber-50 border border-amber-200 rounded-lg p-4", children: _jsxs("div", { className: "flex gap-3", children: [_jsx(AlertCircle, { className: "w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" }), _jsxs("p", { className: "text-sm text-amber-900", children: ["\u68C0\u6D4B\u5230 ", parsedData.length - validCount, " \u6761\u8BB0\u5F55\u5B58\u5728\u9519\u8BEF\uFF0C\u63D0\u4EA4\u65F6\u5C06\u81EA\u52A8\u8DF3\u8FC7\u8FD9\u4E9B\u8BB0\u5F55"] })] }) })), submitResult && (_jsx("div", { className: "mt-4 bg-green-50 border border-green-200 rounded-lg p-4", children: _jsxs("div", { className: "flex items-start gap-3", children: [_jsx(CheckCircle, { className: "w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" }), _jsxs("div", { className: "flex-1", children: [_jsx("h3", { className: "text-green-900 mb-1", children: "\u63D0\u4EA4\u6210\u529F\uFF01" }), _jsxs("p", { className: "text-sm text-green-700", children: ["\u5DF2\u6210\u529F\u63D0\u4EA4 ", submitResult.success, " \u6761\u8BB0\u5F55\u81F3\u540E\u7AEF\uFF0C\u5931\u8D25 ", submitResult.failed, " \u6761"] }), _jsxs("p", { className: "text-xs text-green-600 mt-2", children: ["\u63D0\u4EA4\u65F6\u95F4\uFF1A", submitResult.submitTime] })] })] }) }))] })] })] })), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { className: "border-b border-gray-100", children: _jsx(CardTitle, { children: "\u5386\u53F2\u5BFC\u5165\u8BB0\u5F55" }) }), _jsx(CardContent, { className: "p-0", children: _jsx("div", { className: "overflow-x-auto", children: _jsxs("table", { className: "w-full", children: [_jsx("thead", { children: _jsxs("tr", { className: "border-b border-gray-200 bg-gray-50", children: [_jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u6587\u4EF6\u540D" }), _jsx("th", { className: "text-left py-3 px-4 text-sm text-gray-600", children: "\u5BFC\u5165\u65F6\u95F4" }), _jsx("th", { className: "text-center py-3 px-4 text-sm text-gray-600", children: "\u603B\u6570" }), _jsx("th", { className: "text-center py-3 px-4 text-sm text-gray-600", children: "\u6210\u529F" }), _jsx("th", { className: "text-center py-3 px-4 text-sm text-gray-600", children: "\u5931\u8D25" }), _jsx("th", { className: "text-center py-3 px-4 text-sm text-gray-600", children: "\u72B6\u6001" })] }) }), _jsx("tbody", { className: "divide-y divide-gray-200", children: historyRecords.map((record) => (_jsxs("tr", { className: "hover:bg-gray-50", children: [_jsx("td", { className: "py-3 px-4 text-sm text-gray-900", children: record.fileName }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-600", children: record.date }), _jsx("td", { className: "py-3 px-4 text-sm text-gray-900 text-center", children: record.total }), _jsx("td", { className: "py-3 px-4 text-sm text-green-600 text-center", children: record.success }), _jsx("td", { className: "py-3 px-4 text-sm text-red-600 text-center", children: record.failed }), _jsx("td", { className: "py-3 px-4 text-center", children: record.status === "completed" ? (_jsxs(Badge, { className: "bg-green-50 text-green-700 border-green-200 text-xs", children: [_jsx(CheckCircle, { className: "w-3 h-3 mr-1" }), "\u5B8C\u6210"] })) : (_jsxs(Badge, { className: "bg-amber-50 text-amber-700 border-amber-200 text-xs", children: [_jsx(AlertCircle, { className: "w-3 h-3 mr-1" }), "\u90E8\u5206\u6210\u529F"] })) })] }, record.id))) })] }) }) })] })] }));
}
