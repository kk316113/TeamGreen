import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { Search, Plus, Edit, Trash2, Lock, CheckCircle, XCircle, Download, } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Badge } from "../../components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, } from "../../components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, } from "../../components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, } from "../../components/ui/dialog";
import { Label } from "../../components/ui/label";
export function UserManagement() {
    const [searchTerm, setSearchTerm] = useState("");
    const [roleFilter, setRoleFilter] = useState("all");
    const [statusFilter, setStatusFilter] = useState("all");
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [editingUser, setEditingUser] = useState(null);
    const users = [
        {
            id: 1,
            username: "张老师",
            account: "teacher_zhang",
            role: "教师",
            email: "zhang@university.edu",
            status: "active",
            lastLogin: "2024-03-29 14:35",
            createdAt: "2023-09-01",
        },
        {
            id: 2,
            username: "王老师",
            account: "teacher_wang",
            role: "教师",
            email: "wang@university.edu",
            status: "active",
            lastLogin: "2024-03-29 13:20",
            createdAt: "2023-09-01",
        },
        {
            id: 3,
            username: "李同学",
            account: "student_li",
            role: "学生",
            email: "li@student.edu",
            status: "active",
            lastLogin: "2024-03-29 13:45",
            createdAt: "2023-09-15",
        },
        {
            id: 4,
            username: "陈同学",
            account: "student_chen",
            role: "学生",
            email: "chen@student.edu",
            status: "active",
            lastLogin: "2024-03-29 12:50",
            createdAt: "2023-09-15",
        },
        {
            id: 5,
            username: "刘老师",
            account: "teacher_liu",
            role: "教师",
            email: "liu@university.edu",
            status: "inactive",
            lastLogin: "2024-03-15 10:20",
            createdAt: "2023-09-01",
        },
        {
            id: 6,
            username: "赵管理员",
            account: "admin_zhao",
            role: "管理员",
            email: "zhao@admin.edu",
            status: "active",
            lastLogin: "2024-03-29 08:00",
            createdAt: "2023-08-01",
        },
        {
            id: 7,
            username: "孙同学",
            account: "student_sun",
            role: "学生",
            email: "sun@student.edu",
            status: "active",
            lastLogin: "2024-03-29 11:30",
            createdAt: "2023-09-15",
        },
        {
            id: 8,
            username: "周同学",
            account: "student_zhou",
            role: "学生",
            email: "zhou@student.edu",
            status: "inactive",
            lastLogin: "2024-03-10 15:40",
            createdAt: "2023-09-15",
        },
    ];
    const filteredUsers = users.filter((user) => {
        const matchesSearch = user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
            user.account.toLowerCase().includes(searchTerm.toLowerCase()) ||
            user.email.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesRole = roleFilter === "all" || user.role === roleFilter;
        const matchesStatus = statusFilter === "all" || user.status === statusFilter;
        return matchesSearch && matchesRole && matchesStatus;
    });
    const stats = {
        total: users.length,
        active: users.filter((u) => u.status === "active").length,
        teachers: users.filter((u) => u.role === "教师").length,
        students: users.filter((u) => u.role === "学生").length,
        admins: users.filter((u) => u.role === "管理员").length,
    };
    const handleEdit = (user) => {
        setEditingUser(user);
        setIsDialogOpen(true);
    };
    const handleAdd = () => {
        setEditingUser(null);
        setIsDialogOpen(true);
    };
    const getRoleBadgeColor = (role) => {
        switch (role) {
            case "管理员":
                return "bg-purple-100 text-purple-700 border-purple-200";
            case "教师":
                return "bg-blue-100 text-blue-700 border-blue-200";
            case "学生":
                return "bg-green-100 text-green-700 border-green-200";
            default:
                return "bg-gray-100 text-gray-700 border-gray-200";
        }
    };
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { children: [_jsx("h1", { className: "text-2xl text-gray-900 mb-1", children: "\u7528\u6237\u7BA1\u7406" }), _jsx("p", { className: "text-gray-600", children: "\u7BA1\u7406\u7CFB\u7EDF\u7528\u6237\u4FE1\u606F\u4E0E\u8D26\u53F7\u72B6\u6001" })] }), _jsxs("div", { className: "grid grid-cols-1 md:grid-cols-5 gap-4", children: [_jsx(Card, { className: "border-0 shadow-sm", children: _jsxs(CardContent, { className: "p-4", children: [_jsx("p", { className: "text-sm text-gray-600 mb-1", children: "\u7528\u6237\u603B\u6570" }), _jsx("p", { className: "text-2xl text-gray-900", children: stats.total })] }) }), _jsx(Card, { className: "border-0 shadow-sm", children: _jsxs(CardContent, { className: "p-4", children: [_jsx("p", { className: "text-sm text-gray-600 mb-1", children: "\u6D3B\u8DC3\u7528\u6237" }), _jsx("p", { className: "text-2xl text-green-600", children: stats.active })] }) }), _jsx(Card, { className: "border-0 shadow-sm", children: _jsxs(CardContent, { className: "p-4", children: [_jsx("p", { className: "text-sm text-gray-600 mb-1", children: "\u6559\u5E08" }), _jsx("p", { className: "text-2xl text-blue-600", children: stats.teachers })] }) }), _jsx(Card, { className: "border-0 shadow-sm", children: _jsxs(CardContent, { className: "p-4", children: [_jsx("p", { className: "text-sm text-gray-600 mb-1", children: "\u5B66\u751F" }), _jsx("p", { className: "text-2xl text-purple-600", children: stats.students })] }) }), _jsx(Card, { className: "border-0 shadow-sm", children: _jsxs(CardContent, { className: "p-4", children: [_jsx("p", { className: "text-sm text-gray-600 mb-1", children: "\u7BA1\u7406\u5458" }), _jsx("p", { className: "text-2xl text-orange-600", children: stats.admins })] }) })] }), _jsxs(Card, { className: "border-0 shadow-sm", children: [_jsx(CardHeader, { children: _jsxs("div", { className: "flex items-center justify-between", children: [_jsx(CardTitle, { children: "\u7528\u6237\u5217\u8868" }), _jsxs("div", { className: "flex items-center gap-3", children: [_jsxs(Button, { variant: "outline", size: "sm", children: [_jsx(Download, { className: "w-4 h-4 mr-2" }), "\u5BFC\u51FA"] }), _jsxs(Button, { onClick: handleAdd, size: "sm", className: "bg-blue-600 hover:bg-blue-700", children: [_jsx(Plus, { className: "w-4 h-4 mr-2" }), "\u6DFB\u52A0\u7528\u6237"] })] })] }) }), _jsxs(CardContent, { children: [_jsxs("div", { className: "flex flex-col md:flex-row gap-3 mb-6", children: [_jsxs("div", { className: "flex-1 relative", children: [_jsx(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" }), _jsx(Input, { placeholder: "\u641C\u7D22\u7528\u6237\u540D\u3001\u8D26\u53F7\u6216\u90AE\u7BB1...", value: searchTerm, onChange: (e) => setSearchTerm(e.target.value), className: "pl-10" })] }), _jsxs(Select, { value: roleFilter, onValueChange: setRoleFilter, children: [_jsx(SelectTrigger, { className: "w-full md:w-[160px]", children: _jsx(SelectValue, { placeholder: "\u89D2\u8272\u7B5B\u9009" }) }), _jsxs(SelectContent, { children: [_jsx(SelectItem, { value: "all", children: "\u5168\u90E8\u89D2\u8272" }), _jsx(SelectItem, { value: "\u7BA1\u7406\u5458", children: "\u7BA1\u7406\u5458" }), _jsx(SelectItem, { value: "\u6559\u5E08", children: "\u6559\u5E08" }), _jsx(SelectItem, { value: "\u5B66\u751F", children: "\u5B66\u751F" })] })] }), _jsxs(Select, { value: statusFilter, onValueChange: setStatusFilter, children: [_jsx(SelectTrigger, { className: "w-full md:w-[160px]", children: _jsx(SelectValue, { placeholder: "\u72B6\u6001\u7B5B\u9009" }) }), _jsxs(SelectContent, { children: [_jsx(SelectItem, { value: "all", children: "\u5168\u90E8\u72B6\u6001" }), _jsx(SelectItem, { value: "active", children: "\u6D3B\u8DC3" }), _jsx(SelectItem, { value: "inactive", children: "\u505C\u7528" })] })] })] }), _jsx("div", { className: "border rounded-lg overflow-hidden", children: _jsxs(Table, { children: [_jsx(TableHeader, { children: _jsxs(TableRow, { children: [_jsx(TableHead, { children: "\u7528\u6237\u540D" }), _jsx(TableHead, { children: "\u8D26\u53F7" }), _jsx(TableHead, { children: "\u90AE\u7BB1" }), _jsx(TableHead, { children: "\u89D2\u8272" }), _jsx(TableHead, { children: "\u72B6\u6001" }), _jsx(TableHead, { children: "\u6700\u8FD1\u767B\u5F55" }), _jsx(TableHead, { children: "\u64CD\u4F5C" })] }) }), _jsx(TableBody, { children: filteredUsers.map((user) => (_jsxs(TableRow, { children: [_jsx(TableCell, { className: "font-medium", children: user.username }), _jsx(TableCell, { children: user.account }), _jsx(TableCell, { className: "text-gray-600", children: user.email }), _jsx(TableCell, { children: _jsx(Badge, { variant: "outline", className: getRoleBadgeColor(user.role), children: user.role }) }), _jsx(TableCell, { children: user.status === "active" ? (_jsxs(Badge, { className: "bg-green-100 text-green-700 hover:bg-green-100", children: [_jsx(CheckCircle, { className: "w-3 h-3 mr-1" }), "\u6D3B\u8DC3"] })) : (_jsxs(Badge, { className: "bg-gray-100 text-gray-700 hover:bg-gray-100", children: [_jsx(XCircle, { className: "w-3 h-3 mr-1" }), "\u505C\u7528"] })) }), _jsx(TableCell, { className: "text-gray-600 text-sm", children: user.lastLogin }), _jsx(TableCell, { children: _jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Button, { variant: "ghost", size: "sm", onClick: () => handleEdit(user), children: _jsx(Edit, { className: "w-4 h-4" }) }), _jsx(Button, { variant: "ghost", size: "sm", children: _jsx(Lock, { className: "w-4 h-4" }) }), _jsx(Button, { variant: "ghost", size: "sm", className: "text-red-600", children: _jsx(Trash2, { className: "w-4 h-4" }) })] }) })] }, user.id))) })] }) }), _jsxs("div", { className: "flex items-center justify-between mt-4", children: [_jsxs("p", { className: "text-sm text-gray-600", children: ["\u663E\u793A ", filteredUsers.length, " \u6761\u7ED3\u679C\uFF0C\u5171 ", users.length, " \u6761"] }), _jsxs("div", { className: "flex gap-2", children: [_jsx(Button, { variant: "outline", size: "sm", disabled: true, children: "\u4E0A\u4E00\u9875" }), _jsx(Button, { variant: "outline", size: "sm", children: "\u4E0B\u4E00\u9875" })] })] })] })] }), _jsx(Dialog, { open: isDialogOpen, onOpenChange: setIsDialogOpen, children: _jsxs(DialogContent, { className: "max-w-md", children: [_jsxs(DialogHeader, { children: [_jsx(DialogTitle, { children: editingUser ? "编辑用户" : "添加用户" }), _jsx(DialogDescription, { children: editingUser
                                        ? "修改用户信息和权限设置"
                                        : "创建新用户并设置角色权限" })] }), _jsxs("div", { className: "space-y-4 py-4", children: [_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "username", children: "\u7528\u6237\u540D" }), _jsx(Input, { id: "username", defaultValue: editingUser?.username, placeholder: "\u8BF7\u8F93\u5165\u7528\u6237\u540D" })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "account", children: "\u8D26\u53F7" }), _jsx(Input, { id: "account", defaultValue: editingUser?.account, placeholder: "\u8BF7\u8F93\u5165\u767B\u5F55\u8D26\u53F7" })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "email", children: "\u90AE\u7BB1" }), _jsx(Input, { id: "email", type: "email", defaultValue: editingUser?.email, placeholder: "\u8BF7\u8F93\u5165\u90AE\u7BB1\u5730\u5740" })] }), _jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "role", children: "\u89D2\u8272" }), _jsxs(Select, { defaultValue: editingUser?.role || "学生", children: [_jsx(SelectTrigger, { children: _jsx(SelectValue, { placeholder: "\u9009\u62E9\u89D2\u8272" }) }), _jsxs(SelectContent, { children: [_jsx(SelectItem, { value: "\u7BA1\u7406\u5458", children: "\u7BA1\u7406\u5458" }), _jsx(SelectItem, { value: "\u6559\u5E08", children: "\u6559\u5E08" }), _jsx(SelectItem, { value: "\u5B66\u751F", children: "\u5B66\u751F" })] })] })] }), !editingUser && (_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: "password", children: "\u521D\u59CB\u5BC6\u7801" }), _jsx(Input, { id: "password", type: "password", placeholder: "\u8BF7\u8BBE\u7F6E\u521D\u59CB\u5BC6\u7801" })] }))] }), _jsxs(DialogFooter, { children: [_jsx(Button, { variant: "outline", onClick: () => setIsDialogOpen(false), children: "\u53D6\u6D88" }), _jsx(Button, { className: "bg-blue-600 hover:bg-blue-700", children: editingUser ? "保存" : "创建" })] })] }) })] }));
}
